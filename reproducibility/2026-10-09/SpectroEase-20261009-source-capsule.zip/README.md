# SpectroEase — A Visual Workflow for Spectral Data Analysis

## Local development update 2026-10-09

The preprocessing workspace now includes **Verified fitted workflow…**. This development entry accepts independently supplied Python candidates for fitted preprocessing, feature selection, classification, regression and scalar metrics. It verifies the declared reference fixtures, requires explicit acceptance of the exact configuration, and executes accepted operators on the application's verified raw training/test partition. Fitted JSON states can be saved and replayed. Editing a candidate requires verification again.

Candidates use `fit(X, y, params)` with `transform(X, state, params)` or `predict(X, state, params)`; metrics use `score(y_true, y_pred, params)`. This entry is separate from the older stateless `transform(X, params)` interface documented below. Candidate fixtures are limited to 128 rows; actual fitted execution permits larger matrices within the message budget. Candidate code runs in bounded child processes for reliability. Supply trusted code: this is not an operating-system sandbox for arbitrary untrusted programs.

This is a local source update. The existing public v1.0.0 executable does not automatically include these changes. Live LLM conversion, physical mixed-DPI display transitions and a new packaged executable remain separate verification tasks. The current correction checklist is `.harness/team/reports/S26_2026_10_09_逐项整改清单.md`.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE.txt)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue.svg)](https://www.python.org/)

**SpectroEase** is an open-source desktop application for spectral data analysis. It provides a visual workflow that covers data loading, partitioning, preprocessing, feature selection, modeling, hyper-parameter optimization, evaluation, and reporting, aimed at users who prefer a GUI for chemometric analysis.

---

<details>
<summary><strong>Table of Contents</strong> (click to expand)</summary>

1. [Key Features](#key-features)
2. [UI Overview](#ui-overview)
3. [System Architecture](#system-architecture)
4. [Algorithm Catalogue](#algorithm-catalogue)
5. [AI / LLM Capabilities and Limitations](#ai--llm-capabilities-and-limitations)
6. [System Requirements](#system-requirements)
7. [Dependencies](#dependencies)
8. [Installation & Quick Start](#installation--quick-start)
9. [Data Format](#data-format)
10. [Performance Notes](#performance-notes)
11. [Licence & Disclaimer](#licence--disclaimer)

</details>

---

## Key Features

- **Multi-format Data Import**: CSV, TXT, and Excel files with automated label recognition and basic data-quality handling.
- **Preprocessing**: spike removal, baseline correction, scatter correction, smoothing, derivatives, scaling, denoising, peak alignment, and outlier detection.
- **Feature Selection / Extraction**: PCA, PLSR, wavelet transform, peak detection, mutual information, variance threshold, correlation filter, Lasso selection, tree importance, ICA, and percentile selection.
- **Modeling**: qualitative (classification) and quantitative (regression) algorithms based on scikit-learn, XGBoost, and LightGBM.
- **Hyper-parameter Optimization**: the active modeling panel provides Grid Search, Random Search, and Bayesian (Optuna) search for eligible trained models, with fold-local imputation/scaling and explicit training/test identity checks.
- **Verified Algorithm Onboarding**: add stateless spectral preprocessing through an editable Python `transform(X, params)` function, typed parameters, trusted numerical fixtures, verification, explicit acceptance, and revalidated persistence.
- **Evaluation & Reporting**: classification and regression metrics, ROC curves, confusion matrices, residual analysis, and PDF report generation.
- **Visual Workflow**: top-to-bottom pipeline layout with parameter panels.

---

## UI Overview

| Main Window | Pipeline |
| :---------: | :------: |
| ![image](https://github.com/user-attachments/assets/b8639d31-b265-4200-8c27-c935ab65daed) | ![image](https://github.com/user-attachments/assets/0e819ef5-3819-43ba-987c-0b36abe8f739) |

---

## System Architecture

```text
SpectroEase/
├── main.py                 # Application entry point
├── plugin_loader.py        # Plugin discovery and registration
├── requirements.txt        # Python dependencies
├── app/                    # Main application
│   ├── controllers/        # MVC controllers
│   ├── models/             # Data and state models
│   ├── services/           # Business-logic services
│   ├── views/              # UI views and dialogs
│   ├── ui/                 # Theme, design tokens, and styling
│   └── utils/              # Application utilities
├── plugins/                # Algorithm plugins
│   ├── data_partitioning/  # Splitting algorithms
│   ├── feature_selection/  # Feature selection and extraction
│   ├── modeling/           # Classification and regression models
│   ├── preprocessing/      # Preprocessing algorithms
│   └── reporting/          # Report generation
├── interfaces/             # Plugin base classes
├── config/                 # Configuration files
├── examples/               # Example datasets
├── translations/           # Multi-language resources
└── utils/                  # Shared legacy utilities
```

---

## Algorithm Catalogue

### 1 · Data Partitioning

| Method | Source |
| ------ | ------ |
| Train–Test Split | `app/services/data_service.py` |
| K-Fold (stratified for classification) | `app/services/data_service.py` |
| Stratified Split | `plugins/data_partitioning/stratified_splitter.py` |
| Advanced Splitter (time-series / group-shuffle / blocked) | `plugins/data_partitioning/advanced_splitter.py` |

### 2 · Pre-processing

| Category | Algorithms |
| -------- | ---------- |
| **Spike Removal** | MAD (Median Absolute Deviation) · Local Z-score |
| **Baseline Correction** | Polynomial · ALS (Asymmetric Least Squares) · airPLS |
| **Scatter Correction** | SNV · MSC · EMSC · RNV · OSC |
| **Smoothing** | Savitzky–Golay · Moving Average · Median Filter · Gaussian · Wavelet |
| **Derivatives** | First Derivative · Second Derivative · Savitzky–Golay Derivative · Finite Difference · Gap-Segment |
| **Scaling & Normalization** | Standard Scale · Min–Max Scale · L2 Normalize · Vector · Area · Maximum |
| **Denoising** | Wavelet · FFT · Wiener · Non-local Means |
| **Peak Alignment** | DTW · COW · ICS · PAFFT · Simple correlation |
| **Outlier Detection** | Z-score · IQR · Isolation Forest · Local Outlier Factor |

### 3 · Feature Selection / Extraction

| Category | Methods |
| -------- | ------- |
| **Transform-based** | PCA · Wavelet Transform |
| **Regression-based** | PLSR (Partial Least Squares Regression) |
| **Spectroscopy-specific** | Peak Detection |

#### 3.1 Shipped but not currently wired

`plugins/feature_selection/advanced_feature_selector.py` ships Mutual Information, Variance Threshold, Correlation Filter, Lasso Selection, Tree Importance, ICA Selection, and Percentile Selection, but the active model-tab combo box only exposes PCA, PLSR, Peak Detection, and Wavelet (`app/views/main_window.py`). `FeatureSelectionView` is constructed for legacy registration and signal routing but is not mounted in the main layout.

### 4 · Modelling

#### 4.1 Classification (Qualitative)

LDA · QDA · SVM · Random Forest (RF) · K-Nearest Neighbors (KNN) · Decision Tree (DT) · Neural Network (MLP) · XGBoost · LightGBM · K-Means · Hierarchical Clustering

#### 4.2 Regression (Quantitative)

Multiple Linear Regression (MLR) · Partial Least Squares Regression (PLSR) · Support Vector Regression (SVR) · Random Forest (RF) · Decision Tree (DT) · Gaussian Process Regression (GPR) · Neural Network (MLP) · XGBoost · LightGBM

#### 4.3 Shipped but not currently wired

`plugins/modeling/advanced_modeling.py` ships additional modeling plugins, including Ensemble Voting, Bagging, AdaBoost, and Extra Trees. The active `start_analysis` workflow uses `QuantitativeAnalyzer` and `QualitativeAnalyzer` directly (`app/views/main_window.py`); presence in the plugin catalogue does not establish availability through that workflow.

### 5 · Hyper-parameter Optimization

**Active modeling panel:** Grid Search · Random Search · Bayesian (Optuna).

`MainWindow.optimize_current_model` dispatches these controls through `HyperparameterOptimizationController.apply_main_window_selection`. The modeling route records training data and the validation scope; optimization is enabled only after training an eligible model. Search fits imputation, scaling, and the estimator separately within each validation fold and checks identities against the outer test partition. A PCA/selected-feature matrix fitted before inner CV is rejected for this search; rerun on the unselected training partition. The one-click panel chooses a small supported parameter range, rather than exposing every estimator parameter.

Bayesian search uses Optuna's seeded TPE sampler when Optuna is installed; otherwise it logs a fallback to Grid Search. Genetic Algorithm remains a backend strategy, not a selection in the active main-window panel. See `app/services/hyperparameter_optimization_service.py` and `app/controllers/hyperparameter_optimization_controller.py`.

---

<a name="ai--llm-capabilities-and-limitations"></a>
## AI / LLM Capabilities and Limitations

The verified onboarding route is in the preprocessing panel: **Add / verify algorithm…**. A separate legacy LLM conversion dialog remains in the toolbar.

### Capabilities

- **Define a candidate** — supply the original standalone R source for provenance, editable Python `transform(X, params)`, a typed parameter schema, a numeric samples-by-channels matrix, the spectral axis/unit, and trusted input/output fixtures. Manual Python entry is available without an API key. R text is retained and hashed; the validator does not execute R.
- **Verify, then accept** — checks cover syntax/interface policy, parameter types, shape/finiteness, repeated-call consistency, numerical agreement with the supplied reference fixtures, and row independence. Missing reference evidence prevents acceptance. Editing Python after verification requires verification again. Explicit acceptance persists a versioned, hashed record and revalidates it in a fresh service instance before registration; startup/refresh revalidates accepted records again.
- **Use the registered operator** — accepted plugins appear in the verified preprocessing controls and dispatch through the preprocessing registry. The current contract supports stateless, per-spectrum operations preserving channel count/order. Stateful `fit/transform`, feature-selection, and modeling plugins are outside this onboarding route.
- **Optional LLM conversion** — with an API key configured, the onboarding dialog requests an R-to-Python draft in a worker thread. Generated code still passes the same verification and explicit acceptance gate. The service also supports a repair callback with at most three rounds; the dialog's verification does not automatically run an LLM repair benchmark.
- **Legacy conversion** — `LLMDialog` and `MainWindow.add_converted_algorithm` retain an experimental class-based conversion path. Some receiving views are not mounted in the active layout. This path does not establish the numerical/persistence evidence of verified onboarding.

Implementation: `app/views/algorithm_onboarding_dialog.py`, `app/services/algorithm_onboarding_service.py`, and `app/views/main_window.py`.

### Limitations and risks

- **Configured endpoint, not universal provider support** — `LLMConfig` defaults to DeepSeek; model and base URL are editable in the settings dialog. `LLMService` sends an OpenAI-compatible `/chat/completions` request. A provider name in the UI does not provide a native adapter for an incompatible API.
- **Evidence scope** — current onboarding evidence covers manual Python verification, controlled repair callbacks, persistence/reload, offscreen UI checks, and real-spectrum SNV dispatch. No live LLM conversion benchmark or R-runtime equivalence experiment was completed.
- **Execution scope** — AST/import/call checks and restricted builtins run in the application process. They provide neither an OS sandbox nor CPU/memory limits. Only submit trusted code; passing fixtures does not prove correctness for every input or recover unknown reference semantics.
- **Credentials and requests** — Windows configuration protects stored API keys with DPAPI; non-Windows storage falls back to plain text. Requests run in workers with timeouts, response-schema checks, and retry/backoff. Closing the onboarding worker's session is a cancellation attempt, not a guarantee that an in-flight HTTP operation stops immediately. See `app/utils/credential_store.py` and `app/services/llm_service.py`.

### October 2026 working-copy evidence

- [Dynamic workflow and stage gates](.harness/team/workflows/spectroease_2026_dynamic_workflow.yaml): implementation, independent review, and rework records. This is a tracked execution plan, not a background scheduler.
- [Frozen public-data analysis protocol](.harness/data/s26/S26_SENSAIFOOD_ANALYSIS_PROTOCOL.md) and [SensAIfood prediction results](.harness/team/evidence/s26/science/s26-61-sensaifood-prediction-results.md): six cereal-by-target analyses, 150 records per analysis, fixed three-component PLSR, five-fold out-of-fold predictions, and training-fold mean baselines. Record IDs establish record-level partitioning; physical replicate/instrument groups are unavailable. These are descriptive results without significance or external-domain claims.
- [Real-spectrum onboarding smoke](.harness/team/evidence/s26/integration/s26-45-real-spectra-onboarding-smoke.md): verified SNV acceptance/reload and dispatch on public spectra. This checks integration/parity, not a gain in predictive accuracy.
- [Evaluation/report isolation review](.harness/team/evidence/s26/plots/s26-22-independent-review.md): 31 targeted tests; the core prediction/data-flow suite was rerun with 116 passing tests. Responsive GUI evidence uses offscreen Qt checks, not physical mixed-DPI monitor testing. Plot exports support explicit physical dimensions and PDF/SVG/PNG/TIFF profiles; remaining GUI/route limits stay visible in the workflow.

This working copy is unreleased. The repository's dependency pins were not validated by a fresh installation; the analysis run manifest records the runtime actually used.


---

## System Requirements

| Component | Specification |
| --------- | ------------- |
| **OS** | Windows 10 / 11 (64-bit) |
| **Python** | >= 3.11 (current verification: 3.12.10) |
| **RAM** | >= 4 GB (recommended 8 GB +) |
| **Disk** | >= 2 GB free (recommended 5 GB +) |
| **GPU** | Not required; current release is CPU-only |

---

## Dependencies

The original application was developed with **Python 3.11.9**; the 2026-10-09 source and pinned dependencies were verified with **Python 3.12.10 on Windows**. The table below is a curated subset of the direct dependencies; the authoritative list is `requirements.txt`.

| Library | Version tested | Purpose |
| ------- | -------------- | ------- |
| PyQt5 | 5.15.7 | Graphical user interface |
| NumPy | 2.3.3 | Numerical computing |
| pandas | 2.3.3 | Data manipulation |
| SciPy | 1.16.2 | Scientific algorithms |
| scikit-learn | 1.7.2 | Machine-learning workflows |
| Matplotlib | 3.10.7 | Visualisation |
| seaborn | 0.13.2 | Statistical visualization |
| pyqtgraph | 0.13.7 | Interactive plotting |
| reportlab | 4.4.4 | PDF / report generation |
| openpyxl | 3.1.5 | Excel file writing |
| xlrd | 2.0.2 | Excel file reading |
| PyWavelets | 1.9.0 | Wavelet transforms |
| deap | 1.4.3 | Genetic algorithms |
| xgboost | 3.0.5 | Gradient boosting |
| lightgbm | 4.6.0 | Gradient boosting |
| onnx | 1.19.1 | Model serialization |
| onnxruntime | 1.23.1 | ONNX inference |
| skl2onnx | 1.19.1 | scikit-learn to ONNX conversion |
| requests | 2.32.5 | HTTP client |
| Pillow | 11.3.0 | Image processing |
| joblib | 1.5.2 | Parallel computing |
| threadpoolctl | 3.6.0 | Thread pool control |
| psutil | 7.1.0 | System / process utilities |
| sympy | 1.14.0 | Symbolic mathematics |
| coloredlogs | 15.0.1 | Coloured logging output |
| humanfriendly | 10.0 | Human-readable logging output |
| protobuf | 6.32.1 | Protocol Buffers serialization |
| flatbuffers | 25.9.23 | FlatBuffers serialization |
| ml_dtypes | 0.5.3 | Numeric types for machine learning |
| PyInstaller | 6.16.0 | Executable packaging |
| altgraph | 0.17.4 | Packaging dependency graph |
| pefile | 2023.2.7 | Windows executable inspection |
| pyinstaller-hooks-contrib | 2025.9 | PyInstaller hooks |
| pyreadline3 | 3.5.4 | Windows readline support |
| pywin32-ctypes | 0.2.3 | Windows ctypes wrappers |

Other packages pinned in `requirements.txt` (for example `certifi`, `charset-normalizer`, `contourpy`, `cycler`, `et-xmlfile`, `fonttools`, `idna`, `kiwisolver`, `mpmath`, `packaging`, `pyparsing`, `python-dateutil`, `pytz`, `PyQt5-Qt5`, `PyQt5_sip`, `six`, `typing_extensions`, `tzdata`, and `urllib3`) are also direct dependencies.

---

## Installation & Quick Start

### Option 1: For General Users

Two pre-built packages are available.

#### A. Standalone Executable
Download `SpectroEase.exe` from **[Google Drive](https://drive.google.com/file/d/1BvLx0z0h46n3n_obOIHizyThG2UIJ_rh/view?usp=drive_link)**. This is a single file that can be run directly.

#### B. Folder Version
Download `SpectroEase_folder.zip` from the **[GitHub Releases](https://github.com/shudayi/SpectroEase-V1.0/releases/tag/v1.0.0)** page, unzip it, and run `SpectroEase_folder.exe`.

### Option 2: For Developers (from Source)

```powershell
git clone https://github.com/shudayi/SpectroEase-V1.0
cd SpectroEase-V1.0
pip install -r requirements.txt
python main.py
```

### Typical Workflow

1. **Import / Partition** → 2. **Pre-process** → 3. **Select Features**
4. **Model / Tune** → 5. **Evaluate** → 6. **Export Report**

---

## Data Format

| Aspect | Details |
| ------ | ------- |
| **Supported files** | CSV · TXT · Excel |
| **Recommended layout** | Row-wise: `Sample_ID, Label, 400 nm, 402 nm, …` |
| **Label keywords** | `category` · `class` · `label` · `variety` · `target` |
| **Demo dataset** | `examples/` (CC-BY-4.0) |

![image](https://github.com/user-attachments/assets/de2a0556-5729-48fc-b10f-c6efb85da488)

---

## Performance Notes

- Long-running tasks (preprocessing, report generation, feature selection, modeling, evaluation) are executed off the UI thread through `Worker` / `FuncWorker` (`app/utils/worker.py`).
- Several scikit-learn, XGBoost, and LightGBM estimators use `n_jobs=-1` to utilize multiple CPU cores.
- Intermediate state is cached in the MVC models (`DataModel`, `PreprocessingModel`, `FeatureSelectionModel`, `ModelingModel`) to avoid redundant recomputation within a session.

---

## Licence & Disclaimer

- **Code** — MIT Licence (see `LICENSE.txt`)
- **Sample data** — CC-BY-4.0
- **Disclaimer** — This software is provided **for research and educational purposes only**. The authors accept no liability for commercial use or any losses arising from model mis-predictions. Users must comply with local laws and regulations.

---

<hr>

# SpectroEase：光谱数据分析可视化工作流软件

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE.txt)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue.svg)](https://www.python.org/)

**SpectroEase** 是一款用于光谱数据分析的开源桌面应用程序。它提供覆盖数据载入、划分、预处理、特征选择、建模、超参数优化、评估与报告的可视化工作流，面向偏好图形界面进行化学计量分析的用户。

---

<details>
<summary><strong>目录</strong>（点击展开）</summary>

1. [关键特性](#关键特性)
2. [界面概览](#界面概览)
3. [系统架构](#系统架构)
4. [完整算法清单](#完整算法清单)
5. [AI / LLM 能力与限制](#ai--llm-能力与限制)
6. [系统需求](#系统需求)
7. [依赖库](#依赖库)
8. [安装与快速上手](#安装与快速上手)
9. [数据格式说明](#数据格式说明)
10. [性能说明](#性能说明)
11. [许可证与免责声明](#许可证与免责声明)

</details>

---

## 关键特性

- **多格式导入**：支持 CSV、TXT、Excel，自动识别标签列并进行基础数据质量处理。
- **预处理**：去峰、基线校正、散射校正、平滑、导数、缩放/归一化、去噪、峰对齐、异常值检测。
- **特征选择 / 提取**：PCA、PLSR、小波变换、寻峰、互信息、方差阈值、相关滤波、Lasso 选择、树重要性、ICA、百分位选择。
- **建模**：基于 scikit-learn、XGBoost 与 LightGBM 的定性（分类）与定量（回归）算法。
- **超参数优化**：当前建模面板已连接网格搜索、随机搜索和 Bayesian（Optuna）搜索；仅对符合条件的已训练模型开放，并在验证折内拟合填补、缩放与模型，检查训练/测试身份边界。
- **验证驱动的算法接入**：以可编辑的 Python `transform(X, params)` 函数、类型化参数和可信数值示例接入无状态光谱预处理，包含验证、明确接受及保存后的重新验证。
- **评估与报告**：分类/回归指标、ROC 曲线、混淆矩阵、残差分析及 PDF 报告生成。
- **可视化工作流**：自上而下流水线布局与参数面板。

---

## 界面概览

| 主界面 | 流程图 |
| :----: | :----: |
| ![image](https://github.com/user-attachments/assets/b8639d31-b265-4200-8c27-c935ab65daed) | ![image](https://github.com/user-attachments/assets/0e819ef5-3819-43ba-987c-0b36abe8f739) |

---

## 系统架构

```text
SpectroEase/
├── main.py                 # 应用程序入口
├── plugin_loader.py        # 插件发现与注册
├── requirements.txt        # Python 依赖
├── app/                    # 主应用程序
│   ├── controllers/        # MVC 控制器
│   ├── models/             # 数据与状态模型
│   ├── services/           # 业务逻辑服务
│   ├── views/              # 界面视图与对话框
│   ├── ui/                 # 主题、设计令牌与样式
│   └── utils/              # 应用工具模块
├── plugins/                # 算法插件
│   ├── data_partitioning/  # 数据划分算法
│   ├── feature_selection/  # 特征选择与提取
│   ├── modeling/           # 分类与回归模型
│   ├── preprocessing/      # 预处理算法
│   └── reporting/          # 报告生成
├── interfaces/             # 插件基类
├── config/                 # 配置文件
├── examples/               # 示例数据集
├── translations/           # 多语言资源
└── utils/                  # 共享遗留工具模块
```

---

## 完整算法清单

### 1 · 数据划分

| 方法 | 来源 |
| ---- | ---- |
| 训练–测试集划分 | `app/services/data_service.py` |
| K 折交叉验证（分类任务使用分层折叠） | `app/services/data_service.py` |
| 分层划分 | `plugins/data_partitioning/stratified_splitter.py` |
| 高级划分（时序 / 分组随机 / 阻塞） | `plugins/data_partitioning/advanced_splitter.py` |

### 2 · 预处理

| 分类 | 算法 |
| ---- | ---- |
| **去峰处理** | MAD（中值绝对偏差）· 局部 Z-score |
| **基线校正** | Polynomial（多项式）· ALS（非对称最小二乘）· airPLS |
| **散射校正** | SNV · MSC · EMSC · RNV · OSC |
| **平滑处理** | Savitzky–Golay · Moving Average · Median Filter · Gaussian · Wavelet |
| **导数** | 一阶导数 · 二阶导数 · Savitzky–Golay 导数 · 有限差分 · Gap-Segment |
| **缩放与归一化** | Standard Scale · Min–Max Scale · L2 Normalize · Vector · Area · Maximum |
| **去噪** | 小波 · FFT · Wiener · 非局部均值 |
| **峰对齐** | DTW · COW · ICS · PAFFT · 简单相关对齐 |
| **异常值检测** | Z-score · IQR · Isolation Forest · Local Outlier Factor |

### 3 · 特征选择 / 提取

| 分类 | 方法 |
| ---- | ---- |
| **变换方法** | PCA · 小波变换 |
| **回归方法** | PLSR（偏最小二乘回归） |
| **光谱专用** | 寻峰 |

#### 3.1 已包含但未接入当前工作流

`plugins/feature_selection/advanced_feature_selector.py` 中已提供互信息、方差阈值、相关滤波、Lasso 选择、树重要性、ICA 选择与百分位选择，但当前激活的模型标签页组合框仅暴露 PCA、PLSR、寻峰与小波变换（`app/views/main_window.py`）。`FeatureSelectionView` 为旧注册流程和信号路由构造，未挂载到主布局。

### 4 · 建模

#### 4.1 定性分析（分类）

LDA · QDA · SVM · 随机森林（RF）· K-近邻（KNN）· 决策树（DT）· 神经网络（MLP）· XGBoost · LightGBM · K-Means · 层次聚类

#### 4.2 定量分析（回归）

多元线性回归（MLR）· 偏最小二乘回归（PLSR）· 支持向量回归（SVR）· 随机森林（RF）· 决策树（DT）· 高斯过程回归（GPR）· 神经网络（MLP）· XGBoost · LightGBM

#### 4.3 已包含但未接入当前工作流

`plugins/modeling/advanced_modeling.py` 中包含集成投票、Bagging、AdaBoost 和 Extra Trees 等额外插件。当前激活的 `start_analysis` 工作流直接使用 `QuantitativeAnalyzer` 与 `QualitativeAnalyzer`（`app/views/main_window.py`）；插件目录中存在代码不代表已通过该流程开放。

### 5 · 超参数优化

**当前建模面板：** 网格搜索 · 随机搜索 · Bayesian（Optuna）。

`MainWindow.optimize_current_model` 经 `HyperparameterOptimizationController.apply_main_window_selection` 分发界面选项。建模时保存训练矩阵和验证范围；仅在模型已训练且范围符合条件时启用优化。每一验证折单独拟合填补、缩放及模型，并检查与外层测试集的身份交叠。内层交叉验证前已拟合的 PCA/筛选矩阵禁止进入该搜索，应在未筛选的训练分区重新分析。单击优化使用一个受支持的小参数范围，不提供所有模型参数的完整搜索界面。

安装 Optuna 时，Bayesian 搜索使用固定种子的 TPE 采样器；未安装时记录日志并回退到网格搜索。遗传算法保留为后端策略，当前主窗口未提供该选项。实现见 `app/services/hyperparameter_optimization_service.py` 和 `app/controllers/hyperparameter_optimization_controller.py`。

---

<a name="ai--llm-能力与限制"></a>
## AI / LLM 能力与限制

预处理面板的 **Add / verify algorithm…** 为当前验证接入入口。主工具栏仍保留独立的旧版 LLM 转换对话框。

### 能力

- **定义候选算法** — 提供独立 R 函数原文作为来源记录、可编辑的 Python `transform(X, params)`、类型化参数、样本×通道的数值矩阵、光谱轴及单位、可信输入/输出示例。无 API 密钥时也可手工输入 Python。R 原文保存并计算哈希，验证器不执行 R。
- **验证后明确接受** — 检查语法与接口策略、参数类型、形状/有限值、重复调用一致性、与参考示例的数值一致性及逐样本独立性。缺少可信参考证据不能接受；验证后修改 Python 需重新验证。接受后保存带版本和哈希的记录，并在新的服务实例重新验证后注册；启动/刷新时再次验证已接受记录。
- **使用注册算子** — 通过验证的插件出现在专用预处理控件中，经预处理注册表调用。当前只接入保留通道数量/顺序的无状态逐光谱操作；带拟合状态的 `fit/transform`、特征选择及建模插件不在此接入范围内。
- **可选 LLM 转换** — 配置 API 密钥后，可在工作线程请求 R→Python 草稿。生成代码仍需相同验证和明确接受。服务支持最多三轮修复回调；对话框的验证操作不自动执行 LLM 修复对照实验。
- **旧版转换** — `LLMDialog` 与 `MainWindow.add_converted_algorithm` 保留实验性的类接口转换流程；部分接收视图未挂载到当前布局。此路径不具备验证接入流程的数值和保存恢复证据。

实现见 `app/views/algorithm_onboarding_dialog.py`、`app/services/algorithm_onboarding_service.py` 和 `app/views/main_window.py`。

### 限制与风险

- **可配置端点，不等同于通用 Provider 支持** — `LLMConfig` 默认 DeepSeek，设置对话框可修改模型和基础 URL。`LLMService` 使用 OpenAI 兼容的 `/chat/completions` 请求；界面显示某 Provider 名称，不代表已有适配其不兼容 API 的原生实现。
- **现有证据范围** — 覆盖手工 Python 验证、受控修复回调、保存/重新载入、offscreen 界面检查及真实光谱 SNV 调用；尚未完成实时 LLM 转换对照或 R 运行时等价性实验。
- **执行范围** — AST/导入/调用检查和受限 builtins 在应用进程内执行，没有操作系统隔离或 CPU/内存限额。仅提交可信代码；示例通过不证明所有输入均正确，也不能恢复未知的参考语义。
- **凭据与请求** — Windows 使用 DPAPI 保护保存的 API 密钥；其他系统回退到明文。请求在工作线程运行，具有超时、返回模式检查及重试退避。关闭接入工作线程的 Session 属于取消尝试，不保证在途 HTTP 操作立即结束。见 `app/utils/credential_store.py` 和 `app/services/llm_service.py`。

### 2026 年 10 月工作副本证据

- [动态工作流与阶段验收](.harness/team/workflows/spectroease_2026_dynamic_workflow.yaml)：记录实现、独立审查和返工；这是执行计划记录，不是后台调度程序。
- [冻结的公开数据分析协议](.harness/data/s26/S26_SENSAIFOOD_ANALYSIS_PROTOCOL.md)与 [SensAIfood 预测结果](.harness/team/evidence/s26/science/s26-61-sensaifood-prediction-results.md)：六组“谷物×目标”分析，每组 150 条记录，固定三成分 PLSR、五折折外预测及训练折均值基线。记录 ID 只支持记录级划分，缺少物理重复样本/仪器分组。结果为描述性结果，不作显著性或跨域泛化结论。
- [真实光谱接入检查](.harness/team/evidence/s26/integration/s26-45-real-spectra-onboarding-smoke.md)：验证 SNV 接受、重新载入及公开光谱调用；检验接入和数值一致性，不代表预测精度提升。
- [评估与报告绘图隔离审查](.harness/team/evidence/s26/plots/s26-22-independent-review.md)：31 项定向测试；核心预测/数据流测试重新运行，116 项通过。响应式 GUI 证据来自 offscreen Qt 检查，未完成真实混合 DPI 显示器测试。绘图导出支持明确物理尺寸与 PDF/SVG/PNG/TIFF 配置，其余 GUI/路由限制保留在工作流中。

本工作副本尚未发布。未通过全新安装验证仓库原有依赖锁定版本；分析记录包含实际使用的运行环境。


---

## 系统需求

| 项目 | 规格 |
| ---- | ---- |
| **操作系统** | Windows 10 / 11（64-bit） |
| **Python** | >= 3.8（推荐 3.11） |
| **内存** | >= 4 GB（推荐 8 GB 以上） |
| **磁盘空间** | >= 2 GB（推荐 5 GB 以上） |
| **GPU** | 无硬性要求；当前版本仅使用 CPU |

---

## 依赖库

本平台基于 **Python 3.11.9** 开发。下表为 `requirements.txt` 中直接依赖的精选子集；完整权威列表请参见 `requirements.txt`。

| 库 | 测试版本 | 用途 |
| -- | -------- | ---- |
| PyQt5 | 5.15.7 | 图形用户界面 |
| NumPy | 2.3.3 | 数值计算 |
| pandas | 2.3.3 | 数据处理 |
| SciPy | 1.16.2 | 科学计算 |
| scikit-learn | 1.7.2 | 机器学习工作流 |
| Matplotlib | 3.10.7 | 可视化 |
| seaborn | 0.13.2 | 统计可视化 |
| pyqtgraph | 0.13.7 | 交互式绘图 |
| reportlab | 4.4.4 | PDF / 报告生成 |
| openpyxl | 3.1.5 | Excel 写入 |
| xlrd | 2.0.2 | Excel 读取 |
| PyWavelets | 1.9.0 | 小波变换 |
| deap | 1.4.3 | 遗传算法 |
| xgboost | 3.0.5 | 梯度提升 |
| lightgbm | 4.6.0 | 梯度提升 |
| onnx | 1.19.1 | 模型序列化 |
| onnxruntime | 1.23.1 | ONNX 推理 |
| skl2onnx | 1.19.1 | scikit-learn 转 ONNX |
| requests | 2.32.5 | HTTP 客户端 |
| Pillow | 11.3.0 | 图像处理 |
| joblib | 1.5.2 | 并行计算 |
| threadpoolctl | 3.6.0 | 线程池控制 |
| psutil | 7.1.0 | 系统/进程工具 |
| sympy | 1.14.0 | 符号数学 |
| coloredlogs | 15.0.1 | 彩色日志输出 |
| humanfriendly | 10.0 | 易读日志输出 |
| protobuf | 6.32.1 | Protocol Buffers 序列化 |
| flatbuffers | 25.9.23 | FlatBuffers 序列化 |
| ml_dtypes | 0.5.3 | 机器学习数值类型 |
| PyInstaller | 6.16.0 | 可执行文件打包 |
| altgraph | 0.17.4 | 打包依赖图 |
| pefile | 2023.2.7 | Windows 可执行文件检查 |
| pyinstaller-hooks-contrib | 2025.9 | PyInstaller 钩子 |
| pyreadline3 | 3.5.4 | Windows readline 支持 |
| pywin32-ctypes | 0.2.3 | Windows ctypes 包装 |

`requirements.txt` 中另外固定的包（例如 `certifi`、`charset-normalizer`、`contourpy`、`cycler`、`et-xmlfile`、`fonttools`、`idna`、`kiwisolver`、`mpmath`、`packaging`、`pyparsing`、`python-dateutil`、`pytz`、`PyQt5-Qt5`、`PyQt5_sip`、`six`、`typing_extensions`、`tzdata`、`urllib3`）同样为直接依赖。

---

## 安装与快速上手

### 方式一：普通用户

#### 选项 A：单文件版
从 **[Google Drive 备份](https://drive.google.com/file/d/1BvLx0z0h46n3n_obOIHizyThG2UIJ_rh/view?usp=drive_link)** 下载 `SpectroEase.exe`，直接运行。

#### 选项 B：文件夹版
从 **[GitHub Release](https://github.com/shudayi/SpectroEase-V1.0/releases/tag/v1.0.0)** 下载 `SpectroEase_folder.zip`，解压后运行其中的 `SpectroEase_folder.exe`。

### 方式二：开发者（源码运行）

```powershell
git clone https://github.com/shudayi/SpectroEase-V1.0
cd SpectroEase-V1.0
pip install -r requirements.txt
python main.py
```

### 基础工作流

1. **导入数据 / 划分** → 2. **预处理** → 3. **特征选择**
4. **建模 / 超参优化** → 5. **评估** → 6. **导出报告**

---

## 数据格式说明

| 维度 | 说明 |
| ---- | ---- |
| **支持格式** | CSV · TXT · Excel |
| **推荐布局** | 行式：`Sample_ID, Label, 400nm, 402nm, …` |
| **标签关键字** | `category` · `class` · `label` · `variety` · `target` |
| **示例数据集** | `examples/`（CC-BY-4.0） |

![image](https://github.com/user-attachments/assets/de2a0556-5729-48fc-b10f-c6efb85da488)

---

## 性能说明

- 耗时操作（预处理、报告生成、特征选择、建模、评估）通过 `Worker` / `FuncWorker`（`app/utils/worker.py`）在 UI 线程外执行。
- 部分 scikit-learn、XGBoost 与 LightGBM 估算器使用 `n_jobs=-1` 以利用多核 CPU。
- 中间状态缓存在 MVC 模型（`DataModel`、`PreprocessingModel`、`FeatureSelectionModel`、`ModelingModel`）中，避免同一会话内重复计算。

---

## 许可证与免责声明

- **代码**：MIT License（见 `LICENSE.txt`）
- **示例数据**：CC-BY-4.0
- **免责声明**：本软件仅供科研与教学使用。作者不对商业用途或模型误判造成的任何损失负责；使用者需遵守当地法律法规。

---
