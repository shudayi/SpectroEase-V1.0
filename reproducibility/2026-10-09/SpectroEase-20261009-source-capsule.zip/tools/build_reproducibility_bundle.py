"""Build a local source capsule without credentials, runtimes or raw archives."""
from pathlib import Path
import hashlib
import json
import re
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '.harness/team/evidence/s26/full_workflow_1009/reproducibility'
TOKEN = re.compile(r'sk-[A-Za-z0-9_-]{24,}')


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    paths = []
    for name in ['app', 'plugins', 'interfaces', 'utils', 'translations', 'tests', 'tools']:
        paths.extend(p for p in (ROOT/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts
                     and p.suffix.lower() in {'.py', '.json', '.ui', '.qss', '.svg', '.png', '.ico', '.csv', '.txt', '.yaml'})
    paths.extend((ROOT/'config').glob('*.py'))
    paths.extend(ROOT/p for p in ['main.py', 'plugin_loader.py', 'requirements.txt', 'README.md', 'LICENSE.txt', 'logo.png', 'main.spec', 'SpectroEase_exe.spec', 'SpectroEase_folder.spec'])
    data = ROOT/'.harness/data/s26/full_workflow_1009'
    paths.extend(data.glob('*.py'))
    paths.extend(data.glob('*.yaml'))
    paths.extend(data.glob('*.md'))
    paths.extend(data.glob('*manifest.json'))
    paths.extend(ROOT/p for p in ['.harness/data/s26/run_sensaifood_s26_61.py',
                                  '.harness/data/s26/S26_SENSAIFOOD_ANALYSIS_PROTOCOL.md',
                                  '.harness/team/workflows/spectroease_2026_dynamic_workflow.yaml',
                                  '.harness/team/workflows/spectroease_2026_10_09_full_workflow.yaml'])
    for directory in ['baseline-results-v2', 'paired-study', 'paired-study-final', 'paired-study-current-source', 'optuna-functional-evidence']:
        paths.extend(p for p in (data/directory).rglob('*') if p.is_file() and p.suffix in {'.py', '.csv', '.json', '.md'}
                     and '__pycache__' not in p.parts)
    evidence = ROOT/'.harness/team/evidence/s26/full_workflow_1009'
    paths.extend(evidence/name for name in [
        'independent_baseline_arithmetic_review.py',
        'independent_current_source_paired_model_review.py',
        'independent_paired_model_review.py',
    ])
    paths.extend(p for p in (ROOT/'examples').glob('*.csv') if p.is_file())
    manifest = {'kind': 'local source capsule, not a public release or packaged executable',
                'raw_datasets': 'Excluded. Acquire primary archives with fetch scripts and verify published/preserved hashes.',
                'credentials': 'Private config/settings JSON excluded; literal sk- tokens redacted in copies only.', 'files': {}}
    target = OUT/'SpectroEase-20261009-source-capsule.zip'
    with ZipFile(target, 'w', ZIP_DEFLATED) as z:
        for path in sorted(set(paths)):
            if not path.exists():
                continue
            relative = path.relative_to(ROOT).as_posix()
            raw = path.read_bytes()
            packaged = raw
            if path.suffix.lower() in {'.py', '.json', '.md', '.yaml', '.txt', '.spec'}:
                try:
                    text = raw.decode('utf-8')
                except UnicodeDecodeError:
                    text = raw.decode('utf-16')
                packaged = TOKEN.sub('REMOVED_PRIVATE_CREDENTIAL', text).encode('utf-8')
            z.writestr(relative, packaged)
            manifest['files'][relative] = {'source_sha256': hashlib.sha256(raw).hexdigest(),
                                          'packaged_sha256': hashlib.sha256(packaged).hexdigest(),
                                          'copy_changed': raw != packaged}
        example = ROOT/'config/config.json.example'
        z.writestr('config/config.json', example.read_bytes())
        z.writestr('CAPSULE_MANIFEST.json', json.dumps(manifest, indent=2, ensure_ascii=False))
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    (OUT/'capsule-manifest.json').write_text(json.dumps({'zip': target.name, 'sha256': digest,
                                                       'bytes': target.stat().st_size, **manifest}, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps({'zip': str(target), 'sha256': digest, 'files': len(manifest['files'])}))


if __name__ == '__main__':
    main()
