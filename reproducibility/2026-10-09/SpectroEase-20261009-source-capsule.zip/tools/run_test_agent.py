"""CLI entry point for the SpectroEase test/proofread agent.

Usage:
    python tools/run_test_agent.py --scope all
    python tools/run_test_agent.py --scope existing_tests --python ./.venv311/Scripts/python.exe
"""
from __future__ import annotations

import os
import sys

# Make the project importable when this script is run directly without
# `python -m`.
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from app.tools.test_agent.runner import main


if __name__ == "__main__":
    sys.exit(main())