# config/settings.py
import json
import os


# Default value constants: kept here so other modules can reference them without
# instantiating Settings. New fields must be added in three places:
#   1. Defaults declared below (or as class-level constants).
#   2. Settings.__init__ to set the field on the instance.
#   3. load_settings/save_settings to read/write the JSON key.
DEFAULT_RANDOM_STATE = 42
DEFAULT_CATEGORICAL_UNIQUE_RATIO_MAX = 0.5
DEFAULT_CATEGORICAL_UNIQUE_COUNT_MAX = 50
DEFAULT_ZSCORE_THRESHOLD = 3.0
DEFAULT_IQR_COEFFICIENT = 1.5
DEFAULT_ISOLATIONFOREST_CONTAMINATION = 0.1
DEFAULT_PREFERRED_X_UNIT = 'nm'
DEFAULT_PREFERRED_Y_UNIT = 'absorbance'
DEFAULT_CLASSIFICATION_METRICS = [
    'accuracy', 'precision', 'recall',
    'f1_macro', 'f1_weighted', 'roc_auc', 'confusion_matrix',
]
DEFAULT_REGRESSION_METRICS = ['rmse', 'mae', 'r2', 'mape', 'rpd']

EVALUATION_SCHEMA_VERSION = 1


class Settings:
    """Persistent application settings.

    Loads and saves ``config/settings.json``. Unknown / missing keys fall back
    to declared defaults so older config files continue to work.
    """

    def __init__(self):
        self.settings_file = 'config/settings.json'

        # Original fields
        self.theme = 'light'
        self.language = 'en'
        self.numeric_conversion_threshold = 0.7
        self.missing_rate_warning_threshold = 0.3

        # S1 / C5: extended thresholds and defaults
        self.random_state = DEFAULT_RANDOM_STATE
        self.categorical_unique_ratio_max = DEFAULT_CATEGORICAL_UNIQUE_RATIO_MAX
        self.categorical_unique_count_max = DEFAULT_CATEGORICAL_UNIQUE_COUNT_MAX
        self.zscore_threshold = DEFAULT_ZSCORE_THRESHOLD
        self.iqr_coefficient = DEFAULT_IQR_COEFFICIENT
        self.isolationforest_contamination = DEFAULT_ISOLATIONFOREST_CONTAMINATION
        self.preferred_x_unit = DEFAULT_PREFERRED_X_UNIT
        self.preferred_y_unit = DEFAULT_PREFERRED_Y_UNIT
        self.default_classification_metrics = list(DEFAULT_CLASSIFICATION_METRICS)
        self.default_regression_metrics = list(DEFAULT_REGRESSION_METRICS)
        self.evaluation_schema_version = EVALUATION_SCHEMA_VERSION

        self.load_settings()

    def load_settings(self):
        if not os.path.exists(self.settings_file):
            return
        try:
            with open(self.settings_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            return

        self.theme = data.get('theme', self.theme)
        self.language = data.get('language', self.language)
        self.numeric_conversion_threshold = data.get(
            'numeric_conversion_threshold', self.numeric_conversion_threshold,
        )
        self.missing_rate_warning_threshold = data.get(
            'missing_rate_warning_threshold', self.missing_rate_warning_threshold,
        )

        # New fields: each uses known default declared at module level.
        self.random_state = int(data.get('random_state', self.random_state))
        self.categorical_unique_ratio_max = float(
            data.get('categorical_unique_ratio_max', self.categorical_unique_ratio_max)
        )
        self.categorical_unique_count_max = int(
            data.get('categorical_unique_count_max', self.categorical_unique_count_max)
        )
        self.zscore_threshold = float(
            data.get('zscore_threshold', self.zscore_threshold)
        )
        self.iqr_coefficient = float(
            data.get('iqr_coefficient', self.iqr_coefficient)
        )
        self.isolationforest_contamination = float(
            data.get('isolationforest_contamination', self.isolationforest_contamination)
        )
        self.preferred_x_unit = data.get('preferred_x_unit', self.preferred_x_unit)
        self.preferred_y_unit = data.get('preferred_y_unit', self.preferred_y_unit)

        cls_metrics = data.get('default_classification_metrics')
        if isinstance(cls_metrics, list) and cls_metrics:
            self.default_classification_metrics = cls_metrics
        reg_metrics = data.get('default_regression_metrics')
        if isinstance(reg_metrics, list) and reg_metrics:
            self.default_regression_metrics = reg_metrics

    def save_settings(self):
        data = {
            'theme': self.theme,
            'language': self.language,
            'numeric_conversion_threshold': self.numeric_conversion_threshold,
            'missing_rate_warning_threshold': self.missing_rate_warning_threshold,
            'random_state': self.random_state,
            'categorical_unique_ratio_max': self.categorical_unique_ratio_max,
            'categorical_unique_count_max': self.categorical_unique_count_max,
            'zscore_threshold': self.zscore_threshold,
            'iqr_coefficient': self.iqr_coefficient,
            'isolationforest_contamination': self.isolationforest_contamination,
            'preferred_x_unit': self.preferred_x_unit,
            'preferred_y_unit': self.preferred_y_unit,
            'default_classification_metrics': self.default_classification_metrics,
            'default_regression_metrics': self.default_regression_metrics,
            'evaluation_schema_version': self.evaluation_schema_version,
        }
        os.makedirs(os.path.dirname(self.settings_file) or '.', exist_ok=True)
        with open(self.settings_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
