import json
import os
from app.utils.credential_store import protect, unprotect

class LLMConfig:
    CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'config.json')
    
    API_KEY = ""
    PROVIDER = "Custom"
    MODEL_NAME = "deepseek-coder"
    API_BASE_URL = "https://api.deepseek.com/v1"
    MAX_TOKENS = 2000
    TEMPERATURE = 0.7
    REQUEST_TIMEOUT = 60

    @classmethod
    def load_config(cls):
        if os.path.exists(cls.CONFIG_PATH):
            with open(cls.CONFIG_PATH, 'r') as file:
                config = json.load(file)
                cls.API_KEY = unprotect(config.get('api_key', ''))
                cls.PROVIDER = config.get('provider', 'Custom')
                cls.MODEL_NAME = config.get('model_name', 'deepseek-coder')
                cls.API_BASE_URL = config.get('api_base_url', 'https://api.deepseek.com/v1')
                cls.MAX_TOKENS = config.get('max_tokens', 2000)
                cls.TEMPERATURE = config.get('temperature', 0.7)
                cls.REQUEST_TIMEOUT = config.get('request_timeout', 60)
                return cls.API_KEY
        return ''

    @classmethod
    def save_config(cls, api_key, model_name=None, api_base_url=None, max_tokens=None, temperature=None, request_timeout=None, provider=None):
        config = {
            'api_key': protect(api_key),
            'provider': provider if provider is not None else cls.PROVIDER,
            'model_name': cls.MODEL_NAME if model_name is None else model_name,
            'api_base_url': cls.API_BASE_URL if api_base_url is None else api_base_url,
            'max_tokens': cls.MAX_TOKENS if max_tokens is None else max_tokens,
            'temperature': cls.TEMPERATURE if temperature is None else temperature,
            'request_timeout': cls.REQUEST_TIMEOUT if request_timeout is None else request_timeout
        }
        with open(cls.CONFIG_PATH, 'w') as file:
            json.dump(config, file, indent=4)


        cls.API_KEY = api_key
        if provider is not None:
            cls.PROVIDER = provider
        if model_name is not None:
            cls.MODEL_NAME = model_name
        if api_base_url is not None:
            cls.API_BASE_URL = api_base_url
        if max_tokens is not None:
            cls.MAX_TOKENS = max_tokens
        if temperature is not None:
            cls.TEMPERATURE = temperature
        if request_timeout is not None:
            cls.REQUEST_TIMEOUT = request_timeout


LLMConfig.load_config() 