from pathlib import Path
import json,hashlib,pandas as pd,numpy as np
r=Path(__file__).resolve().parent/'paired-study-final'
if not (r/'completion.json').exists():raise SystemExit('Study not finished; no report emitted')
a=json.loads((r/'integration-results.json').read_text());d=pd.read_csv(r/'paired-predictions.csv',dtype=str);rows=[]
for x in a:
 g=d[d.dataset==x['dataset']]
 if x['dataset'] in ['ecaps','strawberry']:assert (g.plugin_prediction==g.reference_prediction).all()
 else:assert np.allclose(g.plugin_prediction.astype(float),g.reference_prediction.astype(float),rtol=1e-8,atol=1e-8)
 rows.append(f"| {x['dataset']} | {x['train_n']} / {x['probe_n']} | {x['raw_channels']} → 8 | {x['max_abs_difference']:.3g} | {x['seconds']:.2f} |")
text='''# Verified algorithm integration results

Six manually authored trusted candidate implementations cover five categories: mean centering, top-variance selection, nearest centroid classification, least-squares regression, accuracy and MSE metrics. All six passed synthetic independent-reference acceptance and six diagnostic tasks were rejected: four source defects (probe-time refit, index mismatch, wrong output shape, invalid JSON state), one invalid oracle fixture, and one axis-metadata defect. This fixed diagnostic set does not estimate a general false acceptance rate and is not six additional independent algorithms.

Each real-data workflow fitted only its designated training subset, executed accepted operators, compared selected original indices and predictions with an independent NumPy implementation, saved JSON, and loaded using a fresh service instance. Reloaded predictions matched exactly. Execution source hashes were unchanged before and after real-data fits. Saved workflow objects contain synthetic train:i/test:i identifiers; actual source IDs, original row indices and ECAPS physical specimen groups are provided separately in source-subset-lineage.csv. The sidecar verifies actual source groups are disjoint, and was reconstructed deterministically without editing the frozen runner.

| Collection | Train / probe | Channels | Max prediction discrepancy | Workflow seconds |
|---|---:|---|---:|---:|
'''+ '\n'.join(rows)+'''

The subsets are deliberately small integration checks and cannot estimate generalization performance. Strawberry first rows were class-sorted; the final pre-fit amendment uses first16 training rows and first8 test rows of each class. ECAPS uses complete seven-scan specimens, two training specimens and one held-out specimen per class. Grainit uses barley Moisture IDs from the previously frozen R1 fold1; Perten uses descriptive first32/next16 rows. Predictive baseline experiments use different algorithms and larger samples and must be reported separately.

No LLM/API calls, external code translation, model-comparison advantage, or automatic repair success is established. Service verification currently repeats at each operation; reported workflow times include its fit/predict/metric cost, but exclude subsequent save/load/replay checks. Six synthetic verification-and-acceptance operations took 57.57 seconds in the retained successful candidate pass; no model/API token costs incurred. Initial schema shorthand mistakes are documented in paired-study/execution-notes.md; the single-class exploratory subset correction is documented in paired-study-plan.md. Development outputs are excluded from final results.
'''
(r/'paired-integration-report.md').write_text(text,encoding='utf-8')
(r/'artifact-manifest.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in r.iterdir() if p.is_file() and p.name!='artifact-manifest.json'},indent=2));print(text)

