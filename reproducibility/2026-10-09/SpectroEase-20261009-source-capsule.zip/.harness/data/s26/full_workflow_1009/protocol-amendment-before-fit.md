# Protocol amendment before any phase-D model fit — 2026-10-09

The original candidate protocol named ECAPS entity-disjoint CV but did not define alignment of its raw spectral axes. Read-only inspection of all 315 source CSVs found 187 files with 3,112 points and 128 files with 4,149 points. All start at 3999.706 cm⁻¹. The shorter spectra end at 9999.265 cm⁻¹ and the longer at 11999.12 cm⁻¹. No prediction or fit was run before this finding.

**Frozen correction:** use a predefined 4000–9995 cm⁻¹ grid at exactly 5 cm⁻¹ intervals, linearly interpolate each raw spectrum from its native per-file axis to that common overlap. This interpolation has no learned statistic or label input. It is followed by the fold-local imputer/scaler/classifier specified in `candidate-protocol.yaml`. Preserve native point counts and original archives for review.

The candidate model, folds, metrics, and group boundary are now frozen before the first phase-D fit. ECAPS split unit remains 45 physical `Sample` entities, each with seven scans. The 315 scans must never be randomly divided as independent rows.
