"""Acquire/verify all four frozen archives; raw data are omitted from capsules."""
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import hashlib
import json
import requests

ROOT = Path(__file__).resolve().parent
SOURCES = [
    ('grainit', ROOT/'sensAIfood_Grainit.zip', 'https://zenodo.org/records/15838272/files/sensAIfood_Grainit.zip?download=1', '8948c63b1cdb6af8a824cc3570094ad1f43410c9ff6b306a9f670c0ee0f875b9'),
    ('strawberry', ROOT/'Strawberry.zip', 'https://www.timeseriesclassification.com/aeon-toolkit/Strawberry.zip', '1293ba770d15817be769958f077cab6f76d65a66465aff80ed393d1e80a71e00'),
    ('ecaps', ROOT/'ECAPS-ba21fdc05f78ce7394699aa45b0b87e6f0fad4b4.zip', 'https://github.com/usnistgov/ECAPS/archive/ba21fdc05f78ce7394699aa45b0b87e6f0fad4b4.zip', '7820a27b640cd01e81e904cf94c6b9ab427e79f72476cd24de757af663f641f1'),
    ('perten', ROOT.parent/'sensaifood_perten_zenodo_v1/sensAIfood_Perten.zip', 'https://zenodo.org/records/15838136/files/sensAIfood_Perten.zip?download=1', 'aa90b0df79f8206a491851bb60c102e72c4256ea2744c8d5eb90029d7eab259f'),
]


def main():
    records = []
    for name, path, url, expected in SOURCES:
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            partial = path.with_suffix('.zip.partial')
            try:
                with requests.get(url, stream=True, timeout=(20,60)) as response:
                    response.raise_for_status()
                    with partial.open('wb') as stream:
                        for chunk in response.iter_content(1024*1024): stream.write(chunk)
                if hashlib.sha256(partial.read_bytes()).hexdigest() != expected:
                    raise ValueError(f'{name}: archive differs from frozen source')
                partial.replace(path)
            finally:
                partial.unlink(missing_ok=True)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError(f'{name}: preserved archive differs; it was not overwritten')
        with ZipFile(path) as archive:
            if archive.testzip() is not None: raise ValueError(f'{name}: ZIP integrity failed')
            if name == 'perten':
                destination = path.parent/'source_files'; destination.mkdir(exist_ok=True)
                for member in archive.namelist():
                    basename = PurePosixPath(member).name
                    if basename.endswith(('.csv','.xlsx')) and basename.startswith(('Barley_', 'Corn_', 'Wheat_')):
                        target = destination/basename
                        data = archive.read(member)
                        if target.exists() and target.read_bytes() != data:
                            raise ValueError('Existing extracted Perten source differs; preserved without overwrite')
                        if not target.exists(): target.write_bytes(data)
        records.append({'dataset': name, 'sha256': actual, 'status': 'verified'})
    (ROOT/'capsule-source-verification.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
    print(json.dumps(records))


if __name__ == '__main__': main()
