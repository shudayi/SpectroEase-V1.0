# Verified algorithm integration results

Six manually authored trusted candidate implementations cover five categories: mean centering, top-variance selection, nearest centroid classification, least-squares regression, accuracy and MSE metrics. All six passed synthetic independent-reference acceptance and six diagnostic tasks were rejected: four source defects (probe-time refit, index mismatch, wrong output shape, invalid JSON state), one invalid oracle fixture, and one axis-metadata defect. This fixed diagnostic set does not estimate a general false acceptance rate and is not six additional independent algorithms.

Each real-data workflow fitted only its designated training subset, executed accepted operators, compared selected original indices and predictions with an independent NumPy implementation, saved JSON, and loaded using a fresh service instance. Reloaded predictions matched exactly. Execution source hashes were unchanged before and after real-data fits. Saved workflow objects contain synthetic train:i/test:i identifiers; actual source IDs, original row indices and ECAPS physical specimen groups are provided separately in source-subset-lineage.csv. The sidecar verifies actual source groups are disjoint, and was reconstructed deterministically without editing the frozen runner.

| Collection | Train / probe | Channels | Max prediction discrepancy | Workflow seconds |
|---|---:|---|---:|---:|
| strawberry | 32 / 16 | 235 → 8 | 0 | 90.85 |
| grainit | 32 / 16 | 351 → 8 | 7.19e-13 | 87.93 |
| perten | 32 / 16 | 141 → 8 | 1.39e-12 | 99.03 |
| ecaps | 28 / 14 | 1200 → 8 | 0 | 107.61 |

The subsets are deliberately small integration checks and cannot estimate generalization performance. Strawberry first rows were class-sorted; the final pre-fit amendment uses first16 training rows and first8 test rows of each class. ECAPS uses complete seven-scan specimens, two training specimens and one held-out specimen per class. Grainit uses barley Moisture IDs from the previously frozen R1 fold1; Perten uses descriptive first32/next16 rows. Predictive baseline experiments use different algorithms and larger samples and must be reported separately.

No LLM/API calls, external code translation, model-comparison advantage, or automatic repair success is established. Service verification currently repeats at each operation; reported workflow times include its fit/predict/metric cost, but exclude subsequent save/load/replay checks. Six synthetic verification-and-acceptance operations took 57.57 seconds in the retained successful candidate pass; no model/API token costs incurred. Initial schema shorthand mistakes are documented in paired-study/execution-notes.md; the single-class exploratory subset correction is documented in paired-study-plan.md. Development outputs are excluded from final results.
