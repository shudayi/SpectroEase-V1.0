"""Create the frozen, source-grounded intake summary without fitting a model."""
from __future__ import annotations

from collections import Counter
from io import BytesIO
import json
from pathlib import Path
import zipfile

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
ARCHIVES = {x["dataset"]: x for x in json.loads((ROOT / "primary-archive-manifest.json").read_text(encoding="utf-8"))}
data = {
    "schema_version": 1,
    "audit_date_client": "2026-10-09",
    "status": "source_intake_only_no_models_run",
    "archives": ARCHIVES,
    "datasets": {},
}

ecaps = ARCHIVES["ecaps"]
with zipfile.ZipFile(ROOT / ecaps["archive"]) as archive:
    csvs = [n for n in archive.namelist() if "/Data/NIR/" in n and n.endswith(".csv") and "Placeholder" not in n]
    ids = [Path(n).stem.rsplit("_", 1)[0] for n in csvs]
    info = pd.read_csv(BytesIO(archive.read(next(n for n in archive.namelist() if n.endswith("/Data/SampleInformation.csv")))))
    example = np.loadtxt(BytesIO(archive.read(csvs[0])), delimiter=",")
    assert len(csvs) == 315 and len(set(ids)) == len(info) == 45
    assert Counter(ids) == {x: 7 for x in set(ids)}
    assert set(ids) == set(info["Sample"].astype(str))
    data["datasets"]["ecaps"] = {
        "reference": "https://doi.org/10.18434/mds2-3022",
        "repository": ecaps["source_record"],
        "commit": "ba21fdc05f78ce7394699aa45b0b87e6f0fad4b4",
        "task": "polyolefin_classification",
        "spectral_files": 315,
        "physical_entities": 45,
        "replicates_per_entity": 7,
        "entity_key": "SampleInformation.Sample = spectrum filename stem without final _replicate",
        "class1_entity_counts": {str(k): int(v) for k, v in info["Class1"].value_counts().items()},
        "class2_entity_counts": {str(k): int(v) for k, v in info["Class2"].value_counts(dropna=False).items()},
        "example_file": csvs[0],
        "example_shape": list(example.shape),
        "axis": "approximately 4000–10000 cm^-1, per-file first column; verify all files before alignment",
        "axis_example_first_last": [float(example[0, 0]), float(example[-1, 0])],
        "signal": "percent reflectance after instrument background subtraction per archive README",
        "leakage_barrier": "All seven replicates of each physical Sample stay in one fold; never random-split 315 spectra",
        "rights": "Archive LICENSE.md explicitly describes NIST-developed software; separate rights statement for underlying data not established by that file. Cite data DOI and check repository/data reuse policy before redistribution.",
    }

strawberry = ARCHIVES["strawberry"]
with zipfile.ZipFile(ROOT / strawberry["archive"]) as archive:
    ycounts = {}
    for split, expected in [("TRAIN", 613), ("TEST", 370)]:
        arr = np.loadtxt(BytesIO(archive.read(f"Strawberry_{split}.txt")))
        assert arr.shape == (expected, 236) and np.isfinite(arr).all()
        ycounts[split] = {str(int(k)): int(v) for k, v in Counter(arr[:, 0]).items()}
    data["datasets"]["strawberry"] = {
        "reference": strawberry["source_record"],
        "task": "ATR-FTIR strawberry authenticity classification",
        "official_train_rows": 613,
        "official_test_rows": 370,
        "channels": 235,
        "label_column": 0,
        "class_counts": ycounts,
        "axis": "channel index only in archive; physical wavenumber calibration not supplied in TXT/TS/ARFF source",
        "leakage_barrier": "Preserve official TRAIN/TEST files and evaluate TEST once; do any selection/tuning inside TRAIN only",
        "rights": "Official page states All rights reserved in footer; no separate downloadable-data redistribution grant verified",
    }

grainit = ARCHIVES["grainit"]
with zipfile.ZipFile(ROOT / grainit["archive"]) as archive:
    cereals = {}
    for n in archive.namelist():
        if not n.endswith(".csv"):
            continue
        table = pd.read_csv(BytesIO(archive.read(n)))
        wavelength = np.asarray(table.columns[8:], dtype=float)
        assert len(wavelength) == 351 and wavelength[0] == 950 and wavelength[-1] == 1650
        assert np.allclose(np.diff(wavelength), 2)
        cereals[n.split("_")[0].lower()] = {
            "archive_member": n,
            "rows": len(table),
            "columns": len(table.columns),
            "unique_ids": int(table["ID"].nunique()),
            "instrument_counts": {str(k): int(v) for k, v in table["Spectrometer"].value_counts().items()},
            "missing_targets": {k: int(v) for k, v in table[["Moisture", "Protein"]].isna().sum().items()},
        }
    assert {k: v["rows"] for k, v in cereals.items()} == {"barley": 86, "corn": 187, "wheat": 410}
    data["datasets"]["grainit"] = {
        "reference": grainit["source_record"],
        "task": "cereal moisture/protein regression",
        "cereals": cereals,
        "first_eight_columns": ["ID", "Spectrometer", "Cereal", "Variety", "Country", "Year", "Moisture", "Protein"],
        "spectral_axis_nm": {"first": 950, "last": 1650, "step": 2, "channels": 351},
        "metadata_units": {"Protein": "% as is", "Moisture": "%", "moisture_reference_basis": "% as is"},
        "metadata_reference_method_warning": "Workbooks label Protein reference as Infratec (Italy)/Oven (other countries) and Moisture reference as Infratec (Italy)/Kjeldahl (other countries); this appears internally surprising and must be reported verbatim, not silently corrected.",
        "leakage_barrier": "Separate per-cereal sample-ID groups and preserve year/country/instrument metadata; no automatic cross-collection target-unit equivalence with Perten",
        "rights": "Zenodo records/15838272 API metadata.license.id = cc-by-4.0, checked 2026-10-09; attribution required",
    }

perten_dir = ROOT.parent / "sensaifood_perten_zenodo_v1"
perten = perten_dir / "sensAIfood_Perten.zip"
assert perten.exists()
import hashlib
perten_hash = hashlib.sha256(perten.read_bytes()).hexdigest()
data["datasets"]["perten"] = {
    "reference": "https://doi.org/10.5281/zenodo.15838136",
    "archive": str(perten.relative_to(ROOT.parent)),
    "sha256": perten_hash,
    "md5": hashlib.md5(perten.read_bytes()).hexdigest(),
    "task": "cereal moisture/protein regression",
    "cereals": {"barley": 150, "corn": 150, "wheat": 150},
    "spectral_axis_nm": {"first": 950, "last": 1650, "step": 5, "channels": 141},
    "first_eight_columns": data["datasets"]["grainit"]["first_eight_columns"],
    "rights": "Zenodo records/15838136 API metadata.license.id = cc-by-4.0, checked 2026-10-09; attribution required",
    "target_unit_warning": "Moisture reported dry basis in local metadata; Protein basis wording ambiguous; do not assume Grainit % as-is equivalence",
}

(ROOT / "dataset-manifest.json").write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
print("Wrote dataset-manifest.json")
