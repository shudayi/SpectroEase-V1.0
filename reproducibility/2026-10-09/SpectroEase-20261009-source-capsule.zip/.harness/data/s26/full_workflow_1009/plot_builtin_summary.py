from pathlib import Path
import json,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=Path(__file__).resolve().parent/'baseline-results-v2';m=json.loads((r/'metrics.json').read_text());fig,ax=plt.subplots(1,2,figsize=(10,3.8),layout='constrained')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none'})
cl=[x for x in m if x['method']=='prediction' and ((x['task']=='ecaps' and x['unit']=='entity')or(x['task']=='strawberry'))]
x=np.arange(len(cl));ax[0].bar(x-.18,[q['balanced_accuracy'] for q in cl],.36,label='Balanced accuracy',color='#317B9A');ax[0].bar(x+.18,[q['macro_f1'] for q in cl],.36,label='Macro F1',color='#D89C49');ax[0].set_xticks(x,[('ECAPS' if q['task']=='ecaps' else 'Strawberry')+'\n'+q['repeat'].replace('official_test','Test') for q in cl]);ax[0].set_ylim(0,1.04);ax[0].set_ylabel('Classification score');ax[0].legend(frameon=False,loc='upper left',bbox_to_anchor=(0,1.17),ncol=2);ax[0].set_title('(a) Fixed logistic regression',pad=42)
g=[q for q in m if q['task'].startswith('grainit') and q['method']=='prediction'];tasks=sorted(set(q['task'] for q in g));x=np.arange(len(tasks))
for rep,offset,col in [('R1',-.18,'#317B9A'),('R2',.18,'#D89C49')]:ax[1].bar(x+offset,[next(q['R2'] for q in g if q['task']==t and q['repeat']==rep) for t in tasks],.36,label=rep,color=col)
ax[1].set_xticks(x,[t.split('_')[1].title()+'\n'+t.split('_')[2] for t in tasks],rotation=35,ha='right');ax[1].set_ylabel('Pooled out-of-fold R²');ax[1].set_title('(b) Grainit fixed PLSR (3 components)',pad=42);ax[1].legend(frameon=False,loc='upper left',bbox_to_anchor=(0,1.17),ncol=2)
for a in ax:a.spines[['top','right']].set_visible(False);a.grid(axis='y',alpha=.2);a.set_axisbelow(True)
for ext in ['png','pdf','svg']:fig.savefig(r/f'builtin-baseline-summary.{ext}',dpi=300)
(r/'figure-scope.md').write_text('Built-in pipelines only. ECAPS primary scores aggregate seven scans by specimen majority vote. Strawberry R1/R2 training CV and official test are distinct evaluations. Grainit R1/R2 are seeded folds of the same cohort, not independent datasets. No error bars or inferential CI. No plugin performance claims. Source metrics.json.',encoding='utf-8')
