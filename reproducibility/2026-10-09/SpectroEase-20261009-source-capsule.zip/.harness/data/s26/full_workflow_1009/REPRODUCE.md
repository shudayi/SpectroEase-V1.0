# Reproduce the October 9 local source study

This is a local source capsule. It is not the older public executable and does not establish a new public release. Use Windows and Python 3.12; the recorded project interpreter is Python 3.12.10. Install the pinned runtime dependencies with `python -m pip install -r requirements.txt`. For software tests also install `pytest==8.4.2`.

Run from the extracted capsule root. Use a short writable temporary directory for Windows file/path tests. For example in PowerShell:

```powershell
$env:QT_QPA_PLATFORM = 'offscreen'
$env:PYTHONUTF8 = '1'
$env:TEMP = Join-Path (Get-Location) '.tmp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null
python -m pytest tests -q -p no:cacheprovider --basetemp .tmp/pytest
```

For interactive use clear `QT_QPA_PLATFORM` and run `python main.py`. Private configuration is excluded; the supplied configuration starts without an API key. The manually supplied algorithm route needs no live API.

Acquire original data separately, respecting source licences:

```powershell
python .harness/data/s26/full_workflow_1009/fetch_all_frozen_sources.py
```

The fetcher verifies exact SHA-256 values, refuses changed existing archives and prepares the Perten source CSVs. ECAPS uses a pinned public repository archive. UCR Strawberry and ECAPS raw archives are omitted from this capsule; a software licence is not assumed to license all source data.

To reconstruct the built-in new references, first save all planned splits, then fit:

```powershell
$env:SPECTRO_PLAN_ONLY = '1'
python .harness/data/s26/full_workflow_1009/run_builtin_baselines.py
Remove-Item Env:SPECTRO_PLAN_ONLY
python .harness/data/s26/full_workflow_1009/run_builtin_baselines.py
python .harness/data/s26/full_workflow_1009/recompute_builtin_metrics.py
```

The scripts write their result directory. Preserve the supplied evidence before re-running if byte comparisons are needed. The original Perten protocol remains separate: `python .harness/data/s26/run_sensaifood_s26_61.py --execute --lead-unlock`. Its source units and record-level independence limitations remain in the protocol.

The paired-study-current-source directory records manually supplied centering, variance selection, nearest-centroid/least-squares and scalar-metric execution on fixed small subsets. This establishes tested integration correctness, not accuracy superiority or autonomous language conversion. Its saved workflows include actual source identities and ordered input axes. Original and current operational timings use different verification behavior and are not a controlled speed comparison.

After acquiring and verifying the archives, replay those accepted operators and independently check their predictions with scikit-learn references:

```powershell
python .harness/data/s26/full_workflow_1009/run_paired_current_source.py
python .harness/team/evidence/s26/full_workflow_1009/independent_current_source_paired_model_review.py
python .harness/team/evidence/s26/full_workflow_1009/independent_baseline_arithmetic_review.py
python .harness/data/s26/full_workflow_1009/plot_baseline_results.py
python .harness/data/s26/full_workflow_1009/plot_verified_architecture.py
```

The supplied accepted records and earlier paired-study-final outputs are intentional inputs to this replay. Preserve copies before rerunning: output manifests and operational times will be regenerated. Historical SHA values identify the recorded run, while a new replay has its own runtime and source manifest.

Software checks use logical Qt work areas and offscreen captures. Physical monitor migration, mixed-DPI transitions, a newly packaged executable and live language-model conversion are not certified by this capsule.
