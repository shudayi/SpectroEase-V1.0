# Built-in baseline results (2026-10-09)

Protocol and all split assignments were saved before the v2 fit pass. Initial baseline-results run retained for transparency: it froze protocol but only persisted splits after fits; v2 corrects that evidence-order issue with a planning-only pass. No model or hyperparameter changed. Official Strawberry test was consequently replayed for artifact reconstruction, with no tuning or selection using its results.

These are built-in sklearn reference pipelines, not evidence of accepted plugin execution. Perten prior six-task results remain untouched. ECAPS all 315 axes checked finite, strictly increasing after sorting, and covering 4000–9995 cm^-1; interpolation does not extrapolate. R1/R2 are resampling plans on the same collection. Grainit record IDs are the only available independence unit; physical replicates cannot be ruled out.

| Task | Repeat | Unit | n | Results |
|---|---|---|---:|---|
| ecaps | R1 | entity | 45 | BA=0.9103, macro-F1=0.7665 |
| ecaps | R2 | entity | 45 | BA=0.7821, macro-F1=0.7462 |
| grainit_barley_Moisture | R1 | record | 86 | RMSE=0.8981, MAE=0.6576, R²=0.4633 |
| grainit_barley_Moisture | R2 | record | 86 | RMSE=0.9661, MAE=0.6954, R²=0.3789 |
| grainit_barley_Protein | R1 | record | 86 | RMSE=1.6209, MAE=1.3183, R²=0.4073 |
| grainit_barley_Protein | R2 | record | 86 | RMSE=1.5740, MAE=1.2800, R²=0.4411 |
| grainit_corn_Moisture | R1 | record | 187 | RMSE=2.2156, MAE=1.6084, R²=0.8519 |
| grainit_corn_Moisture | R2 | record | 187 | RMSE=2.2709, MAE=1.6525, R²=0.8444 |
| grainit_corn_Protein | R1 | record | 187 | RMSE=0.4597, MAE=0.3524, R²=0.2373 |
| grainit_corn_Protein | R2 | record | 187 | RMSE=0.4626, MAE=0.3500, R²=0.2278 |
| grainit_wheat_Moisture | R1 | record | 410 | RMSE=2.1053, MAE=1.0118, R²=0.1623 |
| grainit_wheat_Moisture | R2 | record | 410 | RMSE=2.0798, MAE=1.0095, R²=0.1824 |
| grainit_wheat_Protein | R1 | record | 410 | RMSE=2.0909, MAE=1.2174, R²=0.1659 |
| grainit_wheat_Protein | R2 | record | 410 | RMSE=2.0993, MAE=1.2263, R²=0.1591 |
| strawberry | R1 | record | 613 | BA=0.9728, macro-F1=0.9667 |
| strawberry | R2 | record | 613 | BA=0.9655, macro-F1=0.9580 |
| strawberry | official_test | record | 370 | BA=0.9592, macro-F1=0.9508 |

Independent persisted-prediction recomputation: 38 metric records, 77 disjoint folds, maximum absolute discrepancy 0.

Do not claim external-cohort validation, automatic algorithm conversion, or physical monitor testing from these results. Grainit workbook target units and surprising method labels remain as documented in dataset-manifest.json.