# Actual Optuna TPE implementation and functional checks

Installed Optuna 4.9.0 and 7 missing dependencies offline from official downloaded PyPI wheels; existing runtime versions unchanged. numpy2.3.3, packaging25.0 and typing_extensions4.15.0 retained. pip check passed. requirements.txt converted from UTF16 to UTF8 and pins added for actual installed dependencies.

Service now errors clearly if Optuna unavailable, instead of silently running GridSearch. Declared lists/tuples are discrete choices including exactly two numeric candidates; scalar settings are retained in trial records and final refit. TPE seed42 uses bounded startup trials, so6-trial demonstrations include4post-startup TPE trials. Metadata records actual engine, version, sampler, budget, scoring, effective params and fold scores. Nonfinite objectives/empty spaces/nonpositive budgets fail explicitly. Optimization caller receives trial CV results.

Focused tests:60passed across actual-engine, CV leakage and group-contract suites. Actual StandardScaler fit observations matched every training fold, repeated4trials and finaltraining-only refit. Missing dependency path, fixedparam retention and two-value semantics checked. Interpreter shutdown emitted an existing pyreadline3 console destructor OSError after all tests exited0; no test failed.

Real-data functional runs (frozen source hashes before/after): Strawberry official TRAIN613 only, 6trials ×3CVfolds, max_depth in[1,3], fixed min_samples_leaf2; Grainit barley Moisture frozen training68/heldout18, 6trials ×3CVfolds, alpha in[0.1,10.0]. Outer-test source IDs excluded from all search fit traces. Independent best-CV reconstruction difference0 for both. Held-out predictions recorded after fitting; these demonstrate functionality, not new manuscript baseline superiority. Existing Perten/Grainit/Strawberry/ECAPS baseline evidence unchanged.

Pip could not remove several sandbox temporary unpack directories; installation and dependency validation nevertheless completed successfully. No recursive cleanup performed.

