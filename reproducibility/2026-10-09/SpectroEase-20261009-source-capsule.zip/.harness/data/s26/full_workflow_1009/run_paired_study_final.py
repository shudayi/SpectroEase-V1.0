from pathlib import Path
import sys,json,time,hashlib,zipfile
from io import BytesIO
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[3]))
from app.services.verified_algorithm_service import Candidate,VerifiedAlgorithmService
from app.services.verified_workflow_service import VerifiedWorkflowService
OUT=ROOT/'paired-study-final';STORE=ROOT/'paired-study'/'accepted'
SOURCES={
'center':'''import numpy as np
def fit(X,y,params):
    return {"mean": np.mean(X,axis=0).tolist()}
def transform(X,state,params):
    return np.asarray(X)-np.asarray(state["mean"])
''',
'select':'''import numpy as np
def fit(X,y,params):
    return {"indices":np.argsort(np.var(X,axis=0))[-params["k"]:].tolist()}
def transform(X,state,params):
    return np.asarray(X)[:,state["indices"]]
''',
'classifier':'''import numpy as np
def fit(X,y,params):
    labels=np.unique(y)
    return {"labels":labels.tolist(),"centroids":[np.mean(np.asarray(X)[np.asarray(y)==c],axis=0).tolist() for c in labels]}
def predict(X,state,params):
    distances=np.sum((np.asarray(X)[:,None,:]-np.asarray(state["centroids"])[None,:,:])**2,axis=2)
    return np.asarray(state["labels"])[np.argmin(distances,axis=1)]
''',
'regressor':'''import numpy as np
def fit(X,y,params):
    a=np.column_stack([np.ones(len(X)),X])
    return {"coef":np.linalg.lstsq(a,np.asarray(y),rcond=None)[0].tolist()}
def predict(X,state,params):
    return np.column_stack([np.ones(len(X)),X])@np.asarray(state["coef"])
''',
'mse':'''import numpy as np
def score(y_true,y_pred,params):
    return float(np.mean((np.asarray(y_true)-np.asarray(y_pred))**2))
''',
'accuracy':'''import numpy as np
def score(y_true,y_pred,params):
    return float(np.mean(np.asarray(y_true)==np.asarray(y_pred)))
'''}
def load_sets():
 sets=[]
 with zipfile.ZipFile(ROOT/'Strawberry.zip') as z:
  rawa=np.loadtxt(BytesIO(z.read('Strawberry_TRAIN.txt')));rawb=np.loadtxt(BytesIO(z.read('Strawberry_TEST.txt')))
  a=np.vstack([rawa[rawa[:,0]==c][:16] for c in [1,2]]);b=np.vstack([rawb[rawb[:,0]==c][:8] for c in [1,2]])
  sets.append(('strawberry',a[:,1:],a[:,0].astype(int),b[:,1:],b[:,0].astype(int)))
 with zipfile.ZipFile(ROOT/'sensAIfood_Grainit.zip') as z:
  n=next(n for n in z.namelist() if n.lower().startswith('barley') and n.endswith('.csv'));d=pd.read_csv(BytesIO(z.read(n)))
  splits=pd.read_csv(ROOT/'baseline-results-v2/splits.csv');s=splits[(splits.task=='grainit_barley_Moisture')&(splits.repeat=='R1')&(splits.fold==1)]
  a=d[d.ID.astype(str).isin(s[s.partition=='train'].id.astype(str))].iloc[:32];b=d[d.ID.astype(str).isin(s[s.partition=='validation'].id.astype(str))].iloc[:16]
  sets.append(('grainit',a.iloc[:,8:].to_numpy(float),a.Moisture.to_numpy(float),b.iloc[:,8:].to_numpy(float),b.Moisture.to_numpy(float)))
 with zipfile.ZipFile(ROOT.parent/'sensaifood_perten_zenodo_v1/sensAIfood_Perten.zip') as z:
  n=next(n for n in z.namelist() if n.lower().startswith('barley') and n.endswith('.csv'));d=pd.read_csv(BytesIO(z.read(n)));a=d.iloc[:32];b=d.iloc[32:48]
  sets.append(('perten',a.iloc[:,8:].to_numpy(float),a.Moisture.to_numpy(float),b.iloc[:,8:].to_numpy(float),b.Moisture.to_numpy(float)))
 with zipfile.ZipFile(next(ROOT.glob('ECAPS-*.zip'))) as z:
  info=pd.read_csv(BytesIO(z.read(next(n for n in z.namelist() if n.endswith('/Data/SampleInformation.csv'))))).set_index('Sample')
  s=pd.read_csv(ROOT/'baseline-results-v2/splits.csv');s=s[(s.task=='ecaps')&(s.repeat=='R1')&(s.fold==1)];parts=[]
  for part,count in [('train',2),('validation',1)]:
   groups=sorted(s[s.partition==part].group.unique());chosen=[]
   for label in ['PE','PP']:chosen.extend([g for g in groups if info.loc[g,'Class1']==label][:count])
   assert len(chosen)==2*count
   names=sorted(n for n in z.namelist() if '/Data/NIR/' in n and n.endswith('.csv') and Path(n).stem.rsplit('_',1)[0] in chosen);xs=[];ys=[]
   for n in names:
    a=np.loadtxt(BytesIO(z.read(n)),delimiter=',');a=a[np.argsort(a[:,0])];xs.append(np.interp(np.arange(4000,9996,5),a[:,0],a[:,1]));ys.append(info.loc[Path(n).stem.rsplit('_',1)[0],'Class1'])
   parts.append((np.array(xs),np.array(ys)))
  sets.append(('ecaps',*parts[0],*parts[1]))
 return sets

def main():
 OUT.mkdir(exist_ok=True)
 freeze={'plan_sha256':hashlib.sha256((ROOT/'paired-study-plan.md').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'sources':SOURCES}
 (OUT/'freeze-before-verification.json').write_text(json.dumps(freeze,indent=2))
 service=VerifiedAlgorithmService(STORE)
 accepted=json.loads((ROOT/'paired-study'/'acceptance-reports.json').read_text())
 ids={a['name']:a['accepted_id'] for a in accepted}
 faults=json.loads((ROOT/'paired-study'/'fault-reports.json').read_text())
 service_paths=['app/services/verified_algorithm_service.py','app/services/verified_algorithm_worker.py','app/services/verified_workflow_service.py','app/services/algorithm_onboarding_service.py','app/utils/code_sandbox.py']
 project=ROOT.parents[3]
 source_hashes={p:hashlib.sha256((project/p).read_bytes()).hexdigest() for p in service_paths}
 (OUT/'service-hashes-before-fit.json').write_text(json.dumps(source_hashes,indent=2))
 results=[];predrows=[]
 for name,A,y,B,z in load_sets():
  task='classification' if name in ['ecaps','strawberry'] else 'regression';selection={'preprocessing':ids['center'],'feature_selection':ids['select'],'model':ids['classifier' if task=='classification' else 'regressor'],'metric':ids['accuracy' if task=='classification' else 'mse']}
  mean=A.mean(axis=0);a=A-mean;b=B-mean;ix=np.argsort(np.var(a,axis=0))[-8:];a=a[:,ix];b=b[:,ix]
  if task=='classification':
   lab=np.unique(y);cent=np.array([a[y==c].mean(axis=0) for c in lab]);ref=lab[np.argmin(((b[:,None]-cent[None])**2).sum(axis=2),axis=1)]
  else:ref=np.column_stack([np.ones(len(b)),b])@np.linalg.lstsq(np.column_stack([np.ones(len(a)),a]),y,rcond=None)[0]
  started=time.perf_counter();workflow=VerifiedWorkflowService(service);result=workflow.run(selection,A,y,B,z);elapsed=time.perf_counter()-started;pred=np.array(result['predictions']);assert np.array_equal(pred,ref) if task=='classification' else np.allclose(pred,ref,rtol=1e-8,atol=1e-8)
  path=OUT/(name+'-workflow.json');workflow.save(result,path);fresh=VerifiedWorkflowService(VerifiedAlgorithmService(STORE));replay=fresh.predict(fresh.load(path),B);assert np.array_equal(pred,replay)
  selected=result['stages'][1]['state']['state']['indices'];assert selected==ix.tolist()
  results.append({'dataset':name,'train_n':len(A),'probe_n':len(B),'raw_channels':A.shape[1],'selected_indices':selected,'prediction_match':True,'restart_reload_exact':True,'seconds':elapsed,'max_abs_difference':0 if task=='classification' else float(np.max(abs(pred-ref))),'metrics':result['metrics']})
  predrows.extend({'dataset':name,'row':i,'truth':str(t),'plugin_prediction':str(p),'reference_prediction':str(q)} for i,(t,p,q) in enumerate(zip(z,pred,ref)))
  (OUT/'integration-results.json').write_text(json.dumps(results,indent=2));pd.DataFrame(predrows).to_csv(OUT/'paired-predictions.csv',index=False);print('Completed '+name,flush=True)
 assert source_hashes=={p:hashlib.sha256((project/p).read_bytes()).hexdigest() for p in service_paths}
 (OUT/'service-hashes-after-fit.json').write_text(json.dumps(source_hashes,indent=2))
 (OUT/'completion.json').write_text(json.dumps({'positive_candidates':len(ids),'fault_candidates_rejected':len(faults),'datasets':len(results),'api_calls':0,'claim_scope':'manually authored trusted candidate integration correctness only'},indent=2))
if __name__=='__main__':main()


