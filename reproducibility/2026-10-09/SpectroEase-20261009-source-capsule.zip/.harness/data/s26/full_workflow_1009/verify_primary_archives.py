"""Verify unmodified official archive bytes against this intake's frozen manifest."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "primary-archive-manifest.json").read_text(encoding="utf-8"))
assert {item["dataset"] for item in manifest} == {"ecaps", "strawberry", "grainit"}
for item in manifest:
    path = ROOT / item["archive"]
    data = path.read_bytes()
    assert len(data) == item["bytes"], f"size mismatch: {path}"
    assert hashlib.sha256(data).hexdigest() == item["sha256"], f"SHA mismatch: {path}"
    if item["published_md5"]:
        assert hashlib.md5(data).hexdigest() == item["published_md5"], f"published MD5 mismatch: {path}"
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None, f"ZIP CRC mismatch: {path}"
        members = [x.filename for x in archive.infolist() if not x.is_dir()]
    assert members == item["members"], f"member list changed: {path}"
    print(f"PASS {item['dataset']} {item['sha256']}")
