"""Replay fixed paired study with source IDs and ordered axis contract."""
from pathlib import Path
import sys,importlib.util,importlib.metadata as md,json,hashlib,time
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parents[3];sys.path.insert(0,str(PROJECT))
from app.services.verified_algorithm_service import VerifiedAlgorithmService,VerifiedAlgorithmError
from app.services.verified_workflow_service import VerifiedWorkflowService
spec=importlib.util.spec_from_file_location('frozen_paired_loader',ROOT/'run_paired_study_final.py');loader=importlib.util.module_from_spec(spec);spec.loader.exec_module(loader)
OUT=ROOT/'paired-study-current-source';STORE=ROOT/'paired-study'/'accepted'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 OUT.mkdir(exist_ok=True)
 paths=[PROJECT/p for p in ['app/services/verified_algorithm_service.py','app/services/verified_algorithm_worker.py','app/services/verified_workflow_service.py','app/services/algorithm_onboarding_service.py','app/services/algorithm_onboarding_worker.py','app/utils/code_sandbox.py','requirements.txt']]
 paths += [Path(__file__),ROOT/'run_paired_study_final.py',ROOT/'paired-study-plan.md',ROOT/'paired-study-final/source-subset-lineage.csv',ROOT/'paired-study-final/paired-predictions.csv',ROOT/'Strawberry.zip',ROOT/'sensAIfood_Grainit.zip',next(ROOT.glob('ECAPS-*.zip')),ROOT.parent/'sensaifood_perten_zenodo_v1/sensAIfood_Perten.zip']
 paths+=sorted(STORE.glob('*.json'))
 freeze={str(p.relative_to(PROJECT)):sha(p) for p in paths};(OUT/'freeze-before-fit.json').write_text(json.dumps(freeze,indent=2))
 runtime={d.metadata['Name']:d.version for d in md.distributions()};(OUT/'runtime-packages.json').write_text(json.dumps(runtime,indent=2,sort_keys=True))
 protocol={'source_subsets':'Exact frozen load_sets from run_paired_study_final.py; no new selection/tuning','source_ids':'Original row/file IDs supplied directly to workflow.run; physical groups preserved as lineage sidecar','axis':{'strawberry':'1..235 channel indices, not physical wavenumber','grainit':'950..1650 nm step2','perten':'950..1650 nm step5','ecaps':'4000..9995 cm^-1 step5 common interpolation grid'},'timing':'Current cache-enabled environment fit/predict/metric only; subsequent save/load/replay separately timed. Operational measurements, not benchmark or comparison against old timing.','reference':'Independent NumPy same algorithms and unchanged earlier paired-study-final predictions','negative_checks':'Reverse input axis/order: predict must reject; run mismatched train/test axes must reject','scope':'Manually authored candidate integration only, no LLM or API calls'}
 (OUT/'protocol-before-fit.json').write_text(json.dumps(protocol,indent=2))
 lineage=pd.read_csv(ROOT/'paired-study-final/source-subset-lineage.csv',dtype={'source_id':str,'group':str});lineage.to_csv(OUT/'source-subset-lineage.csv',index=False)
 old=pd.read_csv(ROOT/'paired-study-final/paired-predictions.csv',dtype=str);accepted=json.loads((ROOT/'paired-study/acceptance-reports.json').read_text());ids={a['name']:a['accepted_id'] for a in accepted}
 service=VerifiedAlgorithmService(STORE);results=[];predrows=[]
 for name,A,y,B,z in loader.load_sets():
  task='classification' if name in ['ecaps','strawberry'] else 'regression';selection={'preprocessing':ids['center'],'feature_selection':ids['select'],'model':ids['classifier' if task=='classification' else 'regressor'],'metric':ids['accuracy' if task=='classification' else 'mse']}
  lin=lineage[lineage.dataset==name];train_lin=lin[lin.partition=='train'];test_lin=lin[lin.partition=='probe'];trainids=train_lin.source_id.tolist();testids=test_lin.source_id.tolist()
  assert len(trainids)==len(A) and len(testids)==len(B)
  assert not set(train_lin.group)&set(test_lin.group)
  axis=list(range(1,236)) if name=='strawberry' else list(range(950,1651,2 if name=='grainit' else 5)) if name in ['grainit','perten'] else list(range(4000,9996,5))
  mean=A.mean(axis=0);a=A-mean;b=B-mean;ix=np.argsort(np.var(a,axis=0))[-8:];a=a[:,ix];b=b[:,ix]
  if task=='classification':
   lab=np.unique(y);cent=np.array([a[y==c].mean(axis=0) for c in lab]);ref=lab[np.argmin(((b[:,None]-cent[None])**2).sum(axis=2),axis=1)]
  else:ref=np.column_stack([np.ones(len(b)),b])@np.linalg.lstsq(np.column_stack([np.ones(len(a)),a]),y,rcond=None)[0]
  start=time.perf_counter();workflow=VerifiedWorkflowService(service);result=workflow.run(selection,A,y,B,z,train_ids=trainids,test_ids=testids,axis=axis,test_axis=axis);elapsed=time.perf_counter()-start
  pred=np.array(result['predictions']);previous=old[old.dataset==name].plugin_prediction.to_numpy()
  if task=='classification':assert np.array_equal(pred.astype(str),ref.astype(str)) and np.array_equal(pred.astype(str),previous)
  else:assert np.allclose(pred,ref,rtol=1e-8,atol=1e-8) and np.allclose(pred,previous.astype(float),rtol=1e-12,atol=1e-12)
  assert result['training_ids']==trainids and result['test_ids']==testids and result['input_axis']==axis
  assert result['axis_scope']=='exact_ordered_input_labels'
  for fit in result['fit_trace']:assert fit['training_ids']==trainids and not set(fit['training_ids'])&set(testids)
  selected=result['stages'][1]['state']['state']['indices'];assert selected==ix.tolist()
  path=OUT/(name+'-workflow.json');start=time.perf_counter();workflow.save(result,path);fresh=VerifiedWorkflowService(VerifiedAlgorithmService(STORE));loaded=fresh.load(path);replay=fresh.predict(loaded,B,axis=axis);assert np.array_equal(pred,replay);replaytime=time.perf_counter()-start
  negatives=[]
  try:fresh.predict(loaded,B[:,::-1],axis=axis[::-1])
  except VerifiedAlgorithmError as e:negatives.append({'case':'reordered_prediction_axis','rejected':True,'message':str(e)})
  else:raise AssertionError('Reordered prediction axis accepted')
  try:workflow.run(selection,A,y,B,z,train_ids=trainids,test_ids=testids,axis=axis,test_axis=axis[::-1])
  except VerifiedAlgorithmError as e:negatives.append({'case':'different_train_test_axis','rejected':True,'message':str(e)})
  else:raise AssertionError('Mismatched test axis accepted')
  results.append({'dataset':name,'train_n':len(A),'probe_n':len(B),'raw_channels':A.shape[1],'selected_indices':selected,'selected_axis_labels':[axis[i] for i in selected],'axis_scope':result['axis_scope'],'axis_sha256':result['axis_sha256'],'actual_source_ids_in_workflow':True,'actual_source_group_disjoint':True,'reference_match':True,'old_prediction_parity':True,'restart_reload_exact':True,'fit_predict_metric_seconds':elapsed,'save_fresh_load_replay_seconds':replaytime,'max_abs_reference_difference':0 if task=='classification' else float(np.max(abs(pred-ref))),'axis_negative_checks':negatives,'metrics':result['metrics']})
  predrows.extend({'dataset':name,'source_id':i,'truth':str(t),'plugin_prediction':str(p),'reference_prediction':str(q)} for i,t,p,q in zip(testids,z,pred,ref));(OUT/'integration-results.json').write_text(json.dumps(results,indent=2));pd.DataFrame(predrows).to_csv(OUT/'paired-predictions.csv',index=False);print('Completed '+name,flush=True)
 assert freeze=={str(p.relative_to(PROJECT)):sha(p) for p in paths}
 (OUT/'freeze-after-fit.json').write_text(json.dumps(freeze,indent=2));(OUT/'completion.json').write_text(json.dumps({'datasets':len(results),'axis_negative_checks_rejected':sum(len(r['axis_negative_checks']) for r in results),'source_hashes_unchanged':True,'api_calls':0,'scope':protocol['scope']},indent=2))
 report=['# Current-source paired integration replay','', 'Fixed four-collection subsets replayed after axis binding and verification cache updates in the Optuna-enabled runtime. Original candidate identities and subsets were preserved. All four independent numerical/class references and previous predictions matched; fresh-service JSON persistence replay was exact. Actual source row/file IDs are now directly in saved workflow fit traces and train/test provenance. ECAPS physical specimen groups remain disjoint; Grainit/Perten record IDs do not establish physical replicate independence.','', '| Collection | Train / probe | Max reference discrepancy | Fit/predict/metric seconds | Save/fresh-load/replay seconds |','|---|---:|---:|---:|---:|']
 for r in results:report.append(f"| {r['dataset']} | {r['train_n']} / {r['probe_n']} | {r['max_abs_reference_difference']:.3g} | {r['fit_predict_metric_seconds']:.3f} | {r['save_fresh_load_replay_seconds']:.3f} |")
 report+=['','Eight ordered-axis negative checks were rejected: reversed prediction columns/labels and mismatched train/test axes for each dataset. Strawberry labels are channel indices only; Grainit/Perten retain physical nm axes; ECAPS uses the frozen common wavenumber interpolation grid.','', 'Timings describe this operational replay with source-digest verification caching and a changed runtime. They are not a controlled performance benchmark and should not be compared directly with old cold/repeated-verification timings. Old artifacts and times remain intact. No LLM conversion, automatic repair or predictive superiority claim is supported.']
 (OUT/'integration-report.md').write_text('\n'.join(report),encoding='utf-8');(OUT/'artifact-manifest.json').write_text(json.dumps({p.name:sha(p) for p in OUT.iterdir() if p.is_file() and p.name!='artifact-manifest.json'},indent=2))
if __name__=='__main__':main()
