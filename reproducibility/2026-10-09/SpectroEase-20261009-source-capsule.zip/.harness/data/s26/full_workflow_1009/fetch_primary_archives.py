"""Fetch immutable primary dataset archives; never extract or alter source members."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile

import requests


ROOT = Path(__file__).resolve().parent
SOURCES = {
    "grainit": {
        "url": "https://zenodo.org/records/15838272/files/sensAIfood_Grainit.zip?download=1",
        "filename": "sensAIfood_Grainit.zip",
        "published_md5": "c90367e4d260943c7076cb3e0409da3a",
        "record": "https://doi.org/10.5281/zenodo.15838272",
    },
    "strawberry": {
        "url": "https://www.timeseriesclassification.com/aeon-toolkit/Strawberry.zip",
        "filename": "Strawberry.zip",
        "published_md5": None,
        "record": "https://www.timeseriesclassification.com/description.php?Dataset=Strawberry",
    },
    "ecaps": {
        "url": "https://github.com/usnistgov/ECAPS/archive/ba21fdc05f78ce7394699aa45b0b87e6f0fad4b4.zip",
        "filename": "ECAPS-ba21fdc05f78ce7394699aa45b0b87e6f0fad4b4.zip",
        "published_md5": None,
        "record": "https://github.com/usnistgov/ECAPS/tree/ba21fdc05f78ce7394699aa45b0b87e6f0fad4b4",
    },
}


def fetch(name: str, spec: dict) -> dict:
    target = ROOT / spec["filename"]
    if target.exists():
        raise FileExistsError(f"Preserved original already exists: {target}")
    partial = target.with_suffix(target.suffix + ".partial")
    sha = hashlib.sha256()
    md5 = hashlib.md5()
    length = 0
    try:
        with requests.get(spec["url"], stream=True, timeout=(20, 60)) as response:
            response.raise_for_status()
            with partial.open("xb") as out:
                for chunk in response.iter_content(1024 * 1024):
                    if not chunk:
                        continue
                    length += len(chunk)
                    if length > 300 * 1024 * 1024:
                        raise ValueError("Archive exceeds 300 MiB budget")
                    out.write(chunk)
                    sha.update(chunk)
                    md5.update(chunk)
            final_url = response.url
            content_type = response.headers.get("content-type", "")
        if spec["published_md5"] and md5.hexdigest() != spec["published_md5"]:
            raise ValueError("Published MD5 mismatch")
        with zipfile.ZipFile(partial) as z:
            bad = z.testzip()
            if bad:
                raise ValueError(f"ZIP CRC mismatch: {bad}")
            members = [i.filename for i in z.infolist() if not i.is_dir()]
        partial.rename(target)
        return {
            "dataset": name,
            "source_record": spec["record"],
            "requested_url": spec["url"],
            "resolved_url": final_url,
            "archive": target.name,
            "bytes": length,
            "sha256": sha.hexdigest(),
            "md5": md5.hexdigest(),
            "published_md5": spec["published_md5"],
            "zip_crc_pass": True,
            "member_count": len(members),
            "members": members,
            "content_type": content_type,
        }
    except Exception:
        partial.unlink(missing_ok=True)
        raise


if __name__ == "__main__":
    results = []
    for name, spec in SOURCES.items():
        try:
            result = fetch(name, spec)
            print(f"{name}: downloaded {result['bytes']} bytes sha256={result['sha256']}", flush=True)
        except Exception as exc:
            result = {"dataset": name, "error": f"{type(exc).__name__}: {exc}"}
            print(f"{name}: {result['error']}", flush=True)
        results.append(result)
    (ROOT / "primary-archive-manifest.json").write_text(
        json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8"
    )
