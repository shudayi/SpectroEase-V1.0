from pathlib import Path
from io import BytesIO
import zipfile,json,hashlib,time,sys,importlib.metadata as md
import numpy as np,pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import Ridge
from sklearn.base import clone
from sklearn.metrics import get_scorer
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parents[3];sys.path.insert(0,str(PROJECT))
from app.services.hyperparameter_optimization_service import HyperparameterOptimizationService
OUT=ROOT/'optuna-functional-evidence'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=[PROJECT/'app/services/hyperparameter_optimization_service.py',PROJECT/'requirements.txt',Path(__file__)]
freeze={str(p.relative_to(PROJECT)):sha(p) for p in files};(OUT/'source-freeze-before-fit.json').write_text(json.dumps(freeze,indent=2))
# A priori fixed functional checks; no paper baseline model changes.
protocol={'classifier':{'dataset':'Strawberry','train':'official TRAIN613','test':'official TEST370','model':'DecisionTreeClassifier random_state42','grid':{'max_depth':[1,3],'min_samples_leaf':2},'cv':3,'trials':6,'score':'balanced_accuracy'},'regressor':{'dataset':'Grainit barley Moisture','train':'frozen R1 fold1 training IDs','test':'same fold held-out IDs','model':'Ridge','grid':{'alpha':[.1,10.]},'cv':3,'trials':6,'score':'neg_mean_squared_error'},'scope':'functional optimizer demonstration, no generalization/model-comparison claim'}
(OUT/'protocol-before-fit.json').write_text(json.dumps(protocol,indent=2))
with zipfile.ZipFile(ROOT/'Strawberry.zip') as z:
 a=np.loadtxt(BytesIO(z.read('Strawberry_TRAIN.txt')));b=np.loadtxt(BytesIO(z.read('Strawberry_TEST.txt')))
cases=[('classifier',DecisionTreeClassifier(random_state=42),a[:,1:],a[:,0].astype(int),b[:,1:],b[:,0].astype(int),[f'TRAIN_row_{i}' for i in range(len(a))],[f'TEST_row_{i}' for i in range(len(b))])]
with zipfile.ZipFile(ROOT/'sensAIfood_Grainit.zip') as z:
 n=next(n for n in z.namelist() if n.lower().startswith('barley') and n.endswith('.csv'));d=pd.read_csv(BytesIO(z.read(n)));s=pd.read_csv(ROOT/'baseline-results-v2/splits.csv');s=s[(s.task=='grainit_barley_Moisture')&(s.repeat=='R1')&(s.fold==1)];a=d[d.ID.astype(str).isin(s[s.partition=='train'].id.astype(str))];b=d[d.ID.astype(str).isin(s[s.partition=='validation'].id.astype(str))]
 cases.append(('regressor',Ridge(),a.iloc[:,8:].to_numpy(float),a.Moisture.to_numpy(float),b.iloc[:,8:].to_numpy(float),b.Moisture.to_numpy(float),a.ID.astype(str).tolist(),b.ID.astype(str).tolist()))
reports=[];preds=[]
for name,estimator,X,y,T,t,ids,testids in cases:
 config=protocol[name];started=time.perf_counter();params,model=HyperparameterOptimizationService().optuna_search(estimator,config['grid'],X,y,cv=config['cv'],n_iter=config['trials'],scoring=config['score'],sample_ids=ids,outer_test_sample_ids=testids);elapsed=time.perf_counter()-started
 # Independently refit chosen configuration on fold rows reconstructed by source IDs.
 scores=[];scorer=get_scorer(config['score']);lookup={v:i for i,v in enumerate(ids)}
 for trace in model.cv_fit_trace_:
  tr=[lookup[i] for i in trace['estimator_fit_sample_ids']];te=[lookup[i] for i in trace['validation_sample_ids']];assert not set(tr)&set(te)
  assert not set(trace['transformer_fit_sample_ids'])&set(testids)
  fitted=clone(model);fitted.fit(X[tr],y[tr]);scores.append(float(scorer(fitted,X[te],y[te])))
 best=max(model.optimization_trials_,key=lambda a:a['mean_score']);difference=abs(np.mean(scores)-best['mean_score']);assert difference<1e-12
 prediction=model.predict(T);preds.extend({'case':name,'source_id':i,'truth':float(v),'prediction':float(p)} for i,v,p in zip(testids,t,prediction))
 reports.append({'case':name,'training_n':len(X),'heldout_n':len(T),'elapsed_seconds':elapsed,'best_params':params,'metadata':model.optimization_metadata_,'trials':model.optimization_trials_,'fit_trace':model.cv_fit_trace_,'refit_ids':model.refit_sample_ids_,'outer_test_ids':testids,'independent_best_cv_mean_score':float(np.mean(scores)),'max_score_reconstruction_difference':difference})
 assert all(t['parameters'].get('estimator__max_depth',1) in [1,3] for t in model.optimization_trials_) if name=='classifier' else all(t['parameters']['estimator__alpha'] in [.1,10.] for t in model.optimization_trials_)
(OUT/'real-optuna-studies.json').write_text(json.dumps(reports,indent=2));pd.DataFrame(preds).to_csv(OUT/'heldout-functional-predictions.csv',index=False)
assert freeze=={str(p.relative_to(PROJECT)):sha(p) for p in files};(OUT/'source-freeze-after-fit.json').write_text(json.dumps(freeze,indent=2))
print(json.dumps([{'case':r['case'],'train':r['training_n'],'heldout':r['heldout_n'],'trials':len(r['trials']),'independent_difference':r['max_score_reconstruction_difference']} for r in reports]))
