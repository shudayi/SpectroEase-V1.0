# Execution notes

First paired attempt stopped during selection candidate schema validation because experiment used unsupported `min`/`max` fields. Changed only schema keys to the service contract `minimum`/`maximum`, before any real dataset fit. Candidate implementation and frozen algorithm choices unchanged. Rejected attempt was a script integration error, not a numerical algorithm failure. Successful rerun freezes updated script hash.
Second pre-fit attempt also rejected short type int; corrected to declared integer schema type. No real data model fit occurred.
