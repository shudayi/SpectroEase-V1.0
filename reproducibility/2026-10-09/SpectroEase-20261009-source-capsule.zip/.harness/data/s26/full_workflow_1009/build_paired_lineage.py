from pathlib import Path
import zipfile,hashlib,json
from io import BytesIO
import numpy as np,pandas as pd
r=Path(__file__).resolve().parent;out=r/'paired-study-final';rows=[]
with zipfile.ZipFile(r/'Strawberry.zip') as z:
 for part,split,count in [('train','TRAIN',16),('probe','TEST',8)]:
  a=np.loadtxt(BytesIO(z.read(f'Strawberry_{split}.txt')));indices=np.concatenate([np.flatnonzero(a[:,0]==c)[:count] for c in [1,2]])
  for i,k in enumerate(indices):rows.append({'dataset':'strawberry','partition':part,'workflow_synthetic_id':f'{"train" if part=="train" else "test"}:{i}','source_id':f'{split}_row_{k}','group':f'{split}_row_{k}','original_zero_based_row':int(k),'source_member':f'Strawberry_{split}.txt'})
for name,archive in [('grainit',r/'sensAIfood_Grainit.zip'),('perten',r.parent/'sensaifood_perten_zenodo_v1/sensAIfood_Perten.zip')]:
 with zipfile.ZipFile(archive) as z:
  n=next(n for n in z.namelist() if n.lower().startswith('barley') and n.endswith('.csv'));d=pd.read_csv(BytesIO(z.read(n)))
  if name=='grainit':
   s=pd.read_csv(r/'baseline-results-v2/splits.csv');s=s[(s.task=='grainit_barley_Moisture')&(s.repeat=='R1')&(s.fold==1)]
   parts=[('train',d[d.ID.astype(str).isin(s[s.partition=='train'].id.astype(str))].iloc[:32]),('probe',d[d.ID.astype(str).isin(s[s.partition=='validation'].id.astype(str))].iloc[:16])]
  else:parts=[('train',d.iloc[:32]),('probe',d.iloc[32:48])]
  for part,frame in parts:
   for i,(k,row) in enumerate(frame.iterrows()):rows.append({'dataset':name,'partition':part,'workflow_synthetic_id':f'{"train" if part=="train" else "test"}:{i}','source_id':str(row.ID),'group':str(row.ID),'original_zero_based_row':int(k),'source_member':n})
with zipfile.ZipFile(next(r.glob('ECAPS-*.zip'))) as z:
 info=pd.read_csv(BytesIO(z.read(next(n for n in z.namelist() if n.endswith('/Data/SampleInformation.csv'))))).set_index('Sample');s=pd.read_csv(r/'baseline-results-v2/splits.csv');s=s[(s.task=='ecaps')&(s.repeat=='R1')&(s.fold==1)]
 for part,count in [('train',2),('probe',1)]:
  groups=sorted(s[s.partition==('train' if part=='train' else 'validation')].group.unique());chosen=[]
  for label in ['PE','PP']:chosen.extend([g for g in groups if info.loc[g,'Class1']==label][:count])
  names=sorted(n for n in z.namelist() if '/Data/NIR/' in n and n.endswith('.csv') and Path(n).stem.rsplit('_',1)[0] in chosen)
  for i,n in enumerate(names):rows.append({'dataset':'ecaps','partition':part,'workflow_synthetic_id':f'{"train" if part=="train" else "test"}:{i}','source_id':Path(n).stem,'group':Path(n).stem.rsplit('_',1)[0],'source_member':n})
d=pd.DataFrame(rows)
for name,g in d.groupby('dataset'):assert not set(g[g.partition=='train'].group)&set(g[g.partition=='probe'].group)
d.to_csv(out/'source-subset-lineage.csv',index=False)
(out/'source-subset-lineage-note.md').write_text('This sidecar deterministically reconstructs actual archive row IDs/groups in execution order. Saved workflow objects themselves use synthetic train:i/test:i identifiers; no source-row lineage claim is made for those objects alone. ECAPS physical specimen IDs are disjoint across train/probe and all seven scans retained. Strawberry row indices are zero-based within original official files. Grainit/Perten IDs are record IDs, not proven physical replicate groups.',encoding='utf-8')
print(d.groupby(['dataset','partition']).size())
