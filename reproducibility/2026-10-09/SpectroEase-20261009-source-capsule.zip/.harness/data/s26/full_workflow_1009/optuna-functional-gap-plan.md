# Optuna functional gap plan — waiting for GUI freeze release

Scope: true Optuna 4.9.0 search and truthful engine reporting. No predictive baseline model or paper result changes.

Observed defects: absent Optuna silently invokes GridSearchCV while user sees Bayesian optimization; numeric lists of exactly two declared candidates are interpreted as continuous/integer bounds, introducing undeclared values. Constant parameters are not present in study.best_params and can be lost during final refit. Trial/fold numerical failures can become NaN results without a clear gate.

After root releases frozen regression:
1. Save runtime package versions; install only missing official downloaded dependencies offline. Preserve numpy2.3.3, packaging25.0, typing_extensions4.15.0 and all other installed versions. Pin newly installed Optuna/alembic/colorlog/Mako/MarkupSafe/PyYAML/SQLAlchemy/tqdm and existing colorama0.4.6 used on Windows. Validate pip check.
2. Require Optuna with actionable dependency error if unavailable; no automatic substitution. Treat declared list/tuple values as categorical candidates including exactly two numeric entries. Preserve fixed scalar params in final refit and recorded effective trial parameters. Use deterministic TPE seed42 with bounded startup count so budgets>1 enter TPE phase. Retain train-only preprocessing, group splits, sample IDs and outer-test exclusion.
3. Attach engine/version/sampler/seed/scoring/trial count, trial scores and effective params; expose cv_results to caller; reject empty spaces/zero budgets/nonfinite objective.
4. Focused tests: two numeric candidates never invent intermediate values; scalar refit persists; classifier/regressor real Optuna trials with actual fold-local preprocessing fit observations; missing dependency clear error; outer-test overlap/group violation blocked; stable metadata and negative scoring handling.
5. Real-data feature test: Strawberry official TRAIN classifier and Grainit barley Moisture regressor, frozen model/grid/budgets and training-only IDs; save trial params/fold scores/predictions, source/runtime hashes. No accuracy superiority or Bayesian convergence claim.

Offline wheels inspected: current downloaded newer numpy/packaging/typing_extensions are unnecessary and will not be installed. Installed versions meet declared package metadata requirements. Frozen GUI run must finish before service, tests, requirements or runtime mutations.
