# Current-source paired integration replay

Fixed four-collection subsets replayed after axis binding and verification cache updates in the Optuna-enabled runtime. Original candidate identities and subsets were preserved. All four independent numerical/class references and previous predictions matched; fresh-service JSON persistence replay was exact. Actual source row/file IDs are now directly in saved workflow fit traces and train/test provenance. ECAPS physical specimen groups remain disjoint; Grainit/Perten record IDs do not establish physical replicate independence.

| Collection | Train / probe | Max reference discrepancy | Fit/predict/metric seconds | Save/fresh-load/replay seconds |
|---|---:|---:|---:|---:|
| strawberry | 32 / 16 | 0 | 35.613 | 23.793 |
| grainit | 32 / 16 | 7.19e-13 | 23.649 | 26.547 |
| perten | 32 / 16 | 1.39e-12 | 15.972 | 26.978 |
| ecaps | 28 / 14 | 0 | 16.822 | 25.655 |

Eight ordered-axis negative checks were rejected: reversed prediction columns/labels and mismatched train/test axes for each dataset. Strawberry labels are channel indices only; Grainit/Perten retain physical nm axes; ECAPS uses the frozen common wavenumber interpolation grid.

Timings describe this operational replay with source-digest verification caching and a changed runtime. They are not a controlled performance benchmark and should not be compared directly with old cold/repeated-verification timings. Old artifacts and times remain intact. No LLM conversion, automatic repair or predictive superiority claim is supported.