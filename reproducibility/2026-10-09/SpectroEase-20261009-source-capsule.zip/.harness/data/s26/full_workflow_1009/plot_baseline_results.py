"""Publication figures from frozen persisted predictions and metric records."""
from pathlib import Path
import hashlib
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'baseline-results-v2'
OUT = ROOT / 'figures'


def main():
    OUT.mkdir(exist_ok=True)
    records = json.loads((DATA / 'metrics.json').read_text())
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 14,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'svg.fonttype': 'none', 'pdf.fonttype': 42})
    selected = [next(r for r in records if r['task'] == task and r['repeat'] == repeat
                     and r['unit'] == unit and r['method'] == 'prediction')
                for task, repeat, unit in [('ecaps', 'R1', 'entity'), ('ecaps', 'R2', 'entity'),
                                          ('strawberry', 'official_test', 'record')]]
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.8), layout='constrained')
    for index, (ax, r) in enumerate(zip(axes, selected)):
        counts = np.asarray(r['confusion_matrix'])
        fractions = counts / counts.sum(axis=1, keepdims=True)
        ax.imshow(fractions, vmin=0, vmax=1, cmap='Blues')
        ax.set_xticks(range(2), r['labels']); ax.set_yticks(range(2), r['labels'])
        ax.set_xlabel('Predicted class'); ax.set_ylabel('Reference class')
        for i in range(2):
            for j in range(2):
                ax.text(j, i, f'{counts[i,j]}\n{fractions[i,j]:.1%}', ha='center', va='center',
                        color='white' if fractions[i,j] > .55 else '#132a3c')
        title = f'ECAPS {r["repeat"]} · 45 entities' if r['task'] == 'ecaps' else 'Strawberry (official test)'
        ax.set_title(f'{chr(97+index)}  {title}\nBA {r["balanced_accuracy"]:.3f} · macro-F1 {r["macro_f1"]:.3f}', fontsize=13)
    save(fig, 'classification-baselines')
    fig, axes = plt.subplots(2, 3, figsize=(10.5, 6.7), layout='constrained')
    for row, target in enumerate(['Moisture', 'Protein']):
        for col, cereal in enumerate(['barley', 'corn', 'wheat']):
            ax = axes[row, col]
            task = f'grainit_{cereal}_{target}'
            values = [next(r for r in records if r['task'] == task and r['repeat'] == rep and r['method'] == method)
                      for rep in ['R1', 'R2'] for method in ['prediction', 'baseline']]
            for k, rep in enumerate(['R1', 'R2']):
                pair = values[2*k:2*k+2]
                for m, record in enumerate(pair):
                    ax.bar(k + (-.18 if m == 0 else .18), record['RMSE'], width=.32,
                           color=['#245a81', '#b5bdc6'][m], label=['PLSR (3 components)', 'Training-mean baseline'][m] if row == col == k == 0 else None)
                ax.text(k-.18, pair[0]['RMSE'], f'{pair[0]["RMSE"]:.2f}', ha='center', va='bottom', fontsize=13)
            ax.set_xticks([0,1], ['R1','R2']); ax.set_ylabel('RMSE (percentage points)')
            ax.set_title(f'{chr(97+row*3+col)}  {cereal.capitalize()} · {target.lower()}', fontsize=13)
            ax.margins(y=.25); ax.grid(axis='y', alpha=.15); ax.set_axisbelow(True)
    fig.legend(*axes[0,0].get_legend_handles_labels(), loc='outside lower center', ncol=2, frameon=False)
    save(fig, 'grainit-baseline-errors')
    provenance = {'input': str(DATA / 'metrics.json'), 'sha256': hashlib.sha256((DATA/'metrics.json').read_bytes()).hexdigest(),
                  'scope': 'Built-in baselines; ECAPS entity vote and fixed official Strawberry holdout; Grainit within-collection record CV.',
                  'outputs': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.suffix in {'.png','.pdf','.svg'}}}
    (OUT/'provenance.json').write_text(json.dumps(provenance, indent=2), encoding='utf-8')


def save(fig, name):
    for extension in ['png', 'pdf', 'svg']:
        fig.savefig(OUT/f'{name}.{extension}', dpi=300, bbox_inches='tight', pad_inches=0.12)
    plt.close(fig)


if __name__ == '__main__':
    main()
