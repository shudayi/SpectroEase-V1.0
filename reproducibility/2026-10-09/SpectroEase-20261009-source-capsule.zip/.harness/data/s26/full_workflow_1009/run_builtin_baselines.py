from pathlib import Path
from io import BytesIO
import zipfile,json,hashlib,sys,platform,os
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold,StratifiedKFold,KFold
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.cross_decomposition import PLSRegression
from sklearn.metrics import balanced_accuracy_score,f1_score,confusion_matrix,mean_squared_error,mean_absolute_error,r2_score
ROOT=Path(__file__).resolve().parent
PLAN_ONLY=os.environ.get('SPECTRO_PLAN_ONLY')=='1'
OUT=ROOT/'baseline-results-v2';OUT.mkdir(exist_ok=True)
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze={'protocol_sha256':hashfile(ROOT/'candidate-protocol.yaml'),'script_sha256':hashfile(Path(__file__)),'source_manifest_sha256':hashfile(ROOT/'primary-archive-manifest.json'),'python':sys.version,'platform':platform.platform()}
(OUT/'freeze-before-fit.json').write_text(json.dumps(freeze,indent=2))
rows=[];splits=[];traces=[];metrics=[];axis_audit=[]
def classify(task,X,y,ids,groups,plans):
 for rep,fold,tr,te in plans:
  assert not set(groups[tr])&set(groups[te])
  splits.extend({'task':task,'repeat':rep,'fold':fold,'id':str(ids[i]),'group':str(groups[i]),'partition':part} for part,ii in [('train',tr),('validation',te)] for i in ii)
  if PLAN_ONLY:continue
  model=make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),LogisticRegression(C=1,class_weight='balanced',solver='lbfgs',max_iter=2000))
  model.fit(X[tr],y[tr]);pred=model.predict(X[te]);base=np.full(len(te),pd.Series(y[tr]).mode().iloc[0])
  traces.append({'task':task,'repeat':rep,'fold':fold,'train_rows':len(tr),'validation_rows':len(te),'train_group_count':len(set(groups[tr])),'validation_group_count':len(set(groups[te])),'fit_only_training':True,'features':X.shape[1]})
  rows.extend({'task':task,'repeat':rep,'fold':fold,'id':str(ids[i]),'group':str(groups[i]),'truth':str(y[i]),'prediction':str(p),'baseline':str(b)} for i,p,b in zip(te,pred,base))
def regression(task,X,y,ids):
 for rep,seed in [('R1',20261009),('R2',20261010)]:
  for fold,(tr,te) in enumerate(KFold(5,shuffle=True,random_state=seed).split(X),1):
   assert not set(ids[tr])&set(ids[te])
   splits.extend({'task':task,'repeat':rep,'fold':fold,'id':str(ids[i]),'group':str(ids[i]),'partition':part} for part,ii in [('train',tr),('validation',te)] for i in ii)
   if PLAN_ONLY:continue
   model=make_pipeline(SimpleImputer(strategy='median'),PLSRegression(n_components=3,scale=True))
   model.fit(X[tr],y[tr]);pred=model.predict(X[te]).ravel();base=np.full(len(te),np.mean(y[tr]))
   traces.append({'task':task,'repeat':rep,'fold':fold,'train_rows':len(tr),'validation_rows':len(te),'fit_only_training':True,'features':X.shape[1]})
   rows.extend({'task':task,'repeat':rep,'fold':fold,'id':str(ids[i]),'group':str(ids[i]),'truth':float(y[i]),'prediction':float(p),'baseline':float(b)} for i,p,b in zip(te,pred,base))
with zipfile.ZipFile(next(ROOT.glob('ECAPS-*.zip'))) as z:
 info=pd.read_csv(BytesIO(z.read(next(n for n in z.namelist() if n.endswith('/Data/SampleInformation.csv'))))).set_index('Sample')
 names=sorted(n for n in z.namelist() if '/Data/NIR/' in n and n.endswith('.csv') and 'Placeholder' not in n)
 grid=np.arange(4000,9996,5);X=[];groups=[]
 for n in names:
  a=np.loadtxt(BytesIO(z.read(n)),delimiter=',');a=a[np.argsort(a[:,0])]
  assert np.isfinite(a).all() and np.all(np.diff(a[:,0])>0) and a[0,0]<=grid[0] and a[-1,0]>=grid[-1]
  axis_audit.append({'file':n,'points':len(a),'minimum':a[0,0],'maximum':a[-1,0],'no_extrapolation':True})
  X.append(np.interp(grid,a[:,0],a[:,1]));groups.append(Path(n).stem.rsplit('_',1)[0])
 X=np.array(X);groups=np.array(groups);ids=np.array([Path(n).stem for n in names]);y=np.array([info.loc[g,'Class1'] for g in groups])
 plans=[]
 for rep,seed in [('R1',20261009),('R2',20261010)]:
  plans.extend((rep,f,tr,te) for f,(tr,te) in enumerate(StratifiedGroupKFold(3,shuffle=True,random_state=seed).split(X,y,groups),1))
 (OUT/'ecaps-axis-audit.json').write_text(json.dumps(axis_audit,indent=2))
 classify('ecaps',X,y,ids,groups,plans)
with zipfile.ZipFile(ROOT/'Strawberry.zip') as z:
 train=np.loadtxt(BytesIO(z.read('Strawberry_TRAIN.txt')));test=np.loadtxt(BytesIO(z.read('Strawberry_TEST.txt')))
 X=np.vstack([train[:,1:],test[:,1:]]);y=np.concatenate([train[:,0],test[:,0]]).astype(int);ids=np.array([f'TRAIN_{i}' for i in range(len(train))]+[f'TEST_{i}' for i in range(len(test))]);plans=[]
 for rep,seed in [('R1',20261009),('R2',20261010)]:
  plans.extend((rep,f,tr,te) for f,(tr,te) in enumerate(StratifiedKFold(5,shuffle=True,random_state=seed).split(train[:,1:],train[:,0]),1))
 plans.append(('official_test',1,np.arange(len(train)),np.arange(len(train),len(X))))
 classify('strawberry',X,y,ids,ids,plans)
with zipfile.ZipFile(ROOT/'sensAIfood_Grainit.zip') as z:
 for n in sorted(z.namelist()):
  if not n.endswith('.csv'):continue
  d=pd.read_csv(BytesIO(z.read(n)));X=d.iloc[:,8:].to_numpy(float);ids=d.ID.astype(str).to_numpy();assert len(set(ids))==len(ids)
  for target in ['Moisture','Protein']:regression('grainit_'+n.split('_')[0].lower()+'_'+target,X,d[target].to_numpy(float),ids)
if PLAN_ONLY:
 pd.DataFrame(splits).to_csv(OUT/'planned-splits-before-any-fit.csv',index=False)
 print('All splits persisted before any model fit');sys.exit(0)
assert (OUT/'planned-splits-before-any-fit.csv').exists()
assert pd.read_csv(OUT/'planned-splits-before-any-fit.csv').astype(str).equals(pd.DataFrame(splits).astype(str))
pd.DataFrame(rows).to_csv(OUT/'predictions.csv',index=False);pd.DataFrame(splits).to_csv(OUT/'splits.csv',index=False);pd.DataFrame(traces).to_csv(OUT/'fit-traces.csv',index=False)
# Metrics deliberately rebuilt from persisted predictions, not model objects.
d=pd.read_csv(OUT/'predictions.csv',dtype={'truth':str,'prediction':str,'baseline':str})
for (task,rep),g in d.groupby(['task','repeat']):
 for unit in (['scan','entity'] if task=='ecaps' else ['record']):
  if unit=='entity':
   g1=g.groupby('group').agg({'truth':'first','prediction':lambda s:s.mode().iloc[0],'baseline':lambda s:s.mode().iloc[0]})
  else:g1=g
  for method in ['prediction','baseline']:
   a=g1.truth.to_numpy();b=g1[method].to_numpy();r={'task':task,'repeat':rep,'unit':unit,'method':method,'n':len(a)}
   if task.startswith('grainit'):
    a=a.astype(float);b=b.astype(float);r.update(RMSE=float(np.sqrt(mean_squared_error(a,b))),MAE=float(mean_absolute_error(a,b)),R2=float(r2_score(a,b)))
   else:r.update(balanced_accuracy=float(balanced_accuracy_score(a,b)),macro_f1=float(f1_score(a,b,average='macro')),labels=sorted(set(a)),confusion_matrix=confusion_matrix(a,b).tolist())
   metrics.append(r)
(OUT/'metrics.json').write_text(json.dumps(metrics,indent=2))
assert freeze['protocol_sha256']==hashfile(ROOT/'candidate-protocol.yaml')
(OUT/'completion-manifest.json').write_text(json.dumps({'status':'completed_builtin_baseline_only','files':{p.name:hashfile(p) for p in OUT.iterdir() if p.is_file() and p.name!='completion-manifest.json'},'prediction_rows':len(d),'perten':'Prior frozen results retained unmodified; no new Perten fit.'},indent=2))
print(json.dumps({'prediction_rows':len(d),'metrics':len(metrics),'fit_traces':len(traces)}))
