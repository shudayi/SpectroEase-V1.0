"""Diagram of the implemented five-role acceptance and fitted execution route."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

OUT = Path(__file__).resolve().parent / 'figures'


def main():
    OUT.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'pdf.fonttype': 42, 'svg.fonttype': 'none'})
    fig, ax = plt.subplots(figsize=(6.7, 6.3), layout='constrained')
    ax.set(xlim=(0, 10.5), ylim=(0, 10.0)); ax.axis('off')
    def box(x, y, w, h, title, detail, color='#eaf1f6'):
        ax.add_patch(FancyBboxPatch((x,y), w,h, boxstyle='round,pad=0.05,rounding_size=0.08', facecolor=color, edgecolor='#7790a2', linewidth=1))
        ax.text(x+w/2, y+h-.27, title, ha='center', va='top', weight='bold', color='#193d57', fontsize=10)
        ax.text(x+w/2, y+h-.65, detail, ha='center', va='top', linespacing=1.45, fontsize=9)
    def arrow(a,b):
        ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='->',color='#425967',lw=1.4))
    box(.1,7.4,4.65,2.15,'1  Candidate and reference','Python source + parameters\nTraining / probe fixtures\nIndependent expected output')
    box(5.65,7.4,4.65,2.15,'2  Contract verification','Interface and numeric checks\nShape / index / state replay\nFixed-row invariance')
    box(5.65,4.5,4.65,2.15,'3  Explicit acceptance','Exact configuration approval\nVersioned JSON record\nReload and reverify')
    box(.1,4.5,4.65,2.15,'4  Fitted execution','Fit on training partition\nTransform / predict new rows\nSaved JSON state replay')
    arrow((4.8,8.45),(5.6,8.45)); arrow((7.97,7.35),(7.97,6.7)); arrow((5.6,5.55),(4.8,5.55))
    ax.text(5.15,3.9,'Failed checks prevent acceptance.\nCandidate edits require new verification.',ha='center',va='center',fontsize=9)
    box(.1,1.5,4.65,1.85,'Supported operator contracts','Fitted preprocessing · Feature selection\nClassification · Regression\nScalar metrics','#f3f6f8')
    box(5.65,1.5,4.65,1.85,'Partition and persistence','Fresh state per supplied fold\nDisjoint row / entity IDs\nHashes and ordered saved stages','#f3f6f8')
    ax.text(5.25,.7,'Trusted code runs in bounded child processes.\nThis is not an operating-system security sandbox.',ha='center',fontsize=9,color='#46525b')
    for ext in ['png','pdf','svg']:
        fig.savefig(OUT/f'verified-five-role-architecture.{ext}',dpi=300)
    plt.close(fig)


if __name__ == '__main__':main()
