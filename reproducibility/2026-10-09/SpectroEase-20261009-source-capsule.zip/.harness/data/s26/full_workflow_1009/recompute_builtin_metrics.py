from pathlib import Path
import json,numpy as np,pandas as pd
r=Path(__file__).resolve().parent/'baseline-results-v2';d=pd.read_csv(r/'predictions.csv',dtype={'truth':str,'prediction':str,'baseline':str});m=json.loads((r/'metrics.json').read_text());errors=[]
for a in m:
 g=d[(d.task==a['task'])&(d.repeat==a['repeat'])]
 if a['unit']=='entity':g=g.groupby('group').agg({'truth':'first','prediction':lambda s:s.mode().iloc[0],'baseline':lambda s:s.mode().iloc[0]})
 y=g.truth.to_numpy();p=g[a['method']].to_numpy()
 if a['task'].startswith('grainit'):
  y=y.astype(float);p=p.astype(float);e=y-p;got={'RMSE':np.sqrt(np.mean(e*e)),'MAE':np.mean(abs(e)),'R2':1-np.sum(e*e)/np.sum((y-y.mean())**2)}
 else:
  labels=sorted(set(y));cm=np.array([[sum((y==i)&(p==j)) for j in labels] for i in labels]);got={'balanced_accuracy':np.mean(np.diag(cm)/cm.sum(axis=1)),'macro_f1':np.mean(2*np.diag(cm)/(cm.sum(axis=0)+cm.sum(axis=1)))};assert cm.tolist()==a['confusion_matrix']
 errors.extend(abs(float(v)-a[k]) for k,v in got.items())
s=pd.read_csv(r/'splits.csv');folds=0
for _,g in s.groupby(['task','repeat','fold']):
 assert not set(g[g.partition=='train'].group)&set(g[g.partition=='validation'].group);folds+=1
out={'metrics_records_checked':len(m),'max_absolute_metric_difference':max(errors),'disjoint_folds_checked':folds,'ecaps_scan_to_entity_counts':d[d.task=='ecaps'].groupby(['repeat','group']).size().value_counts().to_dict(),'status':'pass'}
(r/'independent-recomputation.json').write_text(json.dumps(out,indent=2));print(out)
lines=['# Built-in baseline results (2026-10-09)','', 'Protocol and all split assignments were saved before the v2 fit pass. Initial baseline-results run retained for transparency: it froze protocol but only persisted splits after fits; v2 corrects that evidence-order issue with a planning-only pass. No model or hyperparameter changed. Official Strawberry test was consequently replayed for artifact reconstruction, with no tuning or selection using its results.','', 'These are built-in sklearn reference pipelines, not evidence of accepted plugin execution. Perten prior six-task results remain untouched. ECAPS all 315 axes checked finite, strictly increasing after sorting, and covering 4000–9995 cm^-1; interpolation does not extrapolate. R1/R2 are resampling plans on the same collection. Grainit record IDs are the only available independence unit; physical replicates cannot be ruled out.','', '| Task | Repeat | Unit | n | Results |','|---|---|---|---:|---|']
for a in m:
 if a['method']!='prediction' or (a['task']=='ecaps' and a['unit']=='scan'):continue
 vals=(f"BA={a['balanced_accuracy']:.4f}, macro-F1={a['macro_f1']:.4f}" if 'balanced_accuracy'in a else f"RMSE={a['RMSE']:.4f}, MAE={a['MAE']:.4f}, R²={a['R2']:.4f}")
 lines.append(f"| {a['task']} | {a['repeat']} | {a['unit']} | {a['n']} | {vals} |")
lines+=['',f"Independent persisted-prediction recomputation: {len(m)} metric records, {folds} disjoint folds, maximum absolute discrepancy {max(errors):.3g}.",'','Do not claim external-cohort validation, automatic algorithm conversion, or physical monitor testing from these results. Grainit workbook target units and surprising method labels remain as documented in dataset-manifest.json.']
(r/'baseline-report.md').write_text('\n'.join(lines),encoding='utf-8')
