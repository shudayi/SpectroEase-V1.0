# S26-61 SensAIfood predictive-analysis protocol

**Frozen before predictive fits:** 2026-10-01  
**Dataset:** SensAIfood Perten cereal NIR release, Zenodo record 10.5281/zenodo.15838136, CC BY 4.0.  
**Source audit:** `sensaifood_perten_zenodo_v1/S26_SENSAIFOOD_DATA_AUDIT.md`

## Questions and scope

This analysis will test the application's sample-identity, fold-local fitting, raw-spectrum prediction, evaluation, and figure-export paths on a public NIR dataset. It is a software workflow evaluation, not a claim of external instrument generalization or a new chemometric method.

The three source files (barley, corn, wheat) will be analyzed separately. Each contains 150 records, 141 spectral channels, and a unique source `ID`. The source IDs are sample-record keys; they will not be described as replicate, parent-sample, or instrument-group identifiers. Instrument, cereal, variety, country, year, and all other metadata will be excluded from predictive features.

## Frozen outcomes and models

- Primary response: the source `Moisture` field, described by the dataset as `% moisture` and on a dry-basis note. Preserve its raw values; do not transform the response or silently reinterpret the basis.
- Secondary exploratory response: the source `Protein` field. Preserve the raw label and values. Because the metadata's basis note is ambiguous, report prediction errors in source target units and do not make absolute compositional comparisons.
- Spectral predictors: the 141 numeric wavelength columns only, preserving the original 950–1650 nm, 5 nm axis.
- Model: application PLS regression with a fixed three latent components; no hyperparameter tuning or wavelength selection.
- Reference baseline: for each fold, predict the training-fold mean response for every validation row.
- Validation: deterministic five-fold `GroupKFold` using the verified source `ID` values as identity keys. IDs must not enter X, and each ID must appear in exactly one validation fold. Since all IDs are unique, this checks record-level separation only; it does not establish repeated-measurement or domain-group separation.
- Fit scope: only the four training folds may fit feature/target scaling and the PLS estimator. Apply those fitted transforms unchanged to the held-out fold. If the active application's route cannot demonstrate this fit scope, stop and report the model evaluation unavailable.

## Reported quantities

For each of the six cereal-by-response combinations, save one out-of-fold prediction per source ID and report pooled out-of-fold RMSE, MAE, and R-squared for PLS and the mean baseline. Also save fold-wise metrics and the exact train/validation ID lists. No confidence interval, significance test, or cross-instrument claim is planned.

## Execution and artifacts

Run each analysis through the active SpectroEase GUI/model/evaluation path after S26-35 passes. Preserve original inputs and record their SHA-256 hashes, application version, Python and dependency versions, model configuration, row/feature mapping, split memberships, fold-fit traces, raw predictions, and exported figure sidecars. Generate figures from the application result objects and use the fixed journal-friendly export profile; do not describe the export as Nature-certified.

If sample IDs, axis order, fold membership, fold-fit trace, prediction/metric parity, or target semantics fail review, stop the predictive analysis and retain only the verified import/structure results.
