"""Gated SensAIfood S26-61 analysis runner.

By default this script prints a plan and does not import datasets or fit models.
Model fitting requires both an explicit ``--execute`` and an S26-35 PASS in the
workflow YAML. Do not run ``--execute`` until the analysis gate is released.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import shutil
import sys
import tempfile
from datetime import datetime, timezone


SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parents[2]
WORKFLOW_PATH = REPO_ROOT / ".harness/team/workflows/spectroease_2026_dynamic_workflow.yaml"
SOURCE_DIR = SCRIPT_DIR / "sensaifood_perten_zenodo_v1/source_files"
OUTPUT_ROOT = REPO_ROOT / ".harness/team/evidence/s26/science/s26-61-predictions"
EXPECTED_METADATA = [
    "ID", "Spectrometer", "Cereal", "Variety", "Country", "Year", "Moisture", "Protein"
]
WAVELENGTH_COLUMNS = [str(value) for value in range(950, 1651, 5)]
CEREALS = ("Barley", "Corn", "Wheat")
TARGETS = ("Moisture", "Protein")
N_OUTER_FOLDS = 5
PLS_COMPONENTS = 3
REGRESSION_METRICS = ("rmse", "mae", "r2")


def _read_s26_35_gate() -> None:
    """Refuse to load data or fit unless the independent gate is fully passed."""
    try:
        import yaml
    except ImportError as exc:  # pragma: no cover - depends on installed runtime
        raise RuntimeError("PyYAML is required to verify the S26-35 execution gate") from exc
    workflow = yaml.safe_load(WORKFLOW_PATH.read_text(encoding="utf-8"))
    task = next((item for item in workflow.get("tasks", []) if item.get("id") == "S26-35"), None)
    if task is None:
        raise RuntimeError("S26-35 is absent from the workflow; predictive analysis is locked")
    required = {
        "status": "completed",
        "review_status": "completed",
        "review_verdict": "pass",
    }
    mismatches = {
        key: {"required": value, "actual": task.get(key)}
        for key, value in required.items()
        if str(task.get(key, "")).lower() != value
    }
    if mismatches:
        raise RuntimeError(
            "S26-35 independent PASS is not recorded; no dataset will be loaded and no model fitted. "
            + json.dumps(mismatches, ensure_ascii=False)
        )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_safe(value):
    """Convert numpy/pandas scalars and nested structures to JSON values."""
    if hasattr(value, "item"):
        try:
            return _json_safe(value.item())
        except (ValueError, TypeError):
            pass
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def _assert_same_metrics(left, right, context: str) -> None:
    for metric in REGRESSION_METRICS:
        if metric not in left or metric not in right:
            raise AssertionError(f"{context}: missing {metric} in {left!r} or {right!r}")
        if not math.isclose(float(left[metric]), float(right[metric]), rel_tol=1e-10, abs_tol=1e-12):
            raise AssertionError(
                f"{context}: {metric} differs ({left[metric]!r} != {right[metric]!r})"
            )


def _version(distribution: str) -> str:
    try:
        return importlib.metadata.version(distribution)
    except importlib.metadata.PackageNotFoundError:
        return "not-installed-as-distribution"


def run_analysis() -> Path:
    # This gate is deliberately before app imports, source reads, output creation,
    # or any fit call.
    _read_s26_35_gate()

    import numpy as np
    import pandas as pd
    from sklearn.model_selection import GroupKFold

    # Import application services only after the scientific exit gate passes.
    sys.path.insert(0, str(REPO_ROOT))
    from app.services.data_service import DataService
    from app.services.modeling_service import ModelingService
    from app.services.prediction_contract import PredictionResult
    from app.version import APP_VERSION, APP_VERSION_SOURCE

    data_service = DataService(plugins={})
    modeling_service = ModelingService(plugins={})
    evaluation_service = modeling_service.evaluation_service
    source_paths = {
        cereal: SOURCE_DIR / f"{cereal}_sensAIfood_Perten.csv" for cereal in CEREALS
    }
    source_hashes_before = {cereal: _sha256(path) for cereal, path in source_paths.items()}
    completed = {}

    for cereal, source_path in source_paths.items():
        frame = data_service.load_data(str(source_path))
        if frame.shape != (150, 149):
            raise AssertionError(f"{cereal}: expected source shape (150, 149), got {frame.shape}")
        if list(frame.columns[:8]) != EXPECTED_METADATA:
            raise AssertionError(f"{cereal}: unexpected metadata/target column order")
        feature_columns = [str(column) for column in frame.columns[8:]]
        if feature_columns != WAVELENGTH_COLUMNS:
            raise AssertionError(f"{cereal}: wavelength axis/order differs from frozen 950–1650 nm axis")

        source_id_values = frame["ID"].tolist()
        sample_ids = [str(value).strip() for value in source_id_values]
        if any(not value for value in sample_ids) or len(set(sample_ids)) != len(sample_ids):
            raise AssertionError(f"{cereal}: source IDs are blank or non-unique after string normalization")
        if len(sample_ids) != 150:
            raise AssertionError(f"{cereal}: expected 150 source record IDs")

        # The predictive matrix is built only from the 141 wavelength fields.
        X = frame.loc[:, feature_columns].apply(pd.to_numeric, errors="raise").astype(float)
        X.index = pd.Index(sample_ids, name="sample_id")
        if list(map(str, X.columns)) != WAVELENGTH_COLUMNS:
            raise AssertionError(f"{cereal}: metadata/ID leaked into X or wavelength order changed")
        if X.shape != (150, 141) or not np.isfinite(X.to_numpy(dtype=float)).all():
            raise AssertionError(f"{cereal}: X is not a finite 150 x 141 raw-spectrum matrix")
        if set(EXPECTED_METADATA).intersection(map(str, X.columns)):
            raise AssertionError(f"{cereal}: metadata or ID field found in X")

        for target in TARGETS:
            y_values = pd.to_numeric(frame[target], errors="raise").to_numpy(dtype=float)
            if y_values.shape != (150,) or not np.isfinite(y_values).all():
                raise AssertionError(f"{cereal}/{target}: target must contain 150 finite source values")
            y = pd.Series(y_values, index=X.index, name=target)
            pls_predictions = np.full(len(sample_ids), np.nan, dtype=float)
            baseline_predictions = np.full(len(sample_ids), np.nan, dtype=float)
            fold_assignment = np.zeros(len(sample_ids), dtype=int)
            fold_details = []

            splitter = GroupKFold(n_splits=N_OUTER_FOLDS)
            for fold_number, (train_positions, validation_positions) in enumerate(
                splitter.split(X, y, groups=np.asarray(sample_ids, dtype=object)), start=1
            ):
                train_ids = [sample_ids[int(i)] for i in train_positions]
                validation_ids = [sample_ids[int(i)] for i in validation_positions]
                train_set, validation_set = set(train_ids), set(validation_ids)
                if train_set & validation_set:
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: ID split overlap")
                if fold_assignment[validation_positions].any():
                    raise AssertionError(f"{cereal}/{target}: an ID appears in multiple validation folds")
                fold_assignment[validation_positions] = fold_number

                X_train, X_validation = X.iloc[train_positions], X.iloc[validation_positions]
                y_train, y_validation = y.iloc[train_positions], y.iloc[validation_positions]
                # IDs are identity/group keys only. They are not columns in X and are
                # not declared to be physical replicate or instrument groups.
                model_data = modeling_service.apply_modeling(
                    X_train,
                    y_train,
                    X_validation,
                    y_validation,
                    "plsr",
                    analysis_type="quantitative",
                    model_params={"n_components": PLS_COMPONENTS},
                    train_row_ids=train_ids,
                    test_row_ids=validation_ids,
                    train_group_ids=train_ids,
                    test_group_ids=validation_ids,
                    group_validation=True,
                    input_representation="raw_spectrum",
                )
                predictor = model_data.fitted_predictor
                if predictor is None or predictor.input_representation != "raw_spectrum":
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: missing raw fitted predictor")
                if tuple(predictor.feature_names or ()) != tuple(WAVELENGTH_COLUMNS):
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: predictor feature boundary changed")
                if tuple(predictor.fit_row_ids or ()) != tuple(train_ids):
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: fit row IDs misaligned")
                if tuple(predictor.fit_group_ids or ()) != tuple(train_ids):
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: fit group IDs misaligned")
                if set(predictor.fit_group_ids).intersection(validation_ids):
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: outer-test group entered fit")

                prediction_result = model_data.prediction_result
                if prediction_result is None or prediction_result.task_type != "regression":
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: invalid prediction result")
                if tuple(prediction_result.row_ids or ()) != tuple(validation_ids):
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: prediction IDs misaligned")
                if tuple(prediction_result.group_ids or ()) != tuple(validation_ids):
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: prediction groups misaligned")
                if not np.array_equal(
                    np.asarray(model_data.predictions), np.asarray(prediction_result.predictions)
                ):
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: service vectors differ")

                # Exercise the raw-spectrum boundary as well as the service route.
                raw_result = predictor.predict_raw(
                    X_validation, row_ids=validation_ids, group_ids=validation_ids
                )
                if tuple(raw_result.row_ids or ()) != tuple(validation_ids) or not np.allclose(
                    raw_result.predictions, prediction_result.predictions, rtol=0, atol=1e-12
                ):
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: raw route differs from service route")

                service_metrics = model_data.evaluation_results
                recomputed_metrics = evaluation_service.evaluate_prediction_result(
                    y_validation.to_numpy(), prediction_result,
                    metrics=list(REGRESSION_METRICS), task_type="regression",
                    row_ids=validation_ids, group_ids=validation_ids,
                )
                if "error" in service_metrics or "error" in recomputed_metrics:
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: evaluation error")
                _assert_same_metrics(
                    service_metrics, recomputed_metrics,
                    f"{cereal}/{target}/fold {fold_number} service-vector metric parity",
                )

                # Check all nested analyzer CV fits stayed entirely within this
                # outer training partition and preserved group disjointness.
                inner_trace = list(getattr(model_data.analyzer, "last_cv_fit_trace", []) or [])
                if len(inner_trace) != N_OUTER_FOLDS:
                    raise AssertionError(
                        f"{cereal}/{target}/fold {fold_number}: expected five inner fit traces, got {len(inner_trace)}"
                    )
                inner_validation_seen = []
                for inner in inner_trace:
                    fit_ids = set(map(str, inner.get("estimator_fit_sample_ids", [])))
                    inner_validation_ids = set(map(str, inner.get("validation_sample_ids", [])))
                    if not fit_ids or not inner_validation_ids:
                        raise AssertionError(f"{cereal}/{target}: incomplete inner fit trace")
                    if not fit_ids.issubset(train_set) or not inner_validation_ids.issubset(train_set):
                        raise AssertionError(f"{cereal}/{target}: outer-test ID appears in inner CV trace")
                    if fit_ids & inner_validation_ids:
                        raise AssertionError(f"{cereal}/{target}: inner fit/validation IDs overlap")
                    if set(map(str, inner.get("train_group_ids", []))) & set(
                        map(str, inner.get("validation_group_ids", []))
                    ):
                        raise AssertionError(f"{cereal}/{target}: inner group IDs overlap")
                    inner_validation_seen.extend(inner_validation_ids)
                if set(inner_validation_seen) != train_set or len(inner_validation_seen) != len(train_set):
                    raise AssertionError(f"{cereal}/{target}: inner CV does not cover outer-training IDs exactly")

                model_prediction = np.asarray(prediction_result.predictions, dtype=float)
                mean_value = float(y_train.mean())
                baseline_prediction = np.full(len(validation_ids), mean_value, dtype=float)
                baseline_result = PredictionResult(
                    predictions=baseline_prediction,
                    task_type="regression",
                    row_ids=tuple(validation_ids),
                    group_ids=tuple(validation_ids),
                )
                baseline_metrics = evaluation_service.evaluate_prediction_result(
                    y_validation.to_numpy(), baseline_result,
                    metrics=list(REGRESSION_METRICS), task_type="regression",
                    row_ids=validation_ids, group_ids=validation_ids,
                )
                if "error" in baseline_metrics:
                    raise AssertionError(f"{cereal}/{target}/fold {fold_number}: baseline evaluation error")

                pls_predictions[validation_positions] = model_prediction
                baseline_predictions[validation_positions] = baseline_prediction
                fold_details.append({
                    "fold": fold_number,
                    "train_ids": train_ids,
                    "validation_ids": validation_ids,
                    "pls_metrics": service_metrics,
                    "baseline_train_mean": mean_value,
                    "baseline_metrics": baseline_metrics,
                    "inner_cv_fit_trace": inner_trace,
                })

            if np.any(fold_assignment == 0) or not np.isfinite(pls_predictions).all() or not np.isfinite(
                baseline_predictions
            ).all():
                raise AssertionError(f"{cereal}/{target}: OOF fold coverage or predictions incomplete")
            if not np.array_equal(np.bincount(fold_assignment)[1:], np.full(N_OUTER_FOLDS, 30)):
                raise AssertionError(f"{cereal}/{target}: unexpected outer fold coverage")

            oof = pd.DataFrame({
                "cereal": cereal,
                "target": target,
                "fold": fold_assignment,
                "sample_id": sample_ids,
                "actual": y_values,
                "plsr_prediction": pls_predictions,
                "train_mean_prediction": baseline_predictions,
            })
            completed[(cereal, target)] = {
                "oof": oof,
                "fold_details": fold_details,
                "sample_ids": sample_ids,
                "target_values": y_values,
            }

    source_hashes_after = {cereal: _sha256(path) for cereal, path in source_paths.items()}
    if source_hashes_after != source_hashes_before:
        raise AssertionError("An immutable SensAIfood source CSV changed during analysis")

    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".s26-61-staging-", dir=OUTPUT_ROOT))
    try:
        summary_rows = []
        fold_rows = []
        manifest_combinations = {}
        for (cereal, target), result in completed.items():
            filename = f"{cereal.lower()}_{target.lower()}_oof.csv"
            result["oof"].to_csv(staging / filename, index=False, float_format="%.17g")
            saved = pd.read_csv(staging / filename, dtype={"sample_id": str})
            if saved["sample_id"].tolist() != result["sample_ids"]:
                raise AssertionError(f"{filename}: saved row IDs/order differ from source order")
            if saved["fold"].tolist() != result["oof"]["fold"].tolist():
                raise AssertionError(f"{filename}: saved fold assignments differ")

            pooled = {}
            for model_key, prediction_column in (
                ("plsr", "plsr_prediction"),
                ("training_fold_mean", "train_mean_prediction"),
            ):
                saved_result = PredictionResult(
                    predictions=saved[prediction_column].to_numpy(dtype=float),
                    task_type="regression",
                    row_ids=tuple(saved["sample_id"].tolist()),
                    group_ids=tuple(saved["sample_id"].tolist()),
                )
                metrics = evaluation_service.evaluate_prediction_result(
                    saved["actual"].to_numpy(dtype=float), saved_result,
                    metrics=list(REGRESSION_METRICS), task_type="regression",
                    row_ids=saved["sample_id"].tolist(), group_ids=saved["sample_id"].tolist(),
                )
                if "error" in metrics:
                    raise AssertionError(f"{cereal}/{target}/{model_key}: pooled OOF evaluation error")
                pooled[model_key] = metrics
                summary_rows.append({
                    "cereal": cereal,
                    "target": target,
                    "model": model_key,
                    **{metric: float(metrics[metric]) for metric in REGRESSION_METRICS},
                })

            for fold in result["fold_details"]:
                for model_key, metrics_key in (("plsr", "pls_metrics"), ("training_fold_mean", "baseline_metrics")):
                    fold_rows.append({
                        "cereal": cereal,
                        "target": target,
                        "fold": fold["fold"],
                        "model": model_key,
                        **{metric: float(fold[metrics_key][metric]) for metric in REGRESSION_METRICS},
                    })
            manifest_combinations[f"{cereal}/{target}"] = {
                "n_records": len(result["sample_ids"]),
                "feature_columns": WAVELENGTH_COLUMNS,
                "oof_file": filename,
                "folds": result["fold_details"],
                "pooled_metrics_recomputed_from_saved_oof": pooled,
            }

        pd.DataFrame(summary_rows).to_csv(staging / "pooled_metrics.csv", index=False, float_format="%.17g")
        pd.DataFrame(fold_rows).to_csv(staging / "fold_metrics.csv", index=False, float_format="%.17g")

        try:
            import numpy
            import pandas
            import sklearn
            runtime_versions = {
                "python": sys.version,
                "platform": platform.platform(),
                "numpy": numpy.__version__,
                "pandas": pandas.__version__,
                "scikit_learn": sklearn.__version__,
                "pyyaml": _version("PyYAML"),
                "app_version": APP_VERSION,
                "app_version_source": APP_VERSION_SOURCE,
            }
        except Exception as exc:
            raise RuntimeError(f"Could not record runtime versions: {exc}") from exc

        manifest = {
            "task": "S26-61 SensAIfood sample-ID predictive analysis",
            "executed_at_utc": datetime.now(timezone.utc).isoformat(),
            "protocol": "S26_SENSAIFOOD_ANALYSIS_PROTOCOL.md",
            "protocol_frozen_before_predictive_fits": "2026-10-01",
            "dataset": "SensAIfood Perten cereal NIR release; Zenodo 10.5281/zenodo.15838136; CC BY 4.0",
            "scope_note": (
                "Record-level sample-ID separation only. Source IDs are unique record keys, not verified physical "
                "replicate, parent-sample, or instrument groups. No cross-instrument generalization claim."
            ),
            "model": {"method": "PLSR", "n_components": PLS_COMPONENTS, "input_representation": "raw_spectrum"},
            "outer_validation": {
                "splitter": "GroupKFold",
                "n_splits": N_OUTER_FOLDS,
                "group_key": "source ID (string-normalized for identity/index only)",
                "metadata_columns_excluded_from_X": EXPECTED_METADATA,
                "spectral_columns": WAVELENGTH_COLUMNS,
                "baseline": "training-fold mean, estimated separately in each outer training fold",
            },
            "responses": {
                "Moisture": {"source_label": "Moisture", "source_description": "% moisture; dry-basis note; raw values retained"},
                "Protein": {"source_label": "Protein", "source_description": "source Protein label; basis note ambiguous; errors reported in source target units"},
            },
            "metrics": list(REGRESSION_METRICS),
            "runtime_versions": runtime_versions,
            "source_csv_sha256": source_hashes_before,
            "combinations": manifest_combinations,
            "generated_tables": ["pooled_metrics.csv", "fold_metrics.csv"],
        }
        (staging / "run_manifest.json").write_text(
            json.dumps(_json_safe(manifest), ensure_ascii=False, indent=2), encoding="utf-8"
        )

        run_name = "run-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        final_path = OUTPUT_ROOT / run_name
        suffix = 1
        while final_path.exists():
            final_path = OUTPUT_ROOT / f"{run_name}-{suffix}"
            suffix += 1
        staging.rename(final_path)
        return final_path
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--execute", action="store_true",
        help="Run only after explicit release and recorded S26-35 PASS; otherwise this script is plan-only.",
    )
    parser.add_argument(
        "--lead-unlock", action="store_true",
        help="Explicitly confirm that the lead released the gated S26-61 analysis.",
    )
    args = parser.parse_args(argv)
    if not args.execute or not args.lead_unlock:
        print("S26-61 runner is prepared; no data imported and no model fitted.")
        print(f"Frozen source files: {', '.join(path.name for path in SOURCE_DIR.glob('*.csv'))}")
        print("Planned: 3 cereals x 2 targets; 5-fold GroupKFold by source record ID; PLSR(3) vs training-fold mean.")
        print("To execute later, after the lead's explicit unlock: python .harness/data/s26/run_sensaifood_s26_61.py --execute --lead-unlock")
        print("Execution still requires S26-35 status=completed, review_status=completed, review_verdict=pass.")
        return 0
    try:
        output_path = run_analysis()
    except Exception as exc:
        print(f"S26-61 analysis stopped: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    print(f"S26-61 analysis completed and validated: {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
