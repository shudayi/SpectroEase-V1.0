from pathlib import Path
import runpy,json,hashlib
import numpy as np,pandas as pd
from sklearn.neighbors import NearestCentroid
from sklearn.linear_model import LinearRegression
root=Path('.harness/data/s26/full_workflow_1009').resolve();out=root/'paired-study-current-source'
if not (out/'completion.json').exists():raise SystemExit('Final paired completion pending; no acceptance report emitted')
namespace=runpy.run_path(str(root/'run_paired_study_final.py'),run_name='independent_audit_loader')
pred=pd.read_csv(out/'paired-predictions.csv',dtype=str);summary=[]
for name,A,y,B,z in namespace['load_sets']():
 wrapper=json.loads((out/(name+'-workflow.json')).read_text());workflow=wrapper['workflow']
 mean=A.mean(0);a=A-mean;b=B-mean
 variances=np.mean((a-a.mean(0))**2,axis=0)
 ix=np.array(sorted(range(a.shape[1]),key=lambda i:variances[i])[-8:])
 states=[stage['state']['state'] for stage in workflow['stages']]
 def input_digest(matrix):
  return hashlib.sha256(json.dumps({'X':matrix.tolist(),'y':y.tolist()},sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')).hexdigest()
 assert workflow['stages'][0]['state']['training_input_sha256']==input_digest(A)
 runtime_a=A-np.asarray(states[0]['mean'])
 assert workflow['stages'][1]['state']['training_input_sha256']==input_digest(runtime_a)
 assert np.allclose(states[0]['mean'],mean,rtol=1e-12,atol=1e-12)
 assert states[1]['indices']==ix.tolist()
 a=a[:,ix];b=b[:,ix]
 assert workflow['stages'][2]['state']['training_input_sha256']==input_digest(runtime_a[:,ix])
 isclass=name in ('ecaps','strawberry')
 oracle=NearestCentroid(priors='uniform').fit(a,y).predict(b) if isclass else LinearRegression().fit(a,y).predict(b)
 saved=np.array(workflow['predictions']);g=pred[pred.dataset==name]
 axis=list(range(1,236)) if name=='strawberry' else list(range(950,1651,2 if name=='grainit' else 5)) if name in ['grainit','perten'] else list(range(4000,9996,5))
 assert workflow['input_axis']==axis
 assert workflow['axis_sha256']==hashlib.sha256(json.dumps(axis,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()).hexdigest()
 assert workflow['test_ids']==g.source_id.tolist()
 assert all(trace['training_ids']==workflow['training_ids'] for trace in workflow['fit_trace'])
 assert not set(workflow['training_ids']) & set(workflow['test_ids'])
 assert len(g)==len(z) and np.array_equal(np.asarray(g.truth,dtype=y.dtype),z)
 discrepancy=0. if isclass else float(np.max(np.abs(saved-oracle)))
 assert np.array_equal(saved,oracle) if isclass else np.allclose(saved,oracle,rtol=1e-8,atol=1e-8)
 if isclass:
  assert np.array_equal(g.plugin_prediction.to_numpy(),g.reference_prediction.to_numpy())
 else:assert np.allclose(g.plugin_prediction.astype(float),g.reference_prediction.astype(float),rtol=1e-8,atol=1e-8)
 summary.append(dict(dataset=name,train_rows=len(A),probe_rows=len(B),scikit_learn_oracle_discrepancy=discrepancy,stored_state_mean_tolerance_match=True,selected_indices_match=True))
checks={}
for p,h in json.loads((out/'freeze-before-fit.json').read_text()).items():checks[p]=hashlib.sha256((root.parents[3]/p).read_bytes()).hexdigest()==h
assert (out/'freeze-before-fit.json').read_bytes()==(out/'freeze-after-fit.json').read_bytes()
assert all(checks.values())
report=dict(status='pass',independent_oracles='sklearn NearestCentroid uniform priors / LinearRegression; direct variance ordering and training state',datasets=summary,current_source_hashes_match_frozen=checks)
Path('.harness/team/evidence/s26/full_workflow_1009/independent-paired-model-review.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))
