from pathlib import Path
import json,hashlib,collections
import numpy as np,pandas as pd
root=Path('.harness/data/s26/full_workflow_1009');out=root/'baseline-results-v2'
d=pd.read_csv(out/'predictions.csv',dtype={'truth':str,'prediction':str,'baseline':str,'id':str,'group':str})
s=pd.read_csv(out/'splits.csv',dtype={'id':str,'group':str})
metric=json.loads((out/'metrics.json').read_text());deltas=[];folds=[]
for (task,repeat,fold),p in s.groupby(['task','repeat','fold']):
 tr=p[p.partition=='train'];te=p[p.partition=='validation']
 assert not set(tr.id)&set(te.id)
 assert not set(tr.group)&set(te.group)
 pred=d[(d.task==task)&(d.repeat==repeat)&(d.fold==fold)]
 assert set(pred.id)==set(te.id) and len(pred)==len(te)
 if task=='strawberry':
  assert all(x.startswith('TRAIN_') for x in tr.id)
  assert all(x.startswith('TEST_' if repeat=='official_test' else 'TRAIN_') for x in te.id)
 if task=='ecaps':
  assert te.groupby('group').size().eq(7).all()
 folds.append(dict(task=task,repeat=repeat,fold=int(fold),train=len(tr),validation=len(te),groups=int(te.group.nunique())))
for m in metric:
 g=d[(d.task==m['task'])&(d.repeat==m['repeat'])]
 if m['unit']=='entity':
  assert g.groupby('group').truth.nunique().eq(1).all()
  g=g.groupby('group').agg({'truth':'first',m['method']:lambda x:collections.Counter(x).most_common(1)[0][0]})
 a=g.truth.to_numpy();b=g[m['method']].to_numpy();assert len(a)==m['n']
 if m['task'].startswith('grainit'):
  a=a.astype(float);b=b.astype(float);res=a-b
  calc={'RMSE':np.sqrt(np.mean(res**2)),'MAE':np.mean(abs(res)),'R2':1-np.sum(res**2)/np.sum((a-np.mean(a))**2)}
 else:
  labels=sorted(set(a));cm=np.array([[np.sum((a==i)&(b==j)) for j in labels] for i in labels]);rec=np.diag(cm)/cm.sum(1)
  f1=2*np.diag(cm)/(cm.sum(1)+cm.sum(0));calc={'balanced_accuracy':np.mean(rec),'macro_f1':np.mean(f1)}
  assert cm.tolist()==m['confusion_matrix']
 for k,v in calc.items():deltas.append(abs(float(v)-m[k]))
checks={}
freeze=json.loads((out/'freeze-before-fit.json').read_text())
for key,path in [('protocol_sha256',root/'candidate-protocol.yaml'),('script_sha256',root/'run_builtin_baselines.py'),('source_manifest_sha256',root/'primary-archive-manifest.json')]:checks[key]=hashlib.sha256(path.read_bytes()).hexdigest()==freeze[key]
manifest=json.loads((out/'completion-manifest.json').read_text())
checks['completion_files_match']=all(hashlib.sha256((out/n).read_bytes()).hexdigest()==h for n,h in manifest['files'].items())
checks['planned_splits_bytes_equal']=(out/'splits.csv').read_bytes()==(out/'planned-splits-before-any-fit.csv').read_bytes()
report=dict(status='pass',prediction_rows=len(d),metric_records=len(metric),disjoint_folds=len(folds),maximum_independent_arithmetic_metric_discrepancy=max(deltas),checks=checks,folds=folds)
assert all(checks.values()) and max(deltas)<1e-12
Path('.harness/team/evidence/s26/full_workflow_1009/independent-baseline-arithmetic-review.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print({k:v for k,v in report.items() if k!='folds'})
