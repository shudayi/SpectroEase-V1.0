#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Plugin Loader for SpectroEase.

Loads plugin modules from the project plugin directory without mutating the
global import path, instantiates plugin classes, and adds compatibility aliases
for older plugin method names.
"""

import importlib.util
import inspect
import io
import logging
import os
from contextlib import redirect_stdout
from typing import Any, Dict, Tuple

logger = logging.getLogger(__name__)


def load_plugins(plugin_base_dir: str) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    """
    Load plugins from the specified directory structure.

    Args:
        plugin_base_dir: Base directory containing plugin subdirectories.

    Returns:
        Tuple of (preprocessing_plugins, feature_selection_plugins,
        modeling_plugins, data_partitioning_plugins).
    """
    preprocessing_plugins: Dict[str, Any] = {}
    feature_selection_plugins: Dict[str, Any] = {}
    modeling_plugins: Dict[str, Any] = {}
    data_partitioning_plugins: Dict[str, Any] = {}

    plugin_dirs = {
        "preprocessing": preprocessing_plugins,
        "feature_selection": feature_selection_plugins,
        "modeling": modeling_plugins,
        "data_partitioning": data_partitioning_plugins,
    }

    if not os.path.isdir(plugin_base_dir):
        logger.warning("Plugin directory not found: %s", plugin_base_dir)
        return preprocessing_plugins, feature_selection_plugins, modeling_plugins, data_partitioning_plugins

    for subdir_name, plugin_dict in plugin_dirs.items():
        subdir_path = os.path.join(plugin_base_dir, subdir_name)
        if not os.path.isdir(subdir_path):
            logger.debug("Plugin subdirectory not found: %s", subdir_path)
            continue

        for filename in sorted(os.listdir(subdir_path)):
            if not filename.endswith(".py") or filename.startswith("__"):
                continue

            module_name = filename[:-3]
            module_path = os.path.join(subdir_path, filename)
            try:
                module = _load_module_from_path(subdir_name, module_name, module_path)
                _register_plugin_classes(module, subdir_name, plugin_dict)
            except Exception as exc:
                logger.warning(
                    "Failed to load plugin %s from %s: %s",
                    filename,
                    subdir_name,
                    exc,
                    exc_info=True,
                )

    return preprocessing_plugins, feature_selection_plugins, modeling_plugins, data_partitioning_plugins


def _load_module_from_path(plugin_type: str, module_name: str, module_path: str):
    """Load a plugin module by file path without modifying sys.path."""
    safe_name = f"_spectroease_plugin_{plugin_type}_{module_name}_{abs(hash(module_path))}"
    spec = importlib.util.spec_from_file_location(safe_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create import spec for {module_path}")

    module = importlib.util.module_from_spec(spec)
    stdout_buf = io.StringIO()
    with redirect_stdout(stdout_buf):
        spec.loader.exec_module(module)
    captured = stdout_buf.getvalue().strip()
    if captured:
        logger.debug("Plugin module %s stdout during load: %s", module_name, captured)
    return module


def _register_plugin_classes(module, plugin_type: str, plugin_dict: Dict[str, Any]) -> None:
    for class_name, cls in inspect.getmembers(module, inspect.isclass):
        if cls.__module__ != module.__name__:
            continue
        if not _is_plugin_class(cls, plugin_type):
            continue

        _prepare_class_compatibility(cls, plugin_type)
        plugin = _instantiate_plugin(cls, plugin_type)
        if plugin is None:
            continue
        _register_plugin(plugin_dict, class_name, plugin)


def _instantiate_plugin(cls, plugin_type: str):
    """Instantiate a plugin and bridge older method names."""
    try:
        stdout_buf = io.StringIO()
        with redirect_stdout(stdout_buf):
            plugin = cls()
        captured = stdout_buf.getvalue().strip()
        if captured:
            logger.debug("Plugin %s stdout during instantiation: %s", cls.__name__, captured)
    except TypeError as exc:
        logger.warning(
            "Skipping %s plugin %s; constructor requires arguments: %s",
            plugin_type,
            cls.__name__,
            exc,
        )
        return None

    _apply_compatibility_aliases(plugin, plugin_type)
    return plugin


def _prepare_class_compatibility(cls, plugin_type: str) -> None:
    """Add class-level parameter-info aliases before ABC instantiation checks run."""
    if not hasattr(cls, "get_params_info") and hasattr(cls, "get_parameter_info"):
        cls.get_params_info = cls.get_parameter_info
    if not hasattr(cls, "get_parameter_info") and hasattr(cls, "get_params_info"):
        cls.get_parameter_info = cls.get_params_info

    abstracts = getattr(cls, "__abstractmethods__", None)
    if abstracts:
        cls.__abstractmethods__ = frozenset(name for name in abstracts if not hasattr(cls, name))


def _apply_compatibility_aliases(plugin: Any, plugin_type: str) -> None:
    """Bridge older plugin parameter-info method names to the canonical names."""
    if not hasattr(plugin, "get_params_info") and hasattr(plugin, "get_parameter_info"):
        plugin.get_params_info = plugin.get_parameter_info
    if not hasattr(plugin, "get_parameter_info") and hasattr(plugin, "get_params_info"):
        plugin.get_parameter_info = plugin.get_params_info


def _register_plugin(plugin_dict: Dict[str, Any], class_name: str, plugin: Any) -> None:
    plugin_name = class_name
    if hasattr(plugin, "get_name"):
        try:
            plugin_name = plugin.get_name()
        except Exception:
            logger.debug("Plugin %s get_name() failed; using class name", class_name, exc_info=True)

    if plugin_name in plugin_dict:
        logger.warning("Duplicate plugin name %s; registering duplicate as %s", plugin_name, class_name)
        plugin_dict[class_name] = plugin
    else:
        plugin_dict[plugin_name] = plugin


def _is_plugin_class(cls, plugin_type: str) -> bool:
    """
    Check if a class is a valid plugin for the given type.

    Args:
        cls: The class to check.
        plugin_type: preprocessing, feature_selection, modeling, or data_partitioning.

    Returns:
        True if the class appears to be a valid plugin.
    """
    if not hasattr(cls, "__init__"):
        return False

    expected_methods = {
        "preprocessing": ["process", "apply"],
        "feature_selection": ["select_features", "fit", "transform"],
        "modeling": ["train", "predict", "fit"],
        "data_partitioning": ["partition"],
    }

    for method_name in expected_methods.get(plugin_type, []):
        if hasattr(cls, method_name):
            return True

    method_names = [method for method in dir(cls) if not method.startswith("_")]
    plugin_indicators = ["process", "apply", "run", "execute", "transform", "fit", "predict"]
    return any(
        any(indicator in method.lower() for method in method_names)
        for indicator in plugin_indicators
    )


if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    plugin_dir = os.path.join(current_dir, "plugins")
    loaded = load_plugins(plugin_dir)
    print("Plugin loading test completed:", [len(group) for group in loaded])
