# app/parsers/excel_parser.py
"""Excel (.xlsx, .xls) parser."""

from __future__ import annotations

import pandas as pd

from app.parsers import DataParser, register_parser


class ExcelParser(DataParser):
    extensions = ('xlsx', 'xls')
    description = 'Microsoft Excel workbook (.xlsx / .xls)'

    def parse(self, path: str) -> pd.DataFrame:
        # ``openpyxl`` handles .xlsx; ``xlrd`` (if installed) handles .xls.
        # ``read_excel`` picks the right engine automatically.
        return pd.read_excel(path)


register_parser(ExcelParser())