# app/parsers/__init__.py
"""File-format parser registry.

Each supported format (.csv, .xlsx, .spc, .jdx, .mat, ...) implements
``DataParser``. New formats register themselves on import. ``data_service``
and ``DataImportDialog`` both look up parsers via ``get_parser(path)``.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from typing import Iterable, List, Optional

import pandas as pd


class DataParser(ABC):
    """Base class for a single file-format parser."""

    extensions: tuple = ()
    description: str = ''

    def can_handle(self, path: str) -> bool:
        ext = os.path.splitext(path)[1].lower().lstrip('.')
        return ext in self.extensions

    @abstractmethod
    def parse(self, path: str) -> pd.DataFrame:
        """Read ``path`` and return a ``pd.DataFrame``."""


# Module-level registry; populated as concrete parsers are imported.
_PARSERS: List[DataParser] = []


def register_parser(parser: DataParser) -> DataParser:
    """Append ``parser`` to the global registry; idempotent on duplicates."""
    if parser not in _PARSERS:
        _PARSERS.append(parser)
    return parser


def list_parsers() -> Iterable[DataParser]:
    return tuple(_PARSERS)


def get_parser(path: str) -> Optional[DataParser]:
    """Return the first parser whose ``can_handle(path)`` is True."""
    for parser in _PARSERS:
        if parser.can_handle(path):
            return parser
    return None


def supported_extensions() -> List[str]:
    seen: List[str] = []
    for parser in _PARSERS:
        for ext in parser.extensions:
            if ext not in seen:
                seen.append(ext)
    return seen


# Concrete parsers are imported below so registration happens at module
# import time. ``data_service.load_data`` only needs to import this module.
from app.parsers.csv_parser import CSVParser, TextParser  # noqa: E402
from app.parsers.excel_parser import ExcelParser  # noqa: E402
from app.parsers.json_parser import JSONParser  # noqa: E402
from app.parsers.npz_parser import NPZParser  # noqa: E402
from app.parsers.parquet_parser import ParquetParser  # noqa: E402
from app.parsers.spc_parser import SPCParser  # noqa: E402
from app.parsers.jcamp_parser import JCAMPParser  # noqa: E402
from app.parsers.mat_parser import MATParser  # noqa: E402
from app.parsers.opus_parser import OPUSParser  # noqa: E402