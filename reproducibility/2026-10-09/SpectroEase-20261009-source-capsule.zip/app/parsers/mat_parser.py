# app/parsers/mat_parser.py
"""MATLAB .mat parser using scipy.io.loadmat."""

from __future__ import annotations

import pandas as pd

from app.parsers import DataParser, register_parser


class MATParser(DataParser):
    extensions = ('mat',)
    description = 'MATLAB .mat file (scipy.io.loadmat)'

    def parse(self, path: str) -> pd.DataFrame:
        try:
            from scipy.io import loadmat
        except ImportError as exc:
            raise RuntimeError(
                "Reading .mat files requires scipy (pip install scipy)"
            ) from exc

        mat = loadmat(path)
        # Skip private keys / metadata that loadmat always returns.
        candidates = [
            (k, v) for k, v in mat.items()
            if not k.startswith('__')
        ]
        if not candidates:
            raise ValueError(".mat file contains no usable variables")
        # Prefer the first 2D array with the largest row count; otherwise
        # any 1D array; otherwise the first variable.
        def _score(item):
            _name, val = item
            try:
                import numpy as np
                arr = np.asarray(val)
            except Exception:
                return (-1, -1)
            if arr.ndim == 2:
                return (arr.shape[0], arr.shape[1])
            if arr.ndim == 1:
                return (arr.shape[0], 1)
            return (-1, -1)

        candidates.sort(key=_score, reverse=True)
        for _, val in candidates:
            try:
                return pd.DataFrame(val)
            except Exception:
                continue
        raise ValueError(".mat file variables could not be coerced to DataFrame")


register_parser(MATParser())