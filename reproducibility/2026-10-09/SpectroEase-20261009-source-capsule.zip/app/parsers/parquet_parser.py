# app/parsers/parquet_parser.py
"""Apache Parquet / Feather parser."""

from __future__ import annotations

import pandas as pd

from app.parsers import DataParser, register_parser


class ParquetParser(DataParser):
    extensions = ('parquet', 'feather')
    description = 'Apache Parquet / Feather (.parquet / .feather)'

    def parse(self, path: str) -> pd.DataFrame:
        if path.lower().endswith('.feather'):
            return pd.read_feather(path)
        return pd.read_parquet(path)


register_parser(ParquetParser())