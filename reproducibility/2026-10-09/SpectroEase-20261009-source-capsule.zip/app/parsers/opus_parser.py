# app/parsers/opus_parser.py
"""Bruker OPUS parser stub.

OPUS is a complex binary format with multiple block types, compression
modes, and parameter metadata. Implementing the full parser is out of
scope for this batch. Users should re-export their OPUS spectra as CSV or
JCAMP-DX from the OPUS software.
"""

from __future__ import annotations

import pandas as pd

from app.parsers import DataParser, register_parser


class OPUSParseNotImplemented(NotImplementedError):
    pass


class OPUSParser(DataParser):
    extensions = ('opus',)
    description = 'Bruker OPUS binary (development stub)'

    def parse(self, path: str) -> pd.DataFrame:
        raise OPUSParseNotImplemented(
            "OPUS parsing is not yet implemented. "
            "Please re-export your OPUS spectra as CSV, JCAMP-DX (.jdx), or SPC."
        )


register_parser(OPUSParser())