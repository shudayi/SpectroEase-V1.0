# app/parsers/jcamp_parser.py
"""JCAMP-DX (.jdx / .dx) parser.

Implements the most common JCAMP-DX forms used in spectroscopy:

- ``##XYDATA=(X++(Y..Y))`` (AFFN/ASDF/SDDN/SQZ/PAC encoded values)
- ``##XYPOINTS=(X,Y)`` (explicit pairs)

Forms not yet supported (raise a friendly error so the user can re-export):

- ``##XYDATA=(X++(Y..Y), firstX, lastX, nPoints)`` - rare
- ``##PEAKTABLE`` / ``##PEAKASSIGNMENTS`` - peak tables
"""

from __future__ import annotations

import re

import numpy as np
import pandas as pd

from app.parsers import DataParser, register_parser


class JCAMPParseError(ValueError):
    pass


# Header key. JCAMP-DX headers start with ``##KEY=`` and may span multiple
# lines until the next ``##`` or end-of-file.
_HEADER_LINE_RE = re.compile(r'^##([^=]+)=(.*)$', re.IGNORECASE)

# Form detection: XYDATA uses AFFN/ASDF/SQZ/SDDN/PAC codes in body;
# XYPOINTS uses comma-separated (X,Y) pairs.
_AFFN_DIGITS = set("0123456789 -+.,")


def _parse_header(text: str) -> dict:
    """Parse ``##KEY=VALUE`` lines from the header block.

    ``##XYDATA`` / ``##XYPOINTS`` / ``##PEAKTABLE`` line is the *start* of the
    data block. We capture the value portion after ``=`` (which may be empty
    or contain a (X..Y) expression) and then append subsequent non-## lines
    to it until the next ``##`` line or end of file.
    """
    header: dict = {}
    data_keys = {'XYDATA', 'XYPOINTS', 'PEAKTABLE'}
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.startswith('##'):
            i += 1
            continue
        match = _HEADER_LINE_RE.match(line)
        if not match:
            i += 1
            continue
        key = match.group(1).strip().upper()
        value = match.group(2).strip()
        if key in data_keys:
            header[key] = value
            # Consume following data lines until next '##' or END.
            i += 1
            while i < len(lines) and not lines[i].startswith('##'):
                if lines[i].strip():
                    header[key] = (header[key] + ' ' + lines[i].strip()).strip()
                i += 1
            break
        header[key] = value
        i += 1
    return header


def _decode_affn(values: str) -> np.ndarray:
    """Decode AFFN (ASCII free-format numeric) values.

    AFFN is just comma- or whitespace-separated numbers.
    """
    cleaned = values.replace(',', ' ').replace(';', ' ')
    nums = []
    for token in cleaned.split():
        try:
            nums.append(float(token))
        except ValueError:
            continue
    return np.array(nums, dtype=np.float64)


def _decode_asdf(values: str) -> np.ndarray:
    """Decode ASDF (ASCII difference form).

    Each value after the first is encoded as a number of "diff" characters
    (0-9 → digit value, A-J → 10-19) relative to the previous value.
    """
    cleaned = values.replace(',', ' ').replace(';', ' ')
    tokens = cleaned.split()
    if not tokens:
        return np.empty(0, dtype=np.float64)
    result = [float(tokens[0])]
    for tok in tokens[1:]:
        delta = 0.0
        sign = +1.0
        for ch in tok:
            if ch == '+':
                sign = +1.0
            elif ch == '-':
                sign = -1.0
            elif ch.isdigit():
                delta = delta * 10.0 + float(ch)
            elif ch.upper() in 'ABCDEFGHIJ':
                delta = delta * 10.0 + (ord(ch.upper()) - ord('A') + 10)
            else:
                # Unknown character terminates the number.
                break
        result.append(result[-1] + sign * delta)
    return np.array(result, dtype=np.float64)


def _decode_sqz(values: str) -> np.ndarray:
    """Decode SQZ (squeezed form) - AFFN with leading +/- and whitespace stripped."""
    cleaned = values.replace(',', ' ').replace(';', ' ')
    return _decode_affn(cleaned)


def _decode_pua(values: str) -> np.ndarray:
    """Decode PUA (Pac compressed) - characters '!'..'-' encode 0..41."""
    cleaned = values.replace(',', ' ').replace(';', ' ')
    result = []
    for tok in cleaned.split():
        val = 0.0
        for ch in tok:
            if ch == '@':
                val = 0.0
                break
            o = ord(ch) - ord('!')
            if 0 <= o <= 41:
                val = val * 42.0 + o
            else:
                break
        result.append(val)
    return np.array(result, dtype=np.float64)


_FORMAT_DECODERS = {
    'AFFN': _decode_affn,
    'ASDF': _decode_asdf,
    'SQZ': _decode_sqz,
    'SDDN': _decode_affn,
    'PAC': _decode_pua,
}


def _split_blocks(body: str) -> list:
    """Split an XYDATA body into (x, [y_values]) blocks separated by semicolons."""
    return [seg.strip() for seg in body.split(';') if seg.strip()]


class JCAMPParser(DataParser):
    extensions = ('jdx', 'dx')
    description = 'JCAMP-DX spectral data (.jdx / .dx)'

    def parse(self, path: str) -> pd.DataFrame:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            text = f.read()
        header = _parse_header(text)

        # Determine the X spacing for AFFN forms.
        first_x = float(header.get('FIRSTX', '0') or 0)
        last_x = float(header.get('LASTX', '0') or 0)
        npts = int(header.get('NPOINTS', '0') or 0)
        x_factor = float(header.get('XFACTOR', '1') or 1)
        y_factor = float(header.get('YFACTOR', '1') or 1)
        delta_x = float(header.get('DELTAX', '0') or 0)

        if 'XYDATA' in header:
            # Format: ##XYDATA=(X++(Y..Y))
            xypart = header['XYDATA']
            inner = xypart.split('(', 1)[1].rstrip(')')
            fmt_token = ''
            for token in inner.split():
                if token in _FORMAT_DECODERS:
                    fmt_token = token
                    break
            if not fmt_token:
                raise JCAMPParseError(
                    f"Unsupported JCAMP-DX XYDATA format (no AFFN/ASDF/SQZ/PAC token in '{xypart}')"
                )
            blocks = _split_blocks(inner.split(')', 1)[1] if ')' in inner else inner)
            x_values = []
            y_values = []
            x_cursor = first_x
            for blk in blocks:
                # Block: x_value y_tokens
                parts = blk.split(None, 1)
                if not parts:
                    continue
                try:
                    x_val = float(parts[0]) * x_factor
                except ValueError:
                    continue
                y_tokens = parts[1] if len(parts) > 1 else ''
                decoded = _FORMAT_DECODERS[fmt_token](y_tokens) * y_factor
                x_values.extend([x_val] * len(decoded))
                y_values.extend(decoded.tolist())
            x = np.array(x_values, dtype=np.float64)
            y = np.array(y_values, dtype=np.float64)
        elif 'XYPOINTS' in header:
            body = header['XYPOINTS']
            # Strip the leading (XY) / (XY..XY) marker if present.
            if '(' in body:
                body = body.split(')', 1)[-1]
            pairs = []
            for chunk in re.split(r'[;\s]+', body):
                chunk = chunk.strip().rstrip(',')
                if not chunk:
                    continue
                parts = chunk.split(',', 1)
                if len(parts) != 2:
                    continue
                try:
                    x_val = float(parts[0].strip()) * x_factor
                    y_val = float(parts[1].strip()) * y_factor
                except ValueError:
                    continue
                pairs.append((x_val, y_val))
            if not pairs:
                raise JCAMPParseError("JCAMP-DX file has no valid (X,Y) pairs")
            x = np.array([p[0] for p in pairs], dtype=np.float64)
            y = np.array([p[1] for p in pairs], dtype=np.float64)
        else:
            raise JCAMPParseError("JCAMP-DX file is missing both ##XYDATA and ##XYPOINTS")

        # If the file did not provide explicit X values (XYDATA PUA/AFFN
        # without per-block X), synthesise a linear grid from FIRSTX/LASTX.
        if len(x) != len(y):
            if delta_x > 0 and npts > 0:
                x = np.linspace(first_x, first_x + delta_x * (npts - 1), npts,
                                dtype=np.float64)
            elif last_x > first_x and npts > 0:
                x = np.linspace(first_x, last_x, npts, dtype=np.float64)
            elif npts > 0:
                x = np.arange(len(y), dtype=np.float64)
            else:
                x = np.arange(len(y), dtype=np.float64)
            if len(x) != len(y):
                n = min(len(x), len(y))
                x, y = x[:n], y[:n]
        return pd.DataFrame({'label': x, 'spectrum': y})


register_parser(JCAMPParser())