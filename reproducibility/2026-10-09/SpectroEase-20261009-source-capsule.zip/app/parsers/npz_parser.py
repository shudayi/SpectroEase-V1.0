# app/parsers/npz_parser.py
"""NumPy .npz / .npy parser.

Loads the first array in a .npz file, or the single array in a .npy file.
The first column is treated as the label column (matching CSV/Excel
convention).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.parsers import DataParser, register_parser


class NPZParser(DataParser):
    extensions = ('npz', 'npy')
    description = 'NumPy archive / single array (.npz / .npy)'

    def parse(self, path: str) -> pd.DataFrame:
        if path.lower().endswith('.npy'):
            arr = np.load(path, allow_pickle=False)
            if arr.ndim == 1:
                return pd.DataFrame({'value': arr})
            return pd.DataFrame(arr)

        with np.load(path, allow_pickle=False) as archive:
            first_key = next(iter(archive.files))
            arr = archive[first_key]
        if arr.ndim == 1:
            return pd.DataFrame({'value': arr})
        return pd.DataFrame(arr)


register_parser(NPZParser())