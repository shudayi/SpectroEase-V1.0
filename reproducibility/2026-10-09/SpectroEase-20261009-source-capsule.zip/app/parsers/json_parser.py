# app/parsers/json_parser.py
"""JSON parser. Accepts either ``records`` orient or a raw array of objects."""

from __future__ import annotations

import pandas as pd

from app.parsers import DataParser, register_parser


class JSONParser(DataParser):
    extensions = ('json',)
    description = 'JSON array of records (.json)'

    def parse(self, path: str) -> pd.DataFrame:
        return pd.read_json(path, orient='records')


register_parser(JSONParser())