# app/parsers/spc_parser.py
"""Thermo Galactic SPC binary parser (subset).

Implements the most common SPC file variants used by spectroscopy
instruments:

- ftflg == 0 (old format, single y-block)
- Single spectrum files with even X spacing
- 16-bit integer Y values with even Y-multiplier scaling

The full SPC specification supports a wide range of sub-formats; this
parser covers the most common OLD/LINEAR/TXVALS subset and raises a
``ValueError`` for variants that are not yet supported. Users encountering
unsupported files should re-export to CSV or JCAMP-DX from the instrument
software.

Specification reference: Thermo Galactic SPC format documentation
(also archived at https://github.com/luessS/SPC-format).
"""

from __future__ import annotations

import struct

import numpy as np
import pandas as pd

from app.parsers import DataParser, register_parser


class SPCParseError(ValueError):
    pass


# Header constants.
_SPC_MAGIC = 0x4B
_SPC_HEADER_SIZE_OLD = 512


def _decode_old_header(buf: bytes) -> dict:
    """Decode the OLD format header (512 bytes, little-endian).

    The OLD format header encodes a fixed number of fields, but the
    numeric range / scaling varies per file. We only parse what we need.
    """
    if len(buf) < _SPC_HEADER_SIZE_OLD:
        raise SPCParseError("SPC file is shorter than the OLD header")

    ftflg = buf[0]
    if ftflg != _SPC_MAGIC:
        raise SPCParseError(
            f"SPC file uses non-OLD format flag {ftflg}; this parser only supports OLD format (magic={_SPC_MAGIC})"
        )

    # Version byte (1) - we only care about major version, ignore the rest
    # of the versioning metadata in this subset parser.
    exp = buf[9]  # Y-axis exponent (signed; value = mantissa * 2^exp)
    npts = struct.unpack_from('<i', buf, 4)[0]
    first_x = struct.unpack_from('<f', buf, 12)[0]
    last_x = struct.unpack_from('<f', buf, 16)[0]
    sub = buf[21]
    if sub != 0:
        raise SPCParseError(
            f"SPC sub-format {sub} (multi-spectra or non-evenly-spaced X) not supported"
        )

    return {
        'npts': npts,
        'first_x': first_x,
        'last_x': last_x,
        'exp': exp,
    }


def _decode_y_values(buf: bytes, header_size: int, npts: int, exp: int) -> np.ndarray:
    """Decode a single-block Y array.

    The OLD format always uses 16-bit signed integers, each scaled by
    ``2 ** (exp - 16)``. The first two bytes of the y-block (after the
    header) carry scaling metadata we ignore.
    """
    expected_bytes = header_size + npts * 2
    if len(buf) < expected_bytes:
        raise SPCParseError("SPC file is truncated before the Y block")

    raw = np.frombuffer(
        buf, dtype='<i2', offset=header_size, count=npts,
    )
    return raw.astype(np.float64) * (2.0 ** (exp - 16))


class SPCParser(DataParser):
    extensions = ('spc',)
    description = 'Thermo Galactic SPC binary (.spc)'

    def parse(self, path: str) -> pd.DataFrame:
        with open(path, 'rb') as f:
            buf = f.read()
        info = _decode_old_header(buf)
        npts = info['npts']
        first_x = info['first_x']
        last_x = info['last_x']
        if npts <= 1:
            raise SPCParseError("SPC file has fewer than 2 points")
        if not np.isfinite(first_x) or not np.isfinite(last_x):
            raise SPCParseError("SPC file has non-finite X endpoints")

        y = _decode_y_values(buf, _SPC_HEADER_SIZE_OLD, npts, info['exp'])
        x = np.linspace(first_x, last_x, npts, dtype=np.float64)
        # Convention: first column is the label; remaining columns are features.
        return pd.DataFrame({'label': x, 'spectrum': y})


register_parser(SPCParser())