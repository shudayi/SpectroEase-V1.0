# app/parsers/csv_parser.py
"""CSV / TSV / TXT parser with cascading encoding fallback."""

from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path

import pandas as pd

from app.parsers import DataParser, register_parser


def _read_with_encoding_fallback(path: str, sep: str, **read_csv_kwargs) -> pd.DataFrame:
    """Try common encodings, fall back gracefully.

    Order matches the legacy ``_read_csv_with_fallback`` implementation in
    ``data_service`` so existing user files continue to load identically.
    """
    encodings = ('utf-8', 'gbk', 'latin1')
    last_err: Exception | None = None
    for enc in encodings:
        try:
            return pd.read_csv(path, sep=sep, encoding=enc, **read_csv_kwargs)
        except (UnicodeDecodeError, UnicodeError) as exc:
            last_err = exc
            continue
    # As a last resort, let pandas guess the encoding transparently.
    return pd.read_csv(
        path, sep=sep, encoding='utf-8', encoding_errors='replace', **read_csv_kwargs
    )


_TEXT_SAMPLE_BYTES = 64 * 1024
_DELIMITER_STABILITY = 0.8


def _read_text_sample(path: str) -> str:
    """Read a bounded text sample using the same encoding order as pandas."""
    with open(path, 'rb') as stream:
        raw = stream.read(_TEXT_SAMPLE_BYTES)

    for encoding in ('utf-8', 'gbk', 'latin1'):
        try:
            sample = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:  # pragma: no cover - latin1 decodes every byte sequence
        sample = raw.decode('utf-8', errors='replace')

    # A truncated final line can make a delimiter look inconsistent. Keep
    # only complete lines when the sample did not reach end-of-file.
    if len(raw) == _TEXT_SAMPLE_BYTES and sample and not sample.endswith(('\n', '\r')):
        last_newline = max(sample.rfind('\n'), sample.rfind('\r'))
        if last_newline >= 0:
            sample = sample[:last_newline]
    return sample


def _field_count(line: str, sep: str) -> int:
    if sep == r'\s+':
        return len(line.split())
    return len(next(csv.reader([line], delimiter=sep)))


def _delimiter_profile(lines: list[str], sep: str) -> dict[str, float | int | bool]:
    """Summarize field-width consistency without loading the whole file."""
    try:
        widths = [_field_count(line, sep) for line in lines]
    except (csv.Error, StopIteration):
        widths = []

    if not widths:
        return {'width': 1, 'consistency': 0.0, 'coverage': 0.0, 'stable': False, 'multi': False}

    mode_width, mode_count = Counter(widths).most_common(1)[0]
    consistency = mode_count / len(widths)
    coverage = sum(width > 1 for width in widths) / len(widths)
    stable = (
        mode_width > 1
        and consistency >= _DELIMITER_STABILITY
        and coverage >= _DELIMITER_STABILITY
    )
    return {
        'width': mode_width,
        'consistency': consistency,
        'coverage': coverage,
        'stable': stable,
        'multi': any(width > 1 for width in widths),
    }


def _infer_txt_separator(path: str, *, skip_first_line: bool = False) -> str:
    """Choose a consistent delimiter for generic TXT input.

    Commas and tabs are counted with CSV quoting rules. Whitespace is a
    fallback for plain space-delimited files. When both comma and tab form
    stable tables, the file is genuinely ambiguous without schema information
    and is rejected instead of being silently imported with the wrong columns.
    """
    sample = _read_text_sample(path)
    lines = [line for line in sample.splitlines() if line.strip()]
    if skip_first_line and lines:
        lines = lines[1:]
    if not lines:
        # Let pandas raise its usual EmptyDataError for an empty file.
        return ','

    profiles = {
        ',': _delimiter_profile(lines, ','),
        '\t': _delimiter_profile(lines, '\t'),
        r'\s+': _delimiter_profile(lines, r'\s+'),
    }
    punctuation_candidates = [
        sep for sep in (',', '\t') if profiles[sep]['stable']
    ]
    if len(punctuation_candidates) > 1:
        raise ValueError(
            "Ambiguous .txt delimiter: both comma and tab form consistent multi-column tables; "
            "use a .csv or .tsv extension to specify the delimiter."
        )
    if punctuation_candidates:
        return punctuation_candidates[0]
    if profiles[r'\s+']['stable']:
        return r'\s+'

    # Ragged multi-column candidates are more likely a malformed table than a
    # legal one-column text file. Do not silently collapse them into one field.
    if any(profile['multi'] for profile in profiles.values()):
        raise ValueError(
            "Unable to infer a consistent delimiter from .txt content; "
            "check for ragged or mixed-delimiter rows."
        )
    return ','


class CSVParser(DataParser):
    extensions = ('csv',)
    description = 'Comma-separated values (.csv)'

    def parse(self, path: str) -> pd.DataFrame:
        return _read_with_encoding_fallback(path, sep=',')


class TextParser(DataParser):
    """Generic text format: TSV / whitespace / TXT.

    `.tsv` always uses tabs. `.txt` selects a delimiter from consistent
    multi-column rows, falling back to one column only when no delimiter is
    present.
    """

    extensions = ('txt', 'tsv')
    description = 'Tab/whitespace/comma-delimited text (.tsv / .txt)'

    def parse(self, path: str) -> pd.DataFrame:
        extension = Path(path).suffix.lower()
        separator = '\t' if extension == '.tsv' else _infer_txt_separator(path)
        return _read_with_encoding_fallback(path, sep=separator)


register_parser(CSVParser())
register_parser(TextParser())
