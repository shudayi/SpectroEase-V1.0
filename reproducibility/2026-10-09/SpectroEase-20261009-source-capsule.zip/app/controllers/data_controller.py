from PyQt5.QtWidgets import QFileDialog, QDialog, QMessageBox
from app.utils.exceptions import DataServiceError, DataQualityError
from app.utils.logger import setup_logger
from app.services.data_service import DataService
from app.models.data_model import DataModel
from app.utils.column_mapping import spectral_column_positions
from app.utils.label_processor import LabelProcessor, EnhancedLabelProcessor
from app.views.data_partitioning_results_dialog import DataPartitioningResultsDialog
import numpy as np
import os
import pandas as pd
from numbers import Integral

class DataController:
    def __init__(self, view, translator, data_partitioning_plugins):
        self.view = view
        self.translator = translator
        self.data_service = DataService(data_partitioning_plugins)
        self.data_model = DataModel()
        self.label_processor = LabelProcessor()
        self.logger = setup_logger()
        self.current_spectral_config = None  # Store current spectral configuration

    def load_data(self):
        try:
            # NEW: First show spectral type pre-selection dialog
            from app.views.spectral_type_pre_selection_dialog import SpectralTypePreSelectionDialog
            
            # Show spectral type selection dialog
            type_dialog = SpectralTypePreSelectionDialog(self.view)
            if type_dialog.exec_() != QDialog.Accepted:
                return False  # User cancelled
            
            selected_type = type_dialog.get_selected_type()
            type_name = type_dialog.get_type_name()
            
            # Now show file selection dialog
            file_path, _ = QFileDialog.getOpenFileName(
                self.view, f"Select {type_name} Data File", "",
                "CSV files (*.csv);;Excel files (*.xlsx *.xls);;All files (*.*)"
            )
            
            if file_path:
                try:
                    # **NEW: Load data with NaN/Inf handling**
                    raw_data = self.data_service.load_data(file_path)
                except DataQualityError as quality_error:
                    # Service layer raises; controller owns the interactive dialog.
                    from app.views.data_quality_dialog import DataQualityDialog
                    dialog = DataQualityDialog(quality_error.data, file_path)
                    if dialog.exec_() == QDialog.Accepted:
                        raw_data, action = dialog.get_processed_data()
                        self.logger.info(f"Data quality handled via '{action}' action")
                    else:
                        return False  # User cancelled data quality handling
                except DataServiceError as e:
                    self.view.display_error(str(e))
                    return False

                # Check for data quality issues and handle them
                from app.views.nan_inf_handling_dialog import detect_and_handle_data_issues
                cleaned_data, cancelled = detect_and_handle_data_issues(raw_data, self.view)

                if cancelled:
                    return False  # User cancelled data cleaning

                # Use cleaned data
                data = cleaned_data
                self.data_model.set_data(data)
                self.data_model.file_path = file_path
                self._notify_dataset_state_changed()
                self.view.update_data_view(data)

                # NEW: Apply spectral configuration based on pre-selected type
                self.apply_preselected_spectral_config(data, selected_type, type_name)

                return True
            else:
                return False
        except Exception as e:
            raise
    
    def apply_preselected_spectral_config(self, data, selected_type, type_name):
        """Apply spectral configuration based on pre-selected type"""
        try:
            wavelengths = self.extract_wavelengths(data)
            
            if selected_type == "auto":
                # Use auto-detection dialog
                from app.views.spectral_type_selection_dialog import SpectralTypeSelectionDialog
                dialog = SpectralTypeSelectionDialog(data, wavelengths, self.view)
                
                if dialog.exec_() == QDialog.Accepted:
                    config = dialog.get_selected_config()
                    self.apply_spectral_configuration(config)
                    self.show_configuration_info(config)
                else:
                    self.use_default_configuration()
            else:
                # Apply configuration for pre-selected type
                config = self.generate_config_for_preselected_type(selected_type, data, wavelengths)
                self.apply_spectral_configuration(config)
                
                # Show simplified confirmation
                QMessageBox.information(self.view, "Spectral Configuration", 
                    f"Data loaded successfully!\n\nSpectral Type: {type_name}\n"
                    f"Samples: {len(data)}\n"
                    f"Features: {self.data_model.get_X().shape[1]}\n\n"
                    f"Optimized preprocessing parameters have been applied automatically.")
                
        except Exception as e:
            self.logger.error(f"Failed to apply preselected spectral config: {e}")
            QMessageBox.warning(self.view, "Warning", 
                              f"Data loaded successfully, but spectral configuration failed.\n"
                              f"Using default settings.\n\nError: {str(e)}")
            self.use_default_configuration()
    
    def generate_config_for_preselected_type(self, spectral_type, data, wavelengths):
        """Generate configuration for pre-selected spectral type"""
        # Basic configuration based on spectral type
        configs = {
            "nir": {
                "spectral_type": "nir",
                "adaptation_level": "basic",
                "preprocessing_config": {
                    "Standard Normal Variate (SNV)": {"enabled": True},
                    "Baseline Correction": {"enabled": True, "method": "als", "lambda": 1e5, "p": 0.01},
                    "Savitzky-Golay Filter": {"enabled": True, "window_length": 15, "polyorder": 2},
                    "Second Derivative": {"enabled": True},
                    "Vector Normalization": {"enabled": True}
                },
                "parameter_adaptations": {
                    "als_baseline": {"lambda": 1e5, "p": 0.01},
                    "savgol_filter": {"window_length": 15, "polyorder": 2}
                }
            },
            "raman": {
                "spectral_type": "raman", 
                "adaptation_level": "basic",
                "preprocessing_config": {
                    "Despiking": {"enabled": True, "method": "mad", "threshold": 2.0},
                    "Peak Alignment": {"enabled": True, "method": "dtw", "reference": "mean"},
                    "Baseline Correction": {"enabled": True, "method": "als", "lambda": 1e6, "p": 0.001},
                    "Savitzky-Golay Filter": {"enabled": True, "window_length": 7, "polyorder": 2},
                    "Area Normalization": {"enabled": True}
                },
                "parameter_adaptations": {
                    "als_baseline": {"lambda": 1e6, "p": 0.001},
                    "despiking": {"threshold": 2.0},
                    "peak_alignment": {"method": "dtw", "reference": "mean"}
                }
            },
            "mir": {
                "spectral_type": "mir",
                "adaptation_level": "basic", 
                "preprocessing_config": {
                    "Multiplicative Scatter Correction (MSC)": {"enabled": True},
                    "Baseline Correction": {"enabled": True, "method": "als", "lambda": 1e4, "p": 0.05},
                    "First Derivative": {"enabled": True},  # MIR benefits from derivative enhancement
                    "Savitzky-Golay Filter": {"enabled": True, "window_length": 9, "polyorder": 2},
                    "Vector Normalization": {"enabled": True}
                },
                "parameter_adaptations": {
                    "als_baseline": {"lambda": 1e4, "p": 0.05}
                }
            },
            "vis_nir": {
                "spectral_type": "vis_nir",
                "adaptation_level": "basic",
                "preprocessing_config": {
                    "Standard Normal Variate (SNV)": {"enabled": True},  # Add scatter correction
                    "Baseline Correction": {"enabled": True, "method": "als", "lambda": 1e3, "p": 0.1},  # Use ALS
                    "Savitzky-Golay Filter": {"enabled": True, "window_length": 11, "polyorder": 2},
                    "Min-Max Scale": {"enabled": True}
                },
                "parameter_adaptations": {
                    "als_baseline": {"lambda": 1e3, "p": 0.1}
                }
            },
            "uv_vis": {
                "spectral_type": "uv_vis",
                "adaptation_level": "basic",
                "preprocessing_config": {
                    "Baseline Correction": {"enabled": True, "method": "polynomial", "order": 1},
                    "Min-Max Scale": {"enabled": True}
                },
                "parameter_adaptations": {}
            }
        }
        
        return configs.get(spectral_type, configs["nir"])
    
    def open_spectral_type_config(self, data):
        """Open spectral type configuration dialog"""
        try:
            from app.views.spectral_type_selection_dialog import SpectralTypeSelectionDialog
            
            # Try to extract wavelength information
            wavelengths = self.extract_wavelengths(data)
            
            dialog = SpectralTypeSelectionDialog(data, wavelengths, self.view)
            
            if dialog.exec_() == QDialog.Accepted:
                config = dialog.get_selected_config()
                self.apply_spectral_configuration(config)
                self.show_configuration_info(config)
            else:
                # User cancelled, use default configuration
                self.use_default_configuration()
                
        except Exception as e:
            self.logger.error(f"Spectral configuration failed: {e}")
            QMessageBox.information(self.view, "Notice", 
                                  "Spectral configuration encountered an issue, using default configuration")
    
    def extract_wavelengths(self, data):
        """Extract wavelength information from data"""
        try:
            # Assume column names contain wavelength information
            columns = data.columns
            wavelengths = []
            
            for col in columns:
                # Try to extract numerical values from column names
                import re
                numbers = re.findall(r'\d+\.?\d*', str(col))
                if numbers:
                    try:
                        wl = float(numbers[0])
                        wavelengths.append(wl)
                    except:
                        continue
            
            if len(wavelengths) > 10:  # Need at least 10 wavelength points
                return np.array(wavelengths)
            else:
                # Generate default wavelengths (NIR range)
                return np.linspace(1000, 2500, len(columns))
                
        except Exception as e:
            self.logger.warning(f"Wavelength extraction failed: {e}")
            # Return default NIR wavelength range
            return np.linspace(1000, 2500, len(data.columns))
    
    def apply_spectral_configuration(self, config):
        """Apply spectral configuration to system"""
        self.current_spectral_config = config
        self.logger.info(f"Applying spectral configuration: {config.get('spectral_type', 'unknown')}")
        
        # Notify other components to update configuration
        if hasattr(self.view, 'update_spectral_config'):
            self.view.update_spectral_config(config)
    
    def show_configuration_info(self, config):
        """Display configuration information"""
        spectral_type = config.get('spectral_type', 'unknown')
        adaptation_level = config.get('adaptation_level', 'basic')
        
        message = f"""Spectral configuration applied:
        
Spectral Type: {spectral_type.upper()}
Adaptation Level: {adaptation_level.title()}
Preprocessing Steps: {len(config.get('preprocessing_config', {}))} steps

Configuration saved and will be used for subsequent preprocessing and modeling analysis."""
        
        QMessageBox.information(self.view, "Spectral Configuration", message)
    
    def use_default_configuration(self):
        """Use default configuration"""
        default_config = {
            "spectral_type": "nir",
            "adaptation_level": "basic",
            "preprocessing_config": {},
            "parameter_adaptations": {}
        }
        self.current_spectral_config = default_config
        self.logger.info("Using default spectral configuration")
    
    def get_current_spectral_config(self):
        """Get current spectral configuration"""
        return self.current_spectral_config
    
    def has_data(self):
        """Check if data exists"""
        return self.data_model.has_data()

    def get_current_data(self):
        """Get current data"""
        return self.data_model.get_data()

    def get_wavelengths(self):
        """Get wavelength information"""
        data = self.data_model.get_data()
        if data is not None:
            return self.extract_wavelengths(data)
        return None

    def apply_data_partitioning(self, method=None, params=None):
        data = self.data_model.get_data()
        if data is None:
            self.view.display_message("No data loaded.", "Error")
            return
        try:
            if method is None:
                method = "Train-Test Split"
            params = {} if params is None else dict(params)
            task_type = params.get('task_type')
            partitioned_data = self.partition_data(method, params, task_type)
            if partitioned_data is None:
                return None
            task_type = self.data_model.task_type
            self.view.display_message(f"Data successfully partitioned using {method}. Task type: {task_type}", "Info")

            try:
                dialog = DataPartitioningResultsDialog(
                    partitioned_data=partitioned_data,
                    method=method,
                    task_type=task_type,
                    parent=self.view
                )
                dialog.exec_()
            except Exception as viz_error:
                self.logger.warning(f"Partition results dialog failed: {viz_error}")
                self.view.display_message("Data partitioned successfully, but results dialog failed", "Warning")

            return partitioned_data
        except Exception as e:
            error_msg = f"Data partitioning failed: {str(e)}"
            self.view.display_message(error_msg, "Error")
            return None

    def _validate_partition_result(self, partitioned_data, expected_row_keys=None,
                                   expected_feature_columns=None):
        """Validate that a partitioning result contains all required keys with compatible shapes."""
        required_keys = ['X_train', 'X_test', 'y_train', 'y_test']
        missing = [k for k in required_keys if k not in partitioned_data or partitioned_data[k] is None]
        if missing:
            raise DataServiceError(f"Partitioning result missing required keys: {', '.join(missing)}")

        X_train = partitioned_data['X_train']
        X_test = partitioned_data['X_test']
        y_train = partitioned_data['y_train']
        y_test = partitioned_data['y_test']

        if not hasattr(X_train, 'shape') or len(X_train.shape) != 2:
            raise DataServiceError("X_train must be a 2D array or DataFrame")
        if not hasattr(X_test, 'shape') or len(X_test.shape) != 2:
            raise DataServiceError("X_test must be a 2D array or DataFrame")

        if X_train.shape[1] != X_test.shape[1]:
            raise DataServiceError(
                f"Feature count mismatch: X_train has {X_train.shape[1]} features, "
                f"X_test has {X_test.shape[1]} features"
            )

        train_samples = len(y_train)
        test_samples = len(y_test)

        if train_samples != X_train.shape[0]:
            raise DataServiceError(
                f"Sample count mismatch: X_train has {X_train.shape[0]} rows, "
                f"y_train has {train_samples} rows"
            )
        if test_samples != X_test.shape[0]:
            raise DataServiceError(
                f"Sample count mismatch: X_test has {X_test.shape[0]} rows, "
                f"y_test has {test_samples} rows"
            )

        if expected_row_keys is not None:
            if not isinstance(X_train, pd.DataFrame) or not isinstance(X_test, pd.DataFrame):
                raise DataServiceError("A verified split must return DataFrames indexed by internal row_key")
            if not isinstance(y_train, pd.Series) or not isinstance(y_test, pd.Series):
                raise DataServiceError("A verified split must return Series indexed by internal row_key")
            train_keys = partitioned_data.get('train_row_keys')
            test_keys = partitioned_data.get('test_row_keys')
            if train_keys is None or test_keys is None:
                raise DataServiceError("Partitioning result is missing train/test row_key evidence")
            train_keys, test_keys = list(train_keys), list(test_keys)
            all_keys = set(expected_row_keys)
            if (len(train_keys) != len(set(train_keys))
                    or len(test_keys) != len(set(test_keys))
                    or set(train_keys) & set(test_keys)
                    or set(train_keys) | set(test_keys) != all_keys):
                raise DataServiceError("Train/test row_keys must be unique, disjoint, and cover the current dataset")
            if (not X_train.index.equals(pd.Index(train_keys, name='_row_key'))
                    or not X_test.index.equals(pd.Index(test_keys, name='_row_key'))
                    or X_train.index.name != '_row_key' or X_test.index.name != '_row_key'):
                raise DataServiceError("X row order does not match the returned internal row_keys")
            if not y_train.index.equals(X_train.index) or not y_test.index.equals(X_test.index):
                raise DataServiceError("X/y train/test row-key order does not match")
            if expected_feature_columns is not None and (
                list(X_train.columns) != list(expected_feature_columns)
                or list(X_test.columns) != list(expected_feature_columns)
            ):
                raise DataServiceError("Partitioning changed the source feature columns")
            for key, expected_index in (
                ('sample_id_train', X_train.index), ('group_id_train', X_train.index),
                ('sample_id_test', X_test.index), ('group_id_test', X_test.index),
            ):
                identity = partitioned_data.get(key)
                if identity is not None and (
                    not isinstance(identity, pd.Series) or not identity.index.equals(expected_index)
                ):
                    raise DataServiceError(f"{key} is not aligned to its X rows by internal row_key")
                if identity is not None:
                    text = identity.astype('string')
                    if (
                        text.isna().any()
                        or (text == '').any()
                        or (text != text.str.strip()).any()
                        or text.str.casefold().isin({'nan', 'none', '<na>'}).any()
                    ):
                        raise DataServiceError(f"{key} contains a noncanonical, missing, or null-sentinel ID")
            if partitioned_data.get('group_validation'):
                train_groups = partitioned_data.get('group_id_train')
                test_groups = partitioned_data.get('group_id_test')
                if train_groups is None or test_groups is None:
                    raise DataServiceError("Group validation result is missing explicit group IDs")
                if set(train_groups) & set(test_groups):
                    raise DataServiceError("Group validation result overlaps train and test group IDs")
                train_samples = partitioned_data.get('sample_id_train')
                test_samples = partitioned_data.get('sample_id_test')
                if train_samples is not None and test_samples is not None and (
                    set(train_samples) & set(test_samples)
                ):
                    raise DataServiceError("Group validation result overlaps train and test physical sample IDs")

    def _notify_dataset_state_changed(self):
        """Clear view-level matrices derived from an earlier dataset or split."""
        invalidate = getattr(self.view, 'invalidate_dataset_feature_state', None)
        if callable(invalidate):
            invalidate()

    def apply_column_mapping(self, mapping):
        """Commit confirmed input roles before clearing downstream UI state."""
        try:
            partition_view = getattr(self.view, 'data_partitioning_view', None)
            sample_column = partition_view.sample_id_combo.currentData() if partition_view is not None else self.data_model.sample_id_column_index
            group_column = partition_view.group_id_combo.currentData() if partition_view is not None else self.data_model.group_id_column_index
            self.data_model.set_column_mapping(mapping, sample_column, group_column)
            self._notify_dataset_state_changed()
            return True
        except (ValueError, TypeError) as exc:
            self.view.display_error(f'Column mapping failed: {exc}')
            return False

    def partition_data(self, method, params=None, task_type=None):
        try:
            data = self.data_model.get_data()
            if data is None:
                raise ValueError("No data loaded")

            if params is None:
                params = {}
            else:
                params = dict(params)

            target_column = params.get('target_column', self.data_model.label_column_index)
            if isinstance(target_column, str) and target_column.isdigit():
                target_column = int(target_column)
            elif isinstance(target_column, str) and target_column in data.columns:
                target_column = int(data.columns.get_loc(target_column))
            if isinstance(target_column, bool) or not isinstance(target_column, Integral) or not 0 <= target_column < data.shape[1]:
                raise ValueError("target_column must identify a valid data column")
            target_column = int(target_column)
            sample_column = self.data_service._resolve_identity_column(
                data, params.get('sample_id_column', self.data_model.sample_id_column_index), 'sample_id'
            )
            group_column = self.data_service._resolve_identity_column(
                data, params.get('group_id_column', self.data_model.group_id_column_index), 'group_id'
            )
            # The view only supplies wavelength_columns when the user has made
            # an explicit spectral-column selection. Otherwise derive features
            # from the current target and identity controls; a cached mapping
            # may predate a later change to sample/group ID selectors.
            selected_wavelengths = params.get('wavelength_columns')
            feature_positions = spectral_column_positions(
                data, target_column, (sample_column, group_column), selected_wavelengths
            )
            # Commit the same canonical mapping consumed by DataService. This
            # also invalidates an earlier split/model if input roles changed.
            mapping_changed = (
                self.data_model.label_column_index != target_column
                or self.data_model.sample_id_column_index != sample_column
                or self.data_model.group_id_column_index != group_column
                or self.data_model.wavelength_column_positions != feature_positions
            )
            if mapping_changed:
                self.data_model.set_column_mapping(
                    {'label_column': target_column, 'wavelength_columns': feature_positions},
                    sample_column, group_column,
                )
            params.update({
                'target_column': target_column,
                'sample_id_column': sample_column,
                'group_id_column': group_column,
                'wavelength_columns': feature_positions,
            })
            y_raw = data.iloc[:, target_column]
            processor = EnhancedLabelProcessor()
            requested_task = task_type or params.get('task_type')
            if requested_task is None:
                requested_task = processor.detect_task_type(y_raw)
                if params.get('force_classification', False):
                    requested_task = 'classification'
                elif params.get('force_regression', False):
                    requested_task = 'regression'
            task_type = requested_task
            try:
                processed_labels, label_metadata = processor.process_labels_smart(y_raw, task_type)
            except ValueError as label_error:
                if 'non-numeric values' in str(label_error) and task_type == 'regression':
                    task_type = 'classification'
                    processed_labels, label_metadata = processor.process_labels_smart(y_raw, task_type)
                else:
                    raise
            params.update({
                'target_column': target_column,
                'task_type': task_type,
                'processed_labels': processed_labels,
                'original_labels': y_raw,
                'label_metadata': label_metadata,
                'row_keys': list(self.data_model.get_row_keys()),
            })

            # Ensure task type is passed through params for the refactored service
            if task_type is not None and 'task_type' not in params:
                params['task_type'] = task_type

            partitioned_data = self.data_service.partition_data(
                data=data,
                method=method,
                params=params
            )

            # Validate required keys and compatible shapes before mutating DataModel
            self._validate_partition_result(
                partitioned_data,
                expected_row_keys=params['row_keys'],
                expected_feature_columns=[data.columns[i] for i in feature_positions],
            )

            self.data_model.set_partitioned_data(
                partitioned_data,
                task_type=task_type,
                label_metadata=label_metadata,
                label_processor=processor,
            )
            self.label_processor = processor
            self._notify_dataset_state_changed()
            return partitioned_data

        except Exception as e:
            self.view.display_error(f"Data partitioning failed: {str(e)}")
            return None

    def _check_data_types(self, X_train, y_train, X_test, y_test):
        if hasattr(X_train, 'dtypes'):
            non_numeric_cols = X_train.select_dtypes(exclude=['number']).columns.tolist()
            na_cols = X_train.columns[X_train.isna().any()].tolist()
        
        if y_train is not None:
            if hasattr(y_train, 'nunique'):
                unique_values = y_train.nunique()
                total_samples = len(y_train)
                # Basic data type checks, no detailed output needed
            else:
                if hasattr(y_train, 'dtype') and hasattr(y_train, 'shape'):
                    unique_values = len(np.unique(y_train))
                    total_samples = y_train.shape[0]
