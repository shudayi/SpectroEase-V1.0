# from utils.visualization_window import VisualizationWindow  # Temporarily disabled for packaging
from app.utils.logger import setup_logger
from app.utils.exceptions import ModelingError
from app.services.modeling_service import ModelingService
from app.models.modeling_model import ModelingModel
from app.utils.label_processor import EnhancedLabelProcessor
from app.services.onnx_service import ONNXService
import numpy as np
import pandas as pd
import os

class ModelingController:
    def __init__(self, view, translator, data_model, plugins):
        self.view = view
        self.translator = translator
        self.data_model = data_model
        self.modeling_service = ModelingService(plugins)
        self.modeling_model = ModelingModel()
        self.onnx_service = ONNXService(save_directory="models")
        self.logger = setup_logger()
        
        from app.services.evaluation_service import EvaluationService
        self.evaluation_service = EvaluationService()
        
        self.modeling_service.evaluation_service = self.evaluation_service
        

        self.label_processor = EnhancedLabelProcessor()
        self.logger.debug("ModelingController initialized with EnhancedLabelProcessor")

    def train_model(self, algorithm, params, task_type=None):
        """Train a model using the active analyzer path and return a result dict.

        Args:
            algorithm: Modeling algorithm/method name.
            params: Algorithm parameters.
            task_type: Explicit task type ('classification' or 'regression').
                       When omitted, it is derived from the analysis context.
        """
        try:
            modeling_result = self.apply_modeling(method=algorithm, params=params, task_type=task_type)
            if modeling_result is None:
                return None

            return {
                'model': getattr(modeling_result, 'model', None),
                'algorithm': algorithm,
                'task_type': getattr(modeling_result, 'task_type', 'unknown'),
                'evaluation': getattr(modeling_result, 'evaluation_results', None),
                'feature_names': getattr(modeling_result, 'feature_names', None),
                'training_params': params,
                'predictions': getattr(modeling_result, 'predictions', [])
            }
        except Exception as e:
            raise ModelingError(f"Model training failed: {str(e)}")

    def get_model_data(self):
        return self.modeling_model.get_model_data()

    def has_trained_model(self):
        return self.modeling_model.has_model_data()

    def auto_save_onnx_model(self, trained_model, X_sample, method, evaluation_results):
        try:

            if hasattr(trained_model, 'model'):
                model = trained_model.model
            elif hasattr(trained_model, 'trained_model'):
                model = trained_model.trained_model
            else:
                model = trained_model
            

            if model is None:
                self.logger.warning("No model available for ONNX export")
                return
            

            self.logger.info("Auto-saving estimator artifact...")
            
            onnx_path = self.onnx_service.auto_save_model(
                model=model,
                X_sample=X_sample,
                model_name=type(model).__name__,
                method=method,
                evaluation_results=evaluation_results
            )
            
            if onnx_path:
                export_format = 'ONNX' if onnx_path.lower().endswith('.onnx') else 'pickle'
                self.view.display_message(
                    f"Estimator automatically saved in {export_format} format.\n\nFile: {os.path.basename(onnx_path)}\nLocation: {os.path.dirname(onnx_path)}",
                    "Information"
                )
                self.logger.info(f"Estimator artifact saved successfully: {onnx_path}")
            else:
                self.logger.info("Model could not be exported to ONNX format (unsupported model type)")
                
        except Exception as e:
            self.logger.error(f"Error in auto_save_onnx_model: {e}")


    def evaluate_model(self, model_id: str = None, X_test=None, y_test=None):
        self.logger.info("Starting model evaluation process...")

        try:
            model_data = None
            if model_id:
                model_data = self.modeling_service.get_model_data(model_id)
            if not model_data:
                model_data = self.modeling_model.get_model_data()
            if not model_data:
                # Fall back to the currently trained model if no registry entry exists.
                if self.modeling_model.trained_model is not None:
                    class SimpleModelData:
                        def __init__(self, model, task_type, fitted_predictor=None):
                            self.model = model
                            self.task_type = task_type
                            self.fitted_predictor = fitted_predictor
                            self.test_data = {}
                    analysis_type = self.modeling_model.analysis_type or 'quantitative'
                    fallback_task_type = 'classification' if analysis_type == 'qualitative' else 'regression'
                    model_data = SimpleModelData(
                        self.modeling_model.trained_model,
                        fallback_task_type,
                        getattr(self.modeling_model, 'fitted_predictor', None),
                    )
                else:
                    return {"error": "Model not found"}

            if X_test is None or y_test is None:
                if hasattr(model_data, 'test_data') and model_data.test_data is not None:
                    X_test = model_data.test_data.get('X_test')
                    y_test = model_data.test_data.get('y_test')
                else:
                    X_test = self.data_model.X_test
                    y_test = self.data_model.y_test

                if X_test is None or y_test is None:
                    return {"error": "Test data incomplete"}

            predictor = (
                getattr(model_data, 'fitted_predictor', None)
                or getattr(getattr(model_data, 'analyzer', None), 'fitted_predictor', None)
                or getattr(self.modeling_model, 'fitted_predictor', None)
            )
            if predictor is None:
                return {"error": "Evaluation requires a fitted spectral prediction contract; the bare estimator has lost its transforms."}

            self.logger.info("Model evaluation - Model type: %s", type(model_data.model).__name__)
            self.logger.debug("Test data shape: X=%s, y=%s", X_test.shape,
                              len(y_test) if hasattr(y_test, '__len__') else 'scalar')
            self.logger.debug("Test labels sample: %s",
                              list(y_test[:5]) if hasattr(y_test, '__getitem__') else [y_test])

            if isinstance(X_test, pd.DataFrame):
                self.logger.debug("Test features are DataFrame")
            elif not isinstance(X_test, np.ndarray):
                X_test = np.array(X_test)
                self.logger.debug("Converted test features to numpy array")

            if hasattr(model_data, 'task_type'):
                model_type = model_data.task_type
                self.logger.info("Task type from model_data: %s", model_type)
            else:
                model_type = self.label_processor.detect_task_type(y_test)
                self.logger.info("Enhanced auto-detected task type: %s", model_type)

            prediction_result = None
            try:
                test_scope = getattr(model_data, 'test_data', {}) or {}
                row_ids = test_scope.get('row_ids')
                physical_ids = test_scope.get('physical_sample_ids')
                group_ids = test_scope.get('group_ids')
                if test_scope.get('X_test') is not X_test and hasattr(X_test, 'index'):
                    row_ids = list(X_test.index)
                    sample_values = getattr(self.data_model, 'sample_id_test', None)
                    group_values = getattr(self.data_model, 'group_id_test', None)
                    if sample_values is not None:
                        physical_ids = sample_values.loc[X_test.index].tolist() if hasattr(sample_values, 'loc') else list(sample_values)
                    if group_values is not None:
                        group_ids = group_values.loc[X_test.index].tolist() if hasattr(group_values, 'loc') else list(group_values)

                prediction_result, metrics = self.evaluation_service.evaluate_with_prediction(
                    predictor, X_test, y_test, task_type=model_type,
                    metrics=(['rmse', 'mae', 'r2'] if model_type == 'regression'
                             else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
                    row_ids=row_ids, physical_sample_ids=physical_ids,
                    group_ids=group_ids,
                )

                if isinstance(metrics, dict) and metrics.get('error'):
                    self.logger.error("Evaluation service returned error: %s", metrics.get('error'))
                    raise ValueError(metrics.get('error'))

                model_data.evaluation_results = metrics
                model_data.prediction_result = prediction_result
                self.modeling_service.update_model_data(model_id, model_data)
                return metrics

            except Exception as e:
                error_message = str(e)
                self.logger.warning("Primary evaluation failed: %s", error_message)

                if "mix of continuous" in error_message or "mix of" in error_message:
                    self.logger.info("Attempting to handle mixed label types...")

                    try:

                        y_test_processed, label_metadata = self.label_processor.process_labels_smart(y_test, model_type)
                        self.logger.info("Smart label processing completed: %s", label_metadata)

                        if prediction_result is not None:
                            metrics = self.evaluation_service.evaluate_prediction_result(
                                y_test_processed, prediction_result,
                                metrics=(['rmse', 'mae', 'r2'] if model_type == 'regression'
                                         else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
                                task_type=model_type,
                                row_ids=row_ids, physical_sample_ids=physical_ids,
                                group_ids=group_ids,
                            )
                        else:
                            # If the first predictor call failed before it
                            # returned a vector, any retry must still go through
                            # the fitted contract; a bare estimator is unsafe.
                            prediction_result, metrics = self.evaluation_service.evaluate_with_prediction(
                                predictor, X_test, y_test_processed, task_type=model_type,
                                metrics=(['rmse', 'mae', 'r2'] if model_type == 'regression'
                                         else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
                                row_ids=row_ids, physical_sample_ids=physical_ids,
                                group_ids=group_ids,
                            )
                        if isinstance(metrics, dict) and metrics.get('error'):
                            raise ValueError(str(metrics['error']))
                        self.logger.info("Evaluation with processed labels successful")

                        if not isinstance(metrics, dict):
                            metrics = {"result": str(metrics), "note": "Used smart label processing for mixed types"}
                        else:
                            metrics["note"] = "Used smart label processing for mixed types"
                            metrics["label_metadata"] = label_metadata

                        model_data.evaluation_results = metrics
                        self.modeling_service.update_model_data(model_id, model_data)
                        return metrics

                    except Exception as backup_error:
                        self.logger.warning("Smart label processing also failed: %s", backup_error)
                        return {
                            "error": (
                                "Evaluation failed with the fitted prediction contract; "
                                "bare-estimator fallback is disabled: "
                                f"{str(backup_error)}"
                            ),
                            "original_error": error_message,
                        }

                return {"error": f"Evaluation failed: {error_message}"}

        except Exception as e:
            self.logger.error("Evaluation process error: %s", e)
            return {"error": f"Evaluation process error: {str(e)}"}

    def apply_modeling(self, method=None, params=None, task_type=None):
        """Apply modeling with the specified method and parameters."""
        try:
            if self.data_model is None:
                raise ValueError("No data available for modeling")

            X_train = self.data_model.X_train
            y_train = self.data_model.y_train
            X_test = self.data_model.X_test
            y_test = self.data_model.y_test

            if X_train is None or y_train is None:
                raise ValueError("Training data is not available")

            if task_type is not None:
                if task_type not in {'classification', 'regression'}:
                    raise ValueError(f'Unsupported task_type: {task_type}')
            else:
                context = str(getattr(self.modeling_model, 'analysis_type', '')).lower()
                if context in {'qualitative', 'classification'}:
                    task_type = 'classification'
                elif context in {'quantitative', 'regression'}:
                    task_type = 'regression'
                else:
                    task_type = self.label_processor.detect_task_type(y_train)
            analysis_type = 'qualitative' if task_type == 'classification' else 'quantitative'

            original_label_mapping = getattr(self.data_model, 'label_mapping', None)
            self.logger.debug("Original label mapping available: %s", original_label_mapping is not None)

            train_index = X_train.index if hasattr(X_train, 'index') else None
            test_index = X_test.index if hasattr(X_test, 'index') else None

            def aligned_scope(value, index):
                if value is None:
                    return None
                if index is not None and hasattr(value, 'loc'):
                    return value.loc[index].tolist()
                return list(value)

            modeling_result = self.modeling_service.apply_modeling(
                X_train, y_train, X_test, y_test, method,
                analysis_type=analysis_type, model_params=params,
                train_row_ids=list(train_index) if train_index is not None else None,
                test_row_ids=list(test_index) if test_index is not None else None,
                train_physical_sample_ids=aligned_scope(getattr(self.data_model, 'sample_id_train', None), train_index),
                test_physical_sample_ids=aligned_scope(getattr(self.data_model, 'sample_id_test', None), test_index),
                train_group_ids=aligned_scope(getattr(self.data_model, 'group_id_train', None), train_index),
                test_group_ids=aligned_scope(getattr(self.data_model, 'group_id_test', None), test_index),
                group_validation=bool(getattr(self.data_model, 'group_validation', False)),
                input_representation=getattr(
                    self.data_model, 'partitioned_input_representation',
                    'fitted_feature_matrix',
                ),
            )

            # Sync result into modeling_model so other controllers can use it.
            self.modeling_model.set_model(modeling_result.model)
            self.modeling_model.trained_model = modeling_result.trained_model
            self.modeling_model.fitted_predictor = modeling_result.fitted_predictor
            self.modeling_model.prediction_result = modeling_result.prediction_result
            self.modeling_model.analyzer = modeling_result.analyzer
            self.modeling_model.set_method(method or '')
            self.modeling_model.set_training_data(X_train, y_train)
            self.modeling_model.set_evaluation_results(modeling_result.evaluation_results)
            self.modeling_model.set_analysis_type(analysis_type)
            self.modeling_model.set_model_data(modeling_result)

            predictions = (
                modeling_result.get('predictions')
                if isinstance(modeling_result, dict)
                else getattr(modeling_result, 'predictions', None)
            )
            if predictions is not None:
                # ModelingService returns predictions from the fitted contract
                # in original target space. Do not remap or stringify them here:
                # that would diverge from the stored PredictionResult/metrics.
                self.logger.debug(
                    "Contract predictions type: %s, sample: %s",
                    type(predictions),
                    predictions[:5] if len(predictions) > 5 else predictions,
                )

            self.data_model.modeling_result = modeling_result
            return modeling_result

        except Exception as e:
            error_msg = f"Modeling failed: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
