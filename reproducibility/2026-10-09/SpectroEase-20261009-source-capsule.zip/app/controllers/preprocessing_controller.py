# app/controllers/preprocessing_controller.py

# from utils.visualization_window import VisualizationWindow  # Temporarily disabled for packaging
try:
    from app.utils.exceptions import PreprocessingError
    from app.utils.logger import setup_logger
except ImportError:
    try:
        from exceptions import PreprocessingError
        from logger import setup_logger
    except ImportError:
        from ..utils.exceptions import PreprocessingError
        from ..utils.logger import setup_logger
try:
    from app.services.preprocessing_service import PreprocessingService
except ImportError:
    # 尝试直接导入（用于PyInstaller打包）
    try:
        from preprocessing_service import PreprocessingService
    except ImportError:
        # 最后尝试相对导入
        from ..services.preprocessing_service import PreprocessingService
from app.services.preprocessing_registry import get_entry
try:
    from app.models.preprocessing_model import PreprocessingModel
    from app.utils.label_processor import EnhancedLabelProcessor
except ImportError:
    try:
        from preprocessing_model import PreprocessingModel
        from label_processor import EnhancedLabelProcessor
    except ImportError:
        from ..models.preprocessing_model import PreprocessingModel
        from ..utils.label_processor import EnhancedLabelProcessor

import pandas as pd

from app.utils.worker import Worker


class _PreprocessingWorker(Worker):
    """Run preprocessing off the UI thread and return a plain result dict.

    The worker reads a snapshot of the input data from the controller/model on
    the UI thread before it starts (see
    ``PreprocessingController.start_preprocessing_worker``), so it never
    touches ``DataModel`` from the background thread.  The result dict is
    emitted via ``result_ready`` and must be applied to ``DataModel`` on the
    UI thread by the caller.

    Result dict keys:
      - ``success`` (bool)
      - ``X_train``, ``X_test`` (partitioned mode)
      - ``X_processed`` (full or combined processed features)
      - ``preprocessed_data`` (alias for ``X_processed``)
      - ``applied_methods_log`` (list of applied method display names)
      - ``is_partitioned`` (bool)
      - ``methods`` (original method keys requested)
      - ``params_dict`` (parameters used)
    """

    def __init__(self, controller, methods, params_dict, parent=None):
        super().__init__(parent)
        self._controller = controller
        self._methods = methods
        self._params = params_dict

    def run_task(self):
        result = self._controller._apply_preprocessing_async(
            self._methods, self._params
        )
        if result is None or not result.get('success'):
            raise PreprocessingError(
                result.get('error', "Preprocessing failed") if isinstance(result, dict)
                else "Preprocessing failed"
            )
        return result


class PreprocessingController:
    def __init__(self, view, translator, data_model, plugins):
        self.view = view
        self.translator = translator
        self.data_model = data_model
        self.preprocessing_service = PreprocessingService(plugins)
        self.preprocessing_model = PreprocessingModel()
        self.logger = setup_logger()

        self.method_mapping = {
            'despiking': 'Despiking',
            'baseline_correction': 'Baseline Correction',
            'smoothing': 'Savitzky-Golay Filter',
            'scatter_correction': 'Standard Normal Variate (SNV)',
            'standardization': 'Standard Scale',
            'normalization': 'Min-Max Scale',
            'derivative': 'First Derivative',
            'outlier_detection': 'Outlier Detection',
            'denoising': 'Gaussian Smooth',
            'alignment': 'Peak Alignment'
        }

        self.scatter_method_mapping = {
            'SNV': 'Standard Normal Variate (SNV)',
            'MSC': 'Multiplicative Scatter Correction (MSC)',
            'EMSC': 'Extended Multiplicative Scatter Correction (EMSC)',
            'RNV': 'Robust Normal Variate (RNV)',
            'OSC': 'Orthogonal Signal Correction (OSC)'
        }

    def apply_preprocessing(self, methods, params_dict=None):
        """
        Apply preprocessing methods to the spectral data.
        Handles both partitioned (train/test) and unpartitioned data.

        This synchronous entry point is kept for backward compatibility:
        it performs the heavy work off-thread via ``_apply_preprocessing_async``
        and then applies the returned result dict to ``DataModel``.
        """
        self.logger.info(f"Starting preprocessing with methods: {methods}")
        if self.data_model is None:
            self.logger.error("DataModel is not initialized.")
            print("ERROR: DataModel not found.")
            return False

        result = self._apply_preprocessing_async(methods, params_dict)
        if result is None or not result.get('success'):
            return False

        # Apply the result dict on the calling (UI) thread.
        if not self.data_model.set_preprocessing_result(result):
            self.logger.warning("Discarded preprocessing output for a stale dataset/split revision")
            return False

        self.record_applied_methods(result)

        self.logger.info(
            f"Preprocessing completed. Applied {len(result.get('applied_methods_log', []))} "
            f"methods: {result.get('applied_methods_log', [])}"
        )
        print(
            f"Preprocessing completed successfully. Applied "
            f"{len(result.get('applied_methods_log', []))} methods: "
            f"{result.get('applied_methods_log', [])}"
        )
        return True

    def record_applied_methods(self, result):
        """Record only committed successful results, on the caller's UI thread."""
        if not isinstance(result,dict) or not result.get('success'):
            return False
        self.preprocessing_model.applied_methods = {}
        params_dict=result.get('params_dict',{})
        steps=result.get('applied_method_steps')
        if steps is None:
            # Compatibility with legacy worker result dictionaries.
            steps=[]
            for applied in result.get('applied_methods_log',[]):
                original=next((key for key in result.get('methods',[])
                               if self._resolve_service_method(key,params_dict)==applied),applied)
                steps.append({'method':applied,'params':params_dict.get(original,{})})
        import copy
        self.preprocessing_model.applied_steps = copy.deepcopy(steps)
        for step in steps:
            self.preprocessing_model.add_applied_method(step['method'],str(step['params']))
        return True

    def _apply_preprocessing_async(self, methods, params_dict=None):
        """
        Perform preprocessing without touching ``DataModel``.

        Reads all required state from ``self.data_model`` up front, runs the
        processing pipeline, and returns a plain result dict.  This method is
        safe to call from a worker thread because it does not mutate shared
        state.

        Returns ``None`` if prerequisites are missing, or a result dict on
        success/failure (with ``success=False`` on failure).
        """
        if params_dict is None:
            params_dict = {}

        state_revision = self.data_model.get_state_revision()

        # --- 1. Snapshot the data source from DataModel ---
        has_split_attempt = getattr(self.data_model, 'has_split_attempt', None)
        split_attempt = (
            bool(has_split_attempt()) if callable(has_split_attempt)
            else self.data_model.has_partitioned_data() or any(
                getattr(self.data_model, name, None) is not None
                for name in ('X_train', 'y_train', 'X_test', 'y_test')
            )
        )
        is_partitioned = self.data_model.has_partitioned_data()
        X_train, X_test, X_full = None, None, None

        # Legacy callers may populate train/test fields without a partition
        # record. Never reinterpret that state as a full-data preview.
        has_verified_split = getattr(self.data_model, 'has_verified_split', None)
        verified_split = (
            bool(has_verified_split()) if callable(has_verified_split)
            else is_partitioned and getattr(self.data_model, 'row_alignment_verified', False)
            and all(getattr(self.data_model, name, None) is not None
                    for name in ('X_train', 'y_train', 'X_test', 'y_test'))
        )
        if split_attempt and not verified_split:
            return {
                'success': False,
                'error': (
                    'Train/test fields exist without a verified row_key partition. '
                    'Recreate the split before preprocessing/modeling.'
                ),
            }
        is_partitioned = split_attempt

        if is_partitioned:
            self.logger.info("Processing partitioned data (X_train, X_test).")
            X_train, X_test = self.data_model.get_partitioned_features()
            if X_train is None or X_test is None:
                self.logger.error("Partitioned data (X_train/X_test) is missing in DataModel.")
                print("ERROR: Partitioned data is missing.")
                return {'success': False}
            if not self.data_model.row_alignment_verified:
                return {
                    'success': False,
                    'error': 'This split has no verified internal row_key alignment. Recreate the split before preprocessing/modeling.',
                }
            partition = self.data_model.get_partitioned_data()
            train_keys = pd.Index(partition.get('train_row_keys', []), name='_row_key')
            test_keys = pd.Index(partition.get('test_row_keys', []), name='_row_key')
            if (not X_train.index.equals(train_keys)
                    or not X_test.index.equals(test_keys)
                    or not self.data_model.y_train.index.equals(train_keys)
                    or not self.data_model.y_test.index.equals(test_keys)):
                return {
                    'success': False,
                    'error': 'X/y split row_key order is inconsistent. Recreate the split before preprocessing/modeling.',
                }
        else:
            self.logger.info("Processing full dataset.")
            X_full = self.data_model.get_X()
            if X_full is None:
                self.logger.error("Full dataset (X) is missing in DataModel.")
                print("ERROR: No data to process.")
                return {'success': False}

        # --- 2. Order methods (logic from original function) ---
        expert_order = [
            'Despiking', 'Peak Alignment', 'Baseline Correction',
            'Standard Normal Variate (SNV)', 'Multiplicative Scatter Correction (MSC)',
            'Extended Multiplicative Scatter Correction (EMSC)', 'Robust Normal Variate (RNV)',
            'Orthogonal Signal Correction (OSC)', 'First Derivative', 'Second Derivative',
            'Savitzky-Golay Filter', 'Moving Average', 'Median Filter', 'Gaussian Smooth',
            'Wavelet Smooth', 'Normalize', 'Standard Scale', 'Min-Max Scale',
            'Vector Normalization', 'Area Normalization', 'Maximum Normalization'
        ]
        ordered_methods = []
        for expert_method in expert_order:
            if expert_method in methods:
                ordered_methods.append(expert_method)
        for method in methods:
            if method not in ordered_methods:
                ordered_methods.append(method)

        # These built-ins either estimate a reference/scaling state from the
        # supplied cohort, alter rows, or process each feature column across
        # samples. Until they expose fit(train)/transform(test), fail closed.
        # The allowlist contains implementations that operate independently
        # within each spectrum along its feature axis.
        samplewise_methods = {
            'Standard Normal Variate (SNV)', 'Robust Normal Variate (RNV)',
            'Normalize', 'Vector Normalization', 'Area Normalization',
            'Maximum Normalization', 'First Derivative', 'Second Derivative',
            'Third Derivative',
            'Savitzky-Golay Derivative', 'Finite Difference',
            'Gap-Segment Derivative',
        }
        if is_partitioned:
            unsupported = []
            for method in ordered_methods:
                service_method = self._resolve_service_method(method, params_dict)
                entry = get_entry(service_method)
                verified_stateless_plugin = (
                    entry is not None
                    and entry.category == 'plugin'
                    and entry.quality == 'verified-stateless'
                )
                if service_method not in samplewise_methods and not verified_stateless_plugin:
                    unsupported.append(service_method)
            if unsupported:
                return {
                    'success': False,
                    'error': (
                        'Partitioned modeling currently accepts only verified sample-wise transforms. '
                        'These methods require a reusable train-fitted state or can change cohort rows: '
                        + ', '.join(dict.fromkeys(unsupported))
                    ),
                }

        self.logger.info(f"Original user order: {methods}")
        self.logger.info(f"Expert chemometrics order: {ordered_methods}")
        print(f"Expert chemometrics order: {ordered_methods}")

        # --- 3. Apply processing ---
        try:
            final_applied_methods = []

            if is_partitioned:
                print(f"Input X_train shape: {X_train.shape}")
                X_train_processed, train_methods = self._process_data(
                    X_train, ordered_methods, params_dict, require_row_alignment=True
                )
                print(f"Processed X_train shape: {X_train_processed.shape}")

                print(f"Input X_test shape: {X_test.shape}")
                X_test_processed, test_methods = self._process_data(
                    X_test, ordered_methods, params_dict, require_row_alignment=True
                )
                print(f"Processed X_test shape: {X_test_processed.shape}")

                combined_processed = pd.concat([X_train_processed, X_test_processed])
                combined_processed = combined_processed.reindex(self.data_model.get_row_keys())
                final_applied_methods = train_methods
                X_processed = combined_processed
            else:
                print(f"Input X_full shape: {X_full.shape}")
                X_full_processed, full_methods = self._process_data(
                    X_full, ordered_methods, params_dict
                )
                print(f"Processed X_full shape: {X_full_processed.shape}")

                X_train_processed = None
                X_test_processed = None
                X_processed = X_full_processed
                final_applied_methods = full_methods

            return {
                'success': True,
                'X_train': X_train_processed,
                'X_test': X_test_processed,
                'X_processed': X_processed,
                'preprocessed_data': X_processed,
                'applied_methods_log': final_applied_methods,
                'applied_method_steps': [
                    {'method':self._resolve_service_method(key,params_dict),
                     'source_key':key,'params':dict(params_dict.get(key,{}))}
                    for key in ordered_methods
                ],
                'is_partitioned': is_partitioned,
                'methods': methods,
                'params_dict': params_dict,
                'state_revision': state_revision,
                'train_row_keys': list(X_train_processed.index) if is_partitioned else None,
                'test_row_keys': list(X_test_processed.index) if is_partitioned else None,
            }

        except Exception as e:
            self.logger.error(f"Preprocessing failed with a critical error: {e}", exc_info=True)
            print(f"Preprocessing failed with error: {e}")
            return {'success': False, 'error': str(e)}

    def _resolve_service_method(self, method, params_dict):
        service_method = self.method_mapping.get(method, method)
        params = params_dict.get(method, {})
        if method == 'scatter_correction' and 'method' in params:
            if params['method'] not in self.scatter_method_mapping:
                raise PreprocessingError(f"Unsupported scatter method: {params['method']}")
            service_method = self.scatter_method_mapping[params['method']]
        maps={
            'smoothing':{'S-Golay':'Savitzky-Golay Filter','Moving Avg':'Moving Average','Median':'Median Filter','Wavelet':'Wavelet Smooth','Gaussian':'Gaussian Smooth'},
            'standardization':{'Z-Score':'Standard Scale','Robust':'Robust Scale','Min-Max':'Min-Max Scale'},
            'normalization':{'Min-Max':'Min-Max Scale','Vector':'Vector Normalization','Area':'Area Normalization','Maximum':'Maximum Normalization'},
            'alignment':{'DTW':'Peak Alignment','COW':'COW (Correlation Optimized Warping)','ICS':'ICS (Interval Correlation Shifting)'},
        }
        if method in maps and 'method' in params:
            if params['method'] not in maps[method]:
                raise PreprocessingError(f"Unsupported {method} method: {params['method']}")
            service_method=maps[method][params['method']]
        if method == 'baseline_correction':
            submethod=params.get('method','Polynomial')
            baseline_map={'Polynomial':'Baseline Correction','ALS':'Baseline (ALS)','airPLS':'Baseline (airPLS)'}
            if submethod not in baseline_map:
                raise PreprocessingError(f'Unsupported baseline method: {submethod}')
            service_method=baseline_map[submethod]
        if method == 'derivative':
            order=params.get('order',1)
            if order not in (1,2,3):
                raise PreprocessingError('Derivative order must be 1, 2, or 3')
            service_method={1:'First Derivative',2:'Second Derivative',3:'Third Derivative'}[order]
        if method == 'denoising':
            service_method='Denoising'
        return service_method

    def _process_data(self, data_to_process, ordered_methods, params_dict,
                      require_row_alignment=False):
        processed_data = data_to_process.copy()
        applied_methods_log = []
        for method in ordered_methods:
            service_method = self._resolve_service_method(method, params_dict)

            params = dict(params_dict.get(method, {}))
            if service_method in ('Moving Average','Median Filter','Gaussian Smooth') and 'window_length' in params:
                params['window_size']=params.pop('window_length')

            if method == 'scatter_correction' and 'method' in params:
                scatter_method = params['method']
                if scatter_method in self.scatter_method_mapping:
                    service_method = self.scatter_method_mapping[scatter_method]

            self.logger.info(f"Applying method: {service_method} with params: {params}")
            print(f"Applying method: {service_method}")
            try:
                processed_data = self.preprocessing_service.apply_method(
                    processed_data, service_method, params
                )
                if require_row_alignment:
                    if not isinstance(processed_data, pd.DataFrame):
                        raise PreprocessingError(
                            f"{service_method} did not return a DataFrame; row identity cannot be verified"
                        )
                    if (not processed_data.index.equals(data_to_process.index)
                            or list(processed_data.columns) != list(data_to_process.columns)
                            or processed_data.shape != data_to_process.shape):
                        raise PreprocessingError(
                            f"{service_method} changed row identity/order or feature shape"
                        )
                applied_methods_log.append(service_method)
                self.logger.info(f"Successfully applied: {service_method}")
                print(f"Successfully applied: {service_method}")
            except Exception as method_error:
                self.logger.error(
                    f"Failed to apply method {service_method}: {method_error}",
                    exc_info=True
                )
                print(f"Failed to apply method {service_method}: {method_error}")
                # A requested step failing must fail the whole operation. The
                # returned working copy has never been committed to DataModel.
                raise
        return processed_data, applied_methods_log

    def start_preprocessing_worker(self, methods, params_dict, on_result, on_error, on_finished=None):
        """
        Build a ``_PreprocessingWorker`` and wire its signals.

        The worker is reparented to ``None`` so the dialog/view that creates it
        can be closed without destroying the running thread.  The result dict is
        delivered on the UI thread through ``on_result``.
        """
        worker = _PreprocessingWorker(self, methods, params_dict, parent=None)
        worker.result_ready.connect(on_result)
        worker.error_occurred.connect(on_error)
        if on_finished is not None:
            worker.finished.connect(on_finished)
        worker.start()
        return worker

    def get_available_methods(self):
        """Get list of available preprocessing methods"""
        return list(self.method_mapping.keys())

    def get_method_mapping(self):
        """Get the mapping between method names and service methods"""
        return self.method_mapping.copy()

    def _get_method_mapping(self):
        """Internal method to get method mapping"""
        return self.method_mapping.copy()
