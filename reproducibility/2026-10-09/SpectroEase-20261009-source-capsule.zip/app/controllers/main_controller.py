from app.controllers.data_controller import DataController
from app.controllers.preprocessing_controller import PreprocessingController
from app.controllers.feature_selection_controller import FeatureSelectionController
from app.controllers.modeling_controller import ModelingController
from app.controllers.evaluation_controller import EvaluationController
from app.controllers.hyperparameter_optimization_controller import HyperparameterOptimizationController
from plugin_loader import load_plugins
import os
import pandas as pd

class MainController:
    def __init__(self, view, translator):
        self.view = view
        self.translator = translator

        self.data_model = None
        self.modeling_model = None

        self.preprocessing_plugins = view.preprocessing_plugins
        self.feature_selection_plugins = view.feature_selection_plugins
        self.modeling_plugins = view.modeling_plugins
        self.data_partitioning_plugins = view.data_partitioning_plugins

        self.initialize_controllers()
        
    def initialize_controllers(self):
        self.data_controller = DataController(
            self.view, 
            self.translator,
            self.data_partitioning_plugins
        )
        
        self.preprocessing_controller = PreprocessingController(
            view=self.view.preprocessing_view, 
            translator=self.translator,
            plugins=self.preprocessing_plugins,
            data_model=self.data_controller.data_model
        )
        
        self.feature_selection_controller = FeatureSelectionController(
            view=self.view.feature_selection_view, 
            translator=self.translator,
            plugins=self.feature_selection_plugins,
            data_model=self.data_controller.data_model
        )
        
        self.modeling_controller = ModelingController(
            view=self.view.modeling_view, 
            translator=self.translator,
            plugins=self.modeling_plugins,
            data_model=self.data_controller.data_model
        )
        
        self.hyperopt_controller = HyperparameterOptimizationController(
            view=self.view.hyperopt_view, 
            translator=self.translator,
            modeling_model=self.modeling_controller.modeling_model
        )
        
        self.evaluation_controller = EvaluationController(
            view=self.view.evaluation_view, 
            translator=self.translator,
            data_model=self.data_controller.data_model,
            modeling_model=self.modeling_controller.modeling_model
        )

    def check_data_ready(self):
        """Check if data is loaded"""
        if hasattr(self, 'data_controller') and hasattr(self.data_controller, 'data_model'):
            if self.data_controller.data_model.data is not None:
                return True

        if hasattr(self.view, 'spectra_data') and self.view.spectra_data is not None:
            spectra_df = pd.DataFrame(self.view.spectra_data)
            if hasattr(self, 'data_controller') and hasattr(self.data_controller, 'data_model'):
                self.data_controller.data_model.set_data(spectra_df)
                invalidate = getattr(self.view, 'invalidate_dataset_feature_state', None)
                if callable(invalidate):
                    invalidate()
            return True

        self.view.display_message("Please load data first", "Warning")
        return False

    def check_model_trained(self):
        modeling_model = getattr(self.modeling_controller, 'modeling_model', None)
        if modeling_model is None or getattr(modeling_model, 'trained_model', None) is None:
            self.view.display_message("Please train model first", "Warning")
            return False
        return True

    def run_analysis(self):
        """Placeholder for future analysis orchestration."""
        pass
