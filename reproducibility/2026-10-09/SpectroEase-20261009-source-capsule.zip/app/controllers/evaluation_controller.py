from app.utils.logger import setup_logger
from app.utils.exceptions import EvaluationError
from app.services.evaluation_service import EvaluationService
from app.utils.worker import run_heavy
# from utils.visualization_window import VisualizationWindow  # Temporarily disabled for packaging

class EvaluationController:
    def __init__(self, view, translator, data_model=None, modeling_model=None):
        self.view = view
        self.translator = translator
        self.data_model = data_model
        self.modeling_model = modeling_model
        self.evaluation_service = EvaluationService()
        self.logger = setup_logger()

    def evaluate_model(self):
        metrics = self.view.get_selected_metrics()

        predictor = getattr(self.modeling_model, 'fitted_predictor', None)
        if predictor is None:
            self.view.display_message("No trained model available for evaluation.", "Error")
            return

        if self.data_model.X_test is None or self.data_model.y_test is None:
            self.view.display_message("Test data is not available.", "Error")
            return

        X_test = self.data_model.X_test.copy()
        y_test = self.data_model.y_test.copy()
        row_ids = list(X_test.index) if hasattr(X_test, 'index') else list(range(len(X_test)))

        def aligned_ids(values):
            if values is None:
                return None
            if hasattr(values, 'loc') and hasattr(X_test, 'index'):
                return values.loc[X_test.index].tolist()
            return list(values)

        physical_ids = aligned_ids(getattr(self.data_model, 'sample_id_test', None))
        group_ids = aligned_ids(getattr(self.data_model, 'group_id_test', None))
        task_type = 'classification' if getattr(self.modeling_model, 'analysis_type', '') == 'qualitative' else 'regression'

        self.view.evaluate_button.setEnabled(False)
        try:
            prediction_result, results = run_heavy(
                lambda: self.evaluation_service.evaluate_with_prediction(
                    predictor,
                    X_test,
                    y_test,
                    metrics=metrics,
                    task_type=task_type,
                    row_ids=row_ids,
                    physical_sample_ids=physical_ids,
                    group_ids=group_ids,
                )
            )
            if results is None:
                return  # cancelled by user

            self.modeling_model.prediction_result = prediction_result
            self.view.update_evaluation_results(results)
            self.view.display_message("Model evaluation completed successfully.")
        except EvaluationError as e:
            self.view.display_message(str(e), "Error")
            self.logger.error(e)
        finally:
            self.view.evaluate_button.setEnabled(True)
