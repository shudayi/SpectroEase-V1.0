# from utils.visualization_window import VisualizationWindow  # Temporarily disabled for packaging
from app.utils.logger import setup_logger
from app.utils.exceptions import HyperparameterOptimizationError
from app.services.hyperparameter_optimization_service import HyperparameterOptimizationService
from app.models.hyperparameter_optimization_model import HyperparameterOptimizationModel
from app.utils.label_processor import EnhancedLabelProcessor
from app.utils.worker import run_heavy

class HyperparameterOptimizationController:
    def __init__(self, view, translator, modeling_model=None):
        self.view = view
        self.logger = setup_logger()
        self.translator = translator
        self.modeling_model = modeling_model
        self.hyperopt_service = HyperparameterOptimizationService()
        self.hyperopt_model = HyperparameterOptimizationModel()
        self.label_processor = EnhancedLabelProcessor()
        self.logger.debug("HyperparameterOptimizationController initialized with EnhancedLabelProcessor")

    def apply_main_window_selection(self, method_label, cv, metric, n_iter):
        """Run the optimizer selected in MainWindow with explicit ID scope."""
        method_map = {
            'Grid Search': 'grid_search',
            'Random Search': 'random_search',
            'Bayesian': 'optuna',
            'Optuna': 'optuna',
        }
        method = method_map.get(str(method_label))
        if method is None:
            raise HyperparameterOptimizationError(
                f"Unsupported MainWindow optimizer selection: {method_label}"
            )
        model_type = str(getattr(self.modeling_model, 'analysis_type', '')).lower()
        is_regression = model_type in {'quantitative', 'regression'}
        metric_key = str(metric or '').strip().lower()
        regression_scores = {
            'rmse': 'neg_root_mean_squared_error',
            'mae': 'neg_mean_absolute_error',
            'r2': 'r2', 'r': 'r2', 're': 'neg_mean_absolute_percentage_error',
        }
        classification_scores = {
            'accuracy': 'accuracy', 'precision': 'precision_weighted',
            'recall': 'recall_weighted', 'f1': 'f1_weighted',
            'auc': 'roc_auc_ovr_weighted',
        }
        scoring = (regression_scores if is_regression else classification_scores).get(
            metric_key, 'r2' if is_regression else 'accuracy'
        )
        if self.modeling_model is None or self.modeling_model.X_train is None:
            raise HyperparameterOptimizationError("Training data is not available for hyperparameter search")
        param_space = self._default_parameter_space(
            self.modeling_model.trained_model,
            self.modeling_model.X_train,
        )
        params = {'param_grid': param_space, 'param_distributions': param_space,
                  'n_iter': max(1, int(n_iter))}
        return self.apply_optimization(
            method_override=method, params_override=params,
            cv_override=int(cv), scoring_override=scoring, notify=False,
        )

    @staticmethod
    def _default_parameter_space(estimator, X_train):
        """Choose a small, valid search space for the visible one-click GUI."""
        if estimator is None:
            raise HyperparameterOptimizationError("No trained estimator is available")
        if hasattr(estimator, 'steps') and estimator.steps:
            estimator = estimator.steps[-1][1]
        raw_params = estimator.get_params(deep=True) if hasattr(estimator, 'get_params') else {}
        priorities = (
            'n_components', 'max_depth', 'C', 'alpha', 'n_estimators',
            'min_samples_leaf', 'gamma', 'kernel', 'fit_intercept',
        )
        values = {
            'n_components': list(range(1, max(2, min(4, getattr(X_train, 'shape', (0, 0))[1] + 1)))),
            'max_depth': [None, 3, 8],
            'C': [0.1, 1.0, 10.0],
            'alpha': [0.001, 0.1, 1.0],
            'n_estimators': [100, 200],
            'min_samples_leaf': [1, 2, 4],
            'gamma': ['scale', 'auto'],
            'kernel': ['linear', 'rbf'],
            'fit_intercept': [True, False],
        }
        for name in priorities:
            matching = name if name in raw_params else next(
                (key for key in raw_params if key.endswith(f'__{name}')), None
            )
            if matching is None:
                continue
            candidates = values[name]
            if name == 'n_components':
                maximum = min(len(X_train) - 1, X_train.shape[1], 3)
                candidates = list(range(1, maximum + 1))
                if not candidates:
                    raise HyperparameterOptimizationError(
                        "Training data is too small for component-count search"
                    )
            return {matching: candidates}
        raise HyperparameterOptimizationError(
            f"No supported automatic parameter range is available for {type(estimator).__name__}"
        )

    def apply_optimization(self, method_override=None, params_override=None,
                           cv_override=None, scoring_override=None, notify=True):
        method = method_override or self.view.get_selected_method()
        params = dict(params_override) if params_override is not None else self.view.get_parameters()

        if self.modeling_model.X_train is None or self.modeling_model.y_train is None:
            message = "Training data is not available."
            if notify:
                self.view.display_message(message, "Error")
                return None
            raise HyperparameterOptimizationError(message)

        if self.modeling_model.trained_model is None:
            message = "No trained model available for optimization."
            if notify:
                self.view.display_message(message, "Error")
                return None
            raise HyperparameterOptimizationError(message)

        if method != 'no_optimization' and not getattr(self.modeling_model, 'cv_scope_safe', False):
            reason = getattr(self.modeling_model, 'cv_scope_reason', None)
            if not reason:
                reason = (
                    "The current model has no recorded fold-safe preprocessing contract. "
                    "Run analysis again on the unselected training partition before searching."
                )
            message = f"Hyperparameter search is unavailable: {reason}"
            if notify:
                self.view.display_message(message, "Error")
                return None
            raise HyperparameterOptimizationError(message)

        X_train = self.modeling_model.X_train.copy()
        y_train = self.modeling_model.y_train.copy()

        self.view.apply_button.setEnabled(False)
        try:
            scoring = scoring_override or params.get('scoring', 'accuracy')
            cv = cv_override if cv_override is not None else params.get('cv', 5)
            search_kwargs = {
                'scoring': scoring,
                'cv': cv,
                'sample_ids': getattr(self.modeling_model, 'cv_train_sample_ids', None),
                'outer_test_sample_ids': getattr(self.modeling_model, 'cv_test_sample_ids', None),
                'physical_sample_ids': getattr(self.modeling_model, 'cv_train_physical_sample_ids', None),
                'outer_test_physical_sample_ids': getattr(self.modeling_model, 'cv_test_physical_sample_ids', None),
                'group_ids': getattr(self.modeling_model, 'cv_train_group_ids', None),
                'outer_test_group_ids': getattr(self.modeling_model, 'cv_test_group_ids', None),
                'group_validation': bool(getattr(self.modeling_model, 'cv_group_validation', False)),
            }
            if method == 'random_search':
                # The view exposes this strategy's distributions and iteration
                # budget under names distinct from Grid Search.
                search_kwargs.update({
                    'param_distributions': params.get('param_distributions', {}),
                    'n_iter': params.get('n_iter', 10),
                })
            elif method == 'genetic_algorithm':
                # optimize() accepts the GA ranges through param_grid and
                # converts two-endpoint numeric lists to sampling intervals.
                search_kwargs.update({
                    'param_grid': params.get('param_ranges', {}),
                    'n_population': params.get('n_population', 20),
                    'n_generations': params.get('n_generations', 10),
                })
            elif method in ('grid_search', 'optuna'):
                search_kwargs['param_grid'] = params.get('param_grid', {})
                if method == 'optuna':
                    search_kwargs['n_iter'] = params.get('n_iter', 10)

            packed = run_heavy(
                lambda: self.hyperopt_service.optimize(
                    self.modeling_model.trained_model,
                    X_train,
                    y_train,
                    method=method,
                    **search_kwargs,
                )
            )
            if packed is None:
                return  # cancelled by user
            best_params, best_model, cv_results = packed

            self.modeling_model.trained_model = best_model
            self.modeling_model.model = best_model
            current_params = getattr(self.modeling_model, 'parameters', {})
            if current_params is None:
                current_params = {}
            current_params.update(best_params)
            self.modeling_model.parameters = current_params

            if notify:
                self.view.update_optimization_results(best_params, cv_results)
                self.view.display_message("Hyperparameter optimization completed successfully.")
            self.logger.info(f"Applied hyperparameter optimization method: {method} with parameters: {params}")
            return best_params, best_model, cv_results
        except HyperparameterOptimizationError as e:
            if notify:
                self.view.display_message(str(e), "Error")
                return None
            self.logger.error(e)
            raise
        finally:
            self.view.apply_button.setEnabled(True)
