"""e2e_smoke scope: headless end-to-end pipeline check.

Loads through DataService, splits with row identity, verifies a preprocessing
preview, then models raw spectra through ModelingService and evaluates its
fitted predictor. Saves predictions and checks serialized predictor replay.
The preview is not presented as a replayable fitted preprocessing pipeline.
"""
from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd


@dataclass
class E2EStepResult:
    name: str
    passed: bool
    detail: str = ""


@dataclass
class E2ESmokeReport:
    passed: bool
    steps: List[E2EStepResult] = field(default_factory=list)
    artefact_dir: str = ""

    @property
    def total(self) -> int:
        return len(self.steps)

    @property
    def failures(self) -> int:
        return sum(1 for s in self.steps if not s.passed)


def _record(rep: E2ESmokeReport, name: str, ok: bool, detail: str = "") -> bool:
    rep.steps.append(E2EStepResult(name=name, passed=ok, detail=detail[:240]))
    return ok


def _load_dataset(rep: E2ESmokeReport, project_root: Path) -> pd.DataFrame:
    """Use the same parser and data-quality entry as the application."""
    csv_path = project_root / "examples" / "Qualitative Analysis.csv"
    if not csv_path.exists():
        _record(rep, "load_data", False, f"missing {csv_path}")
        return pd.DataFrame()
    try:
        from app.services.data_service import DataService
        df = DataService({}).load_data(str(csv_path))
        _record(rep, "load_data", not df.empty,
                f"rows={len(df)} cols={df.shape[1]}")
        return df
    except Exception as exc:
        _record(rep, "load_data", False, f"{type(exc).__name__}: {exc}")
        return pd.DataFrame()


def _partition(rep: E2ESmokeReport, df: pd.DataFrame) -> Dict[str, Any]:
    """Partition the dataframe 80/20 with a fixed random seed."""
    from app.services.data_service import DataService
    y = df.iloc[:, 0]
    numeric, _ = pd.factorize(y)
    result = DataService({}).partition_data(df, "Train-Test Split", {
        "target_column": 0, "task_type": "classification",
        "processed_labels": numeric, "original_labels": y.to_numpy(),
        "row_keys": [f"smoke-row-{i}" for i in range(len(df))],
        "test_size": 0.2, "random_state": 42, "shuffle": True,
    })
    assert result['X_train'].index.equals(result['y_train'].index)
    assert result['X_test'].index.equals(result['y_test'].index)
    assert set(result['X_train'].index).isdisjoint(result['X_test'].index)
    _record(rep, "partition", True,
            f"train={len(result['X_train'])} test={len(result['X_test'])}; disjoint row keys")
    return result


def _preprocess(rep: E2ESmokeReport, X_train: pd.DataFrame, X_test: pd.DataFrame):
    """Validate actual stateless service output against an independent oracle."""
    from app.services.preprocessing_service import PreprocessingService

    def snv(frame: pd.DataFrame) -> pd.DataFrame:
        arr = frame.values.astype(float)
        mean = arr.mean(axis=1, keepdims=True)
        std = arr.std(axis=1, keepdims=True)
        std[std == 0] = 1.0
        normalised = (arr - mean) / std
        return pd.DataFrame(normalised, index=frame.index, columns=frame.columns)

    try:
        import numpy as np
        svc = PreprocessingService({})
        out_train = svc.apply_method(X_train, 'Standard Normal Variate (SNV)', {})
        out_test = svc.apply_method(X_test, 'Standard Normal Variate (SNV)', {})
        ok = out_train.shape == X_train.shape and out_test.shape == X_test.shape
        ok = ok and np.allclose(out_train, snv(X_train), rtol=1e-12, atol=1e-12)
        ok = ok and np.allclose(out_test, snv(X_test), rtol=1e-12, atol=1e-12)
        _record(rep, "preprocess_preview", ok,
                f"shape={out_train.shape}; independent SNV formula; modeling below uses raw spectra")
        return out_train, out_test
    except Exception as exc:
        _record(rep, "preprocess_preview", False, f"{type(exc).__name__}: {exc}")
        return X_train, X_test


def _report(rep: E2ESmokeReport, artefact_dir: Path, metrics: Dict[str, float]) -> bool:
    """Generate and inspect a fresh readable report, including metric content."""
    from plugins.reporting.spectrum_report_generator import SpectrumReportGenerator
    try:
        from pypdf import PdfReader
        output_root = artefact_dir.resolve()
        previous = {
            path.resolve(): (path.stat().st_mtime_ns, path.stat().st_size)
            for path in artefact_dir.rglob('*.pdf') if path.is_file()
        }
        gen = SpectrumReportGenerator(output_dir=str(artefact_dir))
        result_path = gen.generate_report(
            spectra_data={},
            preprocessing_results={},
            feature_extraction_results={},
            analysis_results={"metrics": metrics},
            title="SpectroEase Test Agent E2E",
        )
        out_path = Path(result_path) if result_path else None
        if out_path is None or not out_path.is_file():
            raise ValueError('Report generator did not produce a file')
        resolved = out_path.resolve()
        if not resolved.is_relative_to(output_root) or resolved.suffix.lower() != '.pdf':
            raise ValueError('Report output must be a PDF inside the artifact directory')
        state = (resolved.stat().st_mtime_ns, resolved.stat().st_size)
        if state == previous.get(resolved):
            raise ValueError('Report generator returned an unchanged earlier artifact')
        if state[1] == 0 or not resolved.read_bytes().startswith(b'%PDF-'):
            raise ValueError('Report is empty or lacks a PDF header')
        reader = PdfReader(str(resolved), strict=True)
        if not reader.pages:
            raise ValueError('Report PDF has no pages')
        text = '\n'.join(page.extract_text() or '' for page in reader.pages)
        if not text.strip():
            raise ValueError('Report PDF has no readable text')
        for name, value in metrics.items():
            if str(name) not in text or str(value) not in text:
                raise ValueError(f'Report PDF is missing the expected metric {name}')
        _record(rep, "report", True,
                f"metric content verified; readable pages={len(reader.pages)}; path={result_path}")
        return True
    except Exception as exc:
        _record(rep, "report", False, f"{type(exc).__name__}: {exc}")
        return False


def run_e2e_smoke(project_root: Path | None = None,
                  artefact_dir: Path | None = None) -> E2ESmokeReport:
    """Run the e2e smoke scope end-to-end and return a report."""
    project_root = project_root or Path.cwd()
    artefact_dir = artefact_dir or (project_root / "reports" / "test_agent_e2e")
    artefact_dir.mkdir(parents=True, exist_ok=True)

    rep = E2ESmokeReport(passed=True, artefact_dir=str(artefact_dir))

    df = _load_dataset(rep, project_root)
    if df.empty:
        rep.passed = False
        return rep

    try:
        parts = _partition(rep, df)
    except Exception as exc:
        _record(rep, 'partition', False, f'{type(exc).__name__}: {exc}')
        rep.passed = False
        return rep
    if parts["X_train"] is None or parts["X_train"].empty:
        rep.passed = False
        return rep

    _preprocess(rep, parts["X_train"], parts["X_test"])
    if not rep.steps[-1].passed:
        rep.passed = False
        return rep
    try:
        import json
        import pickle
        import numpy as np
        from app.services.modeling_service import ModelingService
        from app.services.evaluation_service import EvaluationService
        result = ModelingService({}).apply_modeling(
            parts['X_train'], parts['y_train'], parts['X_test'], parts['y_test'],
            'rf', analysis_type='qualitative',
            model_params={'n_estimators': 20, 'max_depth': 6, 'random_state': 42},
            train_row_ids=list(parts['X_train'].index),
            test_row_ids=list(parts['X_test'].index), input_representation='raw_spectrum',
        )
        _record(rep, 'train_application_route', result.fitted_predictor is not None,
                f'{type(result.model).__name__}; fold-local model route')
        predicted = result.fitted_predictor.predict_raw(
            parts['X_test'], row_ids=list(parts['X_test'].index))
        assert np.array_equal(predicted.predictions, result.predictions)
        metrics = EvaluationService().evaluate_prediction_result(
            parts['y_test'], predicted, task_type='classification',
            metrics=['accuracy', 'f1'])
        for key in ('accuracy', 'f1'):
            assert np.isclose(metrics[key], result.evaluation_results[key])
        _record(rep, 'evaluate_contract_parity', True,
                f"accuracy={metrics['accuracy']:.3f}; predictor/service metrics agree")
        pd.DataFrame({'row_key': predicted.row_ids,
                      'observed': parts['y_test'].to_numpy(),
                      'predicted': predicted.predictions}).to_csv(
                          artefact_dir / 'smoke_predictions.csv', index=False)
        (artefact_dir / 'smoke_metrics.json').write_text(
            json.dumps({key:float(metrics[key]) for key in ('accuracy', 'f1')}, indent=2),
            encoding='utf-8')
        predictor_path = artefact_dir / 'trusted_smoke_predictor.pkl'
        predictor_path.write_bytes(pickle.dumps(result.fitted_predictor))
        restored = pickle.loads(predictor_path.read_bytes())
        assert np.array_equal(restored.predict_raw(
            parts['X_test'], row_ids=list(parts['X_test'].index)).predictions,
            predicted.predictions)
        _record(rep, 'trusted_predictor_reload', True,
                'same-process Python serialization parity; not GUI import or new-process deployment')
    except Exception as exc:
        _record(rep, 'application_model_evaluate_reload', False,
                f'{type(exc).__name__}: {exc}')
        rep.passed = False
        return rep

    if not _report(rep, artefact_dir, metrics):
        rep.passed = False

    rep.passed = all(s.passed for s in rep.steps)
    return rep
