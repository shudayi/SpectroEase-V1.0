"""runner: orchestrator for the four test_agent scopes."""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional

from app.tools.test_agent.copy_proofread import (
    CopyProofreadReport,
    format_markdown,
    run_copy_proofread,
)
from app.tools.test_agent.e2e_smoke import E2ESmokeReport, run_e2e_smoke
from app.tools.test_agent.existing_tests import ExistingTestsReport, run_existing_tests
from app.tools.test_agent.ui_smoke import UISmokeReport, run_ui_smoke


@dataclass
class ScopeResult:
    name: str
    passed: bool
    detail: str = ""
    payload: object = None

    def format_line(self) -> str:
        marker = "PASS" if self.passed else "FAIL"
        return f"[{marker}] {self.name:<14} {self.detail}"


def _scope_existing(python: Optional[str]) -> ScopeResult:
    rep: ExistingTestsReport = run_existing_tests(python=python)
    total = rep.total_tests
    fails = rep.total_failures
    detail = f"tests={total} failures={fails} suites={len(rep.suites)}"
    return ScopeResult("existing_tests", rep.passed, detail, rep)


def _scope_e2e(project_root: Path, artefact_dir: Path) -> ScopeResult:
    rep: E2ESmokeReport = run_e2e_smoke(project_root, artefact_dir)
    detail = f"steps={rep.total} failures={rep.failures} artefacts={rep.artefact_dir}"
    return ScopeResult("e2e_smoke", rep.passed, detail, rep)


def _scope_ui() -> ScopeResult:
    rep: UISmokeReport = run_ui_smoke()
    detail = f"steps={rep.total} failures={rep.failures} warnings={len(rep.warnings)}"
    return ScopeResult("ui_smoke", rep.passed, detail, rep)


def _scope_copy(project_root: Path, report_dir: Path) -> ScopeResult:
    rep = run_copy_proofread(project_root)
    md_path = report_dir / "copy_proofread.md"
    md_path.write_text(format_markdown(rep), encoding="utf-8")
    fails = len(rep.fails)
    warns = len([f for f in rep.findings if f.severity == "warn"])
    detail = f"fails={fails} warnings={warns} report={md_path.name}"
    return ScopeResult("copy_proofread", rep.passed, detail, rep)


SCOPE_FUNCS: dict[str, Callable[..., ScopeResult]] = {
    "existing_tests": lambda **kw: _scope_existing(kw.get("python")),
    "e2e_smoke": lambda **kw: _scope_e2e(kw["project_root"], kw["artefact_dir"]),
    "ui_smoke": lambda **kw: _scope_ui(),
    "copy_proofread": lambda **kw: _scope_copy(kw["project_root"], kw["report_dir"]),
}


def run_all_scopes(project_root: Path | None = None,
                   report_dir: Path | None = None,
                   python: Optional[str] = None) -> List[ScopeResult]:
    project_root = project_root or Path.cwd()
    report_dir = report_dir or (project_root / "reports" / "test_agent")
    report_dir.mkdir(parents=True, exist_ok=True)
    artefact_dir = report_dir / "e2e_artefacts"
    artefact_dir.mkdir(parents=True, exist_ok=True)

    results: List[ScopeResult] = []
    for name in ["existing_tests", "e2e_smoke", "ui_smoke", "copy_proofread"]:
        func = SCOPE_FUNCS[name]
        result = func(
            project_root=project_root,
            report_dir=report_dir,
            artefact_dir=artefact_dir,
            python=python,
        )
        results.append(result)

    summary = _summary_markdown(results, project_root, report_dir)
    summary_path = report_dir / "test_agent_summary.md"
    summary_path.write_text(summary, encoding="utf-8")
    return results


def _summary_markdown(results: List[ScopeResult], project_root: Path, report_dir: Path) -> str:
    lines = [
        "# SpectroEase Test Agent Summary",
        "",
        f"Project root: `{project_root}`",
        f"Reports: `{report_dir}`",
        "",
        "| Scope | Result | Detail |",
        "| --- | --- | --- |",
    ]
    for r in results:
        marker = "PASS" if r.passed else "FAIL"
        lines.append(f"| {r.name} | **{marker}** | {r.detail} |")
    lines.append("")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    import argparse
    parser = argparse.ArgumentParser(description="SpectroEase test agent.")
    parser.add_argument("--scope", default="all",
                        choices=["all", "existing_tests", "e2e_smoke", "ui_smoke", "copy_proofread"])
    parser.add_argument("--report-dir", default=None)
    parser.add_argument("--python", default=sys.executable)
    args = parser.parse_args(argv)

    project_root = Path.cwd()
    report_dir = Path(args.report_dir) if args.report_dir else (project_root / "reports" / "test_agent")
    artefact_dir = report_dir / "e2e_artefacts"
    report_dir.mkdir(parents=True, exist_ok=True)
    artefact_dir.mkdir(parents=True, exist_ok=True)

    if args.scope == "all":
        results = run_all_scopes(project_root=project_root, report_dir=report_dir, python=args.python)
    else:
        func = SCOPE_FUNCS[args.scope]
        result = func(
            project_root=project_root,
            report_dir=report_dir,
            artefact_dir=artefact_dir,
            python=args.python,
        )
        results = [result]

    print()
    for r in results:
        print(r.format_line())
    print()
    failed = [r for r in results if not r.passed]
    if failed:
        print(f"FAILED: {', '.join(r.name for r in failed)}")
        return 1
    print("All selected scopes passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())