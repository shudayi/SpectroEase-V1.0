"""Test/proofread agent for SpectroEase.

Orchestrates existing pytest suites, headless end-to-end smoke tests, an
offscreen UI smoke test, and a translation/copy proofreading pass. The
agent is read-only against application code and translation files; it
imports modules and asserts behaviour, never mutates the project.
"""

from app.tools.test_agent.runner import (
    ScopeResult,
    run_all_scopes,
    run_copy_proofread,
    run_e2e_smoke,
    run_existing_tests,
    run_ui_smoke,
)

__all__ = [
    "ScopeResult",
    "run_all_scopes",
    "run_copy_proofread",
    "run_e2e_smoke",
    "run_existing_tests",
    "run_ui_smoke",
]