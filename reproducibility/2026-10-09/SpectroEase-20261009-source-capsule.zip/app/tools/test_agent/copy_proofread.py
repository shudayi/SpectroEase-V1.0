"""copy_proofread scope: audit translation files and inline UI copy.

Scans every key/value pair in ``translations/en.json`` and
``translations/zh.json`` for emoji decorations, marketing tokens, and
overly long values. Also scans a small set of inline strings in
``app/views/main_window.py`` and the three parameter-dialog files.

Findings are reported with severity ``fail`` (exit non-zero) or
``warn`` (logged only). ``fail`` triggers are limited to technical
emojis and very long values that would visibly overflow a dialog.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, List, Tuple

import json


EMOJI_BLOCK = set("🔒🔓⚠️❌⚡✨🚀💡🧠✅🔬")


# "Marketing" tokens: keep this list short and concrete so we don't
# regress into the AI-flavor copy the project explicitly removed.
MARKETING_TOKENS = [
    "seamless",
    "leverage",
    "empower",
    "effortless",
    "next.gen",
    "state.of.the.art",
    "cutting.edge",
    "smartly",
    "world.class",
    "magic",
]

MAX_VALUE_LEN = 240  # hard fail above this; warn above 160


@dataclass
class Finding:
    severity: str  # 'fail' or 'warn'
    scope: str     # 'en' / 'zh' / 'inline'
    key: str
    detail: str


@dataclass
class CopyProofreadReport:
    passed: bool
    findings: List[Finding] = field(default_factory=list)

    @property
    def fails(self) -> List[Finding]:
        return [f for f in self.findings if f.severity == "fail"]


# Keys that legitimately contain multi-line descriptions; length warnings
# remain informational and never fail.
LENIENT_LENGTH_KEYS = (
    "description_text",
    "description_",
    "problem_text",
    "preview_results",
    "success_message",
    "recommendations_",
    "info_label",
    "explanation_text",
)


def _is_lenient(key: str) -> bool:
    return any(token in key for token in LENIENT_LENGTH_KEYS)


def _scan_value(scope: str, key: str, value: str) -> Iterable[Finding]:
    findings: List[Finding] = []
    for ch in value:
        if ch in EMOJI_BLOCK:
            findings.append(Finding(
                severity="fail",
                scope=scope,
                key=key,
                detail=f"emoji {ch!r} in copy",
            ))
            break
    lowered = value.lower()
    for tok in MARKETING_TOKENS:
        if tok in lowered:
            findings.append(Finding(
                severity="warn",
                scope=scope,
                key=key,
                detail=f"marketing token {tok!r}",
            ))
            break
    if len(value) > MAX_VALUE_LEN:
        severity = "warn" if _is_lenient(key) else "fail"
        findings.append(Finding(
            severity=severity,
            scope=scope,
            key=key,
            detail=f"length {len(value)} > {MAX_VALUE_LEN}",
        ))
    elif len(value) > 160:
        findings.append(Finding(
            severity="warn",
            scope=scope,
            key=key,
            detail=f"length {len(value)} > 160",
        ))
    return findings


def _scan_json(path: Path, scope: str) -> List[Finding]:
    if not path.exists():
        return [Finding("fail", scope, "<file>", f"missing {path}")]
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return [Finding("fail", scope, "<file>", f"json error: {exc}")]
    out: List[Finding] = []
    for key, value in data.items():
        if not isinstance(value, str):
            continue
        out.extend(_scan_value(scope, key, value))
    return out


def _scan_inline(project_root: Path) -> List[Finding]:
    """Scan a curated list of inline UI strings in main_window.py."""
    findings: List[Finding] = []
    target = project_root / "app" / "views" / "main_window.py"
    if not target.exists():
        return findings
    text = target.read_text(encoding="utf-8")
    for ch in EMOJI_BLOCK:
        if ch in text:
            findings.append(Finding(
                severity="fail", scope="inline", key="main_window.py",
                detail=f"emoji {ch!r} present",
            ))
    return findings


def run_copy_proofread(project_root: Path | None = None) -> CopyProofreadReport:
    project_root = project_root or Path.cwd()
    findings: List[Finding] = []
    findings.extend(_scan_json(project_root / "translations" / "en.json", "en"))
    findings.extend(_scan_json(project_root / "translations" / "zh.json", "zh"))
    findings.extend(_scan_inline(project_root))
    return CopyProofreadReport(
        passed=not any(f.severity == "fail" for f in findings),
        findings=findings,
    )


def format_markdown(report: CopyProofreadReport) -> str:
    if not report.findings:
        return "# Copy proofread\n\nNo issues found.\n"
    lines = ["# Copy proofread", ""]
    for f in report.findings:
        lines.append(f"- **[{f.severity.upper()}]** `{f.scope}:{f.key}` — {f.detail}")
    return "\n".join(lines) + "\n"