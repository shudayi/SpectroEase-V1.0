"""existing_tests scope: re-run the project's pytest suites and parse the results.

The agent shells out to pytest with the correct interpreter and the
offscreen Qt environment, then parses the JUnit XML output to surface a
per-class PASS/FAIL summary. The scope passes only when every suite is
green.

Each test file is invoked separately so that a single crashing test
cannot suppress the rest of the report (Pytest on Windows can swallow
the final summary when its capture buffer teardown raises).
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


def discover_test_files(project_root: Path | None = None) -> List[str]:
    """Discover application tests without traversing bundled dependencies."""
    root = project_root or Path(__file__).resolve().parents[3]
    return [path.relative_to(root).as_posix()
            for path in sorted((root / "tests").rglob("test_*.py"))]


TEST_FILES = discover_test_files()


@dataclass
class TestSuiteResult:
    name: str
    path: str
    passed: bool
    tests_run: int = 0
    failures: int = 0
    errors: int = 0
    skipped: int = 0
    duration_sec: float = 0.0
    message: str = ""


@dataclass
class ExistingTestsReport:
    passed: bool
    suites: List[TestSuiteResult] = field(default_factory=list)

    @property
    def total_tests(self) -> int:
        return sum(s.tests_run for s in self.suites)

    @property
    def total_failures(self) -> int:
        return sum(s.failures + s.errors for s in self.suites)


def _qt_env() -> dict:
    """Return the offscreen Qt environment variables required by Qt5."""
    pyqt5 = Path(os.path.dirname(__import__("PyQt5").__file__)) / "Qt5" / "plugins"
    return {
        "QT_QPA_PLATFORM": "offscreen",
        "QT_QPA_PLATFORM_PLUGIN_PATH": str(pyqt5),
    }


def run_unittest_one_inproc(test_file: str) -> TestSuiteResult:
    """Run a test file in-process via ``unittest.main(exit=False)``.

    On Windows, Qt C-level stderr writes close the stream that Pytest's
    capture buffer (and even unittest's subprocess stdout/stderr) try
    to read at teardown. Running in-process bypasses capture entirely,
    so the exit code reflects only the test verdict.
    """
    import io
    import unittest
    label = Path(test_file).stem
    # Configure Qt offscreen mode BEFORE the test module imports PyQt5.
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    pyqt5 = Path(os.path.dirname(__import__("PyQt5").__file__)) / "Qt5" / "plugins"
    os.environ.setdefault("QT_QPA_PLATFORM_PLUGIN_PATH", str(pyqt5))

    buffer = io.StringIO()
    runner = unittest.TextTestRunner(stream=buffer, verbosity=1)
    loader = unittest.TestLoader()
    module = test_file.replace("/", ".").replace(".py", "")
    suite = loader.loadTestsFromName(module)
    result = runner.run(suite)
    passed = result.wasSuccessful()
    return TestSuiteResult(
        name=label,
        path=test_file,
        passed=passed,
        tests_run=result.testsRun,
        failures=len(result.failures),
        errors=len(result.errors),
        skipped=len(result.skipped),
        message=buffer.getvalue()[-400:] if not passed else "",
    )


def _parse_unittest(proc: subprocess.CompletedProcess, label: str,
                    path: str) -> TestSuiteResult:
    """Parse a unittest run summary line into a TestSuiteResult.

    On Windows the unittest subprocess inherits a stderr buffer that
    closes after teardown, so the trailing stderr noise is unreliable.
    We rely on the exit code combined with the "OK" / "FAILED" line in
    stdout for the verdict.
    """
    summary = proc.stdout or ""
    # On Windows the trailing stderr noise from Qt teardown
    # (lost sys.stderr) corrupts the last lines of the captured output.
    # Trust the subprocess exit code: unittest exits 0 only when every
    # test passes.
    passed = proc.returncode == 0
    tests_run = 0
    failures = 0
    errors = 0
    skipped = 0
    for line in summary.splitlines():
        if line.startswith("Ran ") and " tests" in line:
            head, _, tail = line.partition(" tests")
            try:
                tests_run = int(head.split()[-1])
            except ValueError:
                pass
            if "skipped" in tail:
                try:
                    skipped = int(tail.split("skipped=")[1].split()[0])
                except (IndexError, ValueError):
                    pass
        if line.startswith("FAILED"):
            if "errors=" in line:
                try:
                    errors = int(line.split("errors=")[1].split(")")[0])
                except (IndexError, ValueError):
                    pass
            if "failures=" in line:
                try:
                    failures = int(line.split("failures=")[1].split(")")[0])
                except (IndexError, ValueError):
                    pass
    return TestSuiteResult(
        name=label,
        path=path,
        passed=passed,
        tests_run=tests_run,
        failures=failures,
        errors=errors,
        skipped=skipped,
        message="" if passed else summary[-400:],
    )


def run_pytest_one(python: str, test_file: str, junit_xml: Path) -> subprocess.CompletedProcess:
    """Invoke pytest against a single test file with the offscreen env."""
    env = os.environ.copy()
    env.update(_qt_env())
    env["PYTHONUTF8"] = "1"
    cmd = [
        python,
        "-m",
        "pytest",
        test_file,
        "-q",
        "-s",
        "-p", "no:cacheprovider",
        f"--junit-xml={junit_xml}",
        "--color=no",
        "--tb=line",
    ]
    return subprocess.run(cmd, env=env, capture_output=True, text=True,
                          encoding="utf-8", errors="replace",
                          cwd=Path(__file__).resolve().parents[3], timeout=180)


def _parse_junit(xml_path: Path, file_label: str) -> List[TestSuiteResult]:
    """Parse a JUnit XML file into TestSuiteResult records."""
    if not xml_path.exists():
        return []
    try:
        tree = ET.parse(xml_path)
    except ET.ParseError:
        return []
    root = tree.getroot()
    suites: List[TestSuiteResult] = []
    for suite in root.iter("testsuite"):
        suites.append(
            TestSuiteResult(
                name=f"{file_label}::{suite.attrib.get('name', '')}",
                path=suite.attrib.get("file", file_label),
                passed=(int(suite.attrib.get("tests", 0))
                        - int(suite.attrib.get("skipped", 0))) > 0
                and int(suite.attrib.get("failures", 0)) == 0
                and int(suite.attrib.get("errors", 0)) == 0,
                tests_run=int(suite.attrib.get("tests", 0)),
                failures=int(suite.attrib.get("failures", 0)),
                errors=int(suite.attrib.get("errors", 0)),
                skipped=int(suite.attrib.get("skipped", 0)),
                duration_sec=float(suite.attrib.get("time", 0.0)),
            )
        )
    return suites


def run_existing_tests(python: str | None = None) -> ExistingTestsReport:
    """Run every application test file in an isolated, no-capture subprocess.

    Both JUnit results and process exit must pass. A crash, timeout or empty
    collection cannot be mistaken for success because an XML file exists.
    """
    python = python or sys.executable
    suites: List[TestSuiteResult] = []
    overall_passed = True
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        for file_index, test_file in enumerate(TEST_FILES, start=1):
            label = Path(test_file).stem
            # Nested test files can share a basename. Each invocation owns an
            # independent output, so a missing result cannot reuse old XML.
            junit_path = tmp_path / f"{file_index:04d}-{label}.xml"
            junit_path.unlink(missing_ok=True)
            try:
                proc = run_pytest_one(python, test_file, junit_path)
                parsed = _parse_junit(junit_path, label)
                if parsed:
                    suites.extend(parsed)
                    if proc.returncode != 0:
                        suites.append(TestSuiteResult(
                            name=f"{label}::process_exit", path=test_file,
                            passed=False, errors=1,
                            message=f"pytest exited {proc.returncode}: "
                                    f"{(proc.stderr or proc.stdout)[-400:]}",
                        ))
                else:
                    suites.append(TestSuiteResult(
                        name=label,
                        path=test_file,
                        passed=False,
                        errors=1,
                        message=(proc.stderr or proc.stdout)[-400:],
                    ))
            except (OSError, subprocess.TimeoutExpired) as exc:
                suites.append(TestSuiteResult(
                    name=label, path=test_file, passed=False, errors=1,
                    message=f"{type(exc).__name__}: {exc}",
                ))
    overall_passed = all(s.passed for s in suites) and bool(suites)
    return ExistingTestsReport(passed=overall_passed, suites=suites)
