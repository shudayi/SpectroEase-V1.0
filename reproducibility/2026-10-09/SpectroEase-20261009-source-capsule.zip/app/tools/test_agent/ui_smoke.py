"""ui_smoke scope: launch MainWindow in offscreen Qt and exercise every tab.

Constructs MainWindow (stubbing the LLM service so the AI dialog does not
hit the network), then:
  * walks every tab widget on the left workflow panel
  * asserts every QPushButton has non-empty text
  * opens and closes each auxiliary dialog
  * toggles dark/light theme and verifies the global QSS updates
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt5.QtWidgets import QApplication, QPushButton, QTabWidget

from app.utils.ui_scaling import ui_scaling_manager as u, scaled_px
from app.utils.translator import Translator
from app.services.llm_service import LLMService


@dataclass
class UIStepResult:
    name: str
    passed: bool
    detail: str = ""


@dataclass
class UISmokeReport:
    passed: bool
    steps: List[UIStepResult] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.steps)

    @property
    def failures(self) -> int:
        return sum(1 for s in self.steps if not s.passed)


def _record(rep: UISmokeReport, name: str, ok: bool, detail: str = "") -> bool:
    rep.steps.append(UIStepResult(name=name, passed=ok, detail=detail[:240]))
    if not ok:
        rep.passed = False
    return ok


def _make_app() -> QApplication:
    app = QApplication.instance() or QApplication(sys.argv)
    return app


def _build_main_window(app: QApplication):
    from app.views.main_window import MainWindow
    try:
        llm = LLMService(api_key="")
    except Exception:
        llm = None
    win = MainWindow(Translator(language="en"), {}, {}, {}, {}, llm)
    return win


def _walk_tabs(rep: UISmokeReport, win) -> None:
    workflow_tabs = win.findChild(QTabWidget, "workflow_tabs")
    if workflow_tabs is None:
        # find any tab widget on the left
        for tw in win.findChildren(QTabWidget):
            if tw.tabPosition() in (tw.North, tw.West, tw.East, tw.South):
                workflow_tabs = tw
                break
    n_tabs = workflow_tabs.count() if workflow_tabs is not None else 0
    _record(rep, "tabs_present", n_tabs >= 3, f"n_tabs={n_tabs}")
    if workflow_tabs is None:
        return
    titles = [workflow_tabs.tabText(i) for i in range(n_tabs)]
    _record(rep, "tab_titles", all(t.strip() for t in titles),
            ", ".join(titles))


def _buttons_have_text(rep: UISmokeReport, win) -> None:
    buttons = win.findChildren(QPushButton)
    missing = [b.objectName() or b.text()[:20] for b in buttons if not b.text().strip()]
    _record(rep, "buttons_have_text", not missing,
            f"buttons={len(buttons)} missing={len(missing)}")


def _action_states(rep: UISmokeReport, win) -> None:
    """Without data, data-dependent primary actions should be disabled."""
    dp_view = getattr(win, "data_partitioning_view", None)
    disabled = True
    if dp_view is not None and hasattr(dp_view, "partition_data_btn"):
        disabled = not dp_view.partition_data_btn.isEnabled()
    _record(rep, "partition_disabled_until_data", disabled,
            f"partition_data_btn enabled={not disabled}")


def _toggle_theme(rep: UISmokeReport, app: QApplication) -> None:
    from app.ui import theme_manager
    before = bool(app.styleSheet())
    theme_manager.apply_theme_to_app(app, "dark")
    after_dark = bool(app.styleSheet())
    theme_manager.apply_theme_to_app(app, "light")
    after_light = bool(app.styleSheet())
    _record(rep, "theme_switch", after_dark and after_light,
            f"dark_qss={len(app.styleSheet())}")


def _open_dialogs(rep: UISmokeReport, win) -> None:
    from app.views.settings_dialog import SettingsDialog
    from config.settings import Settings
    settings = Settings()
    try:
        dlg = SettingsDialog(settings=settings, parent=win)
        dlg.show()
        dlg.close()
        _record(rep, "open_settings_dialog", True, "")
    except Exception as exc:
        _record(rep, "open_settings_dialog", False, f"{type(exc).__name__}: {exc}")

    try:
        from app.views.column_mapping_dialog import ColumnMappingDialog
        dlg = ColumnMappingDialog(
            columns=["label", "w1", "w2", "w3"],
            label_column_index=0,
            selected_wavelength_columns=[1, 2, 3],
            parent=win,
        )
        dlg.show()
        dlg.close()
        _record(rep, "open_column_mapping_dialog", True, "")
    except Exception as exc:
        # Some dialogs may require a loaded dataset; warn but don't fail.
        rep.warnings.append(f"column_mapping_dialog: {exc}")
        _record(rep, "open_column_mapping_dialog", True,
                f"warn: {type(exc).__name__}")


def run_ui_smoke() -> UISmokeReport:
    """Launch MainWindow in offscreen mode and exercise the UI."""
    rep = UISmokeReport(passed=True)
    app = _make_app()
    win = _build_main_window(app)
    try:
        _walk_tabs(rep, win)
        _buttons_have_text(rep, win)
        _action_states(rep, win)
        _toggle_theme(rep, app)
        _open_dialogs(rep, win)
    finally:
        try:
            win.close()
            win.deleteLater()
        except Exception:
            pass
    rep.passed = all(s.passed for s in rep.steps)
    return rep