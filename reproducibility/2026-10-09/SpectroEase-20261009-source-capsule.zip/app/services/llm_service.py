from typing import Dict, Any
import requests
import json
import logging
import time
from config.llm_config import LLMConfig
from app.utils.exceptions import LLMServiceError

logger = logging.getLogger(__name__)


# Simple retry policy for transient LLM API failures.
_MAX_RETRIES = 3
_BASE_BACKOFF_SECONDS = 1.0


def _extract_message_content(data: dict) -> str:
    """Extract text from OpenAI-compatible and Anthropic-compatible responses."""
    if not isinstance(data, dict):
        raise LLMServiceError("The LLM service returned an unexpected response format.")

    base_resp = data.get("base_resp")
    if isinstance(base_resp, dict) and base_resp.get("status_code", 0) not in (0, "0", None):
        raise LLMServiceError("MiniMax reported an unsuccessful response.")

    # MiniMax Token Plan uses an Anthropic-compatible Messages response. Keep
    # reasoning blocks out of the algorithm source returned to the caller.
    content_blocks = data.get("content")
    if isinstance(content_blocks, list):
        text_parts = [
            block.get("text") for block in content_blocks
            if isinstance(block, dict) and block.get("type") == "text"
            and isinstance(block.get("text"), str)
        ]
        if text_parts:
            return "\n".join(text_parts)
        raise LLMServiceError("The LLM service returned no text content.")

    choices = data.get("choices")
    if not isinstance(choices, list) or not choices:
        raise LLMServiceError("The LLM service returned no choices in the response.")

    first_choice = choices[0]
    if not isinstance(first_choice, dict):
        raise LLMServiceError("The LLM service returned an invalid choice format.")

    message = first_choice.get("message")
    if not isinstance(message, dict):
        raise LLMServiceError("The LLM service returned an invalid message format.")

    content = message.get("content")
    if not isinstance(content, str):
        raise LLMServiceError("The LLM service returned an empty or invalid message content.")

    return content


class LLMService:
    def __init__(self, api_key: str, base_url: str = None, *, model_name=None, temperature=None, max_tokens=None, request_timeout=None):
        self.api_key = api_key
        self.model_name = LLMConfig.MODEL_NAME if model_name is None else model_name
        self.temperature = LLMConfig.TEMPERATURE if temperature is None else temperature
        self.max_tokens = LLMConfig.MAX_TOKENS if max_tokens is None else max_tokens
        self.request_timeout = LLMConfig.REQUEST_TIMEOUT if request_timeout is None else request_timeout
        self.base_url = (base_url or LLMConfig.API_BASE_URL or "https://api.deepseek.com/v1").rstrip("/")
        self._uses_anthropic_messages = self.base_url.lower().endswith("/anthropic")
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

    def _post_with_retry(self, payload: dict, session: requests.Session = None) -> requests.Response:
        """POST to the chat completions endpoint with retry/backoff.

        Args:
            payload: Request JSON payload.
            session: Optional ``requests.Session`` to use. If provided, the
                caller can close the session to abort an in-flight request.

        Returns:
            The HTTP response object.
        """
        if self._uses_anthropic_messages:
            url = f"{self.base_url}/v1/messages"
            headers = {
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json",
            }
        else:
            url = f"{self.base_url}/chat/completions"
            headers = self.headers
        last_error = None
        http = session or requests.Session()

        try:
            for attempt in range(_MAX_RETRIES):
                try:
                    response = http.post(
                        url,
                        headers=headers,
                        timeout=(5, self.request_timeout),
                        json=payload
                    )
                    # Do not retry client errors (4xx) other than rate-limit (429).
                    if response.status_code == 429 or response.status_code >= 500:
                        last_error = LLMServiceError(
                            f"LLM API returned status {response.status_code}. Retrying..."
                        )
                        logger.warning("LLM API status %s on attempt %s", response.status_code, attempt + 1)
                    else:
                        return response
                except requests.RequestException as e:
                    last_error = LLMServiceError("Network error while calling the LLM service.")
                    last_error.__cause__ = e
                    logger.warning("LLM API network error on attempt %s: %s", attempt + 1, e)

                if attempt < _MAX_RETRIES - 1:
                    sleep_seconds = _BASE_BACKOFF_SECONDS * (2 ** attempt)
                    logger.debug("Retrying LLM API call in %s seconds", sleep_seconds)
                    time.sleep(sleep_seconds)
        finally:
            if session is None:
                http.close()

        raise last_error or LLMServiceError("The LLM service is unavailable after multiple retries.")

    def chat(self, message: str, code: str = None, session: requests.Session = None) -> str:
        """
        Chat with the LLM.

        Args:
            message: User message.
            code: Optional related code snippet.
            session: Optional ``requests.Session`` that the caller can close to
                abort the request (e.g. when the user clicks Cancel).

        Returns:
            The generated response content as a string.
        """
        # Build prompt
        if code:
            prompt = f"""User message: {message}

Related code:
```python
{code}
```

Please provide a professional response, ensuring the code meets system requirements. If code modification is needed, ensure:
1. Code follows Python syntax standards
2. Code adheres to interface definition requirements
3. Maintains the core logic of the original algorithm
4. Provides complete code implementation without omitting any parts
5. Ensures code can be directly integrated into the system
"""
        else:
            prompt = f"""User message: {message}

Please provide a professional response. If code is involved, ensure the code meets system requirements:
1. Code follows Python syntax standards
2. Code adheres to interface definition requirements
3. Provides complete code implementation without omitting any parts
4. Ensures code can be directly integrated into the system
"""

        system_prompt = """You are a professional machine learning algorithm expert skilled in code conversion and optimization.
Your main task is to help users convert various machine learning algorithm code into system-compatible formats.

The system supports the following types of algorithms:
1. Preprocessing Algorithms (PreprocessingAlgorithm): For data cleaning, transformation, and standardization
2. Feature Selection Algorithms (FeatureSelectionAlgorithm): For selecting the most relevant features
3. Modeling Algorithms (ModelingAlgorithm): For training and predicting models
4. Data Partitioning Algorithms (DataPartitioningAlgorithm): For splitting data into training and test sets

Each algorithm has specific interface requirements. You need to ensure the converted code fully complies with these interfaces.
When converting, preserve the core logic of the original algorithm while adapting to the system interface.
"""
        if self._uses_anthropic_messages:
            # Token Plan subscription keys use MiniMax's Anthropic-compatible
            # Messages endpoint; they are not interchangeable with the
            # OpenAI-compatible pay-as-you-go API key type.
            payload = {
                "model": self.model_name,
                "system": system_prompt,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": self.temperature,
                "max_tokens": self.max_tokens,
            }
        else:
            payload = {
                "model": self.model_name,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ],
                "temperature": self.temperature,
                "max_tokens": self.max_tokens
            }

        try:
            response = self._post_with_retry(payload, session=session)

            if response.status_code != 200:
                # Provider error bodies are not needed to diagnose the common
                # status classes and should not be copied into local logs.
                logger.error("LLM API returned status %s", response.status_code)
                raise LLMServiceError("The LLM service returned an error. Check the API key and network connection.")

            return _extract_message_content(response.json())

        except LLMServiceError:
            raise
        except Exception as e:
            logger.error("Unexpected error calling LLM API: %s", e, exc_info=True)
            raise LLMServiceError("An unexpected error occurred while calling the LLM service.") from e
