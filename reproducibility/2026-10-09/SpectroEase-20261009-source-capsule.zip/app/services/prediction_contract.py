"""Shared prediction boundary for fitted spectral analyzers.

Predictions exposed by this module are always in the user's target space:
original regression units or original classification labels.  The wrapped
estimator continues to operate on the training-fitted imputer/scaler and, for
regression, a scaled target.
"""

from dataclasses import dataclass
from typing import Any, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def _vector(values, name: str) -> np.ndarray:
    array = np.asarray(values)
    if array.ndim == 2 and array.shape[1] == 1:
        array = array.reshape(-1)
    if array.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional vector")
    return array


def _optional_ids(values, name: str, n_rows: int) -> Optional[Tuple[Any, ...]]:
    if values is None:
        return None
    result = tuple(values)
    if len(result) != n_rows:
        raise ValueError(f"{name} must match the number of prediction rows")
    return result


@dataclass(frozen=True)
class PredictionResult:
    """One aligned prediction vector and the identities of its input rows."""

    predictions: np.ndarray
    task_type: str
    row_ids: Optional[Tuple[Any, ...]] = None
    physical_sample_ids: Optional[Tuple[Any, ...]] = None
    group_ids: Optional[Tuple[Any, ...]] = None

    def __post_init__(self):
        predictions = _vector(self.predictions, "predictions")
        object.__setattr__(self, "predictions", predictions)
        for field, label in (
            ("row_ids", "row_ids"),
            ("physical_sample_ids", "physical_sample_ids"),
            ("group_ids", "group_ids"),
        ):
            values = getattr(self, field)
            if values is not None and len(values) != len(predictions):
                raise ValueError(f"{label} must match the number of predictions")
        if self.task_type not in {"regression", "classification"}:
            raise ValueError(f"Unsupported prediction task type: {self.task_type}")


class FittedSpectrumPredictor:
    """Training-fitted input/target transforms plus one estimator.

    ``feature_names`` is enforced whenever callers provide named columns.  For
    array inputs, the feature count is enforced; the caller owns any upstream
    preprocessing/feature-selection replay and must pass the same representation
    used to fit this object.
    """

    def __init__(
        self,
        estimator,
        task_type: str,
        imputer=None,
        x_scaler=None,
        y_scaler=None,
        label_encoder=None,
        feature_names: Optional[Sequence[str]] = None,
        n_features: Optional[int] = None,
        fit_row_ids=None,
        fit_physical_sample_ids=None,
        fit_group_ids=None,
        group_validation: bool = False,
        input_representation: str = "fitted_feature_matrix",
    ):
        self.estimator = estimator
        self.task_type = task_type
        self.imputer = imputer
        self.x_scaler = x_scaler
        self.y_scaler = y_scaler
        self.label_encoder = label_encoder
        self.feature_names = tuple(map(str, feature_names)) if feature_names is not None else None
        self.n_features = int(n_features) if n_features is not None else None
        self.fit_row_ids = tuple(fit_row_ids) if fit_row_ids is not None else None
        self.fit_physical_sample_ids = (
            tuple(fit_physical_sample_ids) if fit_physical_sample_ids is not None else None
        )
        self.fit_group_ids = tuple(fit_group_ids) if fit_group_ids is not None else None
        self.group_validation = bool(group_validation)
        self.input_representation = str(input_representation)
        if self.group_validation:
            if self.fit_group_ids is None:
                raise ValueError(
                    "A group-validated predictor requires explicit training group IDs"
                )
            if self.fit_row_ids is not None and len(self.fit_group_ids) != len(self.fit_row_ids):
                raise ValueError("Training group IDs must align with training row IDs")
        if (self.fit_physical_sample_ids is not None and self.fit_row_ids is not None
                and len(self.fit_physical_sample_ids) != len(self.fit_row_ids)):
            raise ValueError("Training physical sample IDs must align with training row IDs")

    def _prepare_X(self, X):
        if isinstance(X, pd.DataFrame):
            if self.feature_names is not None and tuple(map(str, X.columns)) != self.feature_names:
                raise ValueError(
                    "Prediction feature columns must exactly match the fitted feature names and order"
                )
            array = X.to_numpy()
        else:
            array = np.asarray(X)
        if array.ndim != 2:
            raise ValueError("Prediction features must be a 2D matrix")
        if self.n_features is not None and array.shape[1] != self.n_features:
            raise ValueError(
                f"Prediction feature count mismatch: expected {self.n_features}, got {array.shape[1]}"
            )
        array = np.asarray(array, dtype=float)
        if self.imputer is not None:
            array = self.imputer.transform(array)
        if self.x_scaler is not None:
            array = self.x_scaler.transform(array)
        return array

    @staticmethod
    def _identity_overlap(actual, fitted, label):
        if actual is None or fitted is None:
            return
        overlap = set(actual).intersection(fitted)
        if overlap:
            raise ValueError(
                f"Prediction {label} overlap training {label}: {sorted(map(str, overlap))[:5]}"
            )

    def predict_result(
        self,
        X,
        row_ids=None,
        physical_sample_ids=None,
        group_ids=None,
        enforce_disjoint: bool = True,
    ) -> PredictionResult:
        if self.estimator is None or not hasattr(self.estimator, "predict"):
            raise ValueError("The fitted spectrum predictor has no trained estimator")
        n_rows = len(X)
        row_ids = _optional_ids(row_ids, "row_ids", n_rows)
        physical_sample_ids = _optional_ids(
            physical_sample_ids, "physical_sample_ids", n_rows
        )
        group_ids = _optional_ids(group_ids, "group_ids", n_rows)
        if enforce_disjoint:
            self._identity_overlap(row_ids, self.fit_row_ids, "row IDs")
            self._identity_overlap(
                physical_sample_ids, self.fit_physical_sample_ids, "physical sample IDs"
            )
            if self.group_validation:
                if self.fit_group_ids is None:
                    raise ValueError(
                        "Group-disjoint prediction requires explicit training group IDs in the fitted contract"
                    )
                if group_ids is None:
                    raise ValueError(
                        "Group-disjoint prediction requires explicit group IDs for prediction rows"
                    )
                if self.fit_row_ids is not None and len(self.fit_group_ids) != len(self.fit_row_ids):
                    raise ValueError("Training group IDs are not aligned to the fitted rows")
                self._identity_overlap(group_ids, self.fit_group_ids, "group IDs")

        prediction = _vector(self.estimator.predict(self._prepare_X(X)), "estimator predictions")
        if len(prediction) != n_rows:
            raise ValueError(
                f"Estimator returned {len(prediction)} predictions for {n_rows} input rows"
            )
        if self.task_type == "regression" and self.y_scaler is not None:
            prediction = self.y_scaler.inverse_transform(
                np.asarray(prediction, dtype=float).reshape(-1, 1)
            ).reshape(-1)
        elif self.task_type == "classification" and self.label_encoder is not None:
            encoded = np.asarray(prediction)
            if not np.all(np.equal(encoded, encoded.astype(int))):
                raise ValueError("Classifier returned non-integer encoded class predictions")
            prediction = self.label_encoder.inverse_transform(encoded.astype(int))
        return PredictionResult(
            predictions=prediction,
            task_type=self.task_type,
            row_ids=row_ids,
            physical_sample_ids=physical_sample_ids,
            group_ids=group_ids,
        )

    def predict(self, X):
        """Compatibility method returning only the target-space vector."""
        return self.predict_result(X, enforce_disjoint=False).predictions

    def predict_raw(self, X, **identity):
        """Predict from imported raw spectra only when fit used that boundary.

        An analyzer fitted on preprocessed/PCA/selected features does not own
        the upstream replay pipeline.  Such a model must use its fitted feature
        matrix boundary and cannot be advertised as accepting raw spectra.
        """
        if self.input_representation != "raw_spectrum":
            raise ValueError(
                "Raw-spectrum prediction is unavailable because this model was fitted on "
                f"{self.input_representation}; the upstream transform is not stored for replay"
            )
        return self.predict_result(X, **identity)
