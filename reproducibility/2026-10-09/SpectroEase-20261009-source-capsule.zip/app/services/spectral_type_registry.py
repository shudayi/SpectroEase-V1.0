# app/services/spectral_type_registry.py
"""Spectral type registry.

Centralizes the list of supported spectral types (NIR, Raman, MIR, ...) so
that the dialog, the data controller, and the model default ranges all share
the same source. Each entry exposes the unit, the default wavelength range,
and the default preprocessing pipeline.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Dict, Optional


@dataclass(frozen=True)
class SpectralType:
    """A single spectral type descriptor."""

    name: str
    display_name: str
    unit: str
    wl_min: float
    wl_max: float
    preprocessing_pipeline: List[str] = field(default_factory=list)

    @property
    def range_label(self) -> str:
        return f"[{self.wl_min:g}, {self.wl_max:g}] {self.unit}"


# Canonical entries. ``name`` is the stable identifier used in
# ``data_controller.apply_preselected_spectral_config``; ``display_name`` is
# shown in the UI combobox.
SPECTRAL_TYPES: List[SpectralType] = [
    SpectralType(
        name="nir",
        display_name="NIR (Near Infrared)",
        unit="nm",
        wl_min=800,
        wl_max=2500,
        preprocessing_pipeline=["snv", "sg_smooth"],
    ),
    SpectralType(
        name="raman",
        display_name="Raman",
        unit="cm-1",
        wl_min=200,
        wl_max=4000,
        preprocessing_pipeline=["baseline", "spike_removal"],
    ),
    SpectralType(
        name="mir",
        display_name="MIR (Mid Infrared)",
        unit="cm-1",
        wl_min=4000,
        wl_max=400,
        preprocessing_pipeline=["emsc", "sg_smooth"],
    ),
    SpectralType(
        name="vis_nir",
        display_name="VIS-NIR",
        unit="nm",
        wl_min=400,
        wl_max=1100,
        preprocessing_pipeline=["msc", "sg_smooth"],
    ),
    SpectralType(
        name="uv_vis",
        display_name="UV-Vis",
        unit="nm",
        wl_min=200,
        wl_max=800,
        preprocessing_pipeline=["snv", "sg_smooth"],
    ),
]


def get_by_name(name: str) -> Optional[SpectralType]:
    """Return the spectral type matching ``name`` (case-insensitive), or None."""
    if name is None:
        return None
    needle = name.strip().lower()
    for entry in SPECTRAL_TYPES:
        if entry.name == needle:
            return entry
    return None


def display_names() -> Dict[str, str]:
    """Return a mapping of ``name -> display_name``."""
    return {entry.name: entry.display_name for entry in SPECTRAL_TYPES}


def by_index(index: int) -> Optional[SpectralType]:
    if 0 <= index < len(SPECTRAL_TYPES):
        return SPECTRAL_TYPES[index]
    return None
