# app/services/hyperparameter_optimization_service.py

from sklearn.base import clone, is_classifier
from sklearn.impute import SimpleImputer
from sklearn.model_selection import (
    GridSearchCV, RandomizedSearchCV, StratifiedKFold, KFold, GroupKFold,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, r2_score, mean_squared_error
from deap import base, creator, tools, algorithms
import numpy as np
import random
from app.utils.logger import setup_logger
from app.utils.exceptions import HyperparameterOptimizationError
# **CRITICAL FIX: Import enhanced label processor for consistent handling**
from app.utils.label_processor import EnhancedLabelProcessor

class HyperparameterOptimizationService:
    def __init__(self):
        self.logger = setup_logger()
        # **CRITICAL FIX: Initialize enhanced label processor for consistent handling**
        self.label_processor = EnhancedLabelProcessor()
        self.logger.debug("HyperparameterOptimizationService initialized with EnhancedLabelProcessor")

    @staticmethod
    def _unwrap_estimator(estimator):
        """Unwrap a completed search while retaining its fitted pipeline contract."""
        if hasattr(estimator, 'best_estimator_'):
            return estimator.best_estimator_
        return estimator

    def _fold_safe_pipeline(self, estimator):
        """Place imputation and scaling inside sklearn's per-fold fit boundary."""
        estimator = self._unwrap_estimator(estimator)
        base = clone(estimator)
        if isinstance(base, Pipeline):
            step_names = {name for name, _ in base.steps}
            if 'imputer' in step_names and 'scaler' in step_names:
                return base
        return Pipeline([
            ('imputer', SimpleImputer(strategy='mean')),
            ('scaler', StandardScaler()),
            ('estimator', base),
        ])

    @staticmethod
    def _normalize_search_params(pipeline, parameters):
        """Map bare estimator parameter names to the pipeline's final step."""
        valid = pipeline.get_params(deep=True)
        final_step = pipeline.steps[-1][0]
        final_params = pipeline.steps[-1][1].get_params(deep=True)
        normalized = {}
        for name, values in parameters.items():
            if name in valid:
                normalized[name] = values
            elif name in final_params:
                normalized[f'{final_step}__{name}'] = values
            else:
                normalized[name] = values
        return normalized

    @staticmethod
    def _best_model_from_search(search):
        """Return the fitted best pipeline with its search evidence attached."""
        best_model = search.best_estimator_
        best_model.best_params_ = dict(search.best_params_)
        best_model.cv_results_ = search.cv_results_
        for attribute in (
                'cv_fit_trace_', 'refit_sample_ids_', 'outer_test_sample_ids_',
                'outer_test_group_ids_', 'group_validation_'):
            if hasattr(search, attribute):
                setattr(best_model, attribute, getattr(search, attribute))
        return best_model

    @staticmethod
    def _fit_scope_splits(estimator, X, y, cv, sample_ids=None,
                          outer_test_sample_ids=None, group_ids=None,
                          outer_test_group_ids=None, physical_sample_ids=None,
                          outer_test_physical_sample_ids=None,
                          group_validation=False):
        """Build deterministic folds and retain the exact row identities per fit."""
        y_array = np.asarray(y)
        n_rows = len(X)
        if y_array.ndim != 1 or len(y_array) != n_rows:
            raise ValueError("Search X/y must have matching rows and one-dimensional targets")
        if sample_ids is None:
            sample_ids = list(X.index) if hasattr(X, 'index') else list(range(n_rows))
        else:
            sample_ids = list(sample_ids)
        outer_test_sample_ids = (
            list(outer_test_sample_ids) if outer_test_sample_ids is not None else []
        )
        if len(sample_ids) != n_rows:
            raise ValueError("Search sample_ids must match the number of training rows")
        if len(set(sample_ids)) != len(sample_ids):
            raise ValueError("Search sample_ids must be unique")
        overlap = set(sample_ids).intersection(outer_test_sample_ids)
        if overlap:
            raise ValueError(
                "Outer-test sample identities overlap the hyperparameter-search input: "
                f"{sorted(map(str, overlap))[:5]}"
            )

        groups = None
        physical = list(physical_sample_ids) if physical_sample_ids is not None else None
        if group_validation:
            if group_ids is None:
                raise ValueError("Group validation was requested but no explicit group_id values reached search")
            groups = [str(value).strip() if value is not None else '' for value in group_ids]
            if len(groups) != n_rows or any(not value or value.lower() in {'nan', 'none', '<na>'} for value in groups):
                raise ValueError("group_id values must be complete, nonblank, and aligned to search rows")
            if isinstance(cv, int) and len(set(groups)) < cv:
                raise ValueError(f"Group search CV needs at least {cv} unique groups; found {len(set(groups))}")
            outer_groups = list(outer_test_group_ids) if outer_test_group_ids is not None else []
            if set(groups) & set(map(str, outer_groups)):
                raise ValueError("Outer-test group IDs overlap hyperparameter-search input groups")
            if physical is not None:
                if len(physical) != n_rows or any(value is None or not str(value).strip() for value in physical):
                    raise ValueError("sample_id values must be complete, nonblank, and aligned to search rows")
                mapping = {}
                for sample, group in zip(physical, groups):
                    sample = str(sample).strip()
                    if sample in mapping and mapping[sample] != group:
                        raise ValueError("A sample_id maps to multiple group_id values")
                    mapping[sample] = group
                outer_samples = list(outer_test_physical_sample_ids) if outer_test_physical_sample_ids is not None else []
                if set(map(str, physical)) & set(map(str, outer_samples)):
                    raise ValueError("Outer-test sample IDs overlap hyperparameter-search input samples")

        if not isinstance(cv, int):
            splitter = cv
        elif group_validation and is_classifier(estimator):
            from sklearn.model_selection import StratifiedGroupKFold
            import pandas as pd
            groups_per_class = pd.DataFrame({'label': y_array, 'group': groups}).drop_duplicates().groupby('label')['group'].nunique()
            if (groups_per_class < cv).any():
                raise ValueError(f"Each class must occur in at least {cv} groups; found {groups_per_class.to_dict()}")
            splitter = StratifiedGroupKFold(n_splits=cv, shuffle=True, random_state=42)
        elif group_validation:
            splitter = GroupKFold(n_splits=cv)
        elif is_classifier(estimator):
            splitter = StratifiedKFold(n_splits=cv, shuffle=True, random_state=42)
        else:
            splitter = KFold(n_splits=cv, shuffle=True, random_state=42)
        splits = list(splitter.split(X, y_array, groups=groups)) if group_validation else list(splitter.split(X, y_array))
        trace = []
        for fold_index, (train_idx, validation_idx) in enumerate(splits, start=1):
            train_ids = [sample_ids[int(index)] for index in train_idx]
            validation_ids = [sample_ids[int(index)] for index in validation_idx]
            trace_item = {
                'fold': fold_index,
                'transformer_fit_sample_ids': list(train_ids),
                'transformer_names': ['SimpleImputer', 'StandardScaler'],
                'transformer_fit_sample_ids_by_name': {
                    'SimpleImputer': list(train_ids),
                    'StandardScaler': list(train_ids),
                },
                'estimator_fit_sample_ids': list(train_ids),
                'validation_sample_ids': list(validation_ids),
            }
            if group_validation:
                train_groups = [groups[int(index)] for index in train_idx]
                validation_groups = [groups[int(index)] for index in validation_idx]
                if set(train_groups) & set(validation_groups):
                    raise ValueError("Group-aware search split overlaps train and validation groups")
                trace_item.update({
                    'train_group_ids': sorted(set(train_groups)),
                    'validation_group_ids': sorted(set(validation_groups)),
                    'train_physical_sample_ids': sorted(set(str(physical[int(i)]) for i in train_idx)) if physical else [],
                    'validation_physical_sample_ids': sorted(set(str(physical[int(i)]) for i in validation_idx)) if physical else [],
                })
            trace.append(trace_item)
        return splits, trace, sample_ids

    def optimize(self, estimator, X, y, method='grid_search', param_grid=None,
                 param_distributions=None, scoring='accuracy', cv=5, n_iter=10,
                 n_population=20, n_generations=10, sample_ids=None,
                 outer_test_sample_ids=None, group_ids=None,
                 outer_test_group_ids=None, physical_sample_ids=None,
                 outer_test_physical_sample_ids=None, group_validation=False):
        """Run search over a fold-safe imputation/scaling/estimator pipeline."""
        param_grid = param_grid or {}
        param_distributions = param_distributions or param_grid
        scope = {
            'sample_ids': sample_ids,
            'outer_test_sample_ids': outer_test_sample_ids,
            'group_ids': group_ids,
            'outer_test_group_ids': outer_test_group_ids,
            'physical_sample_ids': physical_sample_ids,
            'outer_test_physical_sample_ids': outer_test_physical_sample_ids,
            'group_validation': group_validation,
        }

        if method == 'no_optimization':
            best_model = self.no_optimization(estimator, X, y)
            return {}, best_model, {}
        if method == 'grid_search':
            search = self.grid_search(
                estimator, param_grid, X, y, cv=cv, scoring=scoring, **scope
            )
            return search.best_params_, self._best_model_from_search(search), search.cv_results_
        if method == 'random_search':
            search = self.random_search(
                estimator, param_distributions, X, y, cv=cv, n_iter=n_iter,
                scoring=scoring, **scope
            )
            return search.best_params_, self._best_model_from_search(search), search.cv_results_
        if method == 'genetic_algorithm':
            param_ranges = {}
            for key, val in param_grid.items():
                if isinstance(val, (list, tuple)) and len(val) == 2 and all(
                        isinstance(value, (int, float)) for value in val):
                    param_ranges[key] = tuple(val)
                elif isinstance(val, list):
                    param_ranges[key] = val
                else:
                    param_ranges[key] = [val]
            base_estimator = self._unwrap_estimator(estimator)
            best_model = self.genetic_algorithm(
                base_estimator.__class__, param_ranges, X, y, cv=cv,
                n_population=n_population, n_generations=n_generations,
                estimator_template=base_estimator, scoring=scoring, **scope
            )
            return getattr(best_model, 'best_params_', {}), best_model, {}
        if method == 'optuna':
            best_params, best_model = self.optuna_search(
                estimator, param_grid, X, y, cv=cv, n_iter=n_iter,
                scoring=scoring, **scope
            )
            return best_params, best_model, best_model.cv_results_
        raise HyperparameterOptimizationError(f"Unknown optimization method: {method}")

    def _resolved_scoring(self, estimator, scoring):
        if not is_classifier(estimator) and scoring in (None, 'accuracy'):
            return 'r2'
        return scoring

    def optuna_search(self, estimator, param_grid, X, y, cv=5, n_iter=10,
                      scoring='accuracy', sample_ids=None,
                      outer_test_sample_ids=None, group_ids=None,
                      outer_test_group_ids=None, physical_sample_ids=None,
                      outer_test_physical_sample_ids=None, group_validation=False):
        """Run seeded TPE over exactly the declared discrete candidates.

        Lists/tuples are categorical choices, even when they contain two numbers.
        Scalars are fixed settings. Missing Optuna is a visible dependency error.
        """
        try:
            import optuna
        except ImportError as error:
            raise HyperparameterOptimizationError(
                "Optuna TPE is unavailable. Install the pinned requirements "
                "or select Grid Search explicitly."
            ) from error
        if isinstance(n_iter, bool) or not isinstance(n_iter, int) or n_iter < 1:
            raise HyperparameterOptimizationError("Optuna trial count must be a positive integer")
        if not param_grid:
            raise HyperparameterOptimizationError("Optuna requires a nonempty parameter configuration")
        from sklearn.model_selection import cross_val_score
        pipeline = self._fold_safe_pipeline(estimator)
        normalized_grid = self._normalize_search_params(pipeline, param_grid)
        for name, choices in normalized_grid.items():
            if isinstance(choices, (list, tuple)) and not choices:
                raise HyperparameterOptimizationError(f"Empty candidate list for {name}")
        splits, trace, ids = self._fit_scope_splits(
            pipeline, X, y, cv, sample_ids, outer_test_sample_ids,
            group_ids, outer_test_group_ids, physical_sample_ids,
            outer_test_physical_sample_ids, group_validation
        )
        scoring = self._resolved_scoring(pipeline, scoring)
        startup_trials = min(5, max(1, n_iter // 3))
        sampler = optuna.samplers.TPESampler(seed=42, n_startup_trials=startup_trials)
        study = optuna.create_study(direction='maximize', sampler=sampler)
        trial_records = []

        def objective(trial):
            params = {
                name: trial.suggest_categorical(name, list(choices))
                if isinstance(choices, (list, tuple)) else choices
                for name, choices in normalized_grid.items()
            }
            candidate = clone(pipeline).set_params(**params)
            scores = cross_val_score(
                candidate, X, y, cv=splits, scoring=scoring, error_score='raise'
            )
            if not np.isfinite(scores).all():
                raise HyperparameterOptimizationError("Optuna objective produced nonfinite fold scores")
            trial_records.append({
                'number': trial.number, 'parameters': dict(params),
                'fold_scores': scores.tolist(), 'mean_score': float(scores.mean()),
            })
            return float(scores.mean())

        try:
            study.optimize(objective, n_trials=n_iter)
            # Include fixed scalar parameters, which Optuna does not put in
            # study.best_params, so refit exactly the evaluated configuration.
            best_params = dict(trial_records[study.best_trial.number]['parameters'])
            best_model = clone(pipeline).set_params(**best_params)
            best_model.fit(X, y)
        except Exception as error:
            raise HyperparameterOptimizationError(f"Optuna TPE failed: {error}") from error
        best_model.cv_fit_trace_ = trace
        best_model.refit_sample_ids_ = list(ids)
        best_model.outer_test_sample_ids_ = list(outer_test_sample_ids) if outer_test_sample_ids is not None else []
        best_model.best_params_ = dict(best_params)
        best_model.outer_test_group_ids_ = list(outer_test_group_ids) if outer_test_group_ids is not None else []
        best_model.group_validation_ = bool(group_validation)
        best_model.optimization_backend_ = 'optuna_tpe'
        best_model.optimization_metadata_ = {
            'engine': 'Optuna', 'version': optuna.__version__, 'sampler': 'TPESampler',
            'seed': 42, 'n_startup_trials': startup_trials, 'n_trials': len(study.trials),
            'scoring': scoring, 'direction': 'maximize',
            'search_space_semantics': 'list/tuple = discrete candidates; scalar = fixed',
        }
        best_model.optimization_trials_ = trial_records
        best_model.cv_results_ = {
            'params': [item['parameters'] for item in trial_records],
            'mean_test_score': np.asarray([item['mean_score'] for item in trial_records]),
            'std_test_score': np.asarray([np.std(item['fold_scores']) for item in trial_records]),
        }
        return best_params, best_model

    def grid_search(self, estimator, param_grid, X, y, cv=5,
                    scoring='accuracy', sample_ids=None,
                    outer_test_sample_ids=None, group_ids=None,
                    outer_test_group_ids=None, physical_sample_ids=None,
                    outer_test_physical_sample_ids=None, group_validation=False):
        """Grid search with fold-local imputation, scaling, and estimator fits."""
        try:
            pipeline = self._fold_safe_pipeline(estimator)
            normalized_grid = self._normalize_search_params(pipeline, param_grid)
            splits, trace, ids = self._fit_scope_splits(
                pipeline, X, y, cv, sample_ids, outer_test_sample_ids,
                group_ids, outer_test_group_ids, physical_sample_ids,
                outer_test_physical_sample_ids, group_validation
            )
            search = GridSearchCV(
                pipeline, normalized_grid, cv=splits,
                scoring=self._resolved_scoring(pipeline, scoring),
            )
            search.fit(X, y)
            search.cv_fit_trace_ = trace
            search.refit_sample_ids_ = list(ids)
            search.outer_test_sample_ids_ = (
                list(outer_test_sample_ids) if outer_test_sample_ids is not None else []
            )
            search.outer_test_group_ids_ = list(outer_test_group_ids) if outer_test_group_ids is not None else []
            search.group_validation_ = bool(group_validation)
            self.logger.info("Fold-safe Grid Search completed.")
            return search
        except Exception as error:
            self.logger.error("Grid Search failed: %s", error)
            raise HyperparameterOptimizationError(f"Grid Search failed: {error}") from error

    def random_search(self, estimator, param_distributions, X, y, cv=5, n_iter=10,
                      scoring='accuracy', sample_ids=None,
                      outer_test_sample_ids=None, group_ids=None,
                      outer_test_group_ids=None, physical_sample_ids=None,
                      outer_test_physical_sample_ids=None, group_validation=False):
        """Random search with the same per-fold learned-state boundary as CV."""
        try:
            pipeline = self._fold_safe_pipeline(estimator)
            normalized_distributions = self._normalize_search_params(
                pipeline, param_distributions
            )
            splits, trace, ids = self._fit_scope_splits(
                pipeline, X, y, cv, sample_ids, outer_test_sample_ids,
                group_ids, outer_test_group_ids, physical_sample_ids,
                outer_test_physical_sample_ids, group_validation
            )
            search = RandomizedSearchCV(
                pipeline, normalized_distributions, n_iter=n_iter, cv=splits,
                scoring=self._resolved_scoring(pipeline, scoring), random_state=42,
            )
            search.fit(X, y)
            search.cv_fit_trace_ = trace
            search.refit_sample_ids_ = list(ids)
            search.outer_test_sample_ids_ = (
                list(outer_test_sample_ids) if outer_test_sample_ids is not None else []
            )
            search.outer_test_group_ids_ = list(outer_test_group_ids) if outer_test_group_ids is not None else []
            search.group_validation_ = bool(group_validation)
            self.logger.info("Fold-safe Random Search completed.")
            return search
        except Exception as error:
            self.logger.error("Random Search failed: %s", error)
            raise HyperparameterOptimizationError(f"Random Search failed: {error}") from error

    def no_optimization(self, estimator, X, y):
        """Return the current fitted estimator without refitting on raw input."""
        self.logger.info("No hyperparameter optimization selected; returning the current fitted model.")
        return estimator

    def genetic_algorithm(self, estimator_class, param_ranges, X, y, cv=5,
                          n_population=20, n_generations=10,
                          estimator_template=None, scoring='accuracy',
                          sample_ids=None, outer_test_sample_ids=None, group_ids=None,
                          outer_test_group_ids=None, physical_sample_ids=None,
                          outer_test_physical_sample_ids=None, group_validation=False):
        """Evolve parameters while fitting a fresh fold-safe pipeline per fold."""
        try:
            if not param_ranges:
                raise ValueError("Genetic search requires at least one parameter range")

            y_array = np.asarray(y)
            template = estimator_template or estimator_class()
            template = self._fold_safe_pipeline(template)
            param_ranges = self._normalize_search_params(template, param_ranges)
            is_classification = is_classifier(template)
            splits, trace, ids = self._fit_scope_splits(
                template, X, y_array, cv, sample_ids, outer_test_sample_ids,
                group_ids, outer_test_group_ids, physical_sample_ids,
                outer_test_physical_sample_ids, group_validation
            )

            def evaluate_parameters(parameters):
                candidate = clone(template).set_params(**parameters)
                fold_scores = []
                for train_idx, validation_idx in splits:
                    pipeline = self._fold_safe_pipeline(candidate)
                    X_train = X.iloc[train_idx] if hasattr(X, 'iloc') else X[train_idx]
                    X_validation = X.iloc[validation_idx] if hasattr(X, 'iloc') else X[validation_idx]
                    y_train = y_array[train_idx]
                    y_validation = y_array[validation_idx]
                    pipeline.fit(X_train, y_train)
                    predictions = pipeline.predict(X_validation)
                    if is_classification:
                        fold_scores.append(accuracy_score(y_validation, predictions))
                    else:
                        fold_scores.append(r2_score(y_validation, predictions))
                return float(np.mean(fold_scores))

            # Use unique creator names so repeated optimization sessions do not
            # collide in DEAP's process-global creator registry.
            suffix = str(random.randrange(1_000_000_000))
            fitness_name = f"FitnessMax_{suffix}"
            individual_name = f"Individual_{suffix}"
            creator.create(fitness_name, base.Fitness, weights=(1.0,))
            creator.create(individual_name, list, fitness=getattr(creator, fitness_name))
            fitness_cls = getattr(creator, fitness_name)
            individual_cls = getattr(creator, individual_name)
            toolbox = base.Toolbox()

            def sample_value(bounds):
                if isinstance(bounds, tuple):
                    low, high = bounds
                    if isinstance(low, int) and isinstance(high, int):
                        return random.randint(low, high)
                    return random.uniform(low, high)
                return random.randrange(len(bounds))

            def mutate_individual(individual, indpb=0.2):
                for position, name in enumerate(names):
                    if random.random() >= indpb:
                        continue
                    bounds = param_ranges[name]
                    individual[position] = sample_value(bounds)
                return (individual,)

            names = list(param_ranges)
            toolbox.register(
                "individual", tools.initIterate, individual_cls,
                lambda: [sample_value(param_ranges[name]) for name in names],
            )
            toolbox.register("population", tools.initRepeat, list, toolbox.individual)

            def score_individual(individual):
                params = {}
                for name, value in zip(names, individual):
                    candidates = param_ranges[name]
                    if isinstance(candidates, list):
                        value = candidates[int(value) % len(candidates)]
                    params[name] = value
                return (evaluate_parameters(params),)

            toolbox.register("evaluate", score_individual)
            toolbox.register(
                "mate",
                tools.cxTwoPoint if len(names) > 1 else tools.cxUniform,
                **({} if len(names) > 1 else {'indpb': 0.5}),
            )
            toolbox.register("mutate", mutate_individual, indpb=0.2)
            toolbox.register("select", tools.selTournament, tournsize=3)
            population = toolbox.population(n=n_population)
            algorithms.eaSimple(
                population, toolbox, cxpb=0.5, mutpb=0.2,
                ngen=n_generations, verbose=False,
            )
            best_individual = tools.selBest(population, k=1)[0]
            best_params = {}
            for name, value in zip(names, best_individual):
                candidates = param_ranges[name]
                if isinstance(candidates, list):
                    value = candidates[int(value) % len(candidates)]
                best_params[name] = value

            best_pipeline = self._fold_safe_pipeline(
                clone(template).set_params(**best_params)
            )
            best_pipeline.fit(X, y_array)
            best_pipeline.cv_fit_trace_ = trace
            best_pipeline.refit_sample_ids_ = list(ids)
            best_pipeline.best_params_ = dict(best_params)
            best_pipeline.outer_test_group_ids_ = list(outer_test_group_ids) if outer_test_group_ids is not None else []
            best_pipeline.group_validation_ = bool(group_validation)
            return best_pipeline
        except Exception as error:
            self.logger.error("Genetic Algorithm optimization failed: %s", error)
            raise HyperparameterOptimizationError(
                f"Genetic Algorithm optimization failed: {error}"
            ) from error
