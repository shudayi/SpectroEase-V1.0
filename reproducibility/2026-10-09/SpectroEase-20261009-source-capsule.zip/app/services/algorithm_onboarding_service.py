"""Verification-first onboarding for stateless spectral preprocessing plugins.

This service deliberately supports only ``transform(X, params)`` operators
that act independently on each spectral row. It verifies edited Python source
as written, checks numerical reference fixtures and row independence, then
persists and reloads a versioned record in a fresh service instance before it
registers an adapter with the existing preprocessing registry.

Execution uses a bounded child process with the existing AST/restricted-builtins
policy. This is crash/timeout containment, not OS isolation for arbitrary
untrusted code. Fitted/stateful transformers are unsupported.
"""

from __future__ import annotations

import ast
import builtins
import hashlib
import importlib
import importlib.metadata
import json
import math
import multiprocessing
import os
import re
import sys
import tempfile
import time
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

import numpy as np
import pandas as pd

from app.services.preprocessing_registry import register_plugin, unregister_plugin
from app.version import APP_VERSION, APP_VERSION_SOURCE
from app.utils.code_sandbox import DANGEROUS_ATTRIBUTES, DANGEROUS_CALLS, validate_code


VALIDATOR_VERSION = "s26-45-stateless-v1"
PROTOCOL = "stateless_transform_X_params_v1"
RECORD_SCHEMA_VERSION = 1
MAX_REPAIR_ROUNDS = 3
WORKER_TIMEOUT_SECONDS = 8.0
VERIFICATION_BUDGET_SECONDS = 60.0
MAX_WORKER_MESSAGE_BYTES = 16 * 1024 * 1024
MAX_VERIFICATION_ROWS = 128
MAX_SOURCE_BYTES = 256 * 1024
_ALLOWED_IMPORT_ROOTS = frozenset({"numpy", "scipy", "math", "statistics"})
_SIDE_EFFECT_CALLS = frozenset({
    "load", "loadtxt", "genfromtxt", "fromfile", "memmap", "loadmat",
    "save", "savetxt", "savez", "savez_compressed", "tofile", "savemat",
    "seterr", "set_printoptions", "seed", "set_state", "system", "popen",
    "open", "urlopen", "remove", "unlink", "rmtree",
})
_SAFE_BUILTIN_NAMES = frozenset({
    "ArithmeticError", "AssertionError", "AttributeError", "Exception",
    "IndexError", "KeyError", "NameError", "NotImplementedError",
    "RuntimeError", "TypeError", "ValueError", "abs", "all", "any",
    "bool", "dict", "enumerate", "filter", "float", "int", "isinstance",
    "len", "list", "map", "max", "min", "range", "repr", "round",
    "set", "slice", "sorted", "str", "sum", "tuple", "zip",
})
_PARAMETER_TYPES = frozenset({"number", "integer", "boolean", "string"})


@dataclass(frozen=True)
class ParameterField:
    """One supported, JSON-serializable parameter schema entry."""

    type: str
    required: bool = False
    default: Any = None
    minimum: float | None = None
    maximum: float | None = None
    enum: tuple[Any, ...] = ()


@dataclass(frozen=True)
class CheckResult:
    name: str
    status: str
    details: str


@dataclass(frozen=True)
class AttemptRecord:
    attempt: int
    source_sha256: str
    passed: bool
    checks: tuple[CheckResult, ...]


@dataclass(frozen=True)
class RepairRecord:
    round: int
    input_source_sha256: str
    output_source_sha256: str | None
    status: str
    details: str


@dataclass(frozen=True)
class OnboardingCandidate:
    name: str
    python_source: str
    original_r_source: str
    algorithm_category: str
    parameter_schema: Mapping[str, Any]
    parameters: Mapping[str, Any]
    X: Any
    axis: Any
    axis_unit: str
    reference_examples: Sequence[Mapping[str, Any]]
    rtol: float = 1e-5
    atol: float = 1e-8
    dependencies: Sequence[str] = ()


@dataclass(frozen=True)
class VerificationReport:
    candidate: OnboardingCandidate
    checks: tuple[CheckResult, ...]
    attempts: tuple[AttemptRecord, ...] = ()
    repairs: tuple[RepairRecord, ...] = ()
    validator_version: str = VALIDATOR_VERSION

    @property
    def passed(self) -> bool:
        return bool(self.checks) and all(check.status == "pass" for check in self.checks)

    @property
    def source_sha256(self) -> str:
        return _sha256_text(self.candidate.python_source)


class AlgorithmOnboardingError(ValueError):
    """Raised when verification, persistence, or activation is rejected."""


def _canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _sha256_json(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _default_storage_dir() -> Path:
    override = os.environ.get("SPECTROEASE_PLUGIN_DIR")
    if override:
        return Path(override).expanduser().resolve()
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
        return base / "SpectroEase" / "plugins" / "onboarded"
    return Path.home() / ".local" / "share" / "SpectroEase" / "plugins" / "onboarded"


def _normalize_schema(schema: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    if not isinstance(schema, Mapping):
        raise ValueError("parameter_schema must be a mapping")
    normalized: dict[str, dict[str, Any]] = {}
    allowed = {"type", "required", "default", "minimum", "maximum", "enum", "description"}
    for name, raw in schema.items():
        if not isinstance(name, str) or not name.isidentifier() or name in {"X", "params"}:
            raise ValueError(f"Invalid parameter name: {name!r}")
        if isinstance(raw, ParameterField):
            raw = {
                key: value for key, value in asdict(raw).items()
                if value is not None and not (key == "enum" and not value)
            }
        if not isinstance(raw, Mapping):
            raise ValueError(f"Schema for {name!r} must be a mapping")
        unknown = set(raw) - allowed
        if unknown:
            raise ValueError(f"Unknown schema fields for {name!r}: {sorted(unknown)}")
        kind = raw.get("type")
        if kind not in _PARAMETER_TYPES:
            raise ValueError(f"Unsupported parameter type for {name!r}: {kind!r}")
        entry: dict[str, Any] = {
            "type": kind,
            "required": bool(raw.get("required", False)),
        }
        for key in ("default", "minimum", "maximum"):
            if key in raw:
                entry[key] = raw[key]
        if "enum" in raw:
            if not isinstance(raw["enum"], (list, tuple)) or not raw["enum"]:
                raise ValueError(f"enum for {name!r} must be a non-empty list")
            entry["enum"] = list(raw["enum"])
        if "description" in raw:
            entry["description"] = str(raw["description"])
        if "default" in entry:
            _validate_single_parameter(name, entry, entry["default"], from_default=True)
        normalized[name] = entry
    return normalized


def _validate_single_parameter(name: str, field: Mapping[str, Any], value: Any, *, from_default=False) -> None:
    kind = field["type"]
    valid = False
    if kind == "number":
        valid = isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))
    elif kind == "integer":
        valid = isinstance(value, int) and not isinstance(value, bool)
    elif kind == "boolean":
        valid = isinstance(value, bool)
    elif kind == "string":
        valid = isinstance(value, str)
    if not valid:
        origin = "default" if from_default else "value"
        raise ValueError(f"Parameter {name!r} {origin} must have type {kind!r}")
    if "minimum" in field and value < field["minimum"]:
        raise ValueError(f"Parameter {name!r} is below its minimum")
    if "maximum" in field and value > field["maximum"]:
        raise ValueError(f"Parameter {name!r} is above its maximum")
    if "enum" in field and value not in field["enum"]:
        raise ValueError(f"Parameter {name!r} is outside its allowed enum")


def _effective_parameters(schema: Mapping[str, Mapping[str, Any]], values: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(values, Mapping):
        raise ValueError("parameters must be a mapping")
    extra = set(values) - set(schema)
    if extra:
        raise ValueError(f"Undeclared parameters: {sorted(extra)}")
    effective = {}
    for name, spec in schema.items():
        if name in values:
            value = values[name]
        elif "default" in spec:
            value = spec["default"]
        elif spec.get("required"):
            raise ValueError(f"Required parameter {name!r} is missing")
        else:
            continue
        _validate_single_parameter(name, spec, value)
        effective[name] = value
    return effective


def _normalize_array(value: Any, label: str, *, ndim: int = 2) -> np.ndarray:
    try:
        array = np.asarray(value, dtype=float)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be numeric") from exc
    if array.ndim != ndim:
        raise ValueError(f"{label} must be {ndim}-dimensional")
    if not np.isfinite(array).all():
        raise ValueError(f"{label} must contain only finite values")
    return array.copy()


def _candidate_to_json(candidate: OnboardingCandidate) -> dict[str, Any]:
    return {
        "name": candidate.name,
        "python_source": candidate.python_source,
        "original_r_source": candidate.original_r_source,
        "algorithm_category": candidate.algorithm_category,
        "parameter_schema": _normalize_schema(candidate.parameter_schema),
        "parameters": dict(candidate.parameters),
        "X": np.asarray(candidate.X, dtype=float).tolist(),
        "axis": np.asarray(candidate.axis, dtype=float).tolist(),
        "axis_unit": candidate.axis_unit,
        "reference_examples": [
            {
                "input": np.asarray(item["input"], dtype=float).tolist(),
                "expected": np.asarray(item["expected"], dtype=float).tolist(),
                "parameters": dict(item.get("parameters", {})),
            }
            for item in candidate.reference_examples
        ],
        "rtol": candidate.rtol,
        "atol": candidate.atol,
        "dependencies": list(candidate.dependencies),
    }


def _candidate_from_json(data: Mapping[str, Any]) -> OnboardingCandidate:
    return OnboardingCandidate(
        name=data["name"],
        python_source=data["python_source"],
        original_r_source=data["original_r_source"],
        algorithm_category=data["algorithm_category"],
        parameter_schema=data["parameter_schema"],
        parameters=data["parameters"],
        X=data["X"],
        axis=data["axis"],
        axis_unit=data["axis_unit"],
        reference_examples=data["reference_examples"],
        rtol=data["rtol"],
        atol=data["atol"],
        dependencies=data.get("dependencies", ()),
    )


def _safe_import(name, globals=None, locals=None, fromlist=(), level=0):
    if level != 0 or name.split(".", 1)[0] not in _ALLOWED_IMPORT_ROOTS:
        raise ImportError(f"Import of {name!r} is not allowed by onboarding policy")
    return importlib.import_module(name)


def _restricted_builtins() -> dict[str, Any]:
    result = {name: getattr(builtins, name) for name in _SAFE_BUILTIN_NAMES}
    result["__import__"] = _safe_import
    return result


def _source_checks(source: str) -> tuple[CheckResult, ...]:
    if not isinstance(source, str) or len(source.encode("utf-8")) > MAX_SOURCE_BYTES:
        return (
            CheckResult("source_syntax", "fail", "Candidate source must be UTF-8 text under 256 KiB"),
            CheckResult("source_policy", "not_verified", "Source size contract failed"),
            CheckResult("interface_contract", "not_verified", "Source size contract failed"),
        )
    try:
        tree = ast.parse(source)
    except (SyntaxError, TypeError) as exc:
        return (
            CheckResult("source_syntax", "fail", str(exc)),
            CheckResult("source_policy", "not_verified", "Syntax tree is unavailable"),
            CheckResult("interface_contract", "not_verified", "Syntax tree is unavailable"),
        )

    sandbox_findings = validate_code(source)
    policy_findings = list(sandbox_findings)
    interface_findings = []
    top_level_allowed = (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.Expr)
    for node in tree.body:
        is_docstring = (
            isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, str)
        )
        if not isinstance(node, top_level_allowed) or (isinstance(node, ast.Expr) and not is_docstring):
            policy_findings.append(f"Top-level {type(node).__name__} is not allowed")
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            root = (node.module or "").split(".", 1)[0] if isinstance(node, ast.ImportFrom) else None
            roots = [alias.name.split(".", 1)[0] for alias in node.names] if isinstance(node, ast.Import) else [root]
            for imported_root in roots:
                if imported_root not in _ALLOWED_IMPORT_ROOTS:
                    policy_findings.append(f"Import root {imported_root!r} is not allowed for onboarding")
            if isinstance(node, ast.ImportFrom):
                side_effect_symbols = [
                    alias.name for alias in node.names
                    if alias.name in _SIDE_EFFECT_CALLS
                ]
                if side_effect_symbols:
                    policy_findings.append(
                        "Import of side-effect-prone function(s) is not allowed: "
                        + ", ".join(sorted(side_effect_symbols))
                    )

    for node in ast.walk(tree):
        if isinstance(node, (ast.Global, ast.Nonlocal)):
            policy_findings.append("global/nonlocal state mutation is not allowed")
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Name) and func.id in DANGEROUS_CALLS:
                policy_findings.append(f"Call to {func.id}() is not allowed")
            if isinstance(func, ast.Attribute) and func.attr in DANGEROUS_ATTRIBUTES:
                policy_findings.append(f"Call to .{func.attr}() is not allowed")
        # Reject references to known side-effecting APIs, not only direct calls.
        # Otherwise a candidate can hide a filesystem operation behind an
        # assignment (for example ``write_array = np.save``) and invoke the
        # alias during verification before the numeric checks complete.
        if isinstance(node, ast.Attribute) and node.attr in _SIDE_EFFECT_CALLS:
            policy_findings.append(
                f"Reference to side-effect-prone .{node.attr} is not allowed, including aliases"
            )
        if isinstance(node, ast.Attribute) and (node.attr.startswith("__") or node.attr.endswith("__")):
            policy_findings.append("Dunder attribute access is not allowed")
        if isinstance(node, (ast.Import, ast.ImportFrom)) and node not in tree.body:
            policy_findings.append("Imports are allowed only at module scope")

    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
    all_functions = [node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
    transform_functions = [node for node in functions if node.name == "transform"]
    if len(transform_functions) != 1:
        interface_findings.append("Source must define exactly one module-level transform(X, params)")
    if len(functions) != 1 or len(all_functions) != 1:
        interface_findings.append("Only the transform function is supported in this stateless MVP")
    if transform_functions:
        function = transform_functions[0]
        args = function.args
        arg_names = [arg.arg for arg in args.args]
        if arg_names != ["X", "params"] or args.vararg or args.kwarg or args.kwonlyargs:
            interface_findings.append("transform must have exactly two positional arguments: X, params")
        if args.defaults or args.kw_defaults or function.decorator_list:
            interface_findings.append("transform defaults and decorators are not allowed")
        if any(arg.annotation is not None for arg in args.args) or function.returns is not None:
            interface_findings.append("transform annotations are not evaluated in this interface")
        if not function.body:
            interface_findings.append("transform body cannot be empty")

    syntax = CheckResult("source_syntax", "pass", "Python source parses")
    policy = CheckResult(
        "source_policy",
        "fail" if policy_findings else "pass",
        "; ".join(sorted(set(policy_findings))) if policy_findings else
        "AST imports, top-level declarations, and restricted-code checks passed",
    )
    interface = CheckResult(
        "interface_contract",
        "fail" if interface_findings else "pass",
        "; ".join(interface_findings) if interface_findings else
        "One stateless transform(X, params) function is present",
    )
    return syntax, policy, interface


def _load_transform_local(source: str) -> Callable[[np.ndarray, Mapping[str, Any]], Any]:
    checks = _source_checks(source)
    if any(check.status != "pass" for check in checks):
        raise AlgorithmOnboardingError("Source failed AST, restricted-code, or interface validation")
    namespace: dict[str, Any] = {
        "__builtins__": _restricted_builtins(),
        "__name__": "spectroease_onboarded_plugin",
    }
    exec(compile(source, "<onboarded-plugin>", "exec"), namespace, namespace)  # noqa: S102
    transform = namespace.get("transform")
    if not callable(transform):
        raise AlgorithmOnboardingError("transform is not callable after source loading")
    return transform


class _IsolatedTransform:
    """Own one spawned candidate process and terminate it on failure."""

    def __init__(self, source: str):
        from app.services.algorithm_onboarding_worker import run_candidate

        context = multiprocessing.get_context("spawn")
        self._connection, child_connection = context.Pipe(duplex=True)
        self._process = context.Process(
            target=run_candidate,
            args=(child_connection, source, MAX_WORKER_MESSAGE_BYTES),
            daemon=True,
        )
        self._cancelled = False
        self._deadline = time.monotonic() + VERIFICATION_BUDGET_SECONDS
        try:
            self._process.start()
            child_connection.close()
            response = self._receive(startup=True)
            if response.get("status") != "ready":
                raise AlgorithmOnboardingError(response.get("detail", "Candidate worker failed to start"))
        except BaseException:
            child_connection.close()
            self.close(force=True)
            raise

    def _receive(self, *, startup: bool = False) -> dict[str, Any]:
        remaining = min(8.0 if startup else WORKER_TIMEOUT_SECONDS, self._deadline - time.monotonic())
        if self._cancelled or remaining <= 0:
            self.close(force=True)
            raise AlgorithmOnboardingError("Candidate execution cancelled or exceeded its total time budget")
        if not self._connection.poll(remaining):
            self.close(force=True)
            raise AlgorithmOnboardingError("Candidate execution timed out")
        try:
            raw = self._connection.recv_bytes(MAX_WORKER_MESSAGE_BYTES)
            response = json.loads(raw.decode("utf-8"))
        except (EOFError, OSError, ValueError, UnicodeError) as exc:
            self.close(force=True)
            raise AlgorithmOnboardingError(f"Candidate worker exited or returned an invalid response: {exc}") from exc
        if not isinstance(response, dict):
            raise AlgorithmOnboardingError("Candidate worker returned an invalid response")
        return response

    def __call__(self, X: np.ndarray, parameters: Mapping[str, Any]) -> np.ndarray:
        if self._cancelled or not self._process.is_alive():
            raise AlgorithmOnboardingError("Candidate worker is not available")
        request = json.dumps({
            "op": "transform", "X": X.tolist(), "parameters": dict(parameters),
        }, allow_nan=False, separators=(",", ":")).encode("utf-8")
        if len(request) > MAX_WORKER_MESSAGE_BYTES:
            raise AlgorithmOnboardingError("Candidate input exceeds worker message size limit")
        try:
            self._connection.send_bytes(request)
            response = self._receive()
        except (OSError, EOFError) as exc:
            self.close(force=True)
            raise AlgorithmOnboardingError(f"Candidate worker communication failed: {exc}") from exc
        if response.get("status") != "ok":
            raise AlgorithmOnboardingError(response.get("detail", "Candidate worker failed"))
        return np.asarray(response["output"], dtype=float)

    def cancel(self) -> None:
        self._cancelled = True
        self.close(force=True)

    def close(self, *, force: bool = False) -> None:
        process = getattr(self, "_process", None)
        connection = getattr(self, "_connection", None)
        if process is not None and getattr(process, "_closed", False):
            return
        if process is not None:
            if process.is_alive():
                if force:
                    process.terminate()
                else:
                    try:
                        connection.send_bytes(b'{"op":"close"}')
                    except (OSError, EOFError):
                        process.terminate()
                process.join(timeout=0.5)
                if process.is_alive():
                    process.kill()
                    process.join(timeout=0.5)
            try:
                process.close()
            except (ValueError, OSError):
                pass
        if connection is not None:
            connection.close()


def _load_transform(source: str) -> _IsolatedTransform:
    checks = _source_checks(source)
    if any(check.status != "pass" for check in checks):
        raise AlgorithmOnboardingError("Source failed AST, restricted-code, or interface validation")
    return _IsolatedTransform(source)


def _run_transform(transform: Callable, X: np.ndarray, parameters: Mapping[str, Any]) -> tuple[np.ndarray | None, str]:
    supplied = np.array(X, dtype=float, copy=True)
    before = supplied.copy()
    try:
        raw = transform(supplied, dict(parameters))
        output = np.asarray(raw, dtype=float)
    except Exception as exc:
        return None, f"transform raised {type(exc).__name__}: {exc}"
    if not np.array_equal(supplied, before, equal_nan=True):
        return None, "transform modified its input array in place"
    if output.ndim != 2:
        return None, f"output must be two-dimensional, got ndim={output.ndim}"
    if output.shape != X.shape:
        return None, f"output shape {output.shape} does not match input shape {X.shape}"
    if not np.isfinite(output).all():
        return None, "output contains NaN or infinite values"
    return output.copy(), "output is numeric, finite, and preserves sample/channel shape"


def _dependency_versions(candidate: OnboardingCandidate) -> list[dict[str, str]]:
    packages = {"python": sys.version.split()[0], "numpy": np.__version__, "scipy": importlib.import_module("scipy").__version__}
    result = [{"name": name, "version": version} for name, version in sorted(packages.items())]
    for dependency in candidate.dependencies:
        name = str(dependency)
        try:
            version = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            version = "not-installed"
        result.append({"name": name, "version": version})
    return result


class AlgorithmOnboardingService:
    """Verify and register versioned, stateless spectral preprocessing code."""

    def __init__(self, storage_dir: str | os.PathLike | None = None):
        self.storage_dir = Path(storage_dir) if storage_dir is not None else _default_storage_dir()

    def verify_candidate(self, candidate: OnboardingCandidate | None = None, **kwargs) -> VerificationReport:
        if candidate is None:
            candidate = OnboardingCandidate(**kwargs)
        checks = list(_source_checks(candidate.python_source))

        try:
            schema = _normalize_schema(candidate.parameter_schema)
            effective = _effective_parameters(schema, candidate.parameters)
            checks.append(CheckResult("parameter_schema", "pass", f"{len(schema)} typed parameter(s) validated"))
        except Exception as exc:
            schema = {}
            effective = {}
            checks.append(CheckResult("parameter_schema", "fail", str(exc)))

        try:
            if (
                isinstance(candidate.rtol, bool)
                or isinstance(candidate.atol, bool)
                or not math.isfinite(float(candidate.rtol))
                or not math.isfinite(float(candidate.atol))
                or candidate.rtol < 0
                or candidate.atol < 0
            ):
                raise ValueError("rtol and atol must be finite, non-negative numbers")
            checks.append(CheckResult("tolerance_contract", "pass", f"rtol={candidate.rtol:g}, atol={candidate.atol:g}"))
        except Exception as exc:
            checks.append(CheckResult("tolerance_contract", "fail", str(exc)))

        if candidate.algorithm_category != "stateless_preprocessing":
            checks.append(CheckResult(
                "state_contract", "fail",
                "Only stateless per-spectrum preprocessing is enabled; fitted/stateful plugins are withheld",
            ))
        else:
            checks.append(CheckResult("state_contract", "pass", "Stateless per-spectrum preprocessing declared"))

        if not candidate.name.strip():
            checks.append(CheckResult("metadata", "fail", "A non-empty plugin name is required"))
        elif not candidate.original_r_source.strip():
            checks.append(CheckResult("metadata", "not_verified", "Original R source is required for provenance hashing"))
        else:
            checks.append(CheckResult("metadata", "pass", "Name and original R source are present"))

        try:
            X = _normalize_array(candidate.X, "X")
            if X.shape[0] < 1 or X.shape[1] < 1:
                raise ValueError("X must contain at least one sample and one channel")
            if X.shape[0] > MAX_VERIFICATION_ROWS:
                raise ValueError(f"Verification input may contain at most {MAX_VERIFICATION_ROWS} rows")
            checks.append(CheckResult("input_matrix", "pass", f"numeric finite matrix with shape {X.shape}; rows are samples"))
        except Exception as exc:
            X = np.empty((0, 0), dtype=float)
            checks.append(CheckResult("input_matrix", "fail", str(exc)))

        try:
            axis = _normalize_array(candidate.axis, "axis", ndim=1)
            if X.size == 0 or axis.shape[0] != X.shape[1]:
                raise ValueError("axis length must equal the spectral channel count")
            if not isinstance(candidate.axis_unit, str) or not candidate.axis_unit.strip():
                raise ValueError("axis_unit must be a non-empty string")
            checks.append(CheckResult(
                "axis_preservation", "pass",
                f"{axis.size} {candidate.axis_unit.strip()} coordinates align with unchanged channel order",
            ))
        except Exception as exc:
            axis = np.empty((0,), dtype=float)
            checks.append(CheckResult("axis_preservation", "fail", str(exc)))

        static_ok = all(item.status == "pass" for item in checks if item.name in {
            "source_syntax", "source_policy", "interface_contract", "parameter_schema",
            "tolerance_contract", "state_contract",
        })
        transform = None
        if static_ok and X.size:
            try:
                transform = _load_transform(candidate.python_source)
            except Exception as exc:
                checks.append(CheckResult("source_load", "fail", f"Could not load transform: {exc}"))
        else:
            checks.append(CheckResult("source_load", "not_verified", "Static or input contract checks did not pass"))

        if transform is not None:
            output, output_detail = _run_transform(transform, X, effective)
            if output is None:
                checks.append(CheckResult("numeric_shape_finiteness", "fail", output_detail))
            else:
                checks.append(CheckResult("numeric_shape_finiteness", "pass", output_detail))
                repeated, repeated_detail = _run_transform(transform, X, effective)
                if repeated is None:
                    checks.append(CheckResult("repeat_determinism", "fail", repeated_detail))
                elif not np.allclose(output, repeated, rtol=candidate.rtol, atol=candidate.atol):
                    checks.append(CheckResult("repeat_determinism", "fail", "Repeated identical call changed output"))
                else:
                    checks.append(CheckResult("repeat_determinism", "pass", "Repeated identical call produced concordant output"))

                # The transform receives spectra only; the axis is kept outside
                # the interface and must remain one-to-one with output columns.
                if axis.size == output.shape[1]:
                    checks.append(CheckResult("axis_output_alignment", "pass", "Output channel count preserves the supplied axis order"))
                else:
                    checks.append(CheckResult("axis_output_alignment", "fail", "Output channels no longer align with the supplied axis"))
        else:
            checks.extend([
                CheckResult("numeric_shape_finiteness", "not_verified", "Transform could not be executed"),
                CheckResult("repeat_determinism", "not_verified", "Transform could not be executed"),
                CheckResult("axis_output_alignment", "not_verified", "Transform could not be executed"),
            ])
            output = None

        examples = list(candidate.reference_examples or ())
        if not examples:
            checks.append(CheckResult("reference_concordance", "not_verified", "No trusted input/output reference examples were supplied"))
        elif transform is None:
            checks.append(CheckResult("reference_concordance", "not_verified", "Transform could not be executed"))
        else:
            reference_issues = []
            reference_count = 0
            for index, example in enumerate(examples):
                try:
                    ref_input = _normalize_array(example["input"], f"reference[{index}].input")
                    ref_expected = _normalize_array(example["expected"], f"reference[{index}].expected")
                    ref_params = _effective_parameters(schema, example.get("parameters", candidate.parameters))
                    if ref_expected.shape != ref_input.shape:
                        raise ValueError("expected reference output shape differs from its input")
                    actual, detail = _run_transform(transform, ref_input, ref_params)
                    if actual is None:
                        raise ValueError(detail)
                    if not math.isfinite(float(candidate.rtol)) or not math.isfinite(float(candidate.atol)) or candidate.rtol < 0 or candidate.atol < 0:
                        raise ValueError("reference tolerances must be finite and non-negative")
                    if not np.allclose(actual, ref_expected, rtol=candidate.rtol, atol=candidate.atol):
                        max_error = float(np.max(np.abs(actual - ref_expected)))
                        raise ValueError(f"reference output exceeded tolerance (max_abs_error={max_error:g})")
                    reference_count += 1
                except Exception as exc:
                    reference_issues.append(f"fixture {index}: {exc}")
            checks.append(CheckResult(
                "reference_concordance",
                "fail" if reference_issues else "pass",
                "; ".join(reference_issues) if reference_issues else
                f"{reference_count} supplied trusted fixture(s) met rtol={candidate.rtol:g}, atol={candidate.atol:g}",
            ))

        if transform is None or output is None:
            checks.append(CheckResult("row_independence", "not_verified", "Transform output was not available"))
        elif X.shape[0] < 2:
            checks.append(CheckResult("row_independence", "not_verified", "At least two samples are required for perturbation testing"))
        else:
            row_issues = []
            for target_row in range(X.shape[0]):
                perturbed = X.copy()
                for other_row in range(X.shape[0]):
                    if other_row != target_row:
                        perturbed[other_row] = perturbed[other_row] * 1.731 + 0.291 + other_row * 0.037
                perturbed_output, detail = _run_transform(transform, perturbed, effective)
                if perturbed_output is None:
                    row_issues.append(f"perturbed batch: {detail}")
                    break
                if not np.allclose(
                    output[target_row], perturbed_output[target_row],
                    rtol=candidate.rtol, atol=candidate.atol,
                ):
                    row_issues.append(f"sample row {target_row} changed when unrelated rows were perturbed")
                    break
            checks.append(CheckResult(
                "row_independence", "fail" if row_issues else "pass",
                "; ".join(row_issues) if row_issues else
                f"All {X.shape[0]} queried rows were invariant to deterministic changes in other rows",
            ))

        if transform is not None:
            transform.close()
        return VerificationReport(candidate=candidate, checks=tuple(checks))

    def verify_with_repairs(
        self,
        candidate: OnboardingCandidate,
        repair_callback: Callable[[str, tuple[CheckResult, ...], int], str | None] | None = None,
        *,
        max_repairs: int = MAX_REPAIR_ROUNDS,
    ) -> VerificationReport:
        """Run one initial candidate and at most three explicit repair rounds.

        The callback is a caller-supplied model/repair hook. This service does
        not contact an LLM or claim a live-model benchmark.
        """
        if not isinstance(max_repairs, int) or not 0 <= max_repairs <= MAX_REPAIR_ROUNDS:
            raise ValueError(f"max_repairs must be between 0 and {MAX_REPAIR_ROUNDS}")
        current = candidate
        attempts: list[AttemptRecord] = []
        repairs: list[RepairRecord] = []
        for index in range(max_repairs + 1):
            report = self.verify_candidate(current)
            passed = report.passed
            attempts.append(AttemptRecord(index + 1, report.source_sha256, passed, report.checks))
            if passed or index >= max_repairs or repair_callback is None:
                break
            try:
                repaired_source = repair_callback(current.python_source, report.checks, index + 1)
            except Exception as exc:
                repairs.append(RepairRecord(index + 1, report.source_sha256, None, "callback_error", f"{type(exc).__name__}: {exc}"))
                break
            if repaired_source is None:
                repairs.append(RepairRecord(index + 1, report.source_sha256, None, "no_candidate", "Repair callback returned no source"))
                break
            if not isinstance(repaired_source, str):
                repairs.append(RepairRecord(index + 1, report.source_sha256, None, "invalid_candidate", "Repair callback must return Python source text or None"))
                break
            repairs.append(RepairRecord(
                index + 1, report.source_sha256, _sha256_text(repaired_source), "candidate", "Repair source recorded for full revalidation",
            ))
            current = replace(current, python_source=repaired_source)
        final = self.verify_candidate(current)
        return replace(final, attempts=tuple(attempts), repairs=tuple(repairs))

    def accept_candidate(
        self,
        report: VerificationReport,
        *,
        edited_python_source: str,
        user_confirmed: bool,
    ) -> str:
        """Revalidate exact editor text, persist/reload, then register on consent."""
        if not user_confirmed:
            raise AlgorithmOnboardingError("Explicit user confirmation is required before registration")
        if edited_python_source != report.candidate.python_source:
            raise AlgorithmOnboardingError("Editor source changed after verification; verify the exact edited source again")
        final_check = self.verify_candidate(replace(report.candidate, python_source=edited_python_source))
        if not final_check.passed:
            raise AlgorithmOnboardingError("Exact edited source did not pass revalidation")
        final_check = replace(final_check, attempts=report.attempts, repairs=report.repairs)

        source_hash = _sha256_text(edited_python_source)
        slug = re.sub(r"[^a-zA-Z0-9]+", "_", report.candidate.name).strip("_").lower() or "plugin"
        candidate_id = f"{slug}_{source_hash[:12]}"
        record_dir = self.storage_dir / candidate_id
        record_path = record_dir / "plugin.json"
        accepted_at = datetime.now(timezone.utc).isoformat()
        candidate_payload = _candidate_to_json(final_check.candidate)
        source_hash = _sha256_text(candidate_payload["python_source"])
        schema_hash = _sha256_json(candidate_payload["parameter_schema"])
        fixture_hash = _sha256_json(candidate_payload["reference_examples"])
        original_r_hash = _sha256_text(candidate_payload["original_r_source"])
        base_checks = [asdict(item) for item in final_check.checks]
        record = {
            "record_schema_version": RECORD_SCHEMA_VERSION,
            "candidate_id": candidate_id,
            "accepted": True,
            "accepted_at_utc": accepted_at,
            "application_version": APP_VERSION,
            "application_version_source": APP_VERSION_SOURCE,
            "protocol": PROTOCOL,
            "validator_version": VALIDATOR_VERSION,
            "candidate": candidate_payload,
            "hashes": {
                "original_r_source_sha256": original_r_hash,
                "generated_python_sha256": source_hash,
                "parameter_schema_sha256": schema_hash,
                "parameters_sha256": _sha256_json(candidate_payload["parameters"]),
                "reference_fixtures_sha256": fixture_hash,
            },
            "dependencies": _dependency_versions(final_check.candidate),
            "tolerances": {"rtol": final_check.candidate.rtol, "atol": final_check.candidate.atol},
            "check_outcomes": base_checks + [{
                "name": "persistence_reload", "status": "pass",
                "details": "Revalidated from persisted JSON by a fresh service instance before registry exposure",
            }],
            "repair_count": len(final_check.repairs),
            "attempts": [
                {
                    "attempt": item.attempt,
                    "source_sha256": item.source_sha256,
                    "passed": item.passed,
                    "checks": [asdict(check) for check in item.checks],
                }
                for item in final_check.attempts
            ],
            "repairs": [asdict(item) for item in final_check.repairs],
        }
        record["manifest_sha256"] = self._manifest_hash(record)

        try:
            self._write_record(record_path, record)
            fresh_service = type(self)(self.storage_dir)
            reloaded = fresh_service._load_record(candidate_id, allow_pending=False)
            if not reloaded["report"].passed:
                raise AlgorithmOnboardingError("Fresh-instance persistence revalidation failed")
            persisted_check = next(
                (item for item in record["check_outcomes"] if item["name"] == "persistence_reload"), None,
            )
            if not persisted_check or persisted_check["status"] != "pass":
                raise AlgorithmOnboardingError("Persistence reload outcome is not recorded as passing")
            fresh_service._register_candidate(reloaded["candidate"], candidate_id)
        except Exception:
            try:
                record_path.unlink(missing_ok=True)
                record_dir.rmdir()
            except OSError:
                pass
            raise
        return candidate_id

    @staticmethod
    def _manifest_hash(record: Mapping[str, Any]) -> str:
        payload = {key: value for key, value in record.items() if key != "manifest_sha256"}
        return _sha256_json(payload)

    @staticmethod
    def _write_record(path: Path, record: Mapping[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary = tempfile.mkstemp(prefix="plugin-", suffix=".tmp", dir=path.parent)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
                json.dump(record, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
                stream.write("\n")
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def _load_record(self, candidate_id: str, *, allow_pending: bool = False) -> dict[str, Any]:
        record_path = self.storage_dir / candidate_id / "plugin.json"
        with record_path.open("r", encoding="utf-8") as stream:
            record = json.load(stream)
        if not isinstance(record, dict):
            raise AlgorithmOnboardingError("Persisted plugin record root must be a JSON object")
        if record.get("candidate_id") != candidate_id:
            raise AlgorithmOnboardingError("Persisted candidate ID does not match its directory")
        if not allow_pending and (not record.get("accepted") or not record.get("accepted_at_utc")):
            raise AlgorithmOnboardingError("Persisted record is not explicitly accepted")
        if record.get("record_schema_version") != RECORD_SCHEMA_VERSION:
            raise AlgorithmOnboardingError("Unsupported persisted record schema version")
        if record.get("protocol") != PROTOCOL:
            raise AlgorithmOnboardingError("Unsupported persisted plugin protocol")
        if record.get("validator_version") != VALIDATOR_VERSION:
            raise AlgorithmOnboardingError("Unsupported persisted validator version")
        if record.get("manifest_sha256") != self._manifest_hash(record):
            raise AlgorithmOnboardingError("Persisted manifest hash mismatch")

        candidate_data = record.get("candidate", {})
        hashes = record.get("hashes", {})
        expected_hashes = {
            "original_r_source_sha256": _sha256_text(candidate_data.get("original_r_source", "")),
            "generated_python_sha256": _sha256_text(candidate_data.get("python_source", "")),
            "parameter_schema_sha256": _sha256_json(candidate_data.get("parameter_schema", {})),
            "parameters_sha256": _sha256_json(candidate_data.get("parameters", {})),
            "reference_fixtures_sha256": _sha256_json(candidate_data.get("reference_examples", [])),
        }
        if hashes != expected_hashes:
            raise AlgorithmOnboardingError("Persisted source/schema/reference hash mismatch")
        name_slug = re.sub(r"[^a-zA-Z0-9]+", "_", candidate_data.get("name", "")).strip("_").lower() or "plugin"
        if candidate_id != f"{name_slug}_{expected_hashes['generated_python_sha256'][:12]}":
            raise AlgorithmOnboardingError("Persisted plugin identity does not match its name/source hash")

        candidate = _candidate_from_json(candidate_data)
        report = self.verify_candidate(candidate)
        if not report.passed:
            failures = [f"{item.name}: {item.status} ({item.details})" for item in report.checks if item.status != "pass"]
            raise AlgorithmOnboardingError("Persisted candidate failed revalidation: " + "; ".join(failures))
        stored_outcomes = record.get("check_outcomes", [])
        stored_base_checks = [item for item in stored_outcomes if item.get("name") != "persistence_reload"]
        actual_checks = [asdict(item) for item in report.checks]
        if stored_base_checks != actual_checks:
            raise AlgorithmOnboardingError("Persisted validation check outcomes differ from fresh revalidation")
        stored_persistence = next(
            (item for item in stored_outcomes if item.get("name") == "persistence_reload"), None,
        )
        if not stored_persistence or stored_persistence.get("status") != "pass":
            raise AlgorithmOnboardingError("Persisted record lacks a passing fresh-instance reload check")
        return {"candidate": candidate, "report": report, "record": record}

    def load_accepted_candidate(self, candidate_id: str, *, register: bool = True) -> VerificationReport:
        """Reload and revalidate an accepted plugin before exposing it again."""
        loaded = self._load_record(candidate_id)
        if register:
            self._register_candidate(loaded["candidate"], candidate_id)
        return loaded["report"]

    def disable_plugin(self, candidate_id: str) -> bool:
        """Remove a plugin from the in-memory preprocessing registry only."""
        return unregister_plugin(candidate_id)

    def remove_plugin_record(self, candidate_id: str, *, user_confirmed: bool) -> bool:
        """Disable and delete an accepted plugin record after explicit consent."""
        if not user_confirmed:
            raise AlgorithmOnboardingError("Explicit confirmation is required to remove a plugin record")
        self.disable_plugin(candidate_id)
        path = self.storage_dir / candidate_id / "plugin.json"
        if not path.exists():
            return False
        path.unlink()
        try:
            path.parent.rmdir()
        except OSError:
            pass
        return True

    @staticmethod
    def _register_candidate(candidate: OnboardingCandidate, candidate_id: str) -> None:
        """Register a DataFrame adapter using the existing plugin dispatcher."""
        source = candidate.python_source
        schema = _normalize_schema(candidate.parameter_schema)

        def apply_spectral_plugin(data: pd.DataFrame, **params) -> pd.DataFrame:
            values = _effective_parameters(schema, params)
            transform = _load_transform(source)
            try:
                input_array = np.asarray(data.to_numpy(), dtype=float)
                output, details = _run_transform(transform, input_array, values)
            finally:
                transform.close()
            if output is None:
                raise AlgorithmOnboardingError(details)
            return pd.DataFrame(output, index=data.index.copy(), columns=data.columns.copy())

        register_plugin(
            candidate_id,
            display_name=candidate.name,
            category="plugin",
            quality="verified-stateless",
        )(apply_spectral_plugin)
