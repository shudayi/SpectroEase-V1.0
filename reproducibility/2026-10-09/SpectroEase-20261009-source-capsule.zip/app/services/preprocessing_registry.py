# app/services/preprocessing_registry.py
"""Preprocessing method registry.

Centralizes the canonical list of preprocessing methods so the dispatcher
in ``PreprocessingService`` is data-driven instead of a long if/elif chain.
Each entry maps a stable ``key`` (the string the UI uses) to:

- ``callable``: ``f(data, **params) -> DataFrame``
- ``display_name``: human-readable label for UI ComboBoxes
- ``category``: ``'baseline' | 'smoothing' | 'scatter' | 'normalization' | 'derivative' | 'cleaning' | 'alignment'``
- ``quality``: ``'real' | 'approx' | 'stub'`` — implementation fidelity marker
- ``params``: list of accepted parameter names

Plugin methods registered via ``register_plugin`` are still supported and
take precedence over built-ins with the same key.
"""

from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

import pandas as pd


@dataclass(frozen=True)
class PreprocessingEntry:
    key: str
    display_name: str
    category: str
    callable: Callable[..., pd.DataFrame]
    quality: str = 'real'
    params: tuple = field(default_factory=tuple)


_ENTRIES: Dict[str, PreprocessingEntry] = {}
_PLUGIN_ENTRIES: Dict[str, PreprocessingEntry] = {}


def _signature_params(func: Callable) -> tuple:
    """Return the named parameters of ``func`` (excluding ``data`` / ``self``)."""
    try:
        sig = inspect.signature(func)
    except (TypeError, ValueError):
        return ()
    params = []
    for name, param in sig.parameters.items():
        if name in ('data', 'self') or name.startswith('_'):
            continue
        if param.kind in (inspect.Parameter.VAR_POSITIONAL,
                          inspect.Parameter.VAR_KEYWORD,
                          inspect.Parameter.POSITIONAL_ONLY):
            continue
        params.append(name)
    return tuple(params)


def register(key: str, *, display_name: Optional[str] = None,
             category: str = 'general', quality: str = 'real') -> Callable:
    """Decorator: register a preprocessing function under ``key``."""
    def decorator(func: Callable[..., pd.DataFrame]) -> Callable:
        entry = PreprocessingEntry(
            key=key,
            display_name=display_name or key,
            category=category,
            callable=func,
            quality=quality,
            params=_signature_params(func),
        )
        _ENTRIES[key] = entry
        return func
    return decorator


def register_plugin(key: str, *, display_name: Optional[str] = None,
                    category: str = 'plugin', quality: str = 'plugin') -> Callable:
    """Decorator for plugin-provided preprocessing methods."""
    def decorator(func: Callable[..., pd.DataFrame]) -> Callable:
        entry = PreprocessingEntry(
            key=key,
            display_name=display_name or key,
            category=category,
            callable=func,
            quality=quality,
            params=_signature_params(func),
        )
        _PLUGIN_ENTRIES[key] = entry
        return func
    return decorator


def unregister_plugin(key: str) -> bool:
    """Remove one in-memory plugin entry without affecting built-ins."""
    return _PLUGIN_ENTRIES.pop(key, None) is not None


def get_entry(key: str) -> Optional[PreprocessingEntry]:
    """Plugin entries shadow built-ins."""
    if key in _PLUGIN_ENTRIES:
        return _PLUGIN_ENTRIES[key]
    return _ENTRIES.get(key)


def list_entries(category: Optional[str] = None,
                 include_plugins: bool = True) -> List[PreprocessingEntry]:
    """Return all known entries; optionally filtered by category."""
    merged: Dict[str, PreprocessingEntry] = dict(_ENTRIES)
    if include_plugins:
        merged.update(_PLUGIN_ENTRIES)
    if category is not None:
        merged = {k: v for k, v in merged.items() if v.category == category}
    return list(merged.values())


def reset() -> None:
    """Drop all registered entries (testing only)."""
    _ENTRIES.clear()
    _PLUGIN_ENTRIES.clear()
