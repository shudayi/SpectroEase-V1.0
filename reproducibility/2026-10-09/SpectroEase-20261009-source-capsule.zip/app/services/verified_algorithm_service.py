"""Verification and persistence core for trusted fitted spectral algorithms.

The first supported contracts are fitted preprocessing, feature selection,
classification, regression and metrics. This module does not register into the
existing GUI. Candidates execute in bounded child processes for reliability,
but this is not an OS security sandbox for untrusted code.
"""

from __future__ import annotations

import ast
import copy
import hashlib
import json
import math
import multiprocessing
import os
import re
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

import numpy as np

from app.services.algorithm_onboarding_service import (
    _ALLOWED_IMPORT_ROOTS, _SIDE_EFFECT_CALLS, _effective_parameters,
    _normalize_schema, _restricted_builtins,
)
from app.utils.code_sandbox import DANGEROUS_ATTRIBUTES, DANGEROUS_CALLS, validate_code


VALIDATOR_VERSION = "s26-full-workflow-core-v1"
SCHEMA_VERSION = 1
KINDS = frozenset({"stateful_preprocessing", "feature_selection", "classification", "regression", "metric"})
MAX_SOURCE_BYTES = 256 * 1024
MAX_MESSAGE_BYTES = 8 * 1024 * 1024
MAX_ROWS = 128
MAX_FEATURES = 4096
JOB_TIMEOUT_SECONDS = 8.0


class VerifiedAlgorithmError(ValueError):
    """A candidate or persisted record did not satisfy its contract."""


@dataclass(frozen=True)
class Candidate:
    kind: str
    name: str
    python_source: str
    parameter_schema: Mapping[str, Any]
    parameters: Mapping[str, Any]
    train_X: Any
    probe_X: Any
    reference_output: Any
    train_y: Any = None
    probe_y: Any = None  # metric only: y_true; probe_X is y_pred
    axis: Any = None
    rtol: float = 1e-5
    atol: float = 1e-8


@dataclass(frozen=True)
class Check:
    name: str
    passed: bool
    detail: str


@dataclass(frozen=True)
class Report:
    candidate: Candidate
    checks: tuple[Check, ...]
    validator_version: str = VALIDATOR_VERSION

    @property
    def passed(self) -> bool:
        return bool(self.checks) and all(check.passed for check in self.checks)

    @property
    def source_sha256(self) -> str:
        return _hash_text(self.candidate.python_source)


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def _hash_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _json_safe(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        value = value.tolist()
    elif isinstance(value, np.generic):
        value = value.item()
    elif isinstance(value, Mapping):
        value = {str(k): _json_safe(v) for k, v in value.items()}
    elif isinstance(value, (list, tuple)):
        value = [_json_safe(v) for v in value]
    try:
        _canonical(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise VerifiedAlgorithmError("Candidate state/output must be finite JSON data") from exc
    return value


def _source_checks(source: str, kind: str) -> tuple[Check, ...]:
    if not isinstance(source, str) or len(source.encode("utf-8")) > MAX_SOURCE_BYTES:
        return (Check("source", False, "Source must be UTF-8 under 256 KiB"),)
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        return (Check("syntax", False, str(exc)),)
    errors = list(validate_code(source))
    required = ("score",) if kind == "metric" else ("fit", "predict" if kind in {"classification", "regression"} else "transform")
    functions = [n for n in tree.body if isinstance(n, ast.FunctionDef)]
    if sorted(n.name for n in functions) != sorted(required):
        errors.append(f"Exactly the module-level functions {required!r} are required")
    names = {"fit": ["X", "y", "params"], "transform": ["X", "state", "params"],
             "predict": ["X", "state", "params"], "score": ["y_true", "y_pred", "params"]}
    for fn in functions:
        args = fn.args
        if [a.arg for a in args.args] != names.get(fn.name) or args.vararg or args.kwarg or args.kwonlyargs or args.defaults or args.kw_defaults or fn.decorator_list:
            errors.append(f"Invalid signature or defaults/decorators for {fn.name}")
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            roots = [a.name.split(".", 1)[0] for a in node.names] if isinstance(node, ast.Import) else [(node.module or "").split(".", 1)[0]]
            if any(root not in _ALLOWED_IMPORT_ROOTS for root in roots):
                errors.append("Unsupported import root")
            if isinstance(node, ast.ImportFrom) and any(a.name in _SIDE_EFFECT_CALLS for a in node.names):
                errors.append("Side-effecting imported function")
        elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            pass
        elif not isinstance(node, ast.FunctionDef):
            errors.append("Only imports, functions and module docstring are allowed at top level")
    for node in ast.walk(tree):
        if isinstance(node, (ast.Global, ast.Nonlocal)):
            errors.append("Global state mutation is disallowed")
        if isinstance(node, ast.Import) and node not in tree.body or isinstance(node, ast.ImportFrom) and node not in tree.body:
            errors.append("Imports must be module-level")
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in DANGEROUS_CALLS:
                errors.append("Dangerous call")
            if isinstance(node.func, ast.Attribute) and node.func.attr in DANGEROUS_ATTRIBUTES:
                errors.append("Dangerous attribute call")
        if isinstance(node, ast.Attribute) and (node.attr in _SIDE_EFFECT_CALLS or node.attr.startswith("__") or node.attr.endswith("__")):
            errors.append("Side-effect/dunder attribute")
    return (Check("source_contract", not errors, "; ".join(sorted(set(errors))) or "AST and interface checks passed"),)


def _load_functions_local(source: str) -> dict[str, Any]:
    # Parent checks candidate kind and signatures before process creation. Child
    # retains the AST policy as a second line of defense against stale input.
    namespace: dict[str, Any] = {"__builtins__": _restricted_builtins(), "__name__": "verified_algorithm"}
    exec(compile(source, "<verified-algorithm>", "exec"), namespace, namespace)  # noqa: S102
    return namespace


def _run_local_operation(functions: dict[str, Any], operation: str, payload: dict) -> Any:
    params = payload["parameters"]
    if operation == "fit":
        X = np.asarray(payload["X"], dtype=float)
        y = None if payload.get("y") is None else np.asarray(payload["y"])
        return _json_safe(functions["fit"](X, y, params))
    if operation in {"transform", "predict"}:
        X = np.asarray(payload["X"], dtype=float)
        return _json_safe(functions[operation](X, payload["state"], params))
    if operation == "score":
        return _json_safe(functions["score"](np.asarray(payload["y_true"]), np.asarray(payload["y_pred"]), params))
    raise VerifiedAlgorithmError("Unknown candidate operation")


def _job(source: str, operation: str, payload: dict) -> Any:
    from app.services.verified_algorithm_worker import run_job

    encoded = _canonical(payload).encode("utf-8")
    if len(encoded) > MAX_MESSAGE_BYTES:
        raise VerifiedAlgorithmError("Candidate request exceeds message budget")
    context = multiprocessing.get_context("spawn")
    parent, child = context.Pipe(duplex=False)
    process = context.Process(target=run_job, args=(child, source, operation, payload, MAX_MESSAGE_BYTES), daemon=True)
    try:
        process.start()
        child.close()
        if not parent.poll(JOB_TIMEOUT_SECONDS):
            raise VerifiedAlgorithmError("Candidate execution timed out")
        raw = parent.recv_bytes(MAX_MESSAGE_BYTES)
        result = json.loads(raw.decode("utf-8"))
        if not result.get("ok"):
            raise VerifiedAlgorithmError(result.get("error", "Candidate failed"))
        return result["result"]
    except (EOFError, OSError, ValueError) as exc:
        if isinstance(exc, VerifiedAlgorithmError):
            raise
        raise VerifiedAlgorithmError(f"Candidate process failed: {exc}") from exc
    finally:
        if process.is_alive():
            process.terminate()
        process.join(timeout=0.5)
        if process.is_alive():
            process.kill()
            process.join(timeout=0.5)
        process.close()
        parent.close()
        child.close()


def _matrix(value: Any, name: str, *, expected_features: int | None = None, max_rows: int | None = MAX_ROWS) -> np.ndarray:
    X = np.asarray(value, dtype=float)
    if X.ndim != 2 or (X.shape[0] < 1 or (max_rows is not None and X.shape[0] > max_rows)) or not 1 <= X.shape[1] <= MAX_FEATURES or not np.isfinite(X).all():
        raise VerifiedAlgorithmError(f"{name} must be a finite bounded 2D matrix")
    if expected_features is not None and X.shape[1] != expected_features:
        raise VerifiedAlgorithmError(f"{name} feature count differs from training input")
    return X


def _reference_equal(output: Any, reference: Any, rtol: float, atol: float, kind: str) -> bool:
    if kind == "classification":
        return np.array_equal(np.asarray(output).reshape(-1), np.asarray(reference).reshape(-1))
    try:
        a, b = np.asarray(output, dtype=float), np.asarray(reference, dtype=float)
        return a.shape == b.shape and np.isfinite(a).all() and np.isfinite(b).all() and bool(np.allclose(a, b, rtol=rtol, atol=atol))
    except (TypeError, ValueError):
        return False


class VerifiedAlgorithmService:
    """Backend-only candidate verification, acceptance and fitted execution."""

    def __init__(self, storage_dir: str | Path):
        self.storage_dir = Path(storage_dir).expanduser().resolve()
        self._verification_cache = {}

    def verify(self, candidate: Candidate) -> Report:
        checks: list[Check] = []
        try:
            if candidate.kind not in KINDS:
                raise VerifiedAlgorithmError("Unsupported algorithm kind")
            if not isinstance(candidate.name, str) or not candidate.name.strip() or len(candidate.name) > 100:
                raise VerifiedAlgorithmError("Invalid candidate name")
            checks.extend(_source_checks(candidate.python_source, candidate.kind))
            if not all(c.passed for c in checks):
                return Report(candidate, tuple(checks))
            params = _effective_parameters(_normalize_schema(candidate.parameter_schema), candidate.parameters)
            if not math.isfinite(candidate.rtol) or not math.isfinite(candidate.atol) or candidate.rtol < 0 or candidate.atol < 0:
                raise VerifiedAlgorithmError("Invalid numeric tolerance")
            checks.append(Check("parameters", True, "Typed parameters accepted"))
            if candidate.kind == "metric":
                truth = np.asarray(candidate.probe_y)
                pred = np.asarray(candidate.probe_X)
                if truth.ndim != 1 or pred.shape != truth.shape or not 1 <= len(truth) <= MAX_ROWS:
                    raise VerifiedAlgorithmError("Metric truth and prediction must be aligned 1D arrays")
                output = _job(candidate.python_source, "score", {"y_true": _json_safe(truth), "y_pred": _json_safe(pred), "parameters": params})
                if not isinstance(output, (int, float)) or isinstance(output, bool) or not math.isfinite(output):
                    raise VerifiedAlgorithmError("Metric must return one finite scalar")
                checks.append(Check("numeric_reference", _reference_equal(output, candidate.reference_output, candidate.rtol, candidate.atol, candidate.kind), "Independent metric reference"))
            else:
                train = _matrix(candidate.train_X, "train_X")
                probe = _matrix(candidate.probe_X, "probe_X", expected_features=train.shape[1])
                if candidate.axis is not None and len(candidate.axis) != train.shape[1]:
                    raise VerifiedAlgorithmError("Spectral axis length differs from features")
                y = None if candidate.train_y is None else np.asarray(candidate.train_y)
                if candidate.kind in {"classification", "regression"} and (y is None or y.ndim != 1 or y.shape[0] != train.shape[0]):
                    raise VerifiedAlgorithmError("Model requires one aligned training target per row")
                state = _job(candidate.python_source, "fit", {"X": train.tolist(), "y": None if y is None else _json_safe(y), "parameters": params})
                if not isinstance(state, dict):
                    raise VerifiedAlgorithmError("fit must return a JSON-safe state mapping")
                checks.append(Check("fitted_state", True, "Training state is finite JSON"))
                op = "predict" if candidate.kind in {"classification", "regression"} else "transform"
                payload = {"X": probe.tolist(), "state": state, "parameters": params}
                output = _job(candidate.python_source, op, payload)
                result = np.asarray(output)
                if result.ndim != (1 if op == "predict" else 2) or result.shape[0] != probe.shape[0]:
                    raise VerifiedAlgorithmError("Output has wrong row count or rank")
                if candidate.kind == "stateful_preprocessing" and result.shape[1] != probe.shape[1]:
                    raise VerifiedAlgorithmError("Preprocessing must preserve spectral dimension")
                if candidate.kind == "feature_selection":
                    selected = state.get("indices")
                    output_axis = state.get("output_axis")
                    if selected is None and output_axis is None:
                        raise VerifiedAlgorithmError("Feature state requires indices or output_axis mapping")
                    if selected is not None:
                        if (not isinstance(selected, list) or len(selected) != result.shape[1]
                                or any(type(i) is not int or i < 0 or i >= train.shape[1] for i in selected)
                                or len(set(selected)) != len(selected)):
                            raise VerifiedAlgorithmError("Feature indices must be unique, valid and match output columns")
                        if not np.allclose(np.asarray(result, dtype=float), probe[:, selected], rtol=candidate.rtol, atol=candidate.atol):
                            raise VerifiedAlgorithmError("Feature output does not match declared indices")
                    if output_axis is not None and (not isinstance(output_axis, list) or len(output_axis) != result.shape[1]):
                        raise VerifiedAlgorithmError("Feature output_axis must match output columns")
                if candidate.kind in {"regression", "stateful_preprocessing", "feature_selection"} and not np.isfinite(result.astype(float)).all():
                    raise VerifiedAlgorithmError("Output contains nonfinite numeric values")
                checks.append(Check("output_contract", True, "Output rank, rows and finite values accepted"))
                checks.append(Check("numeric_reference", _reference_equal(output, candidate.reference_output, candidate.rtol, candidate.atol, candidate.kind), "Independent reference output"))
                replay = _job(candidate.python_source, op, json.loads(_canonical(payload)))
                checks.append(Check("state_replay", _reference_equal(replay, output, 0, 0, candidate.kind), "Serialized state replay"))
                if probe.shape[0] > 1:
                    perturbed = probe.copy()
                    perturbed[1:] += 3.25
                    isolated = _job(candidate.python_source, op, {"X": perturbed.tolist(), "state": state, "parameters": params})
                    checks.append(Check("row_invariance", _reference_equal(np.asarray(isolated)[0], result[0], candidate.rtol, candidate.atol, candidate.kind), "Fixed row with other prediction rows changed"))
        except (VerifiedAlgorithmError, TypeError, ValueError, OverflowError) as exc:
            checks.append(Check("contract", False, str(exc)))
        return Report(candidate, tuple(checks))

    def accept(self, report: Report, edited_python_source: str, *, user_confirmed: bool) -> str:
        if not user_confirmed or not report.passed or edited_python_source != report.candidate.python_source:
            raise VerifiedAlgorithmError("Explicit acceptance of the exact verified source is required")
        if _hash_text(edited_python_source) != report.source_sha256 or not self.verify(report.candidate).passed:
            raise VerifiedAlgorithmError("Candidate changed or failed re-verification")
        candidate = report.candidate
        candidate_id = re.sub(r"[^a-z0-9]+", "-", candidate.name.lower()).strip("-")[:40] + "-" + _hash_text(_canonical(_json_safe(asdict(candidate))))[:12]
        if not candidate_id.strip("-"):
            raise VerifiedAlgorithmError("Invalid candidate ID")
        record = {
            "schema_version": SCHEMA_VERSION, "validator_version": VALIDATOR_VERSION,
            "candidate_id": candidate_id, "kind": candidate.kind,
            "source_sha256": report.source_sha256,
            "schema_sha256": _hash_text(_canonical(_json_safe(candidate.parameter_schema))),
            "configuration_sha256": _hash_text(_canonical(_json_safe(asdict(candidate)))),
            "fixture_sha256": _hash_text(_canonical(_json_safe({"train_X": candidate.train_X, "train_y": candidate.train_y, "probe_X": candidate.probe_X, "probe_y": candidate.probe_y, "reference_output": candidate.reference_output}))),
            "candidate": _json_safe(asdict(candidate)),
            "checks": [asdict(c) for c in report.checks],
            "accepted": True,
        }
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        path = self.storage_dir / f"{candidate_id}.json"
        fd, temporary = tempfile.mkstemp(prefix=".candidate-", suffix=".json", dir=self.storage_dir)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(record, stream, ensure_ascii=False, sort_keys=True, allow_nan=False)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        persisted = path.read_bytes()
        if json.loads(persisted.decode("utf-8")) == record:
            self._verification_cache[candidate_id] = (hashlib.sha256(persisted).hexdigest(), VALIDATOR_VERSION, copy.deepcopy(candidate))
        return candidate_id

    def clear_verification_cache(self) -> None:
        """Request full verification on the next access to each accepted record."""
        self._verification_cache.clear()

    def reload(self, candidate_id: str, *, force_verify: bool = False) -> Candidate:
        if not re.fullmatch(r"[a-z0-9-]{1,64}", candidate_id):
            raise VerifiedAlgorithmError("Invalid candidate ID")
        path = self.storage_dir / f"{candidate_id}.json"
        try:
            persisted = path.read_bytes()
            digest = hashlib.sha256(persisted).hexdigest()
            cached = self._verification_cache.get(candidate_id)
            if not force_verify and cached and cached[:2] == (digest, VALIDATOR_VERSION):
                return copy.deepcopy(cached[2])
            self._verification_cache.pop(candidate_id, None)
            record = json.loads(persisted.decode("utf-8"))
            candidate = Candidate(**record["candidate"])
        except (OSError, ValueError, TypeError, KeyError) as exc:
            raise VerifiedAlgorithmError("Stored candidate is missing or invalid") from exc
        if record.get("candidate_id") != candidate_id or record.get("schema_version") != SCHEMA_VERSION or record.get("validator_version") != VALIDATOR_VERSION or record.get("source_sha256") != _hash_text(candidate.python_source) or record.get("schema_sha256") != _hash_text(_canonical(_json_safe(candidate.parameter_schema))) or not record.get("accepted"):
            raise VerifiedAlgorithmError("Stored candidate version or hash mismatch")
        if record.get("fixture_sha256") != _hash_text(_canonical(_json_safe({"train_X": candidate.train_X, "train_y": candidate.train_y, "probe_X": candidate.probe_X, "probe_y": candidate.probe_y, "reference_output": candidate.reference_output}))):
            raise VerifiedAlgorithmError("Stored reference fixture changed")
        if record.get("configuration_sha256") != _hash_text(_canonical(_json_safe(asdict(candidate)))):
            raise VerifiedAlgorithmError("Stored candidate configuration changed")
        if not self.verify(candidate).passed:
            raise VerifiedAlgorithmError("Stored candidate failed re-verification")
        self._verification_cache[candidate_id] = (digest, VALIDATOR_VERSION, copy.deepcopy(candidate))
        return copy.deepcopy(candidate)

    def list_accepted(self, kind: str | None = None) -> list[str]:
        if kind is not None and kind not in KINDS:
            raise VerifiedAlgorithmError("Unknown algorithm kind")
        if not self.storage_dir.is_dir():
            return []
        result = []
        for path in sorted(self.storage_dir.glob("*.json")):
            try:
                candidate = self.reload(path.stem)
            except VerifiedAlgorithmError:
                continue
            if kind is None or candidate.kind == kind:
                result.append(path.stem)
        return result

    def fit(self, candidate_id: str, X: Any, y: Any = None) -> dict[str, Any]:
        candidate = self.reload(candidate_id)
        if candidate.kind == "metric":
            raise VerifiedAlgorithmError("Metric has no fit state")
        matrix = _matrix(X, "X", max_rows=None)
        params = _effective_parameters(_normalize_schema(candidate.parameter_schema), candidate.parameters)
        target = None if y is None else _json_safe(np.asarray(y))
        if target is not None and (np.asarray(target).ndim != 1 or len(target) != matrix.shape[0]):
            raise VerifiedAlgorithmError("Training targets must be aligned one-dimensional arrays")
        if candidate.kind in {"classification", "regression"} and target is None:
            raise VerifiedAlgorithmError("Aligned training targets are required")
        state = _job(candidate.python_source, "fit", {"X": matrix.tolist(), "y": target, "parameters": params})
        if not isinstance(state, dict):
            raise VerifiedAlgorithmError("fit did not return a state mapping")
        envelope = {"runtime_state_version": 1, "candidate_id": candidate_id,
                    "configuration_sha256": _hash_text(_canonical(_json_safe(asdict(candidate)))),
                    "n_features": matrix.shape[1], "n_training_rows": matrix.shape[0],
                    "training_input_sha256": _hash_text(_canonical({"X": matrix.tolist(), "y": target})),
                    "state": state}
        envelope["integrity_sha256"] = _hash_text(_canonical(envelope))
        return envelope

    def fit_accepted(self, candidate_id: str, X: Any, y: Any = None) -> dict[str, Any]:
        """Fit a fresh independent state from this caller's training partition."""
        return self.fit(candidate_id, X, y)

    def _validate_state(self, candidate_id: str, candidate: Candidate, state: Mapping[str, Any]) -> dict:
        envelope = _json_safe(dict(state))
        digest = envelope.pop("integrity_sha256", None)
        if digest != _hash_text(_canonical(envelope)):
            raise VerifiedAlgorithmError("Runtime state integrity mismatch")
        if (envelope.get("runtime_state_version") != 1 or envelope.get("candidate_id") != candidate_id
                or envelope.get("configuration_sha256") != _hash_text(_canonical(_json_safe(asdict(candidate))))
                or not isinstance(envelope.get("state"), dict)
                or type(envelope.get("n_features")) is not int):
            raise VerifiedAlgorithmError("Runtime state belongs to another candidate or configuration")
        envelope["integrity_sha256"] = digest
        return envelope

    def save_state(self, state: Mapping[str, Any], path: str | Path) -> None:
        """Atomically persist JSON state; hashes detect accidental edits, not malicious forgery."""
        candidate_id = state.get("candidate_id")
        candidate = self.reload(candidate_id)
        envelope = self._validate_state(candidate_id, candidate, state)
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=".state-", suffix=".json", dir=destination.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                stream.write(_canonical(envelope))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, destination)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def load_state(self, candidate_id: str, path: str | Path) -> dict[str, Any]:
        candidate = self.reload(candidate_id)
        try:
            state = json.loads(Path(path).read_text(encoding="utf-8"))
            return self._validate_state(candidate_id, candidate, state)
        except (OSError, ValueError, TypeError, AttributeError) as exc:
            raise VerifiedAlgorithmError("Saved runtime state is invalid") from exc

    def execute(self, candidate_id: str, X: Any, *, state: Mapping[str, Any] | None = None, y_true: Any = None) -> Any:
        candidate = self.reload(candidate_id)
        params = _effective_parameters(_normalize_schema(candidate.parameter_schema), candidate.parameters)
        if candidate.kind == "metric":
            truth = np.asarray(y_true)
            pred = np.asarray(X)
            if truth.ndim != 1 or pred.shape != truth.shape:
                raise VerifiedAlgorithmError("Metric arrays must be aligned")
            value = _job(candidate.python_source, "score", {"y_true": _json_safe(truth), "y_pred": _json_safe(pred), "parameters": params})
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise VerifiedAlgorithmError("Runtime metric must return one finite scalar")
            return value
        if state is None or not isinstance(state, Mapping):
            raise VerifiedAlgorithmError("A fitted JSON state is required")
        envelope = self._validate_state(candidate_id, candidate, state)
        matrix = _matrix(X, "X", expected_features=envelope["n_features"], max_rows=None)
        op = "predict" if candidate.kind in {"classification", "regression"} else "transform"
        result = _job(candidate.python_source, op, {"X": matrix.tolist(), "state": envelope["state"], "parameters": params})
        output = np.asarray(result)
        expected_rank = 1 if op == "predict" else 2
        if output.ndim != expected_rank or output.shape[0] != matrix.shape[0]:
            raise VerifiedAlgorithmError("Runtime output row count changed")
        if candidate.kind == "stateful_preprocessing" and output.shape[1] != matrix.shape[1]:
            raise VerifiedAlgorithmError("Preprocessing changed spectral dimension")
        if candidate.kind == "feature_selection":
            selected = envelope["state"].get("indices")
            output_axis = envelope["state"].get("output_axis")
            if selected is None and output_axis is None:
                raise VerifiedAlgorithmError("Runtime feature state requires indices or output_axis")
            if selected is not None:
                if (not isinstance(selected, list) or len(selected) != output.shape[1]
                        or any(type(i) is not int or i < 0 or i >= matrix.shape[1] for i in selected)
                        or len(set(selected)) != len(selected)):
                    raise VerifiedAlgorithmError("Runtime feature indices are invalid")
                if not np.allclose(output.astype(float), matrix[:, selected], rtol=candidate.rtol, atol=candidate.atol):
                    raise VerifiedAlgorithmError("Runtime feature output differs from declared indices")
            if output_axis is not None and (not isinstance(output_axis, list) or len(output_axis) != output.shape[1]):
                raise VerifiedAlgorithmError("Runtime output_axis does not match features")
        if candidate.kind in {"regression", "stateful_preprocessing", "feature_selection"} and not np.isfinite(output.astype(float)).all():
            raise VerifiedAlgorithmError("Runtime output contains nonfinite values")
        return result
