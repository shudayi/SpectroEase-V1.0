"""Execute accepted operators with fresh training states and explicit row provenance."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import accuracy_score, balanced_accuracy_score, mean_absolute_error, mean_squared_error, r2_score

from app.services.verified_algorithm_service import VerifiedAlgorithmError, VerifiedAlgorithmService


class VerifiedWorkflowService:
    def __init__(self, algorithm_service: VerifiedAlgorithmService):
        self.algorithms = algorithm_service

    @staticmethod
    def _ids(values, count, prefix):
        result = [f"{prefix}:{i}" for i in range(count)] if values is None else list(values)
        if len(result) != count or len(set(result)) != count:
            raise VerifiedAlgorithmError("Row identifiers must be unique and aligned")
        return result

    @staticmethod
    def _axis(values, feature_count):
        if values is None:
            return None
        axis = list(values)
        if (len(axis) != feature_count or any(isinstance(v, (list, dict, tuple, bool)) or v is None for v in axis)):
            raise VerifiedAlgorithmError("Input axis must contain one scalar label per feature")
        axis = [v.item() if isinstance(v, np.generic) else v for v in axis]
        try:
            encoded = json.dumps(axis, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
            if any(isinstance(v, bool) or not isinstance(v, (str, int, float)) for v in axis) or len({json.dumps(v, ensure_ascii=False, allow_nan=False) for v in axis}) != len(axis):
                raise ValueError("Axis labels must be unique JSON scalars")
        except (ValueError, TypeError) as exc:
            raise VerifiedAlgorithmError("Axis labels must be unique finite JSON scalars") from exc
        return axis

    @staticmethod
    def _axis_digest(axis):
        return hashlib.sha256(json.dumps(axis, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")).hexdigest()

    def run(self, selection, X_train, y_train, X_test, y_test=None, train_ids=None, test_ids=None, axis=None, test_axis=None):
        train = np.asarray(X_train, dtype=float)
        probe = np.asarray(X_test, dtype=float)
        target = np.asarray(y_train)
        if train.ndim != 2 or probe.ndim != 2 or train.shape[1] != probe.shape[1] or target.shape != (len(train),):
            raise VerifiedAlgorithmError("Training and held-out arrays are not aligned")
        input_axis = self._axis(axis, train.shape[1])
        probe_axis = self._axis(test_axis, probe.shape[1])
        if (input_axis is None) != (probe_axis is None) or (input_axis is not None and self._axis_digest(input_axis) != self._axis_digest(probe_axis)):
            raise VerifiedAlgorithmError("Training and held-out input axes differ or are missing")
        training_ids = self._ids(train_ids, len(train), "train")
        testing_ids = self._ids(test_ids, len(probe), "test")
        if set(training_ids).intersection(testing_ids):
            raise VerifiedAlgorithmError("Training and held-out row identifiers overlap")
        model_id = selection.get("model")
        if not model_id:
            raise VerifiedAlgorithmError("Select an accepted classification or regression model")
        if not len(train) or not len(probe) or not train.shape[1] or not np.isfinite(train).all() or not np.isfinite(probe).all():
            raise VerifiedAlgorithmError("Workflow inputs must be nonempty finite matrices")
        model = self.algorithms.reload(model_id)
        if model.kind not in {"classification", "regression"}:
            raise VerifiedAlgorithmError("Selected model has an incompatible role")
        if any(value is None or (isinstance(value, (float, np.floating)) and not np.isfinite(value)) for value in target):
            raise VerifiedAlgorithmError("Training targets contain missing or nonfinite values")
        if model.kind == "regression":
            try:
                if not np.isfinite(target.astype(float)).all():
                    raise ValueError("nonfinite target")
            except (TypeError, ValueError) as exc:
                raise VerifiedAlgorithmError("Regression targets must be finite numeric values") from exc
        if y_test is not None:
            truth = np.asarray(y_test)
            if truth.shape != (len(probe),):
                raise VerifiedAlgorithmError("Held-out targets must be aligned one-dimensional arrays")
            if any(value is None or (isinstance(value, (float, np.floating)) and not np.isfinite(value)) for value in truth):
                raise VerifiedAlgorithmError("Held-out targets contain missing or nonfinite values")
            if model.kind == "regression" and not np.isfinite(truth.astype(float)).all():
                raise VerifiedAlgorithmError("Held-out regression targets must be finite")
        stages, trace = [], []
        for role, kind in (("preprocessing", "stateful_preprocessing"), ("feature_selection", "feature_selection"), ("model", model.kind)):
            identifier = selection.get(role)
            if not identifier:
                continue
            candidate = self.algorithms.reload(identifier)
            if candidate.kind != kind:
                raise VerifiedAlgorithmError(f"Incompatible algorithm selected for {role}")
            state = self.algorithms.fit_accepted(identifier, train, target)
            stages.append({"role": role, "candidate_id": identifier, "state": state})
            trace.append({"role": role, "training_ids": training_ids, "input_shape": list(train.shape),
                          "state_sha256": state["integrity_sha256"]})
            if role != "model":
                train = np.asarray(self.algorithms.execute(identifier, train, state=state))
                probe = np.asarray(self.algorithms.execute(identifier, probe, state=state))
            else:
                predictions = np.asarray(self.algorithms.execute(identifier, probe, state=state))
        metrics = {}
        if y_test is not None:
            truth = np.asarray(y_test)
            if truth.shape != predictions.shape:
                raise VerifiedAlgorithmError("Held-out targets must align with predictions")
            if model.kind == "classification":
                metrics = {"accuracy": float(accuracy_score(truth, predictions)),
                           "balanced_accuracy": float(balanced_accuracy_score(truth, predictions))}
            else:
                metrics = {"RMSE": float(np.sqrt(mean_squared_error(truth, predictions))),
                           "MAE": float(mean_absolute_error(truth, predictions)),
                           "R2": float(r2_score(truth, predictions)) if len(truth) > 1 else None}
            if selection.get("metric"):
                identifier = selection["metric"]
                if self.algorithms.reload(identifier).kind != "metric":
                    raise VerifiedAlgorithmError("Selected metric has an incompatible role")
                metrics[identifier] = self.algorithms.execute(identifier, predictions, y_true=truth)
        return {"workflow_version": 1, "selection": dict(selection), "stages": stages,
                "input_axis": input_axis, "axis_sha256": None if input_axis is None else self._axis_digest(input_axis),
                "axis_scope": "feature_count_only" if input_axis is None else "exact_ordered_input_labels",
                "fit_trace": trace, "training_ids": training_ids, "test_ids": testing_ids,
                "predictions": predictions.tolist(), "metrics": metrics}

    def _validate_structure(self, result, *, validate_states=False):
        if not isinstance(result, dict) or result.get("workflow_version") != 1:
            raise VerifiedAlgorithmError("Unsupported workflow version")
        selection = result.get("selection")
        stages = result.get("stages")
        if not isinstance(selection, dict) or not selection.get("model") or not isinstance(stages, list):
            raise VerifiedAlgorithmError("Saved workflow requires a model and ordered stages")
        expected = [(role, selection[role]) for role in ("preprocessing", "feature_selection", "model") if selection.get(role)]
        actual = [(stage.get("role"), stage.get("candidate_id")) for stage in stages if isinstance(stage, dict)]
        if actual != expected or len(actual) != len(stages):
            raise VerifiedAlgorithmError("Saved workflow stages are missing, duplicated or out of order")
        for stage in stages:
            candidate = self.algorithms.reload(stage["candidate_id"])
            allowed = {"stateful_preprocessing"} if stage["role"] == "preprocessing" else {"feature_selection"} if stage["role"] == "feature_selection" else {"classification", "regression"}
            if candidate.kind not in allowed:
                raise VerifiedAlgorithmError("Saved workflow stage has an incompatible role")
            if validate_states:
                self.algorithms._validate_state(stage["candidate_id"], candidate, stage["state"])
        stored_axis = result.get("input_axis")
        if stored_axis is not None:
            feature_count = stages[0]["state"].get("n_features")
            validated_axis = self._axis(stored_axis, feature_count)
            if result.get("axis_sha256") != self._axis_digest(validated_axis):
                raise VerifiedAlgorithmError("Saved workflow input axis digest mismatch")
        elif result.get("axis_sha256") is not None:
            raise VerifiedAlgorithmError("Saved workflow axis is missing")
        training = self._ids(result.get("training_ids"), len(result.get("training_ids", [])), "train")
        testing = self._ids(result.get("test_ids"), len(result.get("test_ids", [])), "test")
        if not training or not testing or set(training).intersection(testing):
            raise VerifiedAlgorithmError("Saved workflow training/test row provenance is invalid")

    def predict(self, result, X, axis=None):
        self._validate_structure(result)
        value = np.asarray(X, dtype=float)
        if value.ndim != 2:
            raise VerifiedAlgorithmError("Prediction input must be a two-dimensional matrix")
        supplied_axis = self._axis(axis, value.shape[1])
        if result.get("input_axis") is not None:
            if supplied_axis is None or self._axis_digest(supplied_axis) != result["axis_sha256"]:
                raise VerifiedAlgorithmError("Prediction input axis differs from fitted workflow or is missing")
        for stage in result["stages"]:
            value = np.asarray(self.algorithms.execute(stage["candidate_id"], value, state=stage["state"]))
        return value

    def cross_validate(self, selection, X, y, splits, row_ids=None, groups=None, axis=None):
        """Fit each operator anew in each supplied, explicitly disjoint fold."""
        matrix, target = np.asarray(X), np.asarray(y)
        identifiers = self._ids(row_ids, len(matrix), "row")
        group_values = None if groups is None else np.asarray(groups)
        if target.shape != (len(matrix),) or (group_values is not None and group_values.shape != target.shape):
            raise VerifiedAlgorithmError("Cross-validation arrays are not aligned")
        results = []
        for fold, (training, testing) in enumerate(splits):
            training, testing = np.asarray(training), np.asarray(testing)
            for indices in (training, testing):
                if (indices.ndim != 1 or not np.issubdtype(indices.dtype, np.integer)
                        or len(indices) == 0 or len(set(indices.tolist())) != len(indices)
                        or np.any(indices < 0) or np.any(indices >= len(matrix))):
                    raise VerifiedAlgorithmError("Invalid fold row indices")
            if set(training.tolist()).intersection(testing.tolist()):
                raise VerifiedAlgorithmError("Cross-validation fold rows overlap")
            if group_values is not None and set(group_values[training].tolist()).intersection(group_values[testing].tolist()):
                raise VerifiedAlgorithmError("Cross-validation entity groups overlap")
            result = self.run(selection, matrix[training], target[training], matrix[testing], target[testing],
                              [identifiers[i] for i in training], [identifiers[i] for i in testing], axis=axis, test_axis=axis)
            result["fold"] = fold
            results.append(result)
        if not results:
            raise VerifiedAlgorithmError("At least one fold is required")
        return results

    def save(self, result, path):
        self._validate_structure(result, validate_states=True)
        payload = json.dumps(result, sort_keys=True, ensure_ascii=False, allow_nan=False)
        wrapper = {"workflow": result, "sha256": hashlib.sha256(payload.encode()).hexdigest()}
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        temporary.write_text(json.dumps(wrapper, ensure_ascii=False, allow_nan=False), encoding="utf-8")
        temporary.replace(destination)

    def load(self, path):
        wrapper = json.loads(Path(path).read_text(encoding="utf-8"))
        result = wrapper["workflow"]
        payload = json.dumps(result, sort_keys=True, ensure_ascii=False, allow_nan=False)
        if wrapper["sha256"] != hashlib.sha256(payload.encode()).hexdigest() or result.get("workflow_version") != 1:
            raise VerifiedAlgorithmError("Saved workflow integrity or version mismatch")
        self._validate_structure(result, validate_states=True)
        return result
