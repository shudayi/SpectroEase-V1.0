# app/services/task_detector.py
"""Single source of truth for task-type detection.

This module converges all the previously-duplicated task-type detection
logic into a single importable function. ``modeling_service`` and
``evaluation_service`` should both call this rather than maintaining their
own rules.
"""

from __future__ import annotations

from typing import Optional

from app.utils.label_processor import EnhancedLabelProcessor


def detect_task_type(labels, settings: Optional[object] = None) -> str:
    """Return ``'classification'`` or ``'regression'`` for ``labels``.

    ``settings`` is an optional ``config.settings.Settings`` instance whose
    thresholds override the built-in defaults.
    """
    processor = EnhancedLabelProcessor(settings=settings)
    return processor.detect_task_type(labels)


def is_classification(labels, settings: Optional[object] = None) -> bool:
    return detect_task_type(labels, settings=settings) == 'classification'