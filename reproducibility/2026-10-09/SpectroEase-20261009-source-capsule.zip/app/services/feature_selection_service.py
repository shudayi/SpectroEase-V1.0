# app/services/feature_selection_service.py

import logging

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor

from app.utils.exceptions import FeatureSelectionError
from interfaces.feature_selection_algorithm import FeatureSelectionAlgorithm

logger = logging.getLogger(__name__)


class FeatureSelectionService:
    def __init__(self, plugins: dict = None):
        self.plugins = plugins or {}

    def _check_user_feature_count(self, user_k, n_classes, n_features, method_name="Feature Selection"):
        """Check and adjust user-specified feature count based on data characteristics"""
        min_recommended = max(n_classes * 2, 10)

        if user_k < min_recommended and n_features >= min_recommended:
            recommended_k = min(min_recommended, n_features // 2, 50)

        elif user_k <= 5 and n_features > 50:
            recommended_k = min(30, n_features // 3)

        final_k = min(user_k, n_features)

        return final_k

    def select_features(self, method: str, params: dict, X, y, *, return_scores=False) -> list:

        import numpy as np

        wavelengths = params.get('wavelengths', None)

        if not isinstance(X, pd.DataFrame):

            logger.debug("Converting input X from %s to pandas DataFrame", type(X))
            X_df = pd.DataFrame(X)

            # Use wavelength information as column names (if provided)
            if wavelengths is not None and len(wavelengths) == X.shape[1]:
                X_df.columns = [f"wavelength_{w:.1f}" if isinstance(w, (int, float)) else f"wavelength_{i}"
                              for i, w in enumerate(wavelengths)]
                logger.debug("Using wavelength information as column names: %s...", list(X_df.columns)[:5])
            else:
                X_df.columns = [f'feature_{i}' for i in range(X.shape[1])]
                logger.debug("Wavelength information not provided, using default feature names")

            X = X_df

        if not isinstance(y, pd.Series):
            logger.debug("Converting input y from %s to pandas Series", type(y))
            y = pd.Series(y)

        try:
            k=params.get('k',min(10,X.shape[1]))
            if isinstance(k,bool) or not isinstance(k,(int,np.integer)) or not 1 <= k <= X.shape[1]:
                raise FeatureSelectionError('Feature count must be an integer between 1 and the input feature count')
            if X.empty or not np.isfinite(X.to_numpy(dtype=float)).all():
                raise FeatureSelectionError('Feature selection requires nonempty finite numeric spectra')
            if y is not None and len(y) and len(y)!=len(X):
                raise FeatureSelectionError('Training target length must match training spectra')
            if method in self.plugins:
                algorithm: FeatureSelectionAlgorithm = self.plugins[method]
                if not callable(getattr(algorithm,'select_features',None)):
                    raise FeatureSelectionError(f"Loaded plugin '{method}' has no integrated feature-selection interface")
                signature=__import__('inspect').signature(algorithm.select_features)
                if 'params' not in signature.parameters:
                    raise FeatureSelectionError(f"Plugin '{method}' requires its dedicated feature-extraction route")
                output=algorithm.select_features(X,y,params)
                if not isinstance(output,list) or not all(column in X.columns for column in output):
                    raise FeatureSelectionError(f"Plugin '{method}' returns transformed features instead of a reusable column selector; its dedicated route is not integrated")
                return (output,None) if return_scores else output
            else:

                is_classification = self._is_classification_task(y)

                # Note: PCA is a dimensionality reduction technique, not feature selection
                # PCA creates new features (principal components) rather than selecting existing ones
                # It has been moved to Feature Extraction Service for proper unsupervised use
                if method == "PCA":
                    # PCA-based feature selection using loadings
                    try:
                        from sklearn.decomposition import PCA
                        from sklearn.preprocessing import StandardScaler

                        k = params.get('k', min(10, X.shape[1]))

                        # Standardize data before PCA
                        scaler = StandardScaler()
                        X_scaled = scaler.fit_transform(X)

                        # The number of components for PCA should not exceed the number of features or samples.
                        n_components = min(X.shape[0], X.shape[1])
                        pca = PCA(n_components=n_components)
                        pca.fit(X_scaled)

                        # Use the sum of absolute loadings on all components to score features
                        loadings = pca.components_.T  # shape: (n_features, n_components)
                        feature_scores = np.sum(np.abs(loadings), axis=1)

                        # Select top k features based on scores
                        k = min(k, len(feature_scores))
                        top_indices = np.argsort(feature_scores)[-k:]
                        selected_features = X.columns[top_indices]

                    except Exception as e:
                        raise FeatureSelectionError(f"PCA feature selection failed: {e}")

                elif method == "Wavelet":
                    # Wavelet feature selection for spectral data
                    # Wavelet transform decomposes signals into time-frequency components
                    # This is especially useful for spectral data to identify important frequency patterns
                    try:
                        import pywt
                    except ImportError:
                        raise FeatureSelectionError("PyWavelets package is required for Wavelet feature selection. Install with: pip install PyWavelets")

                    k = params.get('k', min(10, X.shape[1]))
                    wavelet = params.get('wavelet', 'db4')  # Daubechies 4 is good for spectral data
                    maximum_level=pywt.dwt_max_level(X.shape[1],pywt.Wavelet(wavelet).dec_len)
                    levels = params.get('levels', min(3,maximum_level))
                    if isinstance(levels,bool) or not isinstance(levels,(int,np.integer)) or not 1<=levels<=maximum_level:
                        raise FeatureSelectionError(f'Wavelet levels must be between 1 and {maximum_level} for this wavelength axis')

                    logger.debug("Wavelet feature selection using %s wavelet with %s levels, selecting %s features", wavelet, levels, k)

                    # Calculate feature importance using wavelet decomposition
                    feature_scores = np.zeros(X.shape[1])

                    for i in range(X.shape[0]):
                        signal = X.iloc[i].to_numpy(dtype=float,copy=True)

                        # Perform wavelet decomposition
                        coeffs = pywt.wavedec(signal, wavelet, level=levels)

                        # Calculate energy in each coefficient
                        # Higher energy coefficients indicate more important features
                        reconstructed_approx = pywt.waverec([coeffs[0]] + [np.zeros_like(c) for c in coeffs[1:]], wavelet)

                        # Ensure same length as original signal
                        if len(reconstructed_approx) != len(signal):
                            reconstructed_approx = reconstructed_approx[:len(signal)]

                        # Calculate the contribution of each original feature to the approximation
                        contribution = np.abs(reconstructed_approx)
                        feature_scores += contribution

                    # Normalize by number of samples
                    feature_scores /= X.shape[0]

                    # Select top k features
                    top_indices = np.argsort(feature_scores)[-k:]
                    selected_features = X.columns[top_indices]

                    logger.debug("Wavelet analysis identified features with highest energy contributions")
                    logger.debug("Selected wavelength ranges: %s...", [X.columns[i] for i in top_indices[:5]])

                elif method == "PLSR" or method == "PLS Regression":
                    # Partial Least Squares Regression feature selection
                    try:
                        from sklearn.cross_decomposition import PLSRegression
                        from sklearn.preprocessing import LabelEncoder
                    except ImportError:
                        raise FeatureSelectionError("scikit-learn is required for PLSR feature selection")

                    n_components = params.get('n_components', min(10, X.shape[0] - 1, X.shape[1]))
                    k = params.get('k', min(10, X.shape[1]))

                    logger.debug("PLSR using %s components to select %s features", n_components, k)

                    # Handle string labels for PLSR
                    # PLSR expects numerical targets, so encode string labels
                    y_for_pls = y.copy() if hasattr(y, 'copy') else y

                    # Check if y contains string labels
                    if isinstance(y_for_pls, pd.Series):
                        y_dtype_is_string = y_for_pls.dtype == 'object' or str(y_for_pls.dtype).startswith('<U')
                        y_sample = y_for_pls.iloc[0] if len(y_for_pls) > 0 else None
                    elif isinstance(y_for_pls, np.ndarray):
                        y_dtype_is_string = y_for_pls.dtype.kind in ['U', 'S', 'O']
                        y_sample = y_for_pls[0] if len(y_for_pls) > 0 else None
                    else:
                        y_dtype_is_string = isinstance(str(y_for_pls), str) if hasattr(y_for_pls, '__iter__') else False
                        y_sample = None

                    if y_dtype_is_string or (y_sample is not None and isinstance(y_sample, str)):
                        logger.debug("PLSR: Converting string labels to numerical for PLS fitting")
                        logger.debug("Sample labels: %s", y_for_pls[:5] if hasattr(y_for_pls, '__getitem__') else y_for_pls)

                        # Use LabelEncoder to convert string labels to integers
                        label_encoder = LabelEncoder()
                        y_encoded = label_encoder.fit_transform(y_for_pls)
                        logger.debug("Encoded sample: %s", y_encoded[:5])
                        logger.debug("Label mapping: %s", dict(zip(label_encoder.classes_, label_encoder.transform(label_encoder.classes_))))
                    else:
                        y_encoded = y_for_pls
                        logger.debug("PLSR: Labels are already numerical, using directly")

                    # Fit PLS model with encoded labels
                    pls = PLSRegression(n_components=n_components, scale=True)
                    pls.fit(X, y_encoded)

                    # Calculate feature importance based on PLS loadings
                    # Use the sum of squared loadings across all components
                    loadings = pls.x_loadings_  # Shape: (n_features, n_components)
                    feature_scores = np.sum(loadings ** 2, axis=1)

                    # Select top k features
                    top_indices = np.argsort(feature_scores)[-k:]
                    selected_features = X.columns[top_indices]

                elif method == "Peak Detection":
                    # Peak detection feature selection for spectral data
                    try:
                        from scipy.signal import find_peaks
                    except ImportError:
                        raise FeatureSelectionError("scipy is required for Peak Detection feature selection")

                    k = params.get('k', min(10, X.shape[1]))
                    height = params.get('height', None)  # Minimum peak height
                    distance = params.get('distance', 1)  # Minimum distance between peaks
                    prominence = params.get('prominence', None)  # Peak prominence

                    logger.debug("Peak Detection selecting %s features with distance=%s", k, distance)

                    # Calculate mean spectrum
                    mean_spectrum = X.mean(axis=0).values

                    # Find peaks in the mean spectrum
                    peaks, properties = find_peaks(
                        mean_spectrum,
                        height=height,
                        distance=distance,
                        prominence=prominence
                    )

                    logger.debug("Found %s peaks in spectrum", len(peaks))

                    if len(peaks) == 0:
                        # If no peaks found, select features with highest variance
                        logger.debug("No peaks found, selecting features with highest variance")
                        variances = X.var(axis=0)
                        top_indices = np.argsort(variances)[-k:]
                        selected_features = X.columns[top_indices]
                    elif len(peaks) < k:
                        # If fewer peaks than requested features, add features around peaks
                        logger.debug("Only %s peaks found, expanding selection around peaks", len(peaks))
                        selected_indices = set(peaks)

                        # Add neighboring features around each peak
                        for peak in peaks:
                            for offset in [-2, -1, 1, 2]:
                                neighbor = peak + offset
                                if 0 <= neighbor < len(X.columns) and len(selected_indices) < k:
                                    selected_indices.add(neighbor)

                        # If still not enough, add features with highest variance
                        if len(selected_indices) < k:
                            variances = X.var(axis=0)
                            remaining_indices = set(range(len(X.columns))) - selected_indices
                            remaining_variances = [(i, variances.iloc[i]) for i in remaining_indices]
                            remaining_variances.sort(key=lambda x: x[1], reverse=True)

                            for i, _ in remaining_variances[:k - len(selected_indices)]:
                                selected_indices.add(i)

                        selected_features = X.columns[list(selected_indices)[:k]]
                    else:
                        # More peaks than requested features, select top k peaks by height/prominence
                        if 'peak_heights' in properties:
                            peak_scores = properties['peak_heights']
                        elif 'prominences' in properties:
                            peak_scores = properties['prominences']
                        else:
                            # Use peak values from mean spectrum
                            peak_scores = mean_spectrum[peaks]

                        top_peak_indices = np.argsort(peak_scores)[-k:]
                        selected_peak_positions = peaks[top_peak_indices]
                        selected_features = X.columns[selected_peak_positions]

                else:
                    raise FeatureSelectionError(f"Unsupported feature selection method: {method}")

                if hasattr(selected_features, 'tolist'):
                    result = selected_features.tolist()
                else:
                    result = list(selected_features)

                if return_scores:
                    if method=='Peak Detection':
                        feature_scores=np.maximum(np.asarray(mean_spectrum,dtype=float),0)
                    return result,np.asarray(feature_scores,dtype=float)
                return result
        except Exception as e:
            logger.exception("Error in select_features for method '%s'", method)
            raise FeatureSelectionError(f"Error in select_features for method '{method}': {e}") from e

    def _is_classification_task(self, y):
        """
        DEPRECATED: Use enhanced label processor instead
        This method is kept for backward compatibility
        """
        # Small continuous regression datasets are not collections of classes.
        from sklearn.utils.multiclass import type_of_target
        kind=type_of_target(np.asarray(y))
        if kind not in ('continuous','binary','multiclass'):
            raise FeatureSelectionError(f'Unsupported target type for feature selection: {kind}')
        return kind in ('binary','multiclass')

    def apply_method(self, X_train, y_train, X_test=None, method=None, params=None):
        """Apply feature selection method to training data, and transform testing data using the same features.

        Args:
            X_train: Training features
            y_train: Training labels
            X_test: Testing features (optional)
            method: Feature selection method name
            params: Method parameters

        Returns:
            tuple: (X_train_selected, X_test_selected or None)
        """

        import numpy as np

        # Validate inputs
        if X_train is None or y_train is None:
            raise ValueError("Training data (X_train, y_train) cannot be None")

        if method is None:
            logger.debug("No feature selection method specified, returning original data")
            return X_train, X_test

        try:
            # Log input data information for debugging
            logger.debug("Applying feature selection method - input data info:")
            logger.debug("X_train type: %s, shape: %s", type(X_train), X_train.shape if hasattr(X_train, 'shape') else 'N/A')
            logger.debug("y_train type: %s, length: %s", type(y_train), len(y_train) if hasattr(y_train, '__len__') else 'N/A')
            if isinstance(y_train, pd.Series) or isinstance(y_train, pd.DataFrame):
                logger.debug("y_train data type: %s", y_train.dtype)
            elif isinstance(y_train, np.ndarray):
                logger.debug("y_train data type: %s", y_train.dtype)

            if isinstance(y_train, pd.Series):
                logger.debug("y_train unique values: %s, count: %s", y_train.unique(), len(y_train.unique()))
            elif isinstance(y_train, np.ndarray):
                logger.debug("y_train unique values: %s, count: %s", np.unique(y_train), len(np.unique(y_train)))

            # Save original data and types
            original_X_train_type = type(X_train)
            original_X_test_type = type(X_test) if X_test is not None else None

            # Create deep copy to ensure original data is not modified
            if hasattr(y_train, 'copy'):
                original_y_train = y_train.copy()
            elif isinstance(y_train, np.ndarray):
                original_y_train = y_train.copy()
            else:
                # If cannot copy, keep reference
                original_y_train = y_train

            logger.debug("Original label save type: %s", type(original_y_train))

            # Check task type needed for feature importance calculation
            task_type = None
            # Try to automatically determine task type
            if y_train is not None:
                if self._is_classification_task(y_train):
                    task_type = 'classification'
                    logger.debug("Automatically detected classification task")
                else:
                    task_type = 'regression'
                    logger.debug("Automatically detected regression task")

            # Handle feature selection
            if method is None:
                # Default method
                method = "SelectKBest"

            if params is None:
                params = {}
            else:
                params=dict(params)

            # Extract the number of features to select from params
            # Support multiple parameter names for different methods
            n_features = params.get('k',
                        params.get('n_features',
                        params.get('n_features_to_select',
                        params.get('top_n', min(10, X_train.shape[1])))))

            if y_train is not None:
                n_classes = len(np.unique(y_train))
                min_features_needed = max(n_classes * 3, 30)

                if 'k' in params and params['k'] is not None:
                    user_k = params['k']
                    if user_k < min_features_needed and X_train.shape[1] >= min_features_needed:
                        recommended_k = min(min_features_needed, X_train.shape[1] // 2, 80)
                        logger.debug("User k=%s may be insufficient for %s classes", user_k, n_classes)
                        logger.debug("Recommended: %s features for better performance", recommended_k)
                        logger.debug("Using user setting: %s (as requested)", user_k)
                    n_features = user_k
                elif 'top_n' in params and params['top_n'] is not None:
                    user_top_n = params['top_n']
                    if user_top_n < min_features_needed and X_train.shape[1] >= min_features_needed:
                        recommended_top_n = min(min_features_needed, X_train.shape[1] // 2, 80)
                        logger.debug("User top_n=%s may be insufficient for %s classes", user_top_n, n_classes)
                        logger.debug("Recommended: %s features for better performance", recommended_top_n)
                        logger.debug("Using user setting: %s (as requested)", user_top_n)
                    n_features = user_top_n
                else:
                    if n_features < min_features_needed and X_train.shape[1] >= min_features_needed:
                        n_features_recommended = min(min_features_needed, X_train.shape[1] // 2, 80)
                        logger.debug("Auto-adjusting features from %s to %s for %s classes", n_features, n_features_recommended, n_classes)
                        n_features = n_features_recommended

            logger.debug("Parameter extraction:")
            logger.debug("Raw params: %s", params)
            logger.debug("Final n_features: %s", n_features)
            logger.debug("Available features: %s", X_train.shape[1])

            # Update params to ensure consistency across all methods
            params['k'] = n_features
            params['n_features'] = n_features
            params['n_features_to_select'] = n_features
            params['top_n'] = n_features

            logger.debug("Feature selection method '%s' selecting %s features...", method, n_features)
            logger.debug("Final parameters passed to method: %s", params)

            # Ensure correct data type - convert to DataFrame for select_features method
            if not isinstance(X_train, pd.DataFrame):
                logger.debug("Converting X_train from %s to DataFrame for feature selection", type(X_train))
                # Save original data
                original_X_train = X_train.copy()
                # Create column names
                feature_names = [f'feature_{i}' for i in range(X_train.shape[1])]
                X_train = pd.DataFrame(X_train, columns=feature_names)
            else:
                feature_names = X_train.columns.tolist()

            # Similarly handle X_test (if exists)
            if X_test is not None and not isinstance(X_test, pd.DataFrame):
                logger.debug("Converting X_test from %s to DataFrame for feature selection", type(X_test))
                original_X_test = X_test.copy()
                X_test = pd.DataFrame(X_test, columns=feature_names)

            # Get feature selected dataset
            selected_features,selection_scores = self.select_features(method, params, X_train, y_train,return_scores=True)

            # Check if selected features is empty
            if not selected_features or len(selected_features) == 0:
                raise FeatureSelectionError('Feature selection returned no columns; no fallback was applied')

            logger.debug("Feature selection completed, selected %s features", len(selected_features))

            # Apply feature selection
            X_train_selected = X_train[selected_features]
            X_test_selected = X_test[selected_features] if X_test is not None else None

            # Convert back to original type (if needed)
            if original_X_train_type == np.ndarray:
                X_train_selected = X_train_selected.values
            if X_test is not None and original_X_test_type == np.ndarray:
                X_test_selected = X_test_selected.values

            # Calculate feature importance using the SAME preprocessed data used for feature selection
            logger.debug("Calculating feature importance using preprocessed data...")
            logger.debug("Using X_train for importance: shape=%s", X_train.shape)

            # Safely handle pandas Series/DataFrame min/max formatting
            try:
                data_min = float(X_train.min().min() if hasattr(X_train.min(), 'min') else X_train.min())
                data_max = float(X_train.max().max() if hasattr(X_train.max(), 'max') else X_train.max())
                logger.debug("Data range: [%s, %s]", data_min, data_max)
            except Exception as fmt_error:
                logger.debug("Data range: [min=%s, max=%s] (format error: %s)", X_train.min(), X_train.max(), fmt_error)
            feature_importances = (selection_scores if selection_scores is not None else
                                   self._calculate_feature_importance(X_train,y_train,method,task_type=task_type))

            # Create visualization data
            # Ensure feature importance array matches feature count
            if len(feature_importances) != X_train.shape[1]:
                logger.debug("Warning: Feature importance array length (%s) does not match feature count (%s), will adjust", len(feature_importances), X_train.shape[1])
                if len(feature_importances) > X_train.shape[1]:
                    feature_importances = feature_importances[:X_train.shape[1]]
                else:
                    # If feature importance array is too short, pad with zeros
                    extended_importances = np.zeros(X_train.shape[1])
                    extended_importances[:len(feature_importances)] = feature_importances
                    feature_importances = extended_importances

            importances = np.array(feature_importances)
            # Ensure only valid indices are selected
            top_n = min(10, len(feature_names))
            indices = np.argsort(importances)[-top_n:]

            # Sort for visualization
            features_for_visualization = [(feature_names[i], float(importances[i])) for i in indices]

            # Ensure feature importance is tuple list not other format
            if len(features_for_visualization) > 0 and not isinstance(features_for_visualization[0], tuple):
                logger.debug("Correcting visualization feature format to tuple list")
                if isinstance(features_for_visualization[0], list) and len(features_for_visualization[0]) == 2:
                    features_for_visualization = [(str(item[0]), float(item[1])) for item in features_for_visualization]
                else:
                    # If format is not (name, importance), create correct format
                    feature_names = [str(f) for f in selected_features]
                    importances_list = [float(imp) for imp in importances]
                    features_for_visualization = list(zip(feature_names, importances_list))

            # Ensure all feature names are string type
            features_for_visualization = [(str(name), float(importance)) for name, importance in features_for_visualization]

            # Log final results for debugging
            logger.debug("Returning %s selected features", len(selected_features))
            logger.debug("Feature importance array length: %s", len(importances))
            logger.debug("Visualization feature array length: %s", len(features_for_visualization))
            logger.debug("Feature importance values: %s", importances)
            logger.debug("Feature names: %s", selected_features)
            logger.debug("Visualization features: %s", features_for_visualization[:5])

            # Ensure checking and logging returned label information
            logger.debug("Returned label type: %s", type(original_y_train))
            if isinstance(original_y_train, pd.Series):
                logger.debug("Label unique values: %s, count: %s", original_y_train.unique(), len(original_y_train.unique()))
            elif isinstance(original_y_train, np.ndarray):
                logger.debug("Label unique values: %s, count: %s", np.unique(original_y_train), len(np.unique(original_y_train)))

            # Ensure returning original labels, not labels that may have been modified during feature selection process
            return {
                'X_train_selected': X_train_selected,
                'X_test_selected': X_test_selected if X_test is not None else None,
                'y_train': original_y_train,  # Return original labels, ensure label information is not lost
                'selected_features': selected_features,
                'feature_importance': importances,
                'features_for_visualization': features_for_visualization
            }

        except Exception as e:
            # Record detailed error and throw appropriate exception
            logger.exception("Error applying feature selection method '%s'", method)
            raise FeatureSelectionError(f"Error applying feature selection method '{method}': {e}") from e

    def _calculate_feature_importance(self, X, y, method, task_type='classification', **kwargs):
        """Calculate feature importance

        Args:
            X: Feature matrix
            y: Target variable
            method: Feature selection method
            task_type: Task type, 'classification' or 'regression'
            **kwargs: Additional parameters

        Returns:
            numpy.ndarray: Feature importance
        """
        # Ensure numpy is available
        import numpy as np

        # Data validation
        if X is None or X.shape[0] == 0 or X.shape[1] == 0:
            logger.debug("Warning: Input feature data is empty or invalid")
            return np.ones(1) / 1

        if y is None or len(y) == 0:
            logger.debug("Warning: Input target data is empty or invalid")
            return np.ones(X.shape[1]) / X.shape[1]

        logger.debug("Calculating feature importance using method: %s", method)
        logger.debug("Task type: %s", task_type)
        logger.debug("Data shape: X=%s, y=%s", X.shape, len(y))

        # Check if preprocessing has already been applied
        def smart_preprocessing(X):
            """Smart preprocessing that detects if preprocessing was already applied"""
            logger.debug("Analyzing data for preprocessing needs...")

            # Check data characteristics
            data_min_val = float(X.min().min()) if hasattr(X.min(), 'min') else float(X.min())
            data_max_val = float(X.max().max()) if hasattr(X.max(), 'max') else float(X.max())
            data_mean_val = float(X.mean().mean()) if hasattr(X.mean(), 'mean') else float(X.mean())
            data_std_val = float(X.std().mean()) if hasattr(X.std(), 'mean') else float(X.std())
            data_range = data_max_val - data_min_val

            logger.debug("Data range: [%s, %s]", data_min_val, data_max_val)
            logger.debug("Data mean: %s, std: %s", data_mean_val, data_std_val)

            # Detect if data is already preprocessed
            is_already_standardized = (-3 < data_min_val < 0) and (0 < data_max_val < 3) and (abs(data_mean_val) < 0.5)
            is_already_normalized = (0 <= data_min_val <= 0.1) and (0.9 <= data_max_val <= 1.1)

            if is_already_standardized:
                logger.debug("Data appears already standardized - using minimal processing")
                return X, None, None
            elif is_already_normalized:
                logger.debug("Data appears already normalized - using minimal processing")
                return X, None, None
            elif data_range < 0.01:
                logger.debug("Data has very small range - scaling up for better discrimination")
                return X * 100, None, None
            elif data_range > 1000 or data_min_val < -100:
                logger.debug("Large data range detected - applying gentle standardization")
                from sklearn.preprocessing import RobustScaler
                scaler = RobustScaler()
                X_scaled = scaler.fit_transform(X)
                return X_scaled, scaler, None
            else:
                logger.debug("Data range is appropriate - using original data")
                return X, None, None

        try:
            # Apply smart preprocessing
            X_processed, scaler, imputer = smart_preprocessing(X)

            # Use the enhanced label processor for proper task type handling
            from app.utils.label_processor import EnhancedLabelProcessor
            label_processor = EnhancedLabelProcessor()

            if task_type not in ('classification','regression'):
                raise FeatureSelectionError(f'Unsupported feature-importance task type: {task_type}')

            # Process labels properly
            y_processed, label_metadata = label_processor.process_labels_smart(y, task_type)
            if task_type == 'classification':
                logger.debug("Label processing: %s classes", label_metadata.get('num_classes', 'N/A'))
            else:
                logger.debug("Label range: [%s, %s]", label_metadata.get('min_value', 'N/A'), label_metadata.get('max_value', 'N/A'))

        except Exception as preprocessing_error:
            logger.exception("Preprocessing failed: %s", preprocessing_error)
            # Fallback to minimal processing
            X_processed = np.array(X)
            y_processed = np.array(y)

        # For random forest or feature importance methods, use random forest to calculate feature importance
        if method in ['Feature Importance', 'Random Forest']:
            try:
                # Multiple importance calculation strategies
                logger.debug("Using Random Forest for feature importance calculation")

                # Choose appropriate random forest model based on task type
                if task_type == 'classification':
                    from sklearn.ensemble import RandomForestClassifier
                    model = RandomForestClassifier(
                        n_estimators=200,         # Increased for more stable importance
                        max_depth=None,          # Allow deeper trees for complex relationships
                        min_samples_split=2,     # Lower values for better feature discrimination
                        min_samples_leaf=1,      # Allow single-sample leaves for better discrimination
                        max_features='sqrt',     # Better feature selection for classification
                        bootstrap=True,          # Enable bootstrapping
                        random_state=42,
                        class_weight='balanced', # Handle class imbalance
                        n_jobs=-1
                    )
                else:
                    from sklearn.ensemble import RandomForestRegressor
                    model = RandomForestRegressor(
                        n_estimators=200,        # Increased for stability
                        max_depth=None,          # Allow deeper trees
                        min_samples_split=2,     # Lower values for better feature discrimination
                        min_samples_leaf=1,      # Allow single-sample leaves
                        max_features='sqrt',     # Better feature selection
                        bootstrap=True,
                        random_state=42,
                        n_jobs=-1
                    )

                # Fit the model
                model.fit(X_processed, y_processed)

                # Get feature importances
                if hasattr(model, 'feature_importances_'):
                    importances = model.feature_importances_.copy()

                    # Enhanced importance validation and correction
                    logger.debug("Raw importances - Max: %s, Min: %s, Mean: %s", float(importances.max()), float(importances.min()), float(importances.mean()))

                    # Check for problematic importance patterns
                    if importances.max() < 0.001:
                        logger.debug("WARNING: Feature importances are extremely low!")
                        logger.debug("Maximum importance: %s", importances.max())
                        logger.debug("Possible causes:")
                        logger.debug("1. Over-preprocessing removing signal")
                        logger.debug("2. Poor feature-target relationships")
                        logger.debug("3. Label quality issues")
                        logger.debug("4. Dataset too small or noisy")

                        # Enhanced fallback: Try multiple strategies
                        logger.debug("Trying enhanced importance calculation strategies...")

                        # Strategy 1: Permutation importance
                        try:
                            from sklearn.inspection import permutation_importance
                            logger.debug("Strategy 1: Permutation importance")
                            perm_importance = permutation_importance(
                                model, X_processed, y_processed,
                                n_repeats=5, random_state=42, n_jobs=-1
                            )
                            perm_importances = perm_importance.importances_mean

                            if perm_importances.max() > importances.max():
                                logger.debug("Permutation importance better: Max=%s", perm_importances.max())
                                importances = perm_importances

                        except Exception as perm_error:
                            logger.debug("Permutation importance failed: %s", perm_error)

                        # Strategy 2: Multiple Random Forest averaging
                        if importances.max() < 0.001:
                            try:
                                logger.debug("Strategy 2: Multiple Random Forest averaging")
                                ensemble_importances = []
                                for seed in [42, 123, 456, 789, 999]:
                                    if task_type == 'classification':
                                        temp_model = RandomForestClassifier(
                                            n_estimators=100, random_state=seed,
                                            class_weight='balanced', n_jobs=-1
                                        )
                                    else:
                                        temp_model = RandomForestRegressor(
                                            n_estimators=100, random_state=seed, n_jobs=-1
                                        )

                                    temp_model.fit(X_processed, y_processed)
                                    ensemble_importances.append(temp_model.feature_importances_)

                                # Average importances across models
                                avg_importances = np.mean(ensemble_importances, axis=0)
                                if avg_importances.max() > importances.max():
                                    logger.debug("Ensemble averaging better: Max=%s", avg_importances.max())
                                    importances = avg_importances

                            except Exception as ensemble_error:
                                logger.debug("Ensemble averaging failed: %s", ensemble_error)

                        # Strategy 3: Correlation-based importance
                        if importances.max() < 0.001:
                            try:
                                logger.debug("Strategy 3: Correlation-based importance")
                                if task_type == 'classification':
                                    # For classification, use mutual information
                                    from sklearn.feature_selection import mutual_info_classif
                                    corr_importances = mutual_info_classif(X_processed, y_processed, random_state=42)
                                else:
                                    # For regression, use correlation
                                    corr_importances = np.abs(np.corrcoef(X_processed.T, y_processed)[:-1, -1])
                                    corr_importances = np.nan_to_num(corr_importances)  # Handle NaN

                                if corr_importances.max() > importances.max():
                                    logger.debug("Correlation-based better: Max=%s", corr_importances.max())
                                    importances = corr_importances

                            except Exception as corr_error:
                                logger.debug("Correlation-based importance failed: %s", corr_error)

                    # Final normalization and validation
                    if importances.max() > 0:
                        # Normalize to sum to 1
                        importances = importances / importances.sum()

                        # Add small baseline to prevent complete zeros
                        min_importance = importances.max() * 0.001  # 0.1% of max
                        importances = np.maximum(importances, min_importance)
                        importances = importances / importances.sum()  # Re-normalize
                    else:
                        # Ultimate fallback: uniform distribution
                        logger.debug("Using uniform distribution as final fallback")
                        importances = np.ones(X.shape[1]) / X.shape[1]

                    logger.debug("Final feature importance calculation:")
                    logger.debug("Max: %s, Min: %s, Mean: %s", float(importances.max()), float(importances.min()), float(importances.mean()))
                    logger.debug("Non-zero features: %s/%s", np.sum(importances > 1e-6), len(importances))
                    return importances
                else:
                    logger.debug("Model does not have feature_importances_ attribute")
                    return self._calculate_mutual_info_importance_enhanced(X_processed, y_processed, task_type)

            except Exception as rf_error:
                logger.debug("Random forest feature importance calculation failed: %s", rf_error)
                return self._calculate_mutual_info_importance_enhanced(X_processed, y_processed, task_type)

        else:
            # For other methods, use appropriate sklearn selectors
            try:
                if method == 'SelectKBest':
                    from sklearn.feature_selection import SelectKBest, f_classif, f_regression

                    score_func = f_classif if task_type == 'classification' else f_regression
                    selector = SelectKBest(score_func=score_func, k='all')
                    selector.fit(X_processed, y_processed)
                    importances = selector.scores_

                    # Normalize scores
                    if importances is not None and np.ptp(importances) > 0:
                        importances = (importances - np.min(importances)) / np.ptp(importances)
                    else:
                        importances = np.ones(X.shape[1]) / X.shape[1]
                else:
                    # Default to enhanced mutual information
                    return self._calculate_mutual_info_importance_enhanced(X_processed, y_processed, task_type)

                return np.nan_to_num(importances)

            except Exception as method_error:
                logger.debug("%s feature importance calculation failed: %s", method, method_error)
                return self._calculate_mutual_info_importance_enhanced(X_processed, y_processed, task_type)

    def _calculate_mutual_info_importance_enhanced(self, X, y, task_type):
        """Enhanced mutual information calculation with multiple strategies"""
        import numpy as np

        try:
            logger.debug("Calculating enhanced mutual information importance...")
            logger.debug("Data shape: X=%s, y=%s", X.shape, len(y))
            logger.debug("Task type: %s", task_type)

            # Enhanced preprocessing for mutual information
            from sklearn.preprocessing import StandardScaler, RobustScaler

            # Use RobustScaler to handle outliers better
            scaler = RobustScaler()
            X_scaled = scaler.fit_transform(X)

            if task_type == 'classification':
                # Ensure proper label encoding
                if isinstance(y, pd.Series):
                    y_safe = y.astype(str)
                else:
                    y_safe = np.array([str(label) for label in y])

                from sklearn.preprocessing import LabelEncoder
                le = LabelEncoder()
                y_encoded = le.fit_transform(y_safe)

                logger.debug("Classification: %s classes", len(np.unique(y_encoded)))

                # Adaptive neighbor count
                n_neighbors = max(3, min(15, len(y_encoded) // 15))

                from sklearn.feature_selection import mutual_info_classif
                importances = mutual_info_classif(
                    X_scaled, y_encoded,
                    discrete_features=False,
                    n_neighbors=n_neighbors,
                    copy=True,
                    random_state=42
                )
            else:
                # Regression task
                n_neighbors = max(3, min(15, len(y) // 15))

                from sklearn.feature_selection import mutual_info_regression
                importances = mutual_info_regression(
                    X_scaled, y,
                    discrete_features=False,
                    n_neighbors=n_neighbors,
                    copy=True,
                    random_state=42
                )

            logger.debug("Mutual info raw - Max: %s, Min: %s", float(importances.max()), float(importances.min()))

            # Enhanced validation and fallback
            if np.all(importances < 1e-10):
                logger.debug("WARNING: Mutual information returned all zeros!")
                logger.debug("Trying fallback strategies...")

                # Zero mutual information is a valid observed result. Keep it;
                # variance or uniform scores would misrepresent the estimator.
                return importances

            # Post-processing: Ensure reasonable distribution
            if importances.max() > 0:
                # Add minimum baseline (prevents complete feature exclusion)
                min_importance = importances.max() * 0.005  # 0.5% of max
                importances = np.maximum(importances, min_importance)
                # Normalize
                importances = importances / importances.sum()

            logger.debug("Enhanced mutual information completed:")
            logger.debug("Final - Max: %s, Min: %s, Mean: %s", float(importances.max()), float(importances.min()), float(importances.mean()))
            logger.debug("Active features: %s/%s", np.sum(importances > importances.mean()), len(importances))

            return importances

        except Exception as e:
            logger.exception("Enhanced mutual information failed: %s", e)
            raise FeatureSelectionError(f'Mutual-information estimation failed: {e}') from e

    def apply_feature_selection(self, X, y=None, method=None, n_features=None, task_type='classification', **kwargs):
        """Apply feature selection method and return selected feature indices and importance scores"""
        try:

            import numpy as np

            if method is None:

                return np.arange(X.shape[1]), np.ones(X.shape[1]) / X.shape[1]

            importances = self._calculate_feature_importance(X, y, method, task_type, **kwargs)

            if any(isinstance(imp, np.ndarray) for imp in importances):
                importances = np.array([float(imp.mean()) if isinstance(imp, np.ndarray) else float(imp)
                                       for imp in importances])

            if n_features is None:
                n_features = X.shape[1] // 2
                n_features = max(1, min(n_features, X.shape[1]))

            indices = np.argsort(importances)[::-1][:n_features]

            logger.debug("Selected features indices: %s, shape: %s", indices, indices.shape)
            logger.debug("Importances shape: %s", importances.shape)

            return indices, importances
        except Exception as e:
            logger.exception("Error applying feature selection method '%s'", method)
            raise FeatureSelectionError(f"Error applying feature selection method '{method}': {e}") from e
