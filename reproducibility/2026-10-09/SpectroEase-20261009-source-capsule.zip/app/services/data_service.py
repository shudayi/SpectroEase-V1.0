# app/services/data_service.py

from app.utils.exceptions import DataServiceError, DataQualityError
import pandas as pd
from sklearn.model_selection import (
    train_test_split, KFold, StratifiedKFold, LeaveOneGroupOut,
    ShuffleSplit, StratifiedShuffleSplit, GroupKFold, GroupShuffleSplit,
)
from interfaces.data_partitioning_algorithm import DataPartitioningAlgorithm
import logging
import numpy as np
import os
import uuid
import time
from typing import Dict, Any
from app.utils.label_processor import EnhancedLabelProcessor
from app.utils.column_mapping import spectral_column_positions

class DataService:
    def __init__(self, plugins: dict):
        self.plugins = plugins
        self.label_mapping = None
        self.label_processor = EnhancedLabelProcessor()
        # 数据导入保守规则阈值（需求D）
        from config.settings import Settings
        self.settings = Settings()
        self.data_import_stats = {}  # 存储数据导入Statistics

    def _read_csv_with_fallback(self, file_path: str, **kwargs) -> pd.DataFrame:
        """Read a CSV-like file with encoding fallback (utf-8 -> gbk -> latin1)."""
        from app.parsers.csv_parser import _read_with_encoding_fallback
        options = {key: value for key, value in kwargs.items() if key != 'sep'}
        return _read_with_encoding_fallback(
            file_path, sep=kwargs.get('sep', ','), **options
        )

    def load_data(self, file_path: str, skip_first_row=False) -> pd.DataFrame:
        try:
            # Delegate format dispatch to the parser registry. CSV/TXT/TSV
            # still honour ``skip_first_row`` for backwards compatibility.
            ext = os.path.splitext(file_path)[1].lower()
            header = 1 if skip_first_row else 0

            if ext in ('.csv', '.tsv', '.txt') and skip_first_row:
                from app.parsers.csv_parser import (
                    _infer_txt_separator,
                    _read_with_encoding_fallback,
                )
                # Preserve the legacy explicit formats while making TXT use
                # the same content-based inference as the parser registry.
                sep = '\t' if ext == '.tsv' else ','
                if ext == '.txt':
                    sep = _infer_txt_separator(file_path, skip_first_line=True)
                data = _read_with_encoding_fallback(file_path, sep=sep, header=header)
                data.columns = [_c if not _c.startswith('Unnamed') else '' for _c in data.columns]
            else:
                from app.parsers import get_parser
                parser = get_parser(file_path)
                if parser is None:
                    raise DataServiceError(f"Unsupported file format: {file_path}")
                try:
                    data = parser.parse(file_path)
                except NotImplementedError as exc:
                    raise DataServiceError(str(exc))

            # Drop all-NaN rows once
            data = data.dropna(how='all').reset_index(drop=True)

            # Data quality check and interactive handling (Reviewer 1 Comment 1)
            processed_data = self._handle_data_quality_issues(data, file_path)

            # 数据导入保守规则检查（需求D）
            self.data_import_stats = self._analyze_data_quality(processed_data, file_path)

            # 应用数据类型转换和质量检查
            processed_data = self._apply_conservative_rules(processed_data)

            return processed_data
        except DataServiceError:
            raise
        except Exception as e:
            raise DataServiceError(f"Error loading data: {str(e)}")
    
    def _handle_data_quality_issues(self, data: pd.DataFrame, file_path: str) -> pd.DataFrame:
        """Analyze data quality and raise DataQualityError if user interaction is needed.

        The service layer must not create UI dialogs; the caller (controller/view)
        catches DataQualityError and presents the interactive dialog.
        """
        from app.views.data_quality_dialog import DataQualityAnalyzer

        analysis = DataQualityAnalyzer.analyze_data_quality(data)

        if analysis['severity'] == 'none':
            logging.info("No data quality issues detected")
            return data

        logging.warning("Data quality issues detected (severity: %s)", analysis['severity'])
        raise DataQualityError(
            "Data quality issues detected",
            analysis=analysis,
            data=data
        )
    
    def _apply_default_data_quality_handling(self, data: pd.DataFrame, analysis: Dict[str, Any]) -> pd.DataFrame:
        """Apply default data quality handling when no GUI is available"""
        processed_data = data.copy()
        
        # Remove infinite values
        if 'inf' in analysis['issues']:
            numeric_cols = processed_data.select_dtypes(include=[np.number]).columns
            for col in numeric_cols:
                processed_data = processed_data[~np.isinf(processed_data[col])]
            logging.info("Removed infinite values")

        # Handle NaN values based on severity
        if 'nan' in analysis['issues']:
            nan_info = analysis['issues']['nan']
            if nan_info['max_nan_percentage'] > 50:
                # Remove columns with >50% NaN
                nan_percentages = processed_data.isnull().sum() / len(processed_data)
                cols_to_remove = nan_percentages[nan_percentages > 0.5].index
                processed_data = processed_data.drop(columns=cols_to_remove)
                logging.info("Removed %d columns with >50%% NaN values", len(cols_to_remove))

            # Remove rows with any remaining NaN
            processed_data = processed_data.dropna()
            logging.info("Removed rows with NaN values")
        
        return processed_data
    
    def _analyze_data_quality(self, data: pd.DataFrame, file_path: str) -> dict:
        """分析数据质量并生成Statistics（需求D）"""
        stats = {
            'file_path': file_path,
            'total_rows': len(data),
            'total_columns': len(data.columns),
            'column_analysis': {},
            'warnings': []
        }
        
        for col_name in data.columns:
            col_data = data[col_name]
            col_stats = {
                'name': col_name,
                'total_values': len(col_data),
                'missing_count': col_data.isnull().sum(),
                'missing_rate': col_data.isnull().sum() / len(col_data),
                'unique_count': col_data.nunique(),
                'data_type': str(col_data.dtype),
                'numeric_convertible_count': 0,
                'numeric_conversion_rate': 0.0,
                'conversion_decision': 'keep_original'
            }
            
            # 检查数值转换可能性
            if col_data.dtype == 'object':
                numeric_count = 0
                for val in col_data.dropna():
                    try:
                        float(val)
                        numeric_count += 1
                    except (ValueError, TypeError):
                        pass
                
                col_stats['numeric_convertible_count'] = numeric_count
                col_stats['numeric_conversion_rate'] = numeric_count / len(col_data.dropna()) if len(col_data.dropna()) > 0 else 0.0
                
                # 应用数值转换阈值
                if col_stats['numeric_conversion_rate'] >= self.settings.numeric_conversion_threshold:
                    col_stats['conversion_decision'] = 'convert_to_numeric'
                    logging.info(f"Column '{col_name}': {col_stats['numeric_conversion_rate']:.1%} numeric convertible (>= {self.settings.numeric_conversion_threshold:.1%} threshold) - Will convert to numeric")
                else:
                    col_stats['conversion_decision'] = 'keep_as_string'
                    logging.info(f"Column '{col_name}': {col_stats['numeric_conversion_rate']:.1%} numeric convertible (< {self.settings.numeric_conversion_threshold:.1%} threshold) - Will keep as string")
            
            # 检查缺失率警戒线
            if col_stats['missing_rate'] > self.settings.missing_rate_warning_threshold:
                warning_msg = f"Column '{col_name}' has high missing rate: {col_stats['missing_rate']:.1%} (> {self.settings.missing_rate_warning_threshold:.1%} threshold)"
                stats['warnings'].append(warning_msg)
                logging.warning(warning_msg)
            
            stats['column_analysis'][col_name] = col_stats
        
        # 记录总体统计
        logging.info(f"Data import analysis completed for {file_path}:")
        logging.info(f"  - Total: {stats['total_rows']} rows, {stats['total_columns']} columns")
        logging.info(f"  - Warnings: {len(stats['warnings'])} issues detected")
        logging.info(f"  - Thresholds: numeric_conversion={self.settings.numeric_conversion_threshold:.1%}, missing_rate_warning={self.settings.missing_rate_warning_threshold:.1%}")
        
        return stats
    
    def _apply_conservative_rules(self, data: pd.DataFrame) -> pd.DataFrame:
        """应用保守规则进行数据处理（需求D）"""
        processed_data = data.copy()
        
        for col_name, col_stats in self.data_import_stats['column_analysis'].items():
            if col_stats['conversion_decision'] == 'convert_to_numeric':
                try:
                    # 转换为数值类型
                    processed_data[col_name] = pd.to_numeric(processed_data[col_name], errors='coerce')
                    logging.info(f"Successfully converted column '{col_name}' to numeric type")
                except Exception as e:
                    logging.error(f"Failed to convert column '{col_name}' to numeric: {e}")
        
        return processed_data

    def load_data_with_first_row(self, file_path: str) -> pd.DataFrame:
        return self.load_data(file_path, skip_first_row=True)

    def _auto_detect_target_column(self, data, target_column=None):
        if target_column is not None and isinstance(target_column, int):
            if 0 <= target_column < data.shape[1]:
                return target_column
        if target_column is not None and isinstance(target_column, str):
            if target_column in data.columns:
                return data.columns.get_loc(target_column)
        category_keywords = ['label', 'class', 'target', 'category', 'type', 'variety', 'group']
        for col_idx, col_name in enumerate(data.columns):
            if any(keyword.lower() in str(col_name).lower() for keyword in category_keywords):
                return col_idx
        for col_idx in range(min(5, data.shape[1])):
            col = data.iloc[:, col_idx]
            unique_count = col.nunique()
            if 2 <= unique_count <= 20 and unique_count / len(col) < 0.1:
                return col_idx
        return 0

    def partition_data(self, data: pd.DataFrame, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Refactored data partitioning method.
        This method is now a pure function that relies entirely on the controller 
        for label processing and task type determination. It only performs the split.
        """
        if data is None:
            raise ValueError("Data is required for partitioning")
        params = dict(params)

        # --- Get pre-processed data from params ---
        task_type = params.get('task_type')
        target_column_index = params.get('target_column', 0)
        processed_labels = params.get('processed_labels') # Numeric labels from controller
        original_labels = params.get('original_labels')   # Original labels from controller
        label_metadata = params.get('label_metadata')

        if task_type is None or processed_labels is None or original_labels is None:
            raise ValueError("Controller did not provide necessary label processing information (task_type, processed_labels).")

        # --- Separate features (X) and labels (y), keyed by internal row identity ---
        if not isinstance(target_column_index, int) or not 0 <= target_column_index < data.shape[1]:
            raise ValueError("target_column must identify a valid data column")
        keys = params.get('row_keys')
        if keys is None:
            # Direct service callers still receive an identity contract. The
            # GUI passes DataModel's keys so all stages share the same IDs.
            keys = [f"rk_{uuid.uuid4().hex}" for _ in range(len(data))]
        keys = list(keys)
        if len(keys) != len(data) or len(set(keys)) != len(keys):
            raise ValueError("row_keys must be unique and match the source row count")
        if len(processed_labels) != len(data) or len(original_labels) != len(data):
            raise ValueError("Processed and original labels must match the source row count")

        row_index = pd.Index(keys, name='_row_key')
        sample_column = self._resolve_identity_column(data, params.get('sample_id_column'), 'sample_id')
        group_column = self._resolve_identity_column(data, params.get('group_id_column'), 'group_id')
        if sample_column == target_column_index or group_column == target_column_index:
            raise ValueError("sample_id and group_id columns must be different from the target column")
        if sample_column is not None and sample_column == group_column:
            raise ValueError("sample_id and group_id must use separate explicit columns")
        group_validation = bool(params.get('group_validation', False))
        if group_validation and group_column is None:
            raise ValueError("Group validation was requested, but no group_id column was selected")

        feature_positions = spectral_column_positions(
            data, target_column_index, (sample_column, group_column),
            params.get('wavelength_columns'),
        )
        params['wavelength_columns'] = list(feature_positions)
        X = data.iloc[:, feature_positions].copy()
        X.index = row_index
        y_numeric = pd.Series(np.asarray(processed_labels), index=row_index, name='target_numeric')
        y_original = pd.Series(
            np.asarray(original_labels), index=row_index,
            name=data.columns[target_column_index],
        )
        sample_ids = self._identity_series(data, sample_column, row_index, 'sample_id')
        group_ids = self._identity_series(data, group_column, row_index, 'group_id')
        self._validate_identity_values(sample_ids, 'sample_id')
        self._validate_identity_values(group_ids, 'group_id')
        if group_validation:
            self._validate_physical_ids(sample_ids, group_ids)

        # --- Determine Stratification ---
        # Stratification should be based on the numeric (integer) labels for classification
        stratify_labels = y_numeric if task_type == 'classification' else None

        # --- Select and Execute Partitioning Method ---
        if method == "Train-Test Split":
            test_size = params.get('test_size', 0.3)
            random_state = params.get('random_state', 42)
            shuffle = params.get('shuffle', True)
            
            if group_validation:
                splitter = GroupShuffleSplit(
                    n_splits=1, test_size=test_size, random_state=random_state
                )
                train_idx, test_idx = next(splitter.split(X, y_numeric, groups=group_ids))
                X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
                y_train_orig, y_test_orig = y_original.iloc[train_idx], y_original.iloc[test_idx]
                y_train_num, y_test_num = y_numeric.iloc[train_idx], y_numeric.iloc[test_idx]
            else:
                train_idx, test_idx = None, None
                X_train, X_test, y_train_orig, y_test_orig, y_train_num, y_test_num = train_test_split(
                    X, y_original, y_numeric,
                    test_size=test_size,
                    random_state=random_state,
                    shuffle=shuffle,
                    stratify=stratify_labels
                )
            
            result = {
                'X_train': X_train, 'X_test': X_test,
                'y_train': y_train_orig, 'y_test': y_test_orig,
                'train_row_keys': X_train.index.tolist(),
                'test_row_keys': X_test.index.tolist(),
                'y_train_numeric': y_train_num, 'y_test_numeric': y_test_num, # For internal use
                'method': method, 'params': params, 'label_metadata': label_metadata
            }
            return self._attach_identity_metadata(
                result, sample_ids, group_ids, sample_column, group_column, group_validation, feature_positions
            )

        elif method == "K-Fold":
            n_splits = params.get('n_splits', 5)
            random_state = params.get('random_state', 42)
            shuffle = params.get('shuffle', True)
            
            if group_validation:
                self._validate_group_fold_capacity(group_ids, y_numeric, task_type, n_splits)
                if task_type == 'classification':
                    try:
                        from sklearn.model_selection import StratifiedGroupKFold
                    except ImportError as exc:
                        raise ValueError("This scikit-learn version lacks StratifiedGroupKFold; group validation cannot run") from exc
                    kf = StratifiedGroupKFold(
                        n_splits=n_splits, shuffle=shuffle, random_state=random_state if shuffle else None
                    )
                    splitter = kf.split(X, y_numeric, groups=group_ids)
                else:
                    kf = GroupKFold(n_splits=n_splits)
                    splitter = kf.split(X, y_numeric, groups=group_ids)
            elif task_type == 'classification':
                kf = StratifiedKFold(n_splits=n_splits, shuffle=shuffle, random_state=random_state if shuffle else None)
                splitter = kf.split(X, y_numeric)
            else:
                kf = KFold(n_splits=n_splits, shuffle=shuffle, random_state=random_state if shuffle else None)
                splitter = kf.split(X)

            # Return the first fold as a representative split
            train_idx, test_idx = next(splitter)
            X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
            y_train_orig, y_test_orig = y_original.iloc[train_idx], y_original.iloc[test_idx]
            y_train_num, y_test_num = y_numeric.iloc[train_idx], y_numeric.iloc[test_idx]
            
            result = {
                'X_train': X_train, 'X_test': X_test,
                'y_train': y_train_orig, 'y_test': y_test_orig,
                'train_row_keys': X_train.index.tolist(),
                'test_row_keys': X_test.index.tolist(),
                'y_train_numeric': y_train_num, 'y_test_numeric': y_test_num,
                'method': method, 'params': params, 'label_metadata': label_metadata,
                'cv_splits': list(
                    kf.split(X, y_numeric, groups=group_ids) if group_validation and task_type == 'classification'
                    else kf.split(X, y_numeric) if task_type == 'classification'
                    else kf.split(X, y_numeric, groups=group_ids) if group_validation
                    else kf.split(X)
                )
            }
            return self._attach_identity_metadata(
                result, sample_ids, group_ids, sample_column, group_column, group_validation, feature_positions
            )

        elif method == "LOGO":
            if not group_validation:
                raise ValueError("Leave-One-Group-Out requires group validation and an explicit group_id column")
            if group_ids.nunique() < 2:
                raise ValueError("Leave-One-Group-Out requires at least two unique groups")
            splitter = LeaveOneGroupOut()
            cv_splits = list(splitter.split(X, y_numeric, groups=group_ids))
            train_idx, test_idx = cv_splits[0]
            X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
            result = {
                'X_train': X_train, 'X_test': X_test,
                'y_train': y_original.iloc[train_idx], 'y_test': y_original.iloc[test_idx],
                'train_row_keys': X_train.index.tolist(), 'test_row_keys': X_test.index.tolist(),
                'y_train_numeric': y_numeric.iloc[train_idx], 'y_test_numeric': y_numeric.iloc[test_idx],
                'method': method, 'params': params, 'label_metadata': label_metadata,
                'cv_splits': cv_splits,
            }
            return self._attach_identity_metadata(
                result, sample_ids, group_ids, sample_column, group_column, group_validation, feature_positions
            )

        # --- Handle Plugin-based Methods ---
        elif method in self.plugins:
            plugin_method = params.get('method')
            if group_validation and not (
                method == 'Advanced Splitter' and plugin_method == 'group_shuffle'
            ):
                raise ValueError("This partition plugin does not declare group-aware splitting; choose Train-Test Split or K-Fold")
            algorithm: DataPartitioningAlgorithm = self.plugins[method]
            # The plugin is expected to handle the data and params
            # We pass the combined data with original labels
            combined_data = X.copy()
            target_col = y_original.name if hasattr(y_original, 'name') and y_original.name else 'target'
            # Ensure the target column name does not collide with an existing feature column.
            if target_col in combined_data.columns:
                base = target_col
                suffix = 1
                target_col = f"{base}_{suffix}"
                while target_col in combined_data.columns:
                    suffix += 1
                    target_col = f"{base}_{suffix}"
            combined_data[target_col] = y_original

            plugin_params = dict(params)
            if group_ids is not None:
                plugin_params['group_ids'] = group_ids
            result = algorithm.partition(combined_data, plugin_params)
            self._validate_plugin_row_alignment(result, X, row_index)
            result['label_metadata'] = label_metadata
            return self._attach_identity_metadata(
                result, sample_ids, group_ids, sample_column, group_column, group_validation, feature_positions
            )
            
        else:
            raise ValueError(f"Partitioning method '{method}' not implemented or supported by this refactored service.")

    @staticmethod
    def _resolve_identity_column(data, selected, name):
        if selected in (None, '', -1):
            return None
        if isinstance(selected, str) and selected in data.columns:
            return int(data.columns.get_loc(selected))
        try:
            index = int(selected)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{name} must identify an explicit source column") from exc
        if index < 0 or index >= data.shape[1]:
            raise ValueError(f"{name} column is outside the source data")
        return index

    @staticmethod
    def _identity_series(data, column_index, row_index, name):
        if column_index is None:
            return None
        # Canonicalize once at the data-service boundary. These exact values
        # flow to splitters, metadata, analyzer CV, and search.
        values = data.iloc[:, column_index].astype('string').str.strip()
        values.index = row_index
        values.name = name
        return values

    @staticmethod
    def _validate_identity_values(values, name):
        if values is None:
            return
        text = values.astype('string')
        null_tokens = text.str.casefold().isin({'nan', 'none', '<na>'})
        if text.isna().any() or (text == '').any() or null_tokens.any():
            raise ValueError(
                f"{name} contains missing, blank, or null-sentinel values "
                "(nan/none/<na>); correct the selected ID column before splitting"
            )

    @staticmethod
    def _validate_physical_ids(sample_ids, group_ids):
        if group_ids is None:
            raise ValueError("Group validation requires an explicit group_id column")
        groups = group_ids
        if sample_ids is not None:
            samples = sample_ids
            mapping = pd.DataFrame({'sample': samples, 'group': groups}).drop_duplicates()
            if mapping['sample'].duplicated().any():
                raise ValueError("A sample_id maps to multiple group_id values; resolve the ambiguous physical IDs")

    @staticmethod
    def _validate_group_fold_capacity(group_ids, labels, task_type, n_splits):
        if group_ids is None:
            raise ValueError("Group validation requires an explicit group_id column")
        n_groups = int(group_ids.nunique(dropna=False))
        if n_groups < n_splits:
            raise ValueError(f"Group validation needs at least {n_splits} unique groups; found {n_groups}")
        if task_type == 'classification':
            pairs = pd.DataFrame({'label': np.asarray(labels), 'group': np.asarray(group_ids)})
            groups_per_class = pairs.drop_duplicates().groupby('label')['group'].nunique()
            if (groups_per_class < n_splits).any():
                bad = groups_per_class[groups_per_class < n_splits].to_dict()
                raise ValueError(f"Each class must occur in at least {n_splits} groups for stratified group CV; found {bad}")

    @staticmethod
    def _attach_identity_metadata(result, sample_ids, group_ids, sample_column, group_column, group_validation, feature_positions=None):
        result.update({
            'wavelength_column_positions': list(feature_positions) if feature_positions is not None else None,
            'sample_id_column_index': sample_column,
            'group_id_column_index': group_column,
            'group_validation': bool(group_validation),
        })
        train_keys = list(result['X_train'].index)
        test_keys = list(result['X_test'].index)
        result['sample_id_train'] = sample_ids.loc[train_keys] if sample_ids is not None else None
        result['sample_id_test'] = sample_ids.loc[test_keys] if sample_ids is not None else None
        result['group_id_train'] = group_ids.loc[train_keys] if group_ids is not None else None
        result['group_id_test'] = group_ids.loc[test_keys] if group_ids is not None else None
        if group_validation:
            train_groups, test_groups = set(result['group_id_train']), set(result['group_id_test'])
            if train_groups & test_groups:
                raise ValueError("Group-aware split placed the same group in train and test")
            if sample_ids is not None and set(result['sample_id_train']) & set(result['sample_id_test']):
                raise ValueError("Group-aware split placed the same physical sample in train and test")
        return result

    @staticmethod
    def _validate_plugin_row_alignment(result, source_X, all_row_keys):
        """Fail closed when a splitter plugin cannot preserve internal row keys."""
        if not isinstance(result, dict):
            raise ValueError("Partitioning plugin must return a mapping")
        required = ('X_train', 'X_test', 'y_train', 'y_test')
        if any(result.get(key) is None for key in required):
            raise ValueError("Partitioning plugin must return X/y train and test values")
        X_train, X_test = result['X_train'], result['X_test']
        y_train, y_test = result['y_train'], result['y_test']
        if not all(isinstance(value, pd.DataFrame) for value in (X_train, X_test)):
            raise ValueError("Partitioning plugin must return row-key-indexed DataFrames for X")
        if not all(isinstance(value, pd.Series) for value in (y_train, y_test)):
            raise ValueError("Partitioning plugin must return row-key-indexed Series for y")
        if list(X_train.columns) != list(source_X.columns) or list(X_test.columns) != list(source_X.columns):
            raise ValueError("Partitioning plugin changed the feature columns; row alignment is unverified")
        train_keys, test_keys = X_train.index, X_test.index
        if not train_keys.is_unique or not test_keys.is_unique or len(set(train_keys) & set(test_keys)):
            raise ValueError("Partitioning plugin returned duplicate or overlapping row keys")
        if not train_keys.isin(all_row_keys).all() or not test_keys.isin(all_row_keys).all():
            raise ValueError("Partitioning plugin returned unknown row keys")
        if not X_train.index.equals(y_train.index) or not X_test.index.equals(y_test.index):
            raise ValueError("Partitioning plugin X/y row-key order does not match")
        if X_train.index.name != '_row_key' or X_test.index.name != '_row_key':
            raise ValueError("Partitioning plugin must preserve the internal _row_key index name")
        result['train_row_keys'] = train_keys.tolist()
        result['test_row_keys'] = test_keys.tolist()

    def map_predictions_to_original(self, predictions, preserve_original=True):
        if self.label_mapping is None:
            return np.array([str(pred) for pred in predictions], dtype='<U50')
        
        if self.label_mapping.get('preserve_original_labels', False):
            if isinstance(predictions, np.ndarray):
                return np.array([str(pred) for pred in predictions], dtype='<U50')
            elif isinstance(predictions, pd.Series):
                return predictions.astype(str)
            else:
                return [str(pred) for pred in predictions]
        
        index_to_label = self.label_mapping.get('index_to_label', {})
        if not index_to_label:
            return np.array([str(pred) for pred in predictions], dtype='<U50')
        
        mapped_predictions = []
        for pred in predictions:
            try:
                if isinstance(pred, str):
                    try:
                        pred_int = int(float(pred))
                        mapped_label = index_to_label.get(pred_int, pred)
                    except (ValueError, TypeError):
                        mapped_label = pred
                else:
                    pred_int = int(round(float(pred)))
                    mapped_label = index_to_label.get(pred_int, f"Unknown_Class_{pred_int}")
                mapped_predictions.append(str(mapped_label))
            except Exception as map_error:
                mapped_predictions.append(str(pred))
        
        result = np.array(mapped_predictions, dtype='<U50')
        return result

    def _is_numeric(self, val):
        if val is None:
            return False
        try:
            float(val)
            return True
        except (ValueError, TypeError):
            return False

    def map_predictions_to_original_safe(self, predictions):
        try:
            if self.label_mapping is None:
                return np.array([str(pred) for pred in predictions])
            index_to_label = self.label_mapping.get('index_to_label', {})
            if not index_to_label:
                return np.array([str(pred) for pred in predictions])
            mapped_results = []
            for pred in predictions:
                try:
                    if isinstance(pred, (int, np.integer)):
                        mapped_label = index_to_label.get(pred, str(pred))
                    elif isinstance(pred, str):
                        try:
                            pred_int = int(pred)
                            mapped_label = index_to_label.get(pred_int, pred)
                        except ValueError:
                            mapped_label = pred
                    else:
                        mapped_label = str(pred)
                    mapped_results.append(str(mapped_label))
                except Exception as map_error:
                    mapped_results.append(str(pred))
            return np.array(mapped_results, dtype='<U50')
        except Exception as e:
            return np.array([str(pred) for pred in predictions])
