"""Private child-process entry point for candidate spectral transforms.

This is a reliability boundary (timeouts and crash containment), not an OS
security sandbox for code supplied by an adversary.
"""

from __future__ import annotations

import json


def run_candidate(connection, source: str, max_message_bytes: int) -> None:
    try:
        from app.services.algorithm_onboarding_service import _load_transform_local, _run_transform

        transform = _load_transform_local(source)
        connection.send_bytes(b'{"status":"ready"}')
        while True:
            request = json.loads(connection.recv_bytes(max_message_bytes).decode("utf-8"))
            if request.get("op") == "close":
                break
            if request.get("op") != "transform":
                connection.send_bytes(b'{"status":"error","detail":"Unknown worker operation"}')
                continue
            import numpy as np

            matrix = np.asarray(request["X"], dtype=float)
            output, detail = _run_transform(transform, matrix, request["parameters"])
            payload = {
                "status": "ok" if output is not None else "error",
                "detail": detail[:4096],
                "output": output.tolist() if output is not None else None,
            }
            encoded = json.dumps(payload, allow_nan=False, separators=(",", ":")).encode("utf-8")
            if len(encoded) > max_message_bytes:
                connection.send_bytes(b'{"status":"error","detail":"Worker output exceeds size limit"}')
            else:
                connection.send_bytes(encoded)
    except EOFError:
        pass
    except BaseException as exc:
        try:
            payload = json.dumps({
                "status": "error",
                "detail": f"Worker failed: {type(exc).__name__}: {str(exc)[:1024]}",
            }).encode("utf-8")
            connection.send_bytes(payload)
        except (OSError, EOFError, BrokenPipeError):
            pass
    finally:
        connection.close()
