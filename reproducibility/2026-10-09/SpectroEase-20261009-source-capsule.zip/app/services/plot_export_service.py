"""Deterministic, publication-oriented exports for existing Matplotlib figures.

The exporter clones the current figure before resizing or styling it. This keeps
the on-screen Qt figure and its navigation state independent from print sizing.
"""

from __future__ import annotations

import copy
import json
import math
import platform
from datetime import datetime, timezone
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import matplotlib
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg

from app.ui import design_tokens as tok
from app.version import APP_VERSION, APP_VERSION_SOURCE


SUPPORTED_FORMATS = ("pdf", "svg", "png", "tiff")
DEFAULT_RASTER_DPI = tok.MPL_EXPORT_DEFAULT_DPI
MM_PER_INCH = 25.4

EXPORT_RC = {
    # Keep text searchable/editable in PDF and SVG outputs.
    "pdf.fonttype": 42,
    "pdf.use14corefonts": False,
    "svg.fonttype": "none",
    "ps.fonttype": 42,
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "Microsoft YaHei", "Noto Sans CJK SC"],
}


@dataclass(frozen=True)
class ExportProfile:
    """Immutable physical-size and rendering contract for one figure export."""

    width_mm: float = tok.MPL_EXPORT_SINGLE_COLUMN_MM
    height_mm: float | None = None
    format: str = "pdf"
    dpi: int = DEFAULT_RASTER_DPI
    publication_style: bool = True

    def __post_init__(self):
        if self.height_mm is None:
            object.__setattr__(self, "height_mm", float(self.width_mm) * 2 / 3)
        normalized = str(self.format).lower()
        if normalized == "tif":
            normalized = "tiff"
        object.__setattr__(self, "format", normalized)


def _jsonable(value: Any) -> Any:
    """Convert common NumPy/path values into stable JSON-friendly values."""
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _axes_metadata(figure) -> list[dict[str, str]]:
    axes = []
    for axis in figure.axes:
        item = {
            "title": axis.get_title(),
            "x_label": axis.get_xlabel(),
            "y_label": axis.get_ylabel(),
        }
        if hasattr(axis, "get_zlabel"):
            item["z_label"] = axis.get_zlabel()
        axes.append(item)
    return axes


def apply_publication_style(figure) -> None:
    """Apply restrained, editable-figure styling to an export-only clone.

    This is a configurable starting point inspired by common journal figure
    guidance; it does not validate a figure against a particular journal.
    """
    figure.patch.set_facecolor("white")

    for axis in figure.axes:
        axis.set_facecolor("white")
        axis.set_title(axis.get_title(), fontsize=8, color="#20242a")

        for spine in axis.spines.values():
            spine.set_color("#20242a")
            spine.set_linewidth(0.7)

        for dimension in (axis.xaxis, axis.yaxis):
            dimension.label.set_fontfamily("sans-serif")
            dimension.label.set_fontsize(7)
            dimension.label.set_color("#20242a")
            dimension.set_tick_params(labelsize=6, colors="#20242a", direction="out")
        if hasattr(axis, "zaxis"):
            axis.zaxis.label.set_fontfamily("sans-serif")
            axis.zaxis.label.set_fontsize(7)
            axis.zaxis.label.set_color("#20242a")
            axis.zaxis.set_tick_params(labelsize=6, colors="#20242a", direction="out")

        # Matplotlib stores gridlines as tick artists. Hide only the grid layer;
        # keep plotted data and category labels unchanged.
        axis.grid(False)
        for text in axis.texts:
            text.set_fontfamily("sans-serif")
            text.set_fontsize(min(text.get_fontsize(), 7))
            text.set_color("#20242a")

        legend = axis.get_legend()
        if legend is not None:
            legend.set_frame_on(False)
            for text in legend.get_texts():
                text.set_fontfamily("sans-serif")
                text.set_fontsize(6)
                text.set_color("#20242a")
            legend.get_title().set_fontsize(6)
            legend.get_title().set_color("#20242a")

    # Layout and rendering happen only on this clone.
    FigureCanvasAgg(figure)
    try:
        from app.ui.mpl_layout import layout_figure
        layout_figure(figure, legend_fontsize=6)
    except (RuntimeError, ValueError):
        # Some 3D or custom Axes layouts do not support tight_layout.
        pass


def export_figure(
    figure,
    file_path: str | Path,
    *,
    profile: ExportProfile | None = None,
    width_mm: float = tok.MPL_EXPORT_SINGLE_COLUMN_MM,
    height_mm: float | None = None,
    fmt: str | None = None,
    dpi: int = DEFAULT_RASTER_DPI,
    publication_style: bool = True,
    chart_type: str | None = None,
    metadata: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Export a cloned figure at fixed physical dimensions and write a sidecar.

    Profiles carry both dimensions, independent of the screen figure aspect
    ratio. Legacy keyword calls without ``height_mm`` use the application's
    3:2 default aspect. ``dpi`` controls PNG/TIFF pixel dimensions and raster
    artists embedded in PDF/SVG; vector lines and editable text remain
    resolution independent.
    """
    if profile is None:
        profile = ExportProfile(
            width_mm=width_mm,
            height_mm=height_mm if height_mm is not None else float(width_mm) * 2 / 3,
            format=fmt or Path(file_path).suffix.lstrip(".") or "pdf",
            dpi=dpi,
            publication_style=publication_style,
        )
    width_mm = profile.width_mm
    height_mm = profile.height_mm
    fmt = profile.format
    dpi = profile.dpi
    publication_style = profile.publication_style

    target = Path(file_path)
    chosen_format = (fmt or target.suffix.lstrip(".") or "pdf").lower()
    if chosen_format == "tif":
        chosen_format = "tiff"
    if chosen_format not in SUPPORTED_FORMATS:
        raise ValueError(f"Unsupported figure format: {chosen_format}")

    try:
        width_mm = float(width_mm)
    except (TypeError, ValueError) as exc:
        raise ValueError("Figure width must be a number in millimetres") from exc
    if not math.isfinite(width_mm) or not tok.MPL_EXPORT_MIN_WIDTH_MM <= width_mm <= tok.MPL_EXPORT_MAX_WIDTH_MM:
        raise ValueError("Figure width must be between 20 and 300 mm")
    try:
        height_mm = float(height_mm)
    except (TypeError, ValueError) as exc:
        raise ValueError("Figure height must be a number in millimetres") from exc
    if not math.isfinite(height_mm) or not tok.MPL_EXPORT_MIN_HEIGHT_MM <= height_mm <= tok.MPL_EXPORT_MAX_HEIGHT_MM:
        raise ValueError("Figure height must be between 20 and 300 mm")
    try:
        dpi = int(dpi)
    except (TypeError, ValueError) as exc:
        raise ValueError("DPI must be an integer") from exc
    if not 72 <= dpi <= 1200:
        raise ValueError("DPI must be between 72 and 1200")
    if not figure.axes:
        raise ValueError("There is no plotted figure to export")

    suffix = ".tif" if chosen_format == "tiff" else f".{chosen_format}"
    if target.suffix.lower() != suffix:
        target = target.with_suffix(suffix)
    target.parent.mkdir(parents=True, exist_ok=True)

    export_figure = copy.deepcopy(figure)
    export_figure.set_size_inches(width_mm / MM_PER_INCH, height_mm / MM_PER_INCH, forward=False)
    export_figure.set_dpi(dpi)
    if publication_style:
        apply_publication_style(export_figure)
    else:
        FigureCanvasAgg(export_figure)

    with matplotlib.rc_context(EXPORT_RC):
        export_figure.savefig(
            target,
            format=chosen_format,
            dpi=dpi,
            bbox_inches=None,
            facecolor="white" if publication_style else export_figure.get_facecolor(),
            edgecolor="none",
            transparent=False,
        )

    sidecar = target.with_suffix(target.suffix + ".json")
    axes = _axes_metadata(figure)
    document = {
        "schema_version": 1,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "application": {
            "name": "SpectroEase",
            "version": APP_VERSION,
            "version_source": APP_VERSION_SOURCE,
        },
        "software": {
            "python": platform.python_version(),
            "matplotlib": matplotlib.__version__,
            "numpy": np.__version__,
        },
        "chart_type": chart_type or "Matplotlib figure",
        "format": chosen_format,
        "width_mm": width_mm,
        "height_mm": height_mm,
        "dpi": dpi,
        "dpi_note": (
            "Controls raster pixels and raster artists embedded in PDF/SVG; "
            "vector lines and editable text are resolution independent."
        ),
        "publication_style": bool(publication_style),
        "axes": axes,
        "metadata": _jsonable(metadata or {}),
    }
    sidecar.write_text(json.dumps(document, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"figure_path": str(target), "sidecar_path": str(sidecar), **document}
