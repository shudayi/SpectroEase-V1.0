"""Bounded child entry for trusted verified-algorithm candidates.

The process boundary contains crashes and timeouts. It is not an adversarial
security sandbox: a child has its parent's OS identity and filesystem access.
"""

from __future__ import annotations

import json


def run_job(connection, source: str, operation: str, payload: dict, max_bytes: int) -> None:
    try:
        from app.services.verified_algorithm_service import _load_functions_local, _run_local_operation

        functions = _load_functions_local(source)
        result = _run_local_operation(functions, operation, payload)
        encoded = json.dumps({"ok": True, "result": result}, allow_nan=False, separators=(",", ":")).encode("utf-8")
        if len(encoded) > max_bytes:
            raise ValueError("Candidate response exceeds message budget")
        connection.send_bytes(encoded)
    except BaseException as exc:
        try:
            encoded = json.dumps({"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:1024]}"}).encode("utf-8")
            connection.send_bytes(encoded[:max_bytes])
        except (OSError, EOFError, BrokenPipeError):
            pass
    finally:
        connection.close()
