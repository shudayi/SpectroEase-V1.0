"""Model diagnostics in original target units, with explicit statistical scope.

Regression formulas follow NIST's regression diagnostics reference. ROC/PR
curves use genuine sklearn classifier scores, never encoded hard predictions.
Every Figure is owned by the caller and uses Agg; no pyplot/global GUI state.
"""
from __future__ import annotations

import numpy as np
from scipy.stats import t, f
from sklearn.base import clone
from sklearn.linear_model import LinearRegression
from sklearn.cross_decomposition import PLSRegression
from sklearn.metrics import (roc_curve, precision_recall_curve, auc,
                             average_precision_score, confusion_matrix)
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from textwrap import fill


def _vector(value, name):
    a = np.asarray(value)
    if a.ndim == 2 and a.shape[1] == 1:
        a = a[:, 0]
    if a.ndim != 1:
        raise ValueError(f"{name} must be one-dimensional")
    return a


def _numeric(value, name):
    a = np.asarray(value, dtype=float)
    if not np.isfinite(a).all():
        raise ValueError(f"{name} contains nonfinite values")
    return a


def _boundary(model, X):
    predictor = getattr(model, 'fitted_predictor', None) or model
    if hasattr(predictor, '_prepare_X') and hasattr(predictor, 'estimator'):
        return predictor, predictor.estimator, predictor._prepare_X(X)
    return predictor, predictor, X


def _predict(model, X):
    if hasattr(model, 'predict_result'):
        return _vector(model.predict_result(X, enforce_disjoint=False).predictions, 'predictions')
    return _vector(model.predict(X), 'predictions')


def generate_diagnostics(model, X, y, task_type, *, X_train=None, y_train=None,
                         alpha=.05, bootstrap_iterations=200, random_state=42):
    """Return JSON-ready diagnostic data without refitting the deployed model.

    X_train must be the same input representation used to fit the predictor.
    Exact linear intervals assume independent, homoscedastic Gaussian errors.
    Other regressors use a training-pairs bootstrap mean-response band; this
    approximate band does not cover a new noisy observation or distribution shift.
    """
    if task_type not in {'classification', 'regression'}:
        raise ValueError('task_type must be classification or regression')
    if not 0 < alpha < 1:
        raise ValueError('alpha must be strictly between zero and one')
    truth = _vector(y, 'targets')
    predictor, estimator, prepared = _boundary(model, X)
    predicted = _predict(predictor, X)
    if len(truth) != len(predicted) or len(truth) == 0:
        raise ValueError('Nonempty targets and predictions must align')
    result = {'schema_version': 1, 'task_type': task_type,
              'observed': truth.tolist(), 'predicted': predicted.tolist(),
              'notes': [], 'unavailable': {}, 'confidence_level': 1 - alpha}
    if task_type == 'classification':
        _classification(result, predictor, estimator, prepared, truth, predicted)
    else:
        truth = _numeric(truth, 'targets')
        predicted = _numeric(predicted, 'predictions')
        result['residuals'] = (truth - predicted).tolist()
        if X_train is None or y_train is None:
            result['unavailable']['training_diagnostics'] = (
                'Training features and targets in the fitted input representation are required.')
        else:
            train_y = _numeric(_vector(y_train, 'training targets'), 'training targets')
            if len(train_y) != len(X_train):
                raise ValueError('Training features and targets must align')
            _, _, train_prepared = _boundary(predictor, X_train)
            _regression_geometry(result, predictor, estimator, prepared,
                                 train_prepared, X_train, train_y, alpha)
            if ('intervals' not in result and bootstrap_iterations
                    and getattr(predictor, 'group_validation', False)):
                result['unavailable']['bootstrap_intervals'] = (
                    'Row bootstrap is invalid for a group-validated fit; group-resampling is not implemented.')
            elif 'intervals' not in result and bootstrap_iterations:
                _bootstrap(result, predictor, X_train, train_y, X, alpha,
                           bootstrap_iterations, random_state)
    _importance(result, predictor, estimator, np.shape(prepared)[1])
    return result


def _classification(result, predictor, estimator, X, truth, predicted):
    classes = getattr(estimator, 'classes_', None)
    if classes is None:
        result['unavailable']['roc_precision_recall'] = 'The estimator exposes no fitted class ordering.'
        classes = np.unique(np.concatenate([truth.astype(str), predicted.astype(str)]))
    else:
        classes = np.asarray(classes)
        encoder = getattr(predictor, 'label_encoder', None)
        if encoder is not None:
            classes = encoder.inverse_transform(classes.astype(int))
    labels = list(map(str, classes))
    truth_s, prediction_s = truth.astype(str), predicted.astype(str)
    all_labels = list(dict.fromkeys(labels + list(truth_s) + list(prediction_s)))
    result['class_distribution'] = {
        'classes': all_labels,
        'observed': [int(np.sum(truth_s == c)) for c in all_labels],
        'predicted': [int(np.sum(prediction_s == c)) for c in all_labels]}
    result['confusion_matrix'] = confusion_matrix(truth_s, prediction_s, labels=all_labels).tolist()
    score_method = None
    for method in ('predict_proba', 'decision_function'):
        if callable(getattr(estimator, method, None)):
            try:
                scores = _numeric(getattr(estimator, method)(X), 'classifier scores')
                score_method = method
                break
            except (AttributeError, NotImplementedError):
                continue
    if score_method is None:
        result['unavailable']['roc_precision_recall'] = (
            'The fitted classifier provides neither probabilities nor decision scores; hard labels are not scores.')
        return
    if score_method == 'decision_function' and getattr(estimator, 'decision_function_shape', None) == 'ovo' and len(labels) > 2:
        result['unavailable']['roc_precision_recall'] = 'Pairwise OVO margins cannot be interpreted as per-class OVR scores.'
        return
    if scores.ndim == 1 and len(labels) == 2:
        scores = np.column_stack([-scores, scores])
    if scores.shape != (len(truth), len(labels)):
        raise ValueError('Classifier score columns do not match fitted classes')
    result['score_method'] = score_method
    result['score_classes'] = labels
    result['scores'] = scores.tolist()
    curves = []
    for i, label in enumerate(labels):
        binary = truth_s == label
        if not binary.any() or binary.all():
            result['unavailable'][f'curve_{label}'] = 'Both positive and negative held-out observations are required.'
            continue
        fpr, tpr, _ = roc_curve(binary, scores[:, i])
        precision, recall, _ = precision_recall_curve(binary, scores[:, i])
        curves.append({'class': label, 'fpr': fpr.tolist(), 'tpr': tpr.tolist(),
                       'roc_auc': float(auc(fpr, tpr)), 'precision': precision.tolist(),
                       'recall': recall.tolist(),
                       'average_precision': float(average_precision_score(binary, scores[:, i]))})
    result['classification_curves'] = curves
    result['notes'].append('ROC and precision-recall curves use one-versus-rest scores in fitted class order; decision scores are not probabilities.')


def _regression_geometry(result, predictor, estimator, X, Xt, original_Xt, yt, alpha):
    if not isinstance(estimator, (LinearRegression, PLSRegression)):
        result['unavailable']['leverage_studentized_hotelling'] = 'Classical linear/PLS geometry is not defined for this estimator.'
        return
    if isinstance(estimator, LinearRegression) and getattr(estimator, 'positive', False):
        result['unavailable']['linear_intervals'] = 'Constrained positive regression does not satisfy the ordinary least-squares covariance formula.'
        return
    is_pls = isinstance(estimator, PLSRegression)
    A, B = (_numeric(estimator.transform(Xt), 'training PLS scores'),
            _numeric(estimator.transform(X), 'test PLS scores')) if is_pls else (
                _numeric(Xt, 'training features'), _numeric(X, 'test features'))
    intercept = is_pls or estimator.fit_intercept
    D = np.column_stack([np.ones(len(A)), A]) if intercept else A
    E = np.column_stack([np.ones(len(B)), B]) if intercept else B
    rank = int(np.linalg.matrix_rank(D))
    df = len(A) - rank
    if df <= 0:
        result['unavailable']['linear_geometry'] = 'Residual degrees of freedom must be positive.'
        return
    # A pseudoinverse gives no variance for unobserved directions. Reject those
    # extrapolations rather than producing falsely narrow intervals.
    if not np.allclose(E @ np.linalg.pinv(D) @ D, E, atol=1e-8, rtol=1e-7):
        result['unavailable']['linear_geometry'] = 'Test rows have components outside the estimable training design space.'
        return
    covariance = np.linalg.pinv(D.T @ D)
    ht = np.einsum('ij,jk,ik->i', D, covariance, D)
    h = np.einsum('ij,jk,ik->i', E, covariance, E)
    fitted = _numeric(_predict(predictor, original_Xt), 'training predictions')
    residual = yt - fitted
    sigma = float(np.sqrt(np.sum(residual ** 2) / df))
    result['geometry'] = {'kind': 'PLS latent scores' if is_pls else 'ordinary least squares',
                          'rank': rank, 'residual_df': df, 'residual_sigma': sigma,
                          'training_leverage': ht.tolist(), 'test_leverage': h.tolist(),
                          'training_predictions': fitted.tolist(),
                          'training_residuals': residual.tolist()}
    valid = (1 - ht > 1e-12) & (sigma > 0)
    studentized = np.full(len(ht), np.nan)
    studentized[valid] = residual[valid] / (sigma * np.sqrt(1 - ht[valid]))
    result['geometry']['training_studentized_residuals'] = [float(v) if np.isfinite(v) else None for v in studentized]
    result['geometry']['test_standardized_prediction_residuals'] = (
        (np.asarray(result['residuals']) / (sigma * np.sqrt(1 + h))).tolist() if sigma > 0 else [None] * len(h))
    result['notes'].append('Studentized residuals refer to the training fit; held-out residuals use prediction standard errors (1 + leverage), not training residual errors (1 - leverage).')
    if is_pls:
        centered = A - np.mean(A, axis=0)
        test_centered = B - np.mean(A, axis=0)
        cov = centered.T @ centered / (len(A) - 1)
        k = int(np.linalg.matrix_rank(cov))
        if k > 0 and k < len(A):
            inv_cov = np.linalg.pinv(cov)
            t2 = np.einsum('ij,jk,ik->i', test_centered, inv_cov, test_centered)
            result['hotelling'] = {'test_t2': t2.tolist(), 'score_rank': k,
                'threshold': float(k * (len(A) + 1) * (len(A) - 1) / (len(A) * (len(A) - k)) * f.ppf(1 - alpha, k, len(A) - k)),
                'scope': 'Approximate new-observation limit for multivariate-normal training scores, conditional on the fitted supervised PLS basis.'}
        result['notes'].append('PLS leverage and studentization condition on the response-trained latent basis; they are descriptive diagnostics, not exact unconditional inferential tests.')
    else:
        critical = float(t.ppf(1 - alpha / 2, df))
        pred = np.asarray(result['predicted'], dtype=float)
        mean_width = critical * sigma * np.sqrt(np.maximum(h, 0))
        prediction_width = critical * sigma * np.sqrt(1 + np.maximum(h, 0))
        result['intervals'] = {'method': 'OLS Student-t', 'confidence_level': 1 - alpha,
            'mean_lower': (pred - mean_width).tolist(), 'mean_upper': (pred + mean_width).tolist(),
            'prediction_lower': (pred - prediction_width).tolist(), 'prediction_upper': (pred + prediction_width).tolist(),
            'scope': 'Pointwise mean confidence and new-observation prediction intervals assuming an unconstrained correctly specified linear model, independent homoscedastic Gaussian errors, and fixed design; not simultaneous bands.'}


def _bootstrap(result, predictor, Xt, yt, X, alpha, iterations, random_state):
    if not isinstance(iterations, int) or not 20 <= iterations <= 2000:
        raise ValueError('bootstrap_iterations must be zero or an integer from 20 to 2000')
    rng = np.random.default_rng(random_state)
    draws, errors = [], []
    for _ in range(iterations):
        ids = rng.integers(0, len(yt), len(yt))
        sample = Xt.iloc[ids] if hasattr(Xt, 'iloc') else np.asarray(Xt)[ids]
        try:
            if hasattr(predictor, 'estimator') and hasattr(predictor, '_prepare_X'):
                features = np.asarray(sample, dtype=float)
                test = np.asarray(X, dtype=float)
                for transform in (predictor.imputer, predictor.x_scaler):
                    if transform is not None:
                        fitted_transform = clone(transform)
                        features = fitted_transform.fit_transform(features)
                        test = fitted_transform.transform(test)
                targets = yt[ids]
                scaler = clone(predictor.y_scaler) if predictor.y_scaler is not None else None
                if scaler is not None:
                    targets = scaler.fit_transform(targets.reshape(-1, 1)).ravel()
                fitted_model = clone(predictor.estimator)
                seeds = {k: int(rng.integers(0, 2**31 - 1)) for k, v in fitted_model.get_params(deep=True).items()
                         if k.endswith('random_state') and v is None}
                if seeds:
                    fitted_model.set_params(**seeds)
                fitted_model.fit(features, targets)
                draw = _vector(fitted_model.predict(test), 'bootstrap predictions')
                if scaler is not None:
                    draw = scaler.inverse_transform(draw.reshape(-1, 1)).ravel()
            else:
                fitted_model = clone(predictor)
                seeds = {k: int(rng.integers(0, 2**31 - 1)) for k, v in fitted_model.get_params(deep=True).items()
                         if k.endswith('random_state') and v is None}
                if seeds:
                    fitted_model.set_params(**seeds)
                draw = _vector(fitted_model.fit(sample, yt[ids]).predict(X), 'bootstrap predictions')
            draws.append(_numeric(draw, 'bootstrap predictions'))
        except Exception as exc:
            errors.append(type(exc).__name__)
    if len(draws) < max(10, .8 * iterations):
        result['unavailable']['bootstrap_intervals'] = f'Only {len(draws)}/{iterations} bootstrap fits succeeded; no band accepted.'
        return
    lower, upper = np.quantile(np.stack(draws), [alpha / 2, 1 - alpha / 2], axis=0)
    result['intervals'] = {'method': 'Training-pairs percentile bootstrap', 'confidence_level': 1 - alpha,
        'mean_lower': lower.tolist(), 'mean_upper': upper.tolist(), 'iterations': iterations,
        'successful_fits': len(draws), 'failed_fits': len(errors), 'random_state': random_state,
        'scope': 'Approximate pointwise mean-response uncertainty from resampling independent training rows and refitting learned transforms and estimator; no new-observation prediction interval, group-resampling, distribution-shift or hyperparameter-selection uncertainty.'}
    if iterations < 1000:
        result['notes'].append(f'Bootstrap uses {iterations} resamples for exploratory display. Percentile tails can be unstable; use at least 1000 resamples and inspect convergence for final inference.')


def _importance(result, predictor, estimator, n_features):
    values = getattr(estimator, 'feature_importances_', None)
    kind = 'Estimator impurity importance'
    if values is None:
        coef = getattr(estimator, 'coef_', None)
        if coef is not None:
            c = np.asarray(coef, dtype=float)
            values = np.abs(c) if c.ndim == 1 else np.linalg.norm(c, axis=0)
            kind = 'Absolute coefficient magnitude in fitted feature units'
    if values is None or np.shape(values) != (n_features,):
        result['unavailable']['feature_importance'] = 'This estimator exposes no per-input-feature importance.'
        return
    names = getattr(predictor, 'feature_names', None)
    result['feature_importance'] = {'names': list(names) if names is not None else [str(i + 1) for i in range(n_features)],
                                    'values': _numeric(values, 'feature importance').tolist(), 'kind': kind}


def diagnostic_figures(data):
    """Build independently owned Agg figures; callers may export PNG/PDF/SVG."""
    figures = {}
    def axes(key, title, xlabel, ylabel):
        fig = Figure(figsize=(6.4, 4.2), constrained_layout=True)
        FigureCanvasAgg(fig)
        ax = fig.subplots()
        ax.set(title=fill(title, 58), xlabel=xlabel, ylabel=ylabel)
        ax.title.set_fontsize(11)
        ax.tick_params(labelsize=9)
        figures[key] = fig
        return ax
    def legend(ax):
        ax.legend(loc='upper left', bbox_to_anchor=(1.02, 1), fontsize=8, borderaxespad=0)
    truth, pred = data['observed'], data['predicted']
    if data['task_type'] == 'regression':
        ax = axes('predicted_observed', 'Predicted versus observed', 'Observed response', 'Predicted response')
        ax.scatter(truth, pred, s=22)
        lo, hi = float(min(min(truth), min(pred))), float(max(max(truth), max(pred)))
        ax.plot([lo, hi], [lo, hi], '--', color='gray', label='Identity')
        legend(ax)
        ax = axes('residuals', 'Held-out residuals', 'Predicted response', 'Observed - predicted')
        ax.scatter(pred, data['residuals'], s=22); ax.axhline(0, color='gray', linestyle='--')
        if data.get('intervals'):
            band = data['intervals']; order = np.argsort(pred)
            ax = axes('confidence_band', 'Pointwise mean-response confidence band', 'Prediction rank', 'Response')
            ax.plot(np.asarray(pred)[order], label='Prediction')
            ax.fill_between(np.arange(len(pred)), np.asarray(band['mean_lower'])[order], np.asarray(band['mean_upper'])[order], alpha=.25, label=f"{data['confidence_level']:.0%} mean band")
            legend(ax)
        geometry = data.get('geometry')
        if geometry:
            ax = axes('studentized_residuals', 'Training internally studentized residuals', 'Training prediction', 'Studentized residual')
            vals = [np.nan if v is None else v for v in geometry['training_studentized_residuals']]
            ax.scatter(geometry['training_predictions'], vals, s=20); ax.axhline(0, color='gray', linestyle='--')
            ax = axes('leverage', 'Held-out leverage', 'Held-out sample index', 'Leverage')
            ax.plot(geometry['test_leverage'], 'o')
        if data.get('hotelling'):
            ax = axes('hotelling', 'PLS latent-score Hotelling T-squared', 'Held-out sample index', 'T-squared')
            ax.plot(data['hotelling']['test_t2'], 'o'); ax.axhline(data['hotelling']['threshold'], color='red', linestyle='--', label='Approximate limit'); legend(ax)
    else:
        distribution = data['class_distribution']; names = distribution['classes']
        ax = axes('class_distribution', 'Held-out class distribution', 'Class', 'Count')
        x = np.arange(len(names)); ax.bar(x - .2, distribution['observed'], .4, label='Observed'); ax.bar(x + .2, distribution['predicted'], .4, label='Predicted'); ax.set_xticks(x, [fill(v, 18) for v in names], rotation=30); legend(ax)
        ax = axes('confusion_matrix', 'Held-out confusion matrix', 'Predicted class', 'Observed class')
        matrix = np.asarray(data['confusion_matrix']); im = ax.imshow(matrix, cmap='Blues'); ax.set_xticks(x, [fill(v, 18) for v in names], rotation=30); ax.set_yticks(x, [fill(v, 18) for v in names]); ax.figure.colorbar(im, ax=ax, label='Observation count')
        for i, j in np.ndindex(matrix.shape): ax.text(j, i, str(matrix[i, j]), ha='center', va='center', color='white' if matrix[i, j] > matrix.max()/2 else 'black', fontsize=9)
        curves = data.get('classification_curves', [])
        if curves:
            ax = axes('roc', 'One-versus-rest ROC curves', 'False positive rate', 'True positive rate')
            for c in curves: ax.plot(c['fpr'], c['tpr'], label=fill(f"{c['class']} (AUC {c['roc_auc']:.3f})", 28))
            ax.plot([0, 1], [0, 1], '--', color='gray'); legend(ax)
            ax = axes('precision_recall', 'One-versus-rest precision-recall curves', 'Recall', 'Precision')
            for c in curves: ax.plot(c['recall'], c['precision'], label=fill(f"{c['class']} (AP {c['average_precision']:.3f})", 28))
            legend(ax)
    importance = data.get('feature_importance')
    if importance:
        ids = np.argsort(importance['values'])[-20:]
        ax = axes('feature_importance', importance['kind'], 'Importance', 'Input feature')
        ax.barh(np.arange(len(ids)), np.asarray(importance['values'])[ids]); ax.set_yticks(np.arange(len(ids)), [fill(str(v), 20) for v in np.asarray(importance['names'])[ids]])
    from matplotlib.text import Text
    from app.ui.mpl_theme import chart_font_family
    for figure in figures.values():
        for artist in figure.findobj(match=Text):
            artist.set_fontfamily(['DejaVu Sans', chart_font_family()])
    return figures
