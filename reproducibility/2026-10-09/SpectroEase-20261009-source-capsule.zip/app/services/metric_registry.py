# app/services/metric_registry.py
"""Evaluation metric registry.

Each metric is registered with a callable, its task_type
(``'regression'`` or ``'classification'``), whether it needs predicted
probabilities, and a display format string.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, Optional

import numpy as np


@dataclass(frozen=True)
class MetricEntry:
    name: str
    task_type: str           # 'regression' | 'classification'
    fn: Callable[..., float]  # signature: (y_true, y_pred, **kwargs) -> float
    needs_proba: bool = False
    fmt: str = '.4f'
    higher_is_better: bool = True


_REGISTRY: Dict[str, MetricEntry] = {}


def register_metric(name: str, *, task_type: str,
                   needs_proba: bool = False, fmt: str = '.4f',
                   higher_is_better: bool = True) -> Callable:
    """Decorator to register a metric function."""
    def decorator(func: Callable[..., float]) -> Callable:
        _REGISTRY[name] = MetricEntry(
            name=name, task_type=task_type, fn=func,
            needs_proba=needs_proba, fmt=fmt,
            higher_is_better=higher_is_better,
        )
        return func
    return decorator


def get_metric(name: str) -> Optional[MetricEntry]:
    return _REGISTRY.get(name)


def list_metrics(task_type: Optional[str] = None) -> list:
    if task_type is None:
        return list(_REGISTRY.values())
    return [m for m in _REGISTRY.values() if m.task_type == task_type]


def reset() -> None:
    """Clear registry (testing only)."""
    _REGISTRY.clear()


# ------------------------------------------------------------------
# Built-in regression metrics.
# ------------------------------------------------------------------
from sklearn.metrics import (
    mean_squared_error, mean_absolute_error, r2_score,
    roc_auc_score, f1_score, precision_score, recall_score,
    accuracy_score, confusion_matrix,
)


@register_metric('rmse', task_type='regression', fmt='.4f', higher_is_better=False)
def _rmse(y_true, y_pred):
    return float(np.sqrt(mean_squared_error(y_true, y_pred)))


@register_metric('mse', task_type='regression', fmt='.4f', higher_is_better=False)
def _mse(y_true, y_pred):
    return float(mean_squared_error(y_true, y_pred))


@register_metric('mae', task_type='regression', fmt='.4f', higher_is_better=False)
def _mae(y_true, y_pred):
    return float(mean_absolute_error(y_true, y_pred))


@register_metric('r2', task_type='regression', fmt='.4f')
def _r2(y_true, y_pred):
    return float(r2_score(y_true, y_pred))


@register_metric('mape', task_type='regression', fmt='.2%', higher_is_better=False)
def _mape(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    safe = np.where(y_true == 0, 1.0, np.abs(y_true))
    return float(np.mean(np.abs((y_true - y_pred) / safe)) * 100.0)


@register_metric('rpd', task_type='regression', fmt='.3f')
def _rpd(y_true, y_pred):
    """Residual predictive deviation = std(y) / RMSE."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    std = float(np.std(y_true, ddof=0))
    if rmse < 1e-12:
        return float('inf')
    return std / rmse


@register_metric('ccc', task_type='regression', fmt='.4f')
def _ccc(y_true, y_pred):
    """Lin's Concordance Correlation Coefficient."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    mean_t = float(np.mean(y_true))
    mean_p = float(np.mean(y_pred))
    var_t = float(np.var(y_true))
    var_p = float(np.var(y_pred))
    cov = float(np.mean((y_true - mean_t) * (y_pred - mean_p)))
    denom = 2.0 * cov
    return float((denom) / (var_t + var_p + (mean_t - mean_p) ** 2 + 1e-12))


@register_metric('explained_variance', task_type='regression', fmt='.4f')
def _ev(y_true, y_pred):
    from sklearn.metrics import explained_variance_score
    return float(explained_variance_score(y_true, y_pred))


# ------------------------------------------------------------------
# Built-in classification metrics.
# ------------------------------------------------------------------
@register_metric('accuracy', task_type='classification', fmt='.4f')
def _accuracy(y_true, y_pred):
    return float(accuracy_score(y_true, y_pred))


@register_metric('precision', task_type='classification', fmt='.4f')
def _precision(y_true, y_pred, **kwargs):
    return float(precision_score(y_true, y_pred, average='macro',
                                  zero_division=0))


@register_metric('recall', task_type='classification', fmt='.4f')
def _recall(y_true, y_pred, **kwargs):
    return float(recall_score(y_true, y_pred, average='macro',
                               zero_division=0))


@register_metric('f1', task_type='classification', fmt='.4f')
def _f1(y_true, y_pred, **kwargs):
    return float(f1_score(y_true, y_pred, average='macro',
                          zero_division=0))


@register_metric('f1_macro', task_type='classification', fmt='.4f')
def _f1_macro(y_true, y_pred, **kwargs):
    return float(f1_score(y_true, y_pred, average='macro',
                          zero_division=0))


@register_metric('f1_weighted', task_type='classification', fmt='.4f')
def _f1_weighted(y_true, y_pred, **kwargs):
    return float(f1_score(y_true, y_pred, average='weighted',
                          zero_division=0))


@register_metric('roc_auc', task_type='classification',
                 needs_proba=True, fmt='.4f')
def _roc_auc(y_true, y_proba, **kwargs):
    """``y_proba`` should be a 2D array (n_samples, n_classes) of probabilities."""
    y_proba = np.asarray(y_proba)
    if y_proba.ndim == 1 or y_proba.shape[1] == 1:
        # Binary case with single-column scores.
        scores = y_proba.ravel()
        return float(roc_auc_score(y_true, scores))
    return float(roc_auc_score(y_true, y_proba, multi_class='ovr',
                                average='macro'))


@register_metric('kappa', task_type='classification', fmt='.4f')
def _kappa(y_true, y_pred, **kwargs):
    from sklearn.metrics import cohen_kappa_score
    return float(cohen_kappa_score(y_true, y_pred))


@register_metric('confusion_matrix', task_type='classification', fmt='s')
def _confusion_matrix(y_true, y_pred, **kwargs):
    cm = confusion_matrix(y_true, y_pred).tolist()
    return cm  # not a float; stored as list under 'confusion_matrix'