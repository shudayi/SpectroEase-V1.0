"""
ONNX Model Export Service
自动将训练好的scikit-learn模型转换并保存为ONNX格式
"""

import os
import re
import uuid
import sys
import json
import tempfile
import subprocess
import pickle
import time
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Any, Optional, Dict, Union
import logging

logger = logging.getLogger(__name__)

class ONNXService:
    @staticmethod
    def _filename_component(value: Any) -> str:
        """Keep caller labels inside a single portable filename component."""
        cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', str(value))
        cleaned = cleaned.strip(' .')[:80].rstrip(' .')
        return cleaned or 'model'

    def _model_filename(
        self,
        model_name: str,
        method: Optional[str],
        extension: str = ".pkl",
        sidecar_suffix: str = "_info.txt",
    ) -> str:
        """Budget the complete path, including the longer metadata sidecar.

        Windows installations without long-path support accept at most 259
        UTF-16 code units before the terminating null. Keep the unique suffix
        intact and shorten caller labels to fit that limit. ``sidecar_suffix``
        is measured from the shared stem, so the longest companion file fits.
        """
        def units(value):
            return len(value.encode('utf-16-le')) // 2

        components = ([self._filename_component(method)] if method else [])
        components.append(self._filename_component(model_name))
        suffix = '_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex
        longest_suffix = max(units(extension), units(sidecar_suffix), units('_info.txt'))
        filename_budget = min(
            240, 259 - units(os.path.abspath(self.save_directory)) - 1 - longest_suffix
        )
        label_budget = filename_budget - units(suffix + extension)
        if label_budget < len(components) * 2 - 1:
            raise ValueError('Model save directory is too long for a unique model filename; choose a shorter directory.')
        while units('_'.join(components)) > label_budget:
            index = max(range(len(components)), key=lambda i: units(components[i]))
            components[index] = components[index][:-1]
        return '_'.join(components) + suffix + extension

    def __init__(self, save_directory: str = "models"):
        """
        初始化ONNX服务
        
        Args:
            save_directory: 模型保存目录
        """
        # Handle exe environment - use absolute path
        if getattr(sys, 'frozen', False):
            # Running as exe
            exe_dir = os.path.dirname(sys.executable)
            self.save_directory = os.path.join(exe_dir, save_directory)
        else:
            # Running as script
            self.save_directory = os.path.abspath(save_directory)
        
        self.ensure_directory_exists()
        self.last_error = None
        
    def ensure_directory_exists(self):
        """确保保存目录存在"""
        try:
            if not os.path.exists(self.save_directory):
                os.makedirs(self.save_directory)
                logger.info(f"Created directory: {self.save_directory}")
        except PermissionError:
            # Fallback to user documents folder
            user_docs = os.path.expanduser("~/Documents/SpectroEase")
            self.save_directory = os.path.join(user_docs, "models")
            if not os.path.exists(self.save_directory):
                os.makedirs(self.save_directory)
                logger.info(f"Created fallback directory: {self.save_directory}")
    
    def can_export_to_onnx(self, model: Any) -> bool:
        """
        检查模型是否可以导出到ONNX格式
        
        Args:
            model: 训练好的模型
            
        Returns:
            bool: 是否可以导出
        """
        try:
            # Class-name allowlists can claim support without a converter.
            # Probe the installed converter registry for the actual estimator.
            if not os.environ.get('SPECTROEASE_ONNX_WORKER'):
                return bool(self._isolated_onnx('can_export_to_onnx', model))
            from skl2onnx import get_model_alias
            if not hasattr(model, "predict"):
                return False
            get_model_alias(type(model))
            try:
                from sklearn.utils.validation import check_is_fitted
                check_is_fitted(model)
            except (TypeError, ValueError, AttributeError):
                return False
            return True
            
        except Exception as e:
            logger.error(f"Error checking ONNX compatibility: {e}")
            return False

    def _write_onnx_artifacts(self, graph, sidecar, model_name, method):
        """Write an ONNX graph and its contract sidecar without leaving a
        partial pair when either write fails.
        """
        self.ensure_directory_exists()
        filename = self._model_filename(
            model_name,
            method,
            extension=".onnx",
            sidecar_suffix="_onnx_contract.json",
        )
        target = os.path.join(self.save_directory, filename)
        sidecar_path = os.path.splitext(target)[0] + "_onnx_contract.json"
        graph_created = False
        metadata_created = False
        try:
            with open(target, "xb") as handle:
                graph_created = True
                handle.write(graph.SerializeToString())
            with open(sidecar_path, "x", encoding="utf-8") as handle:
                metadata_created = True
                json.dump(sidecar, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
            return target
        except Exception:
            if metadata_created and os.path.exists(sidecar_path):
                os.remove(sidecar_path)
            if graph_created and os.path.exists(target):
                os.remove(target)
            raise

    @staticmethod
    def _flatten_single_target_output(graph, onnx_module, reference_prediction):
        """Expose scalar-regression predictions as sklearn's (n,) vector."""
        if not graph.graph.output or np.asarray(reference_prediction).ndim != 1:
            return
        output = graph.graph.output[0]
        tensor = output.type.tensor_type
        dimensions = tensor.shape.dim
        # Some skl2onnx converters publish an incorrect static second output
        # dimension for single-target PLS. The fitted estimator's actual
        # prediction rank is the contract; ORT validates that axis 1 is one.
        if len(dimensions) != 2:
            return

        raw_output_name = output.name
        axes_name = f"spectroease_squeeze_axes_{uuid.uuid4().hex}"
        flat_output_name = f"spectroease_flat_prediction_{uuid.uuid4().hex}"
        graph.graph.initializer.append(
            onnx_module.numpy_helper.from_array(np.asarray([1], dtype=np.int64), axes_name)
        )
        graph.graph.node.append(
            onnx_module.helper.make_node(
                "Squeeze", [raw_output_name, axes_name], [flat_output_name]
            )
        )
        output.name = flat_output_name
        del tensor.shape.dim[:]
        tensor.shape.dim.add().dim_param = "N"
    
    def export_model_to_onnx(self, model: Any, X_sample: np.ndarray, 
                           model_name: str = None, method: str = None) -> Optional[str]:
        """
        Export a fitted estimator on its declared fitted-feature-matrix boundary.

        This is a real estimator conversion and ONNX Runtime parity check. It
        does not include upstream spectral preprocessing, feature selection,
        target scaling or raw-spectrum replay. The sidecar records this input
        contract; callers must provide the same representation used at fit.
        
        Args:
            model: 训练好的模型
            X_sample: 样本数据，用于推断输入形状
            model_name: 模型名称
            method: 训练Method名称
            
        Returns:
            str: 保存的ONNX文件路径，如果失败返回None
        """
        self.last_error = None
        if not os.environ.get('SPECTROEASE_ONNX_WORKER'):
            return self._isolated_onnx('export_model_to_onnx', model, X_sample, model_name=model_name, method=method)
        try:
            from skl2onnx import to_onnx
            import onnx
            import onnxruntime as ort

            values = np.asarray(X_sample, dtype=np.float32)
            if values.ndim != 2 or len(values) < 1 or not np.isfinite(values).all():
                raise ValueError("ONNX export requires a nonempty finite 2D fitted-feature sample")
            if not self.can_export_to_onnx(model):
                raise TypeError(f"No fitted ONNX converter is registered for {type(model).__name__}")

            sample = np.ascontiguousarray(values[: min(len(values), 32)])
            reference = np.asarray(model.predict(sample))
            graph = to_onnx(model, sample, target_opset=17)
            self._flatten_single_target_output(graph, onnx, reference)
            onnx.checker.check_model(graph)
            session = ort.InferenceSession(graph.SerializeToString(), providers=["CPUExecutionProvider"])
            input_name = session.get_inputs()[0].name
            graph_outputs = session.run(None, {input_name: sample})
            if not graph_outputs:
                raise ValueError("Converted ONNX graph exposes no outputs")
            onnx_prediction = np.asarray(graph_outputs[0])
            reference = np.asarray(reference)
            # skl2onnx commonly represents a scalar regression target as
            # (n_samples, 1), while sklearn's predict() returns (n_samples,).
            # Treat only this explicit single-target shape difference as
            # equivalent; do not flatten multiclass or multi-output results.
            if (
                onnx_prediction.ndim == reference.ndim + 1
                and onnx_prediction.shape[-1] == 1
                and onnx_prediction.shape[:-1] == reference.shape
            ):
                onnx_prediction = onnx_prediction[..., 0]
            if onnx_prediction.shape != reference.shape:
                raise ValueError(
                    f"ONNX prediction shape {onnx_prediction.shape} does not match estimator {reference.shape}"
                )
            if np.issubdtype(reference.dtype, np.number):
                parity = np.allclose(onnx_prediction, reference, rtol=2e-4, atol=2e-5)
            else:
                parity = np.array_equal(onnx_prediction.astype(str), reference.astype(str))
            if not parity:
                raise ValueError("ONNX Runtime outputs do not match estimator predictions on the parity sample")

            sidecar = {
                "schema_version": 1,
                "format": "ONNX",
                "model_type": type(model).__name__,
                "method": method,
                "input_representation": "fitted_feature_matrix",
                "input_feature_count": int(values.shape[1]),
                "raw_spectrum_replay": False,
                "runtime_parity": "passed",
                "parity_rows": int(len(sample)),
                "parity_atol": 2e-5,
                "parity_rtol": 2e-4,
                "output_names": [item.name for item in session.get_outputs()],
                "output_shapes": [item.shape for item in session.get_outputs()],
                "task_type": "classification" if hasattr(model, "classes_") else "regression",
                "class_labels": np.asarray(getattr(model, "classes_", [])).tolist(),
            }
            return self._write_onnx_artifacts(
                graph, sidecar, model_name or type(model).__name__, method
            )

        except Exception as e:
            self.last_error = str(e)
            logger.error(f"ONNX export failed: {e}")
            logger.error(f"Failed to export model to ONNX: {e}")
            return None

    def export_analyzer_to_onnx(
        self,
        analyzer: Any,
        X_sample: Any,
        model_name: str = None,
        method: str = None,
        cancel_event=None,
    ) -> Optional[str]:
        """Export the fitted analyzer's input transforms and estimator.

        Imputation and X standardization are embedded. Regression outputs are
        restored to the analyzer's target units. Classification outputs remain
        integer class codes and the sidecar carries their label mapping. Any
        upstream spectral preprocessing or feature selection is outside this
        graph and remains part of ``input_representation``.
        """
        self.last_error = None
        if not os.environ.get('SPECTROEASE_ONNX_WORKER'):
            return self._isolated_onnx('export_analyzer_to_onnx', analyzer, X_sample, model_name=model_name, method=method, _cancel_event=cancel_event)
        try:
            from sklearn.pipeline import Pipeline
            from skl2onnx import to_onnx
            import onnx
            import onnxruntime as ort

            estimator = getattr(analyzer, "model", None)
            predictor = getattr(analyzer, "fitted_predictor", None)
            imputer = getattr(analyzer, "imputer", None)
            x_scaler = getattr(analyzer, "scaler_x", None) or getattr(analyzer, "scaler", None)
            if estimator is None or predictor is None or imputer is None or x_scaler is None:
                raise ValueError("A fitted analyzer with saved imputation and X-scaling state is required")
            if not self.can_export_to_onnx(estimator):
                raise TypeError(f"No fitted ONNX converter is registered for {type(estimator).__name__}")

            if isinstance(X_sample, pd.DataFrame):
                feature_names = [str(value) for value in X_sample.columns]
                fitted_names = getattr(predictor, "feature_names", None)
                if fitted_names is not None and tuple(feature_names) != tuple(map(str, fitted_names)):
                    raise ValueError("ONNX export columns must match the fitted input feature order")
                values64 = X_sample.to_numpy(dtype=float)
            else:
                values64 = np.asarray(X_sample, dtype=float)
                feature_names = getattr(predictor, "feature_names", None)
                feature_names = list(map(str, feature_names)) if feature_names is not None else None
            if values64.ndim != 2 or not len(values64):
                raise ValueError("ONNX export requires a nonempty 2D fitted-input sample")
            if np.isinf(values64).any():
                raise ValueError("ONNX export accepts missing values handled by the fitted imputer, but not infinity")
            if getattr(predictor, "n_features", None) not in (None, values64.shape[1]):
                raise ValueError("ONNX input feature count does not match the fitted analyzer")

            sample = np.ascontiguousarray(values64[: min(len(values64), 32)], dtype=np.float32)
            pipeline = Pipeline([
                ("imputer", imputer),
                ("x_scaler", x_scaler),
                ("estimator", estimator),
            ])
            parity_input = X_sample[: min(len(X_sample), 32)] if hasattr(X_sample, "__getitem__") else sample
            reference = np.asarray(analyzer.predict(parity_input))
            if reference.ndim == 2 and reference.shape[-1] == 1:
                reference = reference[:, 0]
            if reference.ndim != 1:
                raise ValueError("The fitted analyzer must return one prediction value per input row")
            options = {id(estimator): {"zipmap": False}} if predictor.task_type == "classification" else None
            graph = to_onnx(
                pipeline,
                sample,
                target_opset=17,
                options=options,
            )

            if predictor.task_type == "regression":
                y_scaler = getattr(analyzer, "scaler_y", None)
                if y_scaler is None or not hasattr(y_scaler, "mean_") or not hasattr(y_scaler, "scale_"):
                    raise ValueError("The fitted regression target scaler cannot be represented in the ONNX graph")
                scale = float(np.asarray(y_scaler.scale_).reshape(-1)[0])
                mean = float(np.asarray(y_scaler.mean_).reshape(-1)[0])
                if not np.isfinite([scale, mean]).all() or scale == 0:
                    raise ValueError("The fitted regression target scaling state is invalid")
                raw_output_name = graph.graph.output[0].name
                output_name = "spectroease_prediction_target_units"
                scaled_name = "spectroease_prediction_scaled_for_inverse"
                graph.graph.initializer.extend([
                    onnx.numpy_helper.from_array(np.asarray([scale], dtype=np.float32), "spectroease_y_scale"),
                    onnx.numpy_helper.from_array(np.asarray([mean], dtype=np.float32), "spectroease_y_mean"),
                ])
                graph.graph.node.extend([
                    onnx.helper.make_node(
                        "Mul", [raw_output_name, "spectroease_y_scale"], [scaled_name]
                    ),
                    onnx.helper.make_node(
                        "Add", [scaled_name, "spectroease_y_mean"], [output_name]
                    ),
                ])
                graph.graph.output[0].name = output_name

                self._flatten_single_target_output(graph, onnx, reference)

            onnx.checker.check_model(graph)
            session = ort.InferenceSession(graph.SerializeToString(), providers=["CPUExecutionProvider"])
            input_name = session.get_inputs()[0].name
            graph_outputs = session.run(None, {input_name: sample})
            if not graph_outputs:
                raise ValueError("Converted analyzer graph exposes no outputs")
            onnx_prediction = np.asarray(graph_outputs[0])
            parity_atol = 0.0
            parity_rtol = 0.0
            if predictor.task_type == "classification":
                label_encoder = getattr(analyzer, "label_encoder", None)
                if label_encoder is None:
                    raise ValueError("A fitted class-label encoder is required to validate ONNX class codes")
                reference = label_encoder.transform(reference)
                parity = np.array_equal(onnx_prediction.astype(int), reference.astype(int))
                class_labels = np.asarray(label_encoder.classes_).tolist()
                output_semantics = "encoded_class_index"
            elif predictor.task_type == "regression":
                tolerance = max(1e-5, float(np.nanstd(reference)) * 2e-4)
                parity_atol = tolerance
                parity_rtol = 2e-4
                parity = np.allclose(onnx_prediction, reference, rtol=2e-4, atol=tolerance)
                class_labels = []
                output_semantics = "target_units"
            else:
                raise ValueError(f"Unsupported analyzer task type: {predictor.task_type}")
            if onnx_prediction.shape != reference.shape or not parity:
                raise ValueError("ONNX Runtime predictions do not match the fitted analyzer on held-out sample rows")

            contract = {
                "schema_version": 2,
                "format": "ONNX",
                "model_type": type(estimator).__name__,
                "method": method or getattr(analyzer, "method", None),
                "task_type": predictor.task_type,
                "input_representation": getattr(predictor, "input_representation", "fitted_feature_matrix"),
                "input_feature_count": int(values64.shape[1]),
                "input_feature_names": feature_names,
                "imputation": "fitted_training_mean_embedded",
                "x_standardization": "fitted_training_standard_scaler_embedded",
                "target_standardization_inverse_embedded": predictor.task_type == "regression",
                "output_semantics": output_semantics,
                "output_shapes": [item.shape for item in session.get_outputs()],
                "class_labels_by_encoded_index": class_labels,
                "raw_spectrum_replay": getattr(predictor, "input_representation", None) == "raw_spectrum",
                "upstream_transform_note": (
                    "Upstream spectral preprocessing or feature selection is outside this graph; "
                    "provide the same feature representation used to fit the analyzer."
                ),
                "runtime_parity": "passed",
                "parity_rows": int(len(sample)),
                "parity_atol": parity_atol,
                "parity_rtol": parity_rtol,
                "output_names": [item.name for item in session.get_outputs()],
            }
            return self._write_onnx_artifacts(
                graph, contract, model_name or type(estimator).__name__, method or getattr(analyzer, "method", None)
            )
        except Exception as exc:
            self.last_error = str(exc)
            logger.error("Analyzer ONNX export failed: %s", exc, exc_info=True)
            return None
    
    def _isolated_onnx(self, operation, *args, **kwargs):
        """Contain native converter crashes in a bounded child process.

        Only locally supplied fitted objects are serialized. No configuration
        file or API key is passed to the worker. Temporary payloads are removed
        even when a native dependency crashes or the timeout expires.
        """
        self.last_error = None
        cancel_event = kwargs.pop('_cancel_event', None)
        try:
            with tempfile.TemporaryDirectory(prefix='spectroease-onnx-') as directory:
                payload = os.path.join(directory, 'request.pkl')
                result = os.path.join(directory, 'result.json')
                with open(payload, 'wb') as handle:
                    pickle.dump((self.save_directory, operation, args, kwargs), handle)
                environment = os.environ.copy()
                # Child needs runtime paths, never provider credentials.
                for key in list(environment):
                    if any(part in key.upper() for part in ('API_KEY', 'TOKEN', 'SECRET')):
                        environment.pop(key, None)
                environment['SPECTROEASE_ONNX_WORKER'] = '1'
                root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                command = ([sys.executable, '--spectroease-onnx-worker'] if getattr(sys, 'frozen', False)
                           else [sys.executable, '-m', 'app.services.onnx_export_worker'])
                process = subprocess.Popen(
                    command + [payload, result],
                    cwd=root, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                    errors='replace',
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
                )
                deadline = time.monotonic() + 120
                try:
                    while True:
                        if cancel_event is not None and cancel_event.is_set():
                            raise RuntimeError('ONNX export cancelled')
                        if time.monotonic() >= deadline:
                            raise TimeoutError('ONNX export exceeded 120 seconds')
                        try:
                            stdout, stderr = process.communicate(timeout=.1)
                            break
                        except subprocess.TimeoutExpired:
                            continue
                finally:
                    if process.poll() is None:
                        process.kill()
                        process.communicate()
                if process.returncode != 0 or not os.path.exists(result):
                    raise RuntimeError(f'ONNX worker failed (exit {process.returncode}): {stderr[-2000:]}')
                with open(result, encoding='utf-8') as handle:
                    response = json.load(handle)
                self.last_error = response.get('error')
                if self.last_error:
                    logger.error('ONNX worker: %s', self.last_error)
                return response.get('result')
        except Exception as exc:
            self.last_error = str(exc)
            logger.error('Isolated ONNX operation failed: %s', exc)
            return False if operation == 'can_export_to_onnx' else None

    def auto_save_model(self, model: Any, X_sample: np.ndarray, 
                      model_name: str = None, method: str = None,
                      evaluation_results: Dict = None,
                      prefer_onnx: bool = False) -> Optional[str]:
        """
        Save a bare estimator as pickle unless ONNX is explicitly preferred.
        
        Args:
            model: 训练好的模型
            X_sample: 样本数据
            model_name: 模型名称
            method: 训练Method名称
            evaluation_results: 评估结果
            
        Returns:
            str: 保存的文件路径
        """
        try:
            logger.info("Starting automatic model save...")

            # ONNX is explicit because this legacy auto-save contract receives
            # bare estimators and cannot promise raw-spectrum replay.
            onnx_path = (
                self.export_model_to_onnx(model, X_sample, model_name, method)
                if prefer_onnx else None
            )

            if onnx_path:
                logger.info(f"ONNX format saved successfully: {onnx_path}")
                # 保存模型信息
                self.save_model_info(onnx_path, model, method, evaluation_results)
                return onnx_path
            else:
                if prefer_onnx:
                    logger.warning("ONNX conversion failed; falling back to pickle format.")
                else:
                    logger.info("ONNX was not requested; saving the fitted estimator as pickle.")
                # 回退到pickle格式
                pickle_path = self.save_model_as_pickle(model, X_sample, model_name, method)
                if pickle_path:
                    logger.info(f"Pickle format saved successfully: {pickle_path}")
                    # 保存模型信息
                    self.save_model_info(pickle_path, model, method, evaluation_results)
                    return pickle_path
                else:
                    logger.error("All save formats failed")
                    return None

        except Exception as e:
            logger.error(f"Automatic model save failed: {e}")
            logger.error(f"Auto save model failed: {e}")
            return None
    
    def save_model_info(self, onnx_path: str, model: Any, method: str = None, 
                       evaluation_results: Dict = None):
        """
        保存模型相关信息到文本文件
        
        Args:
            onnx_path: ONNX文件路径
            model: Original模型
            method: 训练Method
            evaluation_results: 评估结果
        """
        try:
            # 生成信息文件路径
            # A pickle fallback must retain its binary payload. Build a separate
            # sidecar for every supported extension instead of replacing only ONNX.
            info_path = os.path.splitext(onnx_path)[0] + '_info.txt'
            
            with open(info_path, 'w', encoding='utf-8') as f:
                f.write(f"Model Information\n")
                f.write(f"=================\n\n")
                f.write(f"Export Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Model Type: {type(model).__name__}\n")
                f.write(f"Training Method: {method or 'Unknown'}\n")
                f.write(f"Model File: {os.path.basename(onnx_path)}\n\n")
                
                if hasattr(model, 'task_type'):
                    f.write(f"Task Type: {model.task_type}\n")
                
                if hasattr(model, 'n_features_in_'):
                    f.write(f"Number of Features: {model.n_features_in_}\n")
                
                if hasattr(model, 'classes_'):
                    f.write(f"Number of Classes: {len(model.classes_)}\n")
                    f.write(f"Classes: {list(model.classes_)}\n")
                
                # 保存评估结果
                if evaluation_results:
                    f.write(f"\nEvaluation Results:\n")
                    f.write(f"------------------\n")
                    for key, value in evaluation_results.items():
                        if key not in ['Confusion Matrix', 'Classification Report']:
                            if isinstance(value, float):
                                f.write(f"{key}: {value:.4f}\n")
                            else:
                                f.write(f"{key}: {value}\n")
                
                # 保存模型Parameters
                if hasattr(model, 'get_params'):
                    f.write(f"\nModel Parameters:\n")
                    f.write(f"----------------\n")
                    params = model.get_params()
                    for key, value in params.items():
                        f.write(f"{key}: {value}\n")
            
            logger.info(f"Model info saved to: {info_path}")
            
        except Exception as e:
            logger.error(f"Failed to save model info: {e}")
    
    def save_model_as_pickle(self, model: Any, X_sample: np.ndarray, 
                           model_name: str = None, method: str = None) -> Optional[str]:
        """
        使用pickle格式保存模型
        
        Args:
            model: 训练好的模型
            X_sample: 样本数据
            model_name: 模型名称
            method: 训练Method名称
            
        Returns:
            str: 保存的文件路径
        """
        try:
            import pickle
            
            # 生成文件名
            if model_name is None:
                model_name = type(model).__name__
            
            filename = self._model_filename(model_name, method)
            
            filepath = os.path.join(self.save_directory, filename)
            
            # 保存模型
            logger.info(f"Saving pickle model to: {filepath}")
            with open(filepath, 'xb') as f:
                pickle.dump({
                    'model': model,
                    'model_name': model_name,
                    'method': method,
                    'input_shape': X_sample.shape,
                    'timestamp': datetime.now().isoformat()
                }, f)

            logger.info(f"Model successfully saved as pickle: {filepath}")
            return filepath

        except Exception as e:
            logger.error(f"Pickle save failed: {e}")
            logger.error(f"Failed to save model as pickle: {e}")
            return None 
