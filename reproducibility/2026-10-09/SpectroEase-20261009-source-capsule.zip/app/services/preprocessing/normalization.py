# app/services/preprocessing/normalization.py
"""Intensity normalization methods: standard scale, min-max, vector / area / max."""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.services.preprocessing_registry import register


@register(
    key='Normalize',
    display_name='Normalize (per-row)',
    category='normalization',
    quality='real',
)
def normalize(data: pd.DataFrame, **_) -> pd.DataFrame:
    """Row-wise L2 normalisation."""
    result = data.copy()
    arr = result.values.astype(float)
    norms = np.linalg.norm(arr, axis=1, keepdims=True)
    norms = np.where(norms < 1e-12, 1.0, norms)
    result.loc[:, :] = arr / norms
    return result


@register(
    key='Standard Scale',
    display_name='Standard Scale (column-wise z-score)',
    category='normalization',
    quality='real',
)
def standard_scale(data: pd.DataFrame, **_) -> pd.DataFrame:
    result = data.copy()
    arr = result.values.astype(float)
    mean = arr.mean(axis=0, keepdims=True)
    std = arr.std(axis=0, keepdims=True, ddof=0)
    std = np.where(std < 1e-12, 1.0, std)
    result.loc[:, :] = (arr - mean) / std
    return result


@register(
    key='Min-Max Scale',
    display_name='Min-Max Scale (column-wise)',
    category='normalization',
    quality='real',
)
def min_max_scale(data: pd.DataFrame, feature_range: tuple = (0.0, 1.0), **_) -> pd.DataFrame:
    low, high = float(feature_range[0]), float(feature_range[1])
    if not np.isfinite([low,high]).all() or low >= high:
        raise ValueError('Min-max feature range must contain finite increasing endpoints')
    result = data.copy()
    arr = result.values.astype(float)
    col_min = arr.min(axis=0, keepdims=True)
    col_max = arr.max(axis=0, keepdims=True)
    rng = col_max - col_min
    rng = np.where(rng < 1e-12, 1.0, rng)
    result.loc[:, :] = (arr - col_min) / rng * (high - low) + low
    return result


@register(key='Robust Scale',display_name='Robust Scale (column-wise median/IQR)',category='normalization',quality='real')
def robust_scale(data: pd.DataFrame, **_) -> pd.DataFrame:
    arr=data.to_numpy(dtype=float)
    median=np.median(arr,axis=0,keepdims=True)
    q=np.quantile(arr,[.25,.75],axis=0)
    iqr=q[1]-q[0]
    iqr=np.where(iqr<1e-12,1.0,iqr)
    return pd.DataFrame((arr-median)/iqr,index=data.index,columns=data.columns)


@register(
    key='Vector Normalization',
    display_name='Vector Normalization (L2 norm = 1)',
    category='normalization',
    quality='real',
)
def vector_normalization(data: pd.DataFrame, **_) -> pd.DataFrame:
    return normalize(data)


@register(
    key='Area Normalization',
    display_name='Area Normalization (sum = 1)',
    category='normalization',
    quality='real',
)
def area_normalization(data: pd.DataFrame, **_) -> pd.DataFrame:
    result = data.copy()
    arr = result.values.astype(float)
    area = np.abs(arr).sum(axis=1, keepdims=True)
    area = np.where(area < 1e-12, 1.0, area)
    result.loc[:, :] = arr / area
    return result


@register(
    key='Maximum Normalization',
    display_name='Maximum Normalization (max = 1)',
    category='normalization',
    quality='real',
)
def maximum_normalization(data: pd.DataFrame, **_) -> pd.DataFrame:
    result = data.copy()
    arr = result.values.astype(float)
    max_abs = np.abs(arr).max(axis=1, keepdims=True)
    max_abs = np.where(max_abs < 1e-12, 1.0, max_abs)
    result.loc[:, :] = arr / max_abs
    return result
