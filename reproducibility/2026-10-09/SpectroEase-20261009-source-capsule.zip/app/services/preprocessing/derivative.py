# app/services/preprocessing/derivative.py
"""Derivative preprocessing: 1st/2nd derivative, SG derivative, finite-difference."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.signal import savgol_filter

from app.services.preprocessing_registry import register


def _first_derivative(arr: np.ndarray) -> np.ndarray:
    return np.gradient(arr, axis=1)


def _second_derivative(arr: np.ndarray) -> np.ndarray:
    g = np.gradient(arr, axis=1)
    return np.gradient(g, axis=1)


@register(
    key='First Derivative',
    display_name='First Derivative',
    category='derivative',
    quality='real',
)
def first_derivative(data: pd.DataFrame, **_) -> pd.DataFrame:
    result = data.copy()
    result.loc[:, :] = _first_derivative(result.values.astype(float))
    return result


@register(
    key='Second Derivative',
    display_name='Second Derivative',
    category='derivative',
    quality='real',
)
def second_derivative(data: pd.DataFrame, **_) -> pd.DataFrame:
    result = data.copy()
    result.loc[:, :] = _second_derivative(result.values.astype(float))
    return result


@register(
    key='Savitzky-Golay Derivative',
    display_name='Savitzky-Golay Derivative',
    category='derivative',
    quality='real',
)
def savgol_derivative(data: pd.DataFrame, window_length: int = 11,
                       polyorder: int = 2, deriv: int = 1, **_) -> pd.DataFrame:
    wl = int(window_length)
    po = int(polyorder)
    if wl < 1 or po < 0 or int(deriv) < 1 or int(deriv)>po:
        raise ValueError('SG derivative requires positive window, derivative order and a sufficient polynomial order')
    if wl % 2 == 0:
        wl += 1
    if po >= wl or wl > data.shape[1]:
        raise ValueError('SG derivative window must fit wavelengths and exceed polynomial order')
    result = data.copy()
    result.loc[:, :] = savgol_filter(
        result.values.astype(float), window_length=wl,
        polyorder=po, deriv=int(deriv),
    )
    return result


@register(
    key='Finite Difference',
    display_name='Finite Difference',
    category='derivative',
    quality='real',
)
def finite_difference(data: pd.DataFrame, step: int = 1, **_) -> pd.DataFrame:
    result = data.copy()
    arr = result.values.astype(float)
    step=int(step)
    if step < 1 or step >= arr.shape[1]:
        raise ValueError('Finite-difference step must be positive and smaller than wavelength count')
    diff = arr[:, step:] - arr[:, :-step]
    pad = np.full((arr.shape[0], step), diff[:, -1:], dtype=float)
    result.loc[:, :] = np.concatenate([diff, pad], axis=1)
    return result


@register(
    key='Gap-Segment Derivative',
    display_name='Gap-Segment Derivative (Savitzky-Golay)',
    category='derivative',
    quality='real',
)
def gap_segment_derivative(data: pd.DataFrame, gap: int = 5,
                           segment_size: int = 11, **_) -> pd.DataFrame:
    """Gap-segment derivative: SG-fit each segment, take derivative at gap steps."""
    from scipy.signal import savgol_filter
    wl = int(segment_size)
    if int(gap) < 1 or wl < 3:
        raise ValueError('Gap and segment size must be positive, with segment size at least 3')
    if wl % 2 == 0:
        wl += 1
    if wl > data.shape[1]:
        raise ValueError('Gap-segment window must fit the wavelength axis')
    arr = data.values.astype(float)
    result = data.copy()
    out = np.zeros_like(arr)
    # Use SG with deriv=1 and delta = gap * sample step (in indices).
    delta = float(gap)
    out = savgol_filter(arr, window_length=wl, polyorder=2,
                        deriv=1, delta=delta, axis=1)
    result.loc[:, :] = out
    return result


@register(key='Third Derivative',display_name='Third Derivative',category='derivative',quality='real')
def third_derivative(data: pd.DataFrame, **_) -> pd.DataFrame:
    arr=data.to_numpy(dtype=float)
    for _ in range(3):
        arr=np.gradient(arr,axis=1)
    return pd.DataFrame(arr,index=data.index,columns=data.columns)
