# app/services/preprocessing/__init__.py
"""Built-in preprocessing methods.

Each module exports one or more decorated functions. Importing this
package registers them with the central ``preprocessing_registry``.

Method categories: baseline, smoothing, scatter, normalization,
derivative, cleaning, alignment.
"""

from app.services.preprocessing import baseline  # noqa: F401
from app.services.preprocessing import smoothing  # noqa: F401
from app.services.preprocessing import scatter  # noqa: F401
from app.services.preprocessing import normalization  # noqa: F401
from app.services.preprocessing import derivative  # noqa: F401
from app.services.preprocessing import alignment  # noqa: F401