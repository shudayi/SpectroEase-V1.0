# app/services/preprocessing/scatter.py
"""Scatter / normalization correction methods: SNV, MSC, EMSC, RNV, OSC."""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.services.preprocessing_registry import register


@register(
    key='Standard Normal Variate (SNV)',
    display_name='Standard Normal Variate (SNV)',
    category='scatter',
    quality='real',
)
def standard_normal_variate(data: pd.DataFrame, center: bool = True, scale: bool = True,
                            min_std: float = 1e-6, **_) -> pd.DataFrame:
    if not np.isfinite(min_std) or min_std <= 0:
        raise ValueError('SNV minimum standard deviation must be positive')
    result = data.copy()
    arr = result.values.astype(float)
    mean = arr.mean(axis=1, keepdims=True)
    std = arr.std(axis=1, keepdims=True, ddof=0)
    std = np.maximum(std,min_std)
    result.loc[:, :] = (arr - mean if center else arr) / (std if scale else 1.0)
    return result


@register(
    key='Multiplicative Scatter Correction (MSC)',
    display_name='Multiplicative Scatter Correction (MSC)',
    category='scatter',
    quality='real',
)
def msc(data: pd.DataFrame, **_) -> pd.DataFrame:
    arr = data.values.astype(float)
    reference = arr.mean(axis=0)
    corrected = np.zeros_like(arr)
    if np.std(reference) < 1e-12:
        raise ValueError('MSC requires a nonconstant reference spectrum')
    for i in range(arr.shape[0]):
        coef = np.polyfit(reference, arr[i], 1)
        if abs(coef[0]) < 1e-12:
            raise ValueError('MSC spectrum has zero multiplicative slope')
        corrected[i] = (arr[i]-coef[1])/coef[0]
    result = data.copy()
    result.loc[:, :] = corrected
    return result


@register(
    key='Extended Multiplicative Scatter Correction (EMSC)',
    display_name='Extended MSC (EMSC)',
    category='scatter',
    quality='approx',
)
def emsc(data: pd.DataFrame, polynomial_order: int = 2, **_) -> pd.DataFrame:
    """EMSC: MSC + polynomial baseline. Polynomial is fitted and subtracted."""
    arr = data.values.astype(float)
    reference = arr.mean(axis=0)
    order = int(polynomial_order)
    if order < 0 or order+2 > arr.shape[1]:
        raise ValueError('EMSC polynomial order must be nonnegative and leave enough wavelength points')
    result = data.copy()
    out = np.zeros_like(arr)
    x = np.linspace(-1, 1, arr.shape[1])
    for i in range(arr.shape[0]):
        basis = np.vstack([reference, *[x ** p for p in range(order + 1)]])
        coef, *_ = np.linalg.lstsq(basis.T, arr[i], rcond=None)
        if abs(coef[0]) < 1e-12:
            raise ValueError('EMSC spectrum has zero reference coefficient')
        polynomial = basis[1:].T @ coef[1:]
        out[i] = (arr[i]-polynomial)/coef[0]
    result.loc[:, :] = out
    return result


@register(
    key='Robust Normal Variate (RNV)',
    display_name='Robust Normal Variate (RNV)',
    category='scatter',
    quality='approx',
)
def rnv(data: pd.DataFrame, **_) -> pd.DataFrame:
    """Median-centred variant of SNV."""
    result = data.copy()
    arr = result.values.astype(float)
    median = np.median(arr, axis=1, keepdims=True)
    mad = np.median(np.abs(arr - median), axis=1, keepdims=True)
    mad = np.where(mad < 1e-12, 1.0, mad) * 1.4826
    result.loc[:, :] = (arr - median) / mad
    return result


@register(
    key='Orthogonal Signal Correction (OSC)',
    display_name='Orthogonal Signal Correction (OSC)',
    category='scatter',
    quality='stub',
)
def osc(data: pd.DataFrame, n_components: int = 1, **_) -> pd.DataFrame:
    """OSC requires supervised fitting; no surrogate target is manufactured."""
    raise ValueError('OSC is unavailable: it requires an explicit training target and reusable fitted state')
