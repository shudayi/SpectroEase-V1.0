# app/services/preprocessing/baseline.py
"""Baseline correction methods: polynomial, ALS, airPLS.

ALS (Asymmetric Least Squares Smoothing) and airPLS are implemented as
described in Eilers & Boelens 2005 and Zhang et al. 2010.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.sparse.linalg import spsolve

from app.services.preprocessing_registry import register


@register(
    key='Baseline Correction',
    display_name='Baseline Correction (Polynomial)',
    category='baseline',
    quality='approx',
)
def baseline_correction(data: pd.DataFrame, method: str = 'Polynomial',
                        polynomial_order: int = 3, **_) -> pd.DataFrame:
    """Polynomial baseline correction. ALS / airPLS are real implementations."""
    order = int(polynomial_order)
    if str(method).lower() == 'als':
        return als_baseline(data)
    if str(method).lower() == 'airpls':
        return airpls_baseline(data)
    if str(method).lower() != 'polynomial':
        raise ValueError(f'Unsupported baseline method: {method}')
    if order < 0 or order >= data.shape[1]:
        raise ValueError('Polynomial order must be nonnegative and smaller than wavelength count')
    out=[]
    for row in data.to_numpy(dtype=float):
        x = np.arange(data.shape[1], dtype=float)
        coef = np.polyfit(x, row, order)
        baseline = np.polyval(coef, x)
        out.append(row-baseline)
    return pd.DataFrame(out,index=data.index,columns=data.columns)


def _als_baseline(y: np.ndarray, lam: float = 1e5, p: float = 0.01,
                  niter: int = 10) -> np.ndarray:
    """Eilers 2005 Asymmetric Least Squares Smoothing baseline."""
    L = len(y)
    # Second-difference penalty matrix (sparse banded form, then dense for solve).
    if L < 3 or not np.isfinite(lam) or lam <= 0 or not 0 < p < 1 or int(niter) < 1:
        raise ValueError('ALS requires at least 3 wavelengths, lambda > 0, 0 < p < 1, and iterations > 0')
    D = sparse.diags([np.ones(L-2),-2*np.ones(L-2),np.ones(L-2)], [0,1,2],shape=(L-2,L),format='csc')
    H = lam * (D.T @ D)
    w = np.ones(L)
    for _ in range(int(niter)):
        W = sparse.diags(w,format='csc')
        Z = W + H
        z = spsolve(Z, w * y)
        w = p * (y > z) + (1 - p) * (y <= z)
    return z


def _airpls_baseline(y: np.ndarray, lam: float = 1e5, niter: int = 15,
                      porder: int = 2) -> np.ndarray:
    """Zhang 2010 airPLS baseline."""
    L = len(y)
    porder=int(porder)
    if porder < 1 or porder >= L or not np.isfinite(lam) or lam <= 0 or int(niter)<1:
        raise ValueError('airPLS requires a valid positive penalty order, lambda and iteration count')
    D = sparse.eye(L,format='csc')
    for _ in range(porder):
        D=D[1:]-D[:-1]
    H = lam * (D.T @ D)
    w = np.ones(L)
    z = np.full(L, np.mean(y))
    for i in range(1, int(niter) + 1):
        W = sparse.diags(w,format='csc')
        Z = W + H
        z = spsolve(Z, w * y)
        residual = y - z
        neg = residual[residual < 0]
        negative_mass=float(np.abs(neg).sum())
        if negative_mass <= max(1e-12,0.001*np.abs(y).sum()) or i == int(niter):
            break
        # Zhang et al. 2010: suppress positive peak residuals, emphasize negative residuals.
        w=np.zeros(L)
        w[residual<0]=np.exp(np.clip(i*np.abs(neg)/negative_mass,-700,700))
        w[0]=w[-1]=np.exp(i*neg.max()/negative_mass)
    return z


@register(
    key='Baseline (ALS)',
    display_name='Baseline Correction (ALS, Whittaker)',
    category='baseline',
    quality='real',
)
def als_baseline(data: pd.DataFrame, lam: float = 1e5, p: float = 0.01,
                 niter: int = 10, **_) -> pd.DataFrame:
    """Asymmetric Least Squares baseline (Eilers 2005)."""
    out=[row-_als_baseline(row,lam=lam,p=p,niter=niter) for row in data.to_numpy(dtype=float)]
    return pd.DataFrame(out,index=data.index,columns=data.columns)


@register(
    key='Baseline (airPLS)',
    display_name='Baseline Correction (airPLS)',
    category='baseline',
    quality='real',
)
def airpls_baseline(data: pd.DataFrame, lam: float = 1e5, niter: int = 15,
                    porder: int = 2, **_) -> pd.DataFrame:
    """airPLS baseline (Zhang 2010)."""
    out=[row-_airpls_baseline(row,lam=lam,niter=niter,porder=porder) for row in data.to_numpy(dtype=float)]
    return pd.DataFrame(out,index=data.index,columns=data.columns)
