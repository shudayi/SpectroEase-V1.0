# app/services/preprocessing/alignment.py
"""Peak alignment: DTW / COW / ICS via shared NLM-backed DP.

DTW is now a real Bellman DP implementation. COW uses DTW alignment to
build a piecewise-linear warp; ICS performs an interval-cosine warp.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.services.preprocessing_registry import register


def _dtw_alignment(reference: np.ndarray, target: np.ndarray,
                   window: int = 50) -> tuple:
    """Bellman DP DTW alignment.

    Returns (warped_target, path) where ``path`` is a list of (ref_idx, tgt_idx)
    indices representing the alignment.
    """
    n = len(reference)
    m = len(target)
    if n == 0 or m == 0 or int(window) < abs(n-m) or int(window)<1:
        raise ValueError('DTW requires nonempty spectra and a positive window spanning the length difference')
    window=int(window)
    window = max(1, min(window, n + m))
    cost = np.full((n + 1, m + 1), np.inf)
    cost[0, 0] = 0.0
    for i in range(1, n + 1):
        lo = max(1, i - window)
        hi = min(m, i + window)
        for j in range(lo, hi + 1):
            d = (reference[i - 1] - target[j - 1]) ** 2
            cost[i, j] = d + min(cost[i - 1, j], cost[i, j - 1], cost[i - 1, j - 1])

    # Trace back the optimal path.
    i, j = n, m
    path = []
    while i > 0 and j > 0:
        path.append((i - 1, j - 1))
        candidates = [
            cost[i - 1, j - 1],
            cost[i - 1, j],
            cost[i, j - 1],
        ]
        move = int(np.argmin(candidates))
        if move == 0:
            i -= 1
            j -= 1
        elif move == 1:
            i -= 1
        else:
            j -= 1
    path.reverse()
    if not path:
        return target.copy(), [(0, 0)]
    # Multiple target points may map to one reference index. Average each
    # reference bucket instead of truncating the longer warping path.
    sums=np.zeros(n)
    counts=np.zeros(n)
    for ref_i,tgt_i in path:
        sums[ref_i]+=target[tgt_i]
        counts[ref_i]+=1
    if np.any(counts==0):
        raise ValueError('DTW path did not cover the reference wavelength axis')
    return sums/counts, path


@register(
    key='Peak Alignment',
    display_name='Peak Alignment (DTW)',
    category='alignment',
    quality='real',
)
def peak_alignment(data: pd.DataFrame, reference: list = None,
                   window: int = 50, **_) -> pd.DataFrame:
    """DTW-align each row to the mean spectrum (or first reference row)."""
    arr = data.values.astype(float)
    ref = np.asarray(reference, dtype=float) if reference is not None else arr.mean(axis=0)
    if ref.ndim == 2:
        ref = ref[0]
    if ref.ndim != 1 or len(ref)!=arr.shape[1] or not np.isfinite(ref).all():
        raise ValueError('Alignment reference must be finite and match the wavelength count')
    result = data.copy()
    out = np.zeros_like(arr)
    for i in range(arr.shape[0]):
        warped, _ = _dtw_alignment(ref, arr[i], window=window)
        out[i] = warped
    result.loc[:, :] = out
    return result


@register(
    key='COW (Correlation Optimized Warping)',
    display_name='COW (Correlation Optimized Warping)',
    category='alignment',
    quality='approx',
)
def cow_alignment(data: pd.DataFrame, segment_length: int = 20,
                   slack: int = 2, **_) -> pd.DataFrame:
    """COW alignment: piecewise linear warp anchored at segment boundaries."""
    arr = data.values.astype(float)
    ref = arr.mean(axis=0)
    sl = int(segment_length)
    slack=int(slack)
    if sl<2 or slack<0:
        raise ValueError('COW approximation requires segment length >= 2 and nonnegative slack')
    result = data.copy()
    out = np.zeros_like(arr)
    for i in range(arr.shape[0]):
        warped = _cow_warp(ref, arr[i], segment_length=sl, slack=slack)
        out[i] = warped
    result.loc[:, :] = out
    return result


def _cow_warp(reference: np.ndarray, target: np.ndarray,
              segment_length: int = 20, slack: int = 2) -> np.ndarray:
    n = len(reference)
    sl = max(2, segment_length)
    boundaries = list(range(0, n, sl)) + [n]
    warped = target.copy()
    for k in range(len(boundaries) - 1):
        s = boundaries[k]
        e = boundaries[k + 1]
        ref_seg = reference[s:e]
        tgt_seg = warped[s:e]
        if len(ref_seg) < 2 or len(tgt_seg) < 2:
            continue
        # Cross-correlate to find the best local shift in [-slack, +slack].
        max_shift = 0
        best = np.inf
        for shift in range(-slack, slack + 1):
            shifted = _shift_segment(tgt_seg,shift)
            d = float(np.mean((ref_seg - shifted) ** 2))
            if d < best:
                best = d
                max_shift = shift
        warped[s:e] = _shift_segment(tgt_seg,max_shift)
    return warped


@register(
    key='ICS (Interval Correlation Shifting)',
    display_name='ICS (Interval Correlation Shifting)',
    category='alignment',
    quality='approx',
)
def ics_alignment(data: pd.DataFrame, interval_size: int = 20,
                   max_shift: int = 5, **_) -> pd.DataFrame:
    """ICS alignment: per-interval linear interpolation."""
    arr = data.values.astype(float)
    ref = arr.mean(axis=0)
    interval = int(interval_size)
    max_shift = int(max_shift)
    if interval<2 or max_shift<0:
        raise ValueError('ICS approximation requires interval >= 2 and nonnegative maximum shift')
    result = data.copy()
    out = np.zeros_like(arr)
    for i in range(arr.shape[0]):
        out[i] = _ics_warp(ref, arr[i], interval=interval, max_shift=max_shift)
    result.loc[:, :] = out
    return result


def _ics_warp(reference: np.ndarray, target: np.ndarray,
              interval: int = 20, max_shift: int = 5) -> np.ndarray:
    n = len(reference)
    boundaries = list(range(0, n, interval)) + [n]
    warped = target.copy()
    for k in range(len(boundaries) - 1):
        s = boundaries[k]
        e = boundaries[k + 1]
        ref_seg = reference[s:e]
        tgt_seg = warped[s:e]
        if len(ref_seg) < 2:
            continue
        best_shift = 0
        best_corr = -np.inf
        for shift in range(-max_shift, max_shift + 1):
            shifted = _shift_segment(tgt_seg,shift)
            denom = (np.std(ref_seg) * np.std(shifted)) + 1e-12
            corr = float(np.mean((ref_seg - ref_seg.mean()) *
                                  (shifted - shifted.mean())) / denom)
            if corr > best_corr:
                best_corr = corr
                best_shift = shift
        if best_shift != 0:
            warped[s:e] = _shift_segment(tgt_seg,best_shift)
    return warped


def _shift_segment(segment,shift):
    """Shift with edge replication, never wrap a spectral endpoint around."""
    positions=np.arange(len(segment),dtype=float)
    return np.interp(positions-shift,positions,segment)
