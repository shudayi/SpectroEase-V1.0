# app/services/preprocessing/smoothing.py
"""Smoothing methods: SG, moving average, median, Gaussian, wavelet."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.signal import savgol_filter
from scipy.ndimage import uniform_filter1d, median_filter as scipy_median_filter, gaussian_filter1d

from app.services.preprocessing_registry import register


@register(
    key='Savitzky-Golay Filter',
    display_name='Savitzky-Golay Filter',
    category='smoothing',
    quality='real',
)
def savgol_filter_fn(data: pd.DataFrame, window_length: int = 11,
                     polyorder: int = 2, **_) -> pd.DataFrame:
    wl = int(window_length)
    po = int(polyorder)
    if wl < 1 or po < 0:
        raise ValueError('SG window must be positive and polynomial order nonnegative')
    if wl % 2 == 0:
        wl += 1
    if wl > data.shape[1] or po >= wl:
        raise ValueError('SG window must fit the wavelength axis and exceed polynomial order')
    return pd.DataFrame(savgol_filter(data.to_numpy(dtype=float), wl, po, axis=1),
                        index=data.index, columns=data.columns)


@register(
    key='Moving Average',
    display_name='Moving Average',
    category='smoothing',
    quality='real',
)
def moving_average(data: pd.DataFrame, window_size: int = 5, **_) -> pd.DataFrame:
    w = int(window_size)
    if w < 1 or w > data.shape[1]:
        raise ValueError('Moving-average window must be between 1 and the wavelength count')
    return pd.DataFrame(uniform_filter1d(data.to_numpy(dtype=float), size=w, axis=1, mode='nearest'),
                        index=data.index, columns=data.columns)


@register(
    key='Median Filter',
    display_name='Median Filter',
    category='smoothing',
    quality='real',
)
def median_filter(data: pd.DataFrame, window_size: int = 5, **_) -> pd.DataFrame:
    w = int(window_size)
    if w < 1 or w > data.shape[1]:
        raise ValueError('Median window must be between 1 and the wavelength count')
    return pd.DataFrame(scipy_median_filter(data.to_numpy(dtype=float), size=(1,w), mode='nearest'),
                        index=data.index, columns=data.columns)


@register(
    key='Gaussian Smooth',
    display_name='Gaussian Smooth',
    category='smoothing',
    quality='real',
)
def gaussian_smooth(data: pd.DataFrame, sigma: float = 1.5,
                    window_size: int = 5, **_) -> pd.DataFrame:
    sigma = float(sigma)
    w = int(window_size)
    if not np.isfinite(sigma) or sigma <= 0 or w < 1 or w > data.shape[1]:
        raise ValueError('Gaussian sigma must be positive and window must fit the wavelength axis')
    return pd.DataFrame(gaussian_filter1d(data.to_numpy(dtype=float), sigma=sigma, axis=1,
                                         mode='nearest', radius=w//2),index=data.index,columns=data.columns)


@register(
    key='Wavelet Smooth',
    display_name='Wavelet Smooth',
    category='smoothing',
    quality='approx',
)
def wavelet_smooth(data: pd.DataFrame, wavelet: str = 'db4', level: int = 1,
                   **_) -> pd.DataFrame:
    """Soft-thresholding wavelet denoise (PyWavelets)."""
    try:
        import pywt
    except ImportError as exc:
        raise RuntimeError("Wavelet smoothing requires PyWavelets (pip install PyWavelets)") from exc

    level = int(level)
    max_level = pywt.dwt_max_level(data.shape[1], pywt.Wavelet(wavelet).dec_len)
    if level < 1 or level > max_level:
        raise ValueError(f'Wavelet level must be between 1 and {max_level} for this wavelength axis')
    out = []
    for arr in data.to_numpy(dtype=float,copy=True):
        coeffs = pywt.wavedec(arr, wavelet=wavelet, level=level)
        sigma = np.median(np.abs(coeffs[-level])) / 0.6745 if level >= 1 else 0.0
        threshold = sigma * np.sqrt(2 * np.log(len(arr)))
        new_coeffs = [coeffs[0]] + [
            pywt.threshold(c, threshold, mode='soft') for c in coeffs[1:]
        ]
        out.append(pywt.waverec(new_coeffs, wavelet)[:len(arr)])
    return pd.DataFrame(out,index=data.index,columns=data.columns)


@register(
    key='Despiking',
    display_name='Despiking (Spike Removal)',
    category='cleaning',
    quality='real',
)
def despiking(data: pd.DataFrame, method: str = 'MAD',
              window: int = 7, threshold: float = 5.0, **_) -> pd.DataFrame:
    """Remove cosmic spikes using local MAD / local z-score."""
    result = data.copy()
    window = int(window)
    thr = float(threshold)
    method_key = str(method).lower()
    if method_key not in ('mad','localz','local z-score'):
        raise ValueError(f'Unsupported despiking method: {method}')
    if window < 3 or window > data.shape[1] or thr <= 0 or not np.isfinite(thr):
        raise ValueError('Despiking window must fit wavelengths and threshold must be positive')
    out=[]
    for series in data.to_numpy(dtype=float):
        n = len(series)
        cleaned = series.copy()
        half = window // 2
        for i in range(n):
            lo = max(0, i - half)
            hi = min(n, i + half + 1)
            local = series[lo:hi]
            local_median = np.median(local)
            mad = np.median(np.abs(local - local_median))
            if method_key == 'mad':
                scale=mad*1.4826
                center=local_median
                # A spike in a locally flat spectrum has zero MAD.
                if scale <= 1e-12 and abs(series[i]-center)>1e-12:
                    cleaned[i]=center
                elif scale>0 and abs(series[i]-center)>thr*scale:
                    cleaned[i]=center
            else:
                # Leave the candidate point out so its own magnitude cannot mask it.
                neighbors=np.delete(local,i-lo)
                center=float(np.mean(neighbors))
                scale=float(np.std(neighbors))
                if abs(series[i]-center)>thr*max(scale,1e-12):
                    cleaned[i]=center
        out.append(cleaned)
    return pd.DataFrame(out,index=data.index,columns=data.columns)


@register(
    key='Outlier Detection',
    display_name='Outlier Detection (IQR / Isolation Forest)',
    category='cleaning',
    quality='approx',
)
def outlier_detection(data: pd.DataFrame, method: str = 'IQR',
                      threshold: float = 1.5, **_) -> pd.DataFrame:
    """Drop rows containing any outlier cell per-column."""
    result = data.copy()
    threshold = float(threshold)
    if threshold <= 0 or not np.isfinite(threshold):
        raise ValueError('Outlier threshold must be positive')
    numeric = result.select_dtypes(include=[np.number])
    if method.upper() == 'IQR':
        q1 = numeric.quantile(0.25)
        q3 = numeric.quantile(0.75)
        iqr = q3 - q1
        lower = q1 - threshold * iqr
        upper = q3 + threshold * iqr
        mask = ~((numeric < lower) | (numeric > upper)).any(axis=1)
        return result.loc[mask]

    if method.lower() not in ('z-score','zscore'):
        raise ValueError(f'Unsupported outlier method: {method}; use IQR or Z-score')
    z = (numeric - numeric.mean()) / (numeric.std(ddof=0) + 1e-12)
    mask = ~(np.abs(z) > threshold).any(axis=1)
    return result.loc[mask]


@register(
    key='Denoising',
    display_name='Denoising (moving-average blend, approximate)',
    category='cleaning',
    quality='approx',
)
def denoising(data: pd.DataFrame, strength: float = 0.5,
              window_size: int = 5, **_) -> pd.DataFrame:
    """Approximate denoising: blend each spectrum with its moving average."""
    strength = float(strength)
    if not np.isfinite(strength) or not 0 <= strength <= 1:
        raise ValueError('Denoising strength must be in [0,1]')
    return moving_average(data, window_size=int(window_size)) * strength + data * (1 - strength)
