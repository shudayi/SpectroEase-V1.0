"""Private child-process entry point for trusted local ONNX requests."""
import json
import os
import pickle
import sys


def main():
    os.environ['SPECTROEASE_ONNX_WORKER'] = '1'
    from app.services.onnx_service import ONNXService
    with open(sys.argv[1], 'rb') as handle:
        directory, operation, args, kwargs = pickle.load(handle)
    if operation not in ('can_export_to_onnx', 'export_model_to_onnx', 'export_analyzer_to_onnx'):
        raise ValueError('Unsupported private worker operation')
    service = ONNXService(directory)
    result = getattr(service, operation)(*args, **kwargs)
    with open(sys.argv[2], 'w', encoding='utf-8') as handle:
        json.dump({'result': result, 'error': service.last_error}, handle)


if __name__ == '__main__':
    main()
