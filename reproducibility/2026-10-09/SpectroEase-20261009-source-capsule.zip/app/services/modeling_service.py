# app/services/modeling_service.py

import time
import weakref
from typing import Dict, Any, List, Tuple, Union, Optional

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import SelectKBest, f_classif, f_regression
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from app.utils.exceptions import ModelingError
from app.utils.data_compatibility import prepare_labels_safely, standardize_classification_labels
from app.utils.logger import setup_logger
from app.services.evaluation_service import (
    safe_accuracy, safe_precision, safe_recall, safe_f1
)
from app.services.evaluation_service import EvaluationService
from interfaces.modeling_algorithm import ModelingAlgorithm
from plugins.modeling.quantitative_analyzer import QuantitativeAnalyzer
from plugins.modeling.qualitative_analyzer import QualitativeAnalyzer

class ModelingService:
    def __init__(self, plugins: dict):
        self.plugins = plugins  # 动态加载的插件字典
        self.models = {}        # In-memory model registry for controller-driven workflows
        # 全局random_state管理（需求E）
        self.global_random_state = 42
        self.logger = setup_logger(__name__)
        self.evaluation_service = EvaluationService()
        # Service-owned metadata container to avoid mutating sklearn estimators.
        self._model_meta = weakref.WeakKeyDictionary()

    def _set_model_meta(self, model, **kwargs):
        """Store service-owned metadata for an estimator without mutating it."""
        if model not in self._model_meta:
            self._model_meta[model] = {}
        self._model_meta[model].update(kwargs)

    def _get_model_meta(self, model, key=None, default=None):
        """Retrieve service-owned metadata for an estimator."""
        meta = self._model_meta.get(model, {})
        if key is None:
            return meta
        return meta.get(key, default)

    def create_leak_proof_pipeline(self, model_name: str, params: dict, task_type: str, 
                                   enable_scaling: bool = True, enable_feature_selection: bool = False,
                                   n_features_to_select: int = None) -> Pipeline:
        """创建防信息泄漏的Pipeline（需求E）
        
        Args:
            model_name: 模型名称
            params: 模型Parameters
            task_type: Task type ('classification' or 'regression')
            enable_scaling: 是否启用标准化
            enable_feature_selection: 是否启用特征选择
            n_features_to_select: 特征选择数量
            
        Returns:
            Pipeline: 完整的处理流水线
        """
        if task_type not in ('classification', 'regression'):
            raise ModelingError(f"Unsupported task type: {task_type}")
        steps = []
        
        # 步骤1：标准化/缩放（在CV内执行）
        if enable_scaling:
            steps.append(('scaler', StandardScaler()))
        
        # 步骤2：特征选择（在CV内执行）
        if enable_feature_selection and n_features_to_select:
            if task_type == 'classification':
                selector = SelectKBest(score_func=f_classif, k=n_features_to_select)
            else:
                selector = SelectKBest(score_func=f_regression, k=n_features_to_select)
            steps.append(('feature_selection', selector))
        
        # 步骤3：模型（确保使用全局random_state）
        model_params = params.copy()
        # SVR and nearest-neighbour estimators have no random_state argument.
        # Preserve explicit parameters and inject the seed only where supported.
        seed_supported = not (
            model_name in ("K-Nearest Neighbors (KNN)", "knn")
            or (task_type == 'regression' and model_name in ("Support Vector Machine (SVM)", "svm"))
        )
        if seed_supported and 'random_state' not in model_params:
            model_params['random_state'] = self.global_random_state
        
        # 根据模型名称创建模型
        if model_name == "Logistic Regression":
            model = LogisticRegression(**model_params)
        elif model_name == "Random Forest" or model_name == "rf":
            if task_type == 'classification':
                model = RandomForestClassifier(**model_params)
            else:
                from sklearn.ensemble import RandomForestRegressor
                model = RandomForestRegressor(**model_params)
        elif model_name == "Support Vector Machine (SVM)" or model_name == "svm":
            if task_type == 'classification':
                model = SVC(**model_params)
            else:
                from sklearn.svm import SVR
                model = SVR(**model_params)
        elif model_name == "K-Nearest Neighbors (KNN)" or model_name == "knn":
            if task_type == 'classification':
                model = KNeighborsClassifier(**model_params)
            else:
                from sklearn.neighbors import KNeighborsRegressor
                model = KNeighborsRegressor(**model_params)
        elif model_name == "Decision Tree" or model_name == "dt":
            if task_type == 'classification':
                model = DecisionTreeClassifier(**model_params)
            else:
                from sklearn.tree import DecisionTreeRegressor
                model = DecisionTreeRegressor(**model_params)
        elif model_name == "Neural Network":
            from sklearn.neural_network import MLPClassifier, MLPRegressor
            if task_type == 'classification':
                model = MLPClassifier(**model_params)
            else:
                model = MLPRegressor(**model_params)
        else:
            raise ModelingError(f"Unsupported model for pipeline: {model_name}")
        
        steps.append(('model', model))
        
        # 创建Pipeline
        pipeline = Pipeline(steps)
        
        # 存储元信息
        self._set_model_meta(
            pipeline,
            task_type=task_type,
            global_random_state=self.global_random_state,
            model_name=model_name,
        )

        self.logger.info("Created leak-proof pipeline for %s (steps=%s, task_type=%s, random_state=%s)",
                         model_name, [step[0] for step in steps], task_type, self.global_random_state)

        return pipeline

    def train_model_with_cv(self, model_name: str, params: dict, X: pd.DataFrame, y: pd.Series,
                           cv_params: dict = None, hyperopt_params: dict = None):
        """使用交叉验证训练模型，确保防泄漏（需求E）
        
        Args:
            model_name: 模型名称
            params: 模型Parameters
            X: 特征数据
            y: 目标变量
            cv_params: 交叉验证Parameters
            hyperopt_params: 超Parameters优化Parameters
            
        Returns:
            训练好的模型或Pipeline
        """
        # 检测Task type
        task_type = self._detect_task_type(y)
        
        # 默认CVParameters
        if cv_params is None:
            cv_params = {
                'enable_scaling': True,
                'enable_feature_selection': False,
                'n_features_to_select': min(20, X.shape[1] // 2)
            }
        
        # 创建防泄漏Pipeline
        pipeline = self.create_leak_proof_pipeline(
            model_name=model_name,
            params=params,
            task_type=task_type,
            enable_scaling=cv_params.get('enable_scaling', True),
            enable_feature_selection=cv_params.get('enable_feature_selection', False),
            n_features_to_select=cv_params.get('n_features_to_select', None)
        )
        
        # 处理标签（分类任务）
        if task_type == 'classification':
            if isinstance(y, pd.Series):
                y_processed = y.astype(str)
            else:
                y_processed = np.array([str(label) for label in y])
            
            from sklearn.preprocessing import LabelEncoder
            label_encoder = LabelEncoder()
            y_encoded = label_encoder.fit_transform(y_processed)
            
            # 存储标签编码器到服务元数据容器，避免修改estimator
            self._set_model_meta(pipeline, label_encoder=label_encoder)
            y_final = y_encoded
        else:
            y_final = y

        # 超Parameters优化（可选）
        if hyperopt_params and hyperopt_params.get('enable', False):
            param_grid = hyperopt_params.get('param_grid', {})
            cv_folds = hyperopt_params.get('cv_folds', 5)

            # 为PipelineParameters添加前缀
            pipeline_param_grid = {}
            for param_name, param_values in param_grid.items():
                pipeline_param_grid[f'model__{param_name}'] = param_values

            if pipeline_param_grid:
                search_method = hyperopt_params.get('method', 'grid')
                if search_method == 'random':
                    n_iter = hyperopt_params.get('n_iter', 10)
                    search = RandomizedSearchCV(
                        pipeline, pipeline_param_grid,
                        cv=cv_folds, n_iter=n_iter,
                        random_state=self.global_random_state,
                        n_jobs=-1
                    )
                else:
                    search = GridSearchCV(
                        pipeline, pipeline_param_grid,
                        cv=cv_folds,
                        n_jobs=-1
                    )

                self.logger.info("Performing %s search with CV=%s", search_method, cv_folds)
                search.fit(X, y_final)
                best_pipeline = search.best_estimator_

                self.logger.info("Best parameters: %s", search.best_params_)
                self.logger.info("Best CV score: %.4f", search.best_score_)

                return best_pipeline

        # 直接训练Pipeline
        self.logger.info("Training %s pipeline...", model_name)
        pipeline.fit(X, y_final)
        self.logger.info("Pipeline training completed")
        
        return pipeline

    def _detect_task_type(self, y):
        """检测Task type"""
        if not hasattr(self, 'label_processor'):
            from app.utils.label_processor import EnhancedLabelProcessor
            self.label_processor = EnhancedLabelProcessor()
        
        return self.label_processor.detect_task_type(y)

    def train_model(self, model_name: str, params: dict, X: pd.DataFrame, y: pd.Series,
                    task_type: Optional[str] = None):
        """Train a built-in or plugin model.

        Args:
            model_name: Name of the model/algorithm.
            params: Hyperparameters and training options.
            X: Feature matrix.
            y: Target vector.
            task_type: Explicit task type ('classification' or 'regression').
                       When omitted, the task type is auto-detected from y.
        """
        # Ensure params is a dictionary without model_method
        if params is None:
            params = {}
        elif 'model_method' in params:
            # Remove model_method parameter to avoid passing to sklearn models
            params = {k: v for k, v in params.items() if k != 'model_method'}

        # Backwards compatibility: accept task_type passed via params as well.
        params_task_type = params.pop('task_type', None)
        if task_type is None:
            task_type = params_task_type

        if task_type is not None:
            is_classification = (task_type == 'classification')
            self.logger.info("Using explicitly specified task type: %s", task_type)
        else:
            is_classification = self._is_classification_task(y)
            task_type = 'classification' if is_classification else 'regression'
            self.logger.info("Auto-detected task type based on data: %s", task_type)

        self.logger.info("Final decision - Task type: %s, target unique values: %s, samples: %s",
                         task_type, y.nunique(), len(y))
            
        if model_name in self.plugins:
            algorithm: ModelingAlgorithm = self.plugins[model_name]
            algorithm.train(X, y, params)
            return algorithm
        else:
            try:
                if model_name == "Logistic Regression":
                    if not is_classification:
                        raise ModelingError("Logistic Regression only supports classification tasks.")
  
                    
                    model = LogisticRegression(**params)
                elif model_name == "Random Forest" or model_name == "rf":
                    if is_classification:


                        model = RandomForestClassifier(**params)
                    else:
                        from sklearn.ensemble import RandomForestRegressor
                        model = RandomForestRegressor(**params)
                elif model_name == "Support Vector Machine (SVM)" or model_name == "svm":
                    if is_classification:


                        model = SVC(**params)
                    else:
                        from sklearn.svm import SVR
                        model = SVR(**params)
                elif model_name == "K-Nearest Neighbors (KNN)" or model_name == "knn":
                    if is_classification:


                        model = KNeighborsClassifier(**params)
                    else:
                        from sklearn.neighbors import KNeighborsRegressor
                        model = KNeighborsRegressor(**params)
                elif model_name == "Decision Tree" or model_name == "dt":
                    if is_classification:


                        model = DecisionTreeClassifier(**params)
                    else:
                        from sklearn.tree import DecisionTreeRegressor
                        model = DecisionTreeRegressor(**params)
                elif model_name == "Gradient Boosting" or model_name == "gb":
                    if is_classification:


                        model = GradientBoostingClassifier(**params)
                    else:
                        from sklearn.ensemble import GradientBoostingRegressor
                        model = GradientBoostingRegressor(**params)
                elif model_name == "XGBoost":
                    try:
                        import xgboost as xgb
                        if is_classification:

    
                            model = xgb.XGBClassifier(**params)
                        else:
                            model = xgb.XGBRegressor(**params)
                    except ImportError:
                        raise ModelingError("XGBoost is not installed. Please install it with: pip install xgboost")
                elif model_name == "Neural Network":
                    from sklearn.neural_network import MLPClassifier, MLPRegressor
                    if is_classification:


                        model = MLPClassifier(**params)
                    else:
                        model = MLPRegressor(**params)
                else:
                    raise ModelingError(f"Unsupported model: {model_name}")
                
                self.logger.info("Fitting %s for %s task", model.__class__.__name__, task_type)

                # **CRITICAL FIX: Handle mixed label types before calling sklearn fit**
                if is_classification:
                    # Convert all labels to consistent string type first
                    self.logger.debug("Standardizing labels for sklearn compatibility")

                    if isinstance(y, pd.Series):
                        y_consistent = y.astype(str)
                    elif isinstance(y, pd.DataFrame):
                        y_consistent = y.iloc[:, 0].astype(str)
                    elif hasattr(y, 'astype'):
                        y_consistent = y.astype(str)
                    else:
                        y_consistent = np.array([str(label) for label in y])

                    self.logger.debug("Labels converted to consistent string type: %s", type(y_consistent).__name__)
                    self.logger.debug("Sample labels: %s", list(y_consistent[:5]))

                    # Now encode string labels to integers for sklearn
                    from sklearn.preprocessing import LabelEncoder
                    label_encoder = LabelEncoder()
                    y_encoded = label_encoder.fit_transform(y_consistent)

                    self.logger.debug("Labels encoded to integers: %s", type(y_encoded).__name__)
                    self.logger.debug("Label range: %s to %s, classes: %s",
                                      y_encoded.min(), y_encoded.max(), len(np.unique(y_encoded)))
                    self.logger.debug("Label type consistency verified - ready for sklearn fit")

                    # Store label encoder in service-owned metadata container.
                    self._set_model_meta(model, label_encoder=label_encoder)
                    y = y_encoded

                elif hasattr(y, 'dtype') and y.dtype.kind == 'f':  # 浮点类型
                    self.logger.debug("Converting %s type labels to integer type", y.dtype)
                    # **CRITICAL FIX: Use enhanced label processor to check before conversion**
                    conversion_task_type = self.label_processor.detect_task_type(y)
                    if conversion_task_type == 'classification':
                        self.logger.debug("Classification labels detected - skipping numeric conversion")
                        # Keep as is for classification
                        pass
                    else:
                        self.logger.debug("Regression labels detected - proceeding with conversion")

                # **CRITICAL FIX: Final safety check before sklearn fit**
                self.logger.debug("Final data check before model.fit: X shape=%s, y type=%s, dtype=%s",
                                  X.shape, type(y), y.dtype if hasattr(y, 'dtype') else 'no dtype')

                # Additional safety check for string labels in y
                if hasattr(y, 'dtype') and y.dtype.kind in 'UO':  # Unicode or Object
                    self.logger.error("CRITICAL ERROR: y still contains string labels before sklearn fit!")
                    # This should never happen at this point, but let's handle it
                    from sklearn.preprocessing import LabelEncoder
                    emergency_encoder = LabelEncoder()
                    y = emergency_encoder.fit_transform(y.astype(str))
                    self._set_model_meta(model, emergency_encoder=emergency_encoder)
                    self.logger.warning("Emergency label encoding applied, y now: %s", y[:5])

                model.fit(X, y)
                self.logger.info("model.fit() completed successfully")

                # Store task type in service-owned metadata container (not on the estimator).
                self._set_model_meta(model, task_type=task_type)

                return model
            except Exception as e:
                raise ModelingError(f"Failed to train model {model_name}: {e}")
                
    def _is_classification_task(self, y):
        """
        DEPRECATED: Use enhanced label processor instead  
        This method is kept for backward compatibility
        """
        # **CRITICAL FIX: Use enhanced label processor for consistent detection**
        if not hasattr(self, 'label_processor'):
            from app.utils.label_processor import EnhancedLabelProcessor
            self.label_processor = EnhancedLabelProcessor()
        
        task_type = self.label_processor.detect_task_type(y)
        return task_type == 'classification'

    def predict(self, model_id: str, X: np.ndarray, row_ids=None,
                physical_sample_ids=None, group_ids=None) -> Dict[str, Any]:
        """
        使用指定模型进行prediction
        
        Args:
            model_id: 模型ID
            X: 输入featuresdata
            
        Returns:
            Dict: 包含predictionresults的字典
        """
        try:
            model_data = self.get_model_data(model_id)
            if not model_data or not hasattr(model_data, 'model') or model_data.model is None:
                return {"error": "Model does not exist or is not trained"}

            fitted_predictor = getattr(model_data, 'fitted_predictor', None)
            if fitted_predictor is not None:
                prediction_result = fitted_predictor.predict_result(
                    X, row_ids=row_ids, physical_sample_ids=physical_sample_ids,
                    group_ids=group_ids, enforce_disjoint=False,
                )
                model_data.prediction_result = prediction_result
                return {
                    "predictions": prediction_result.predictions.tolist(),
                    "task_type": prediction_result.task_type,
                    "shape": tuple(prediction_result.predictions.shape),
                    "row_ids": list(prediction_result.row_ids) if prediction_result.row_ids is not None else None,
                    "physical_sample_ids": list(prediction_result.physical_sample_ids) if prediction_result.physical_sample_ids is not None else None,
                    "group_ids": list(prediction_result.group_ids) if prediction_result.group_ids is not None else None,
                    "prediction_result": prediction_result,
                }
                
            model = model_data.model
            
            # 准备输入数据
            try:
                if isinstance(X, pd.DataFrame):
                    X_data = X
                elif isinstance(X, np.ndarray):
                    if hasattr(model_data, 'feature_names'):
                        feature_names = model_data.feature_names
                        if len(feature_names) == X.shape[1]:
                            X_data = pd.DataFrame(X, columns=feature_names)
                        else:
                            X_data = pd.DataFrame(X)
                    else:
                        X_data = pd.DataFrame(X)
                else:
                    X_data = np.array(X)
            except Exception as e:
                self.logger.error("Data preparation error: %s", e)
                X_data = X

            # 进行预测
            predictions = model.predict(X_data)
            self.logger.debug("Raw model predictions: %s, type=%s, dtype=%s",
                              predictions[:10], type(predictions),
                              predictions.dtype if hasattr(predictions, 'dtype') else 'N/A')

            # **CRITICAL FIX: 检查并使用存储的LabelEncoder进行逆转换**
            label_encoder = self._get_model_meta(model, 'label_encoder')
            if label_encoder is not None:
                self.logger.debug("Found stored LabelEncoder, converting predictions back to original labels")
                try:
                    # 将整数预测结果转换回Original标签
                    predictions_original = label_encoder.inverse_transform(predictions)
                    self.logger.debug("Converted predictions back to original labels: %s", predictions_original[:10])

                    return {
                        "predictions": predictions_original.tolist() if hasattr(predictions_original, 'tolist') else list(predictions_original),
                        "task_type": "classification",
                        "shape": (len(predictions_original),),
                        "label_conversion": "success"
                    }
                except Exception as e:
                    self.logger.warning("Label inverse transform failed: %s", e)
                    # 继续使用Original预测结果

            emergency_encoder = self._get_model_meta(model, 'emergency_encoder')
            if emergency_encoder is not None:
                self.logger.debug("Found emergency encoder, using for inverse transform")
                try:
                    predictions_original = emergency_encoder.inverse_transform(predictions)
                    self.logger.debug("Emergency conversion successful: %s", predictions_original[:10])

                    return {
                        "predictions": predictions_original.tolist() if hasattr(predictions_original, 'tolist') else list(predictions_original),
                        "task_type": "classification",
                        "shape": (len(predictions_original),),
                        "label_conversion": "emergency_success"
                    }
                except Exception as e:
                    self.logger.warning("Emergency label inverse transform failed: %s", e)

            self.logger.debug("No label encoder found in model, predictions may be in encoded format")

            # 获取Task type from service-owned metadata or model_data
            task_type = self._get_model_meta(model, 'task_type')
            if task_type is None and hasattr(model_data, 'task_type'):
                task_type = model_data.task_type

            # 如果没有找到编码器，尝试使用通用处理
            try:
                predictions_processed, actual_task_type = prepare_labels_safely(predictions, task_type)

                if task_type and actual_task_type != task_type:
                    self.logger.warning("Task type mismatch: expected %s, got %s", task_type, actual_task_type)

                if isinstance(predictions_processed, np.ndarray):
                    predictions_list = predictions_processed.tolist()
                else:
                    predictions_list = list(predictions_processed)

                return {
                    "predictions": predictions_list,
                    "task_type": actual_task_type,
                    "shape": (len(predictions_list),),
                    "label_conversion": "generic"
                }
            except Exception as proc_error:
                self.logger.warning("Generic processing failed: %s", proc_error)
                # 最后的兜底方案
                try:
                    predictions_list = [str(p) for p in predictions]
                    return {
                        "predictions": predictions_list,
                        "note": "Prediction results converted to strings",
                        "error_detail": str(proc_error),
                        "label_conversion": "fallback"
                    }
                except:
                    return {"error": "Unable to process prediction results", "detail": str(proc_error)}

        except Exception as e:
            self.logger.error("Prediction error: %s", e)
            return {"error": str(e)}
            
    def evaluate(self, model_data, X_test, y_test):
        """
        Enhanced model evaluation with proper task type handling
        
        Args:
            model_data: Model data containing trained model
            X_test: Test features
            y_test: Test labels
            
        Returns:
            dict: Evaluation results
        """
        try:
            fitted_predictor = getattr(model_data, 'fitted_predictor', None)
            if fitted_predictor is not None:
                test_scope = getattr(model_data, 'test_data', {}) or {}
                prediction_result, metrics = self.evaluation_service.evaluate_with_prediction(
                    fitted_predictor, X_test, y_test,
                    task_type=getattr(model_data, 'task_type', None),
                    metrics=(['rmse', 'mae', 'r2']
                             if getattr(model_data, 'task_type', None) == 'regression'
                             else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
                    row_ids=test_scope.get('row_ids'),
                    physical_sample_ids=test_scope.get('physical_sample_ids'),
                    group_ids=test_scope.get('group_ids'),
                )
                model_data.prediction_result = prediction_result
                model_data.evaluation_results = metrics
                return metrics

            model = model_data.model if hasattr(model_data, 'model') else model_data

            self.logger.info("Model evaluation - Model type: %s", type(model).__name__)
            self.logger.debug("Test data shape: X=%s, y=%s", X_test.shape, len(y_test))
            self.logger.debug("Test labels sample: %s", list(y_test[:5]))

            # **CRITICAL FIX: Enhanced task type detection**
            task_type = None
            is_classification = None

            # Method 1: Check model_data or service-owned metadata
            model_class_name = model.__class__.__name__
            self.logger.debug("Model class: %s", model_class_name)

            if hasattr(model_data, 'task_type'):
                task_type = model_data.task_type
                is_classification = (task_type == 'classification')
                self.logger.info("Task type from model_data: %s", task_type)

            if task_type is None:
                task_type = self._get_model_meta(model, 'task_type')
                if task_type is not None:
                    is_classification = (task_type == 'classification')
                    self.logger.info("Task type from service metadata: %s", task_type)

            if task_type is None:
                # Method 2: Infer from model class name
                if model_class_name in ['RandomForestClassifier', 'SVC', 'LogisticRegression', 'GaussianNB',
                                      'KNeighborsClassifier', 'DecisionTreeClassifier', 'QualitativeAnalyzer']:
                    is_classification = True
                    task_type = 'classification'
                    self.logger.info("CLASSIFICATION inferred from model class: %s", model_class_name)
                elif model_class_name in ['RandomForestRegressor', 'SVR', 'LinearRegression', 'Ridge', 'Lasso']:
                    is_classification = False
                    task_type = 'regression'
                    self.logger.info("REGRESSION inferred from model class: %s", model_class_name)
                elif model_class_name in ['KMeans', 'AgglomerativeClustering', 'DBSCAN']:
                    task_type = 'clustering'
                    is_classification = False
                    self.logger.info("CLUSTERING inferred from model class: %s", model_class_name)

            # Method 3: Analyze labels if task type still unknown
            if task_type is None:
                from app.utils.label_processor import EnhancedLabelProcessor
                label_processor = EnhancedLabelProcessor()
                detected_task_type = label_processor.detect_task_type(y_test)
                is_classification = (detected_task_type == 'classification')
                task_type = detected_task_type
                self.logger.info("Task type detected from labels: %s", task_type)

            self.logger.info("Final task type: %s, is_classification: %s", task_type, is_classification)

            # **CRITICAL FIX: Validate task type and labels compatibility**
            if task_type == 'regression':
                # For regression, check if labels are actually numeric
                try:
                    sample_labels = list(y_test[:5])
                    has_string_labels = any(any(c.isalpha() for c in str(label)) for label in sample_labels)

                    if has_string_labels:
                        self.logger.warning("TASK TYPE MISMATCH: Regression model with string labels! Sample: %s", sample_labels)
                        self.logger.warning("Forcing classification mode...")
                        task_type = 'classification'
                        is_classification = True
                except:
                    pass

            # Get model predictions
            self.logger.debug("Getting model predictions...")
            y_pred = model.predict(X_test)
            self.logger.debug("Predictions sample: %s", list(y_pred[:5]))
            
            # Process evaluation based on task type
            if is_classification:
                # **CLASSIFICATION EVALUATION**
                self.logger.debug("Performing classification evaluation...")

                from sklearn.metrics import (
                    accuracy_score, precision_score, recall_score, f1_score,
                    confusion_matrix
                )

                try:
                    # Use enhanced label processing for proper handling
                    from app.utils.label_processor import EnhancedLabelProcessor
                    label_processor = EnhancedLabelProcessor()

                    # Process true labels
                    y_test_processed, test_metadata = label_processor.process_labels_smart(y_test, 'classification')

                    # Process predictions - convert back to original format first
                    if hasattr(model, 'label_inverse_map') and model.label_inverse_map:
                        # Model has its own label mapping
                        y_pred_original = [model.label_inverse_map.get(int(pred), f"Unknown_{pred}") for pred in y_pred]
                    else:
                        y_pred_original = y_pred

                    # Process predictions through same label processor
                    y_pred_processed, pred_metadata = label_processor.process_labels_smart(y_pred_original, 'classification')

                    # Ensure both have same label mapping
                    label_mapping = test_metadata.get('label_mapping', {})
                    num_classes = test_metadata.get('num_classes', len(np.unique(y_test_processed)))

                    self.logger.debug("Classes: %s, Mapping: %s", num_classes, label_mapping.get('unique_labels', 'N/A'))

                    # Calculate metrics with proper error handling
                    def safe_metric_calc(metric_func, *args, **kwargs):
                        try:
                            return float(metric_func(*args, **kwargs))
                        except Exception as e:
                            self.logger.warning("%s calculation failed: %s", metric_func.__name__, e)
                            return 0.0

                    # Calculate accuracy
                    accuracy = safe_metric_calc(accuracy_score, y_test_processed, y_pred_processed)

                    # Calculate precision, recall, f1 based on number of classes
                    if num_classes == 2:
                        precision = safe_metric_calc(precision_score, y_test_processed, y_pred_processed, average='binary', zero_division=0)
                        recall = safe_metric_calc(recall_score, y_test_processed, y_pred_processed, average='binary', zero_division=0)
                        f1 = safe_metric_calc(f1_score, y_test_processed, y_pred_processed, average='binary', zero_division=0)
                    else:
                        precision = safe_metric_calc(precision_score, y_test_processed, y_pred_processed, average='weighted', zero_division=0)
                        recall = safe_metric_calc(recall_score, y_test_processed, y_pred_processed, average='weighted', zero_division=0)
                        f1 = safe_metric_calc(f1_score, y_test_processed, y_pred_processed, average='weighted', zero_division=0)

                    # Calculate confusion matrix
                    try:
                        cm = confusion_matrix(y_test_processed, y_pred_processed)
                        cm_dict = {
                            "matrix": cm.tolist(),
                            "labels": label_mapping.get('unique_labels', list(range(num_classes)))
                        }
                    except Exception as cm_error:
                        self.logger.warning("Confusion matrix calculation failed: %s", cm_error)
                        cm_dict = {"matrix": [[0]], "labels": ["Unknown"]}

                    results = {
                        "accuracy": accuracy,
                        "precision": precision,
                        "recall": recall,
                        "f1": f1,
                        "confusion_matrix": cm_dict,
                        "task_type": "classification",
                        "num_classes": num_classes
                    }

                    self.logger.info("Classification evaluation completed: accuracy=%.4f, precision=%.4f, recall=%.4f, f1=%.4f",
                                     accuracy, precision, recall, f1)
                    return results

                except Exception as classification_error:
                    self.logger.error("Classification evaluation failed: %s", classification_error)
                    # Fallback evaluation
                    try:
                        accuracy = accuracy_score(y_test, y_pred) if len(set(y_test)) == len(set(y_pred)) else 0.0
                        return {
                            "accuracy": float(accuracy),
                            "precision": 0.0,
                            "recall": 0.0,
                            "f1": 0.0,
                            "task_type": "classification",
                            "error": "Fallback evaluation used",
                            "original_error": str(classification_error)
                        }
                    except Exception as fallback_error:
                        return {
                            "error": f"Classification evaluation completely failed: {str(fallback_error)}",
                            "task_type": "classification"
                        }
            
            else:
                # **REGRESSION EVALUATION**
                self.logger.debug("Performing regression evaluation...")

                # **CRITICAL FIX: Strict validation for regression task**
                # Check if this is actually a regression task or misclassified
                if task_type == 'classification':
                    self.logger.error("Classification task incorrectly routed to regression evaluation")
                    return {"error": "Task type mismatch: Classification data sent to regression evaluation", "task_type": "classification"}

                try:
                    from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

                    # **ENHANCED: Safe numeric conversion with validation**
                    def safe_numeric_conversion(values, context=""):
                        """Safely convert values to numeric with detailed error reporting"""
                        converted = []
                        errors = []

                        for i, val in enumerate(values):
                            if val is None or pd.isna(val):
                                converted.append(np.nan)
                                continue

                            try:
                                # Check for obvious string labels
                                val_str = str(val).strip()
                                if any(c.isalpha() for c in val_str):
                                    errors.append(f"Index {i}: '{val}' contains letters")
                                    converted.append(np.nan)
                                    continue

                                # Try numeric conversion
                                numeric_val = float(val)
                                converted.append(numeric_val)

                            except (ValueError, TypeError) as e:
                                errors.append(f"Index {i}: '{val}' - {str(e)}")
                                converted.append(np.nan)

                        converted_array = np.array(converted, dtype=float)
                        error_ratio = len(errors) / len(values) if len(values) > 0 else 0

                        # Report errors if significant
                        if errors:
                            self.logger.warning("%s conversion errors (%.1f%%):", context, error_ratio * 100)
                            for error in errors[:3]:  # Show first 3 errors
                                self.logger.warning("  %s", error)
                            if len(errors) > 3:
                                self.logger.warning("  ... and %s more", len(errors) - 3)

                        return converted_array, error_ratio, errors

                    # Convert test labels and predictions
                    y_test_float, test_error_ratio, test_errors = safe_numeric_conversion(y_test, "Test labels")
                    y_pred_float, pred_error_ratio, pred_errors = safe_numeric_conversion(y_pred, "Predictions")

                    # Check if conversion was successful enough for regression
                    if test_error_ratio > 0.1:  # More than 10% errors
                        self.logger.error("REGRESSION TASK VALIDATION FAILED: %.1f%% of test labels cannot be converted to numeric",
                                          test_error_ratio * 100)
                        self.logger.error("This suggests the task should be CLASSIFICATION, not REGRESSION")

                        return {
                            "error": f"Regression task requires numeric labels, but {test_error_ratio:.1%} are non-numeric",
                            "task_type": "regression",
                            "suggestion": "Consider using CLASSIFICATION task instead",
                            "problematic_samples": test_errors[:5]
                        }

                    # Calculate valid data mask
                    valid_mask = ~np.isnan(y_test_float) & ~np.isnan(y_pred_float)
                    valid_count = np.sum(valid_mask)

                    if valid_count == 0:
                        return {
                            "error": "No valid numeric data available for regression evaluation",
                            "task_type": "regression"
                        }

                    # Extract valid data
                    y_test_clean = y_test_float[valid_mask]
                    y_pred_clean = y_pred_float[valid_mask]

                    self.logger.debug("Valid samples for regression: %s/%s", valid_count, len(y_test))

                    # Calculate regression metrics
                    mse = mean_squared_error(y_test_clean, y_pred_clean)
                    mae = mean_absolute_error(y_test_clean, y_pred_clean)
                    r2 = r2_score(y_test_clean, y_pred_clean)

                    results = {
                        "task_type": "regression",
                        "mse": float(mse),
                        "rmse": float(np.sqrt(mse)),
                        "mae": float(mae),
                        "r2_score": float(r2),
                        "data_points": int(valid_count),
                        "data_coverage": float(valid_count / len(y_test))
                    }

                    self.logger.info("Regression evaluation completed: MSE=%.6f, RMSE=%.6f, MAE=%.6f, R2=%.6f",
                                     mse, np.sqrt(mse), mae, r2)
                    return results

                except Exception as regression_error:
                    self.logger.error("Regression evaluation failed: %s", regression_error)
                    return {
                        "error": f"Regression evaluation error: {str(regression_error)}",
                        "task_type": "regression"
                    }

        except Exception as e:
            self.logger.error("Model evaluation completely failed: %s", e)
            return {"error": f"Evaluation failed: {str(e)}"}

    def evaluate_model(self, model, X_test, y_test, task_type=None,
                       row_ids=None, physical_sample_ids=None, group_ids=None):
        """
        兼容性method - 提供与evaluation_service.evaluate_model相同的接口
        
        This is a bridge method to resolve the issue where controller calls evaluate_model but service only has evaluate method.
        该method将parametersprocessing为evaluatemethod所需的格式，并调用evaluatemethod。
        
        Args:
            model: training好的模型
            X_test: 测试features
            y_test: 测试labels
            task_type: Task type（可选，classification或regression）
            
        Returns:
            dict: evaluationresults字典
        """
        self.logger.debug("Calling evaluation through ModelingService.evaluate_model bridge method...")

        predictor = getattr(model, 'fitted_predictor', None) or model
        if hasattr(predictor, 'predict_result'):
            resolved_task = task_type or getattr(predictor, 'task_type', None)
            _prediction_result, metrics = self.evaluation_service.evaluate_with_prediction(
                predictor, X_test, y_test, task_type=resolved_task,
                metrics=(['rmse', 'mae', 'r2'] if resolved_task == 'regression'
                         else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
                row_ids=row_ids, physical_sample_ids=physical_sample_ids,
                group_ids=group_ids,
            )
            return metrics

        class ModelData:
            def __init__(self, model, task_type):
                self.model = model
                self.task_type = task_type

        if task_type is None:
            task_type = self._get_model_meta(model, 'task_type')

        model_data = ModelData(model, task_type)

        return self.evaluate(model_data, X_test, y_test)

    def apply_modeling(self, X_train, y_train, X_test, y_test, method,
                       analysis_type='quantitative', model_params=None,
                       train_row_ids=None, test_row_ids=None,
                       train_physical_sample_ids=None, test_physical_sample_ids=None,
                       train_group_ids=None, test_group_ids=None,
                       group_validation=False, input_representation='fitted_feature_matrix'):
        """Run the active analyzer plugin path used by MainWindow.start_analysis.

        This method makes the MVC modeling path functional by reusing the same
        QuantitativeAnalyzer / QualitativeAnalyzer plugins that the UI already
        uses successfully.
        """
        model_params = dict(model_params or {})
        if analysis_type == 'quantitative':
            analyzer = QuantitativeAnalyzer(method=method.lower())
        else:
            analyzer = QualitativeAnalyzer(method=method.lower())

        # Preserve label type: numeric for regression, string for classification.
        if analysis_type == 'quantitative':
            if isinstance(y_train, pd.Series):
                y_train_safe = pd.to_numeric(y_train, errors='coerce')
            else:
                y_train_safe = np.array([float(v) for v in y_train])
        else:
            y_train_safe = y_train

        if train_row_ids is None and isinstance(X_train, pd.DataFrame):
            train_row_ids = list(X_train.index)
        if test_row_ids is None and isinstance(X_test, pd.DataFrame):
            test_row_ids = list(X_test.index)
        model_params.update({
            'row_ids': train_row_ids,
            'physical_sample_ids': train_physical_sample_ids,
            'group_ids': train_group_ids,
            'group_validation': group_validation,
            'input_representation': input_representation,
        })
        analyzer.fit(X_train, y_train_safe, **model_params)
        cv_results = analyzer.cross_validate(
            X_train, y_train_safe,
            sample_ids=train_row_ids,
            outer_test_sample_ids=test_row_ids,
            physical_sample_ids=train_physical_sample_ids,
            outer_test_physical_sample_ids=test_physical_sample_ids,
            group_ids=train_group_ids,
            outer_test_group_ids=test_group_ids,
            group_validation=group_validation,
        )

        task_type = 'classification' if analysis_type == 'qualitative' else 'regression'
        # Store task type in service-owned metadata so downstream code can read it
        # without mutating the analyzer's underlying estimator.
        self._set_model_meta(analyzer.model, task_type=task_type)
        prediction_result = analyzer.predict_result(
            X_test,
            row_ids=test_row_ids,
            physical_sample_ids=test_physical_sample_ids,
            group_ids=test_group_ids,
        )
        metrics = self.evaluation_service.evaluate_prediction_result(
            y_test, prediction_result,
            metrics=(['rmse', 'mae', 'r2'] if task_type == 'regression'
                     else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
            task_type=task_type,
        )

        class ModelData:
            def __init__(self, model, trained_model, analyzer, fitted_predictor,
                         prediction_result, method, cv_results,
                         predictions, metrics, task_type, feature_names):
                self.model = model
                self.trained_model = trained_model
                self.analyzer = analyzer
                self.fitted_predictor = fitted_predictor
                self.prediction_result = prediction_result
                self.method = method
                self.cv_results = cv_results
                self.predictions = predictions
                self.evaluation_results = metrics
                self.task_type = task_type
                self.feature_names = feature_names
                self.test_data = {
                    'X_test': X_test, 'y_test': y_test,
                    'row_ids': test_row_ids,
                    'physical_sample_ids': test_physical_sample_ids,
                    'group_ids': test_group_ids,
                }

        feature_names = list(X_train.columns) if hasattr(X_train, 'columns') else None
        model_data = ModelData(
            model=analyzer.model,
            trained_model=analyzer.model,
            analyzer=analyzer,
            fitted_predictor=analyzer.fitted_predictor,
            prediction_result=prediction_result,
            method=method,
            cv_results=cv_results,
            predictions=prediction_result.predictions,
            metrics=metrics,
            task_type=task_type,
            feature_names=feature_names
        )

        model_id = f"{method}_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}"
        self.update_model_data(model_id, model_data)
        return model_data

    def get_model_data(self, model_id: str):
        """Retrieve model data from the in-memory registry."""
        return self.models.get(model_id)

    def update_model_data(self, model_id: str, model_data):
        """Store or update model data in the in-memory registry."""
        self.models[model_id] = model_data
        return model_id
