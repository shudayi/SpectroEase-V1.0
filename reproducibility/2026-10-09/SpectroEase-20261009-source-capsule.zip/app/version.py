"""Source-level identity for SpectroEase metadata.

This version follows the existing internal reproducibility-report label. It is
not a statement that a public package or release tag has been updated.
"""

APP_VERSION = "1.1"
APP_VERSION_SOURCE = "existing internal reproducibility-report software_versions.spectroease label"
