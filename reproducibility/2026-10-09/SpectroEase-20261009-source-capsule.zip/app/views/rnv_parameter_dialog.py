#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
RNV (Robust Normal Variate) Parameter Dialog
"""

from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QCheckBox, QDoubleSpinBox, QComboBox, QSpinBox,
    QPushButton, QGroupBox, QTextEdit, QFrame, QScrollArea, QWidget, QSizePolicy
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
import numpy as np
from app.utils.responsive import fit_window_to_screen
from app.utils.exceptions import user_facing_error

class RNVParameterDialog(QDialog):
    """RNV Parameter Setting Dialog"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(_("rnv_parameter_dialog.title"))
        self.init_ui()
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_PARAM_MD[0]), ui.scaled_px(tok.DIALOG_SIZE_PARAM_MD[1]), min_width=ui.scaled_px(400), min_height=ui.scaled_px(400))

    def init_ui(self):
        """Initialize interface"""
        content_widget = QWidget()
        main_layout = QVBoxLayout(content_widget)
        main_layout.setSpacing(ui.scaled_px(tok.DIALOG_SECTION_SPACING))

        # Title
        title_label = QLabel(_("rnv_parameter_dialog.title_label"))
        title_label.setAlignment(Qt.AlignCenter)
        __font = ui.get_scaled_font(tok.FONT_FAMILY_UI[0], tok.DIALOG_TITLE_FONT_PT)
        __font.setBold(True)
        title_label.setFont(__font)
        main_layout.addWidget(title_label)

        # Separator
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main_layout.addWidget(line)

        # Basic Parameters
        basic_group = QGroupBox(_("rnv_parameter_dialog.basic_group"))
        basic_layout = QFormLayout()

        # Centering method
        self.centering_combo = QComboBox()
        for _text, _key in [(_("rnv_parameter_dialog.mean_item"), "Mean"),
                            (_("rnv_parameter_dialog.median_item"), "Median"),
                            (_("rnv_parameter_dialog.trimmed_mean_item"), "Trimmed Mean"),
                            (_("rnv_parameter_dialog.huber_item"), "Huber")]:
            self.centering_combo.addItem(_text, _key)
        self.centering_combo.setCurrentIndex(1)  # Default to Median
        basic_layout.addRow(_("rnv_parameter_dialog.centering_method_label"), self.centering_combo)

        # Scaling method
        self.scaling_combo = QComboBox()
        for _text, _key in [(_("rnv_parameter_dialog.standard_deviation_item"), "Standard Deviation"),
                            (_("rnv_parameter_dialog.mad_item"), "MAD"),
                            (_("rnv_parameter_dialog.iqr_item"), "IQR"),
                            (_("rnv_parameter_dialog.robust_scale_item"), "Robust Scale")]:
            self.scaling_combo.addItem(_text, _key)
        self.scaling_combo.setCurrentIndex(1)  # Default to MAD
        basic_layout.addRow(_("rnv_parameter_dialog.scaling_method_label"), self.scaling_combo)

        # Outlier threshold
        self.outlier_threshold_spin = QDoubleSpinBox()
        self.outlier_threshold_spin.setRange(1.0, 5.0)
        self.outlier_threshold_spin.setValue(2.5)
        self.outlier_threshold_spin.setDecimals(2)
        self.outlier_threshold_spin.setSingleStep(0.1)
        basic_layout.addRow(_("rnv_parameter_dialog.outlier_threshold_label"), self.outlier_threshold_spin)

        # Robust estimation
        self.robust_check = QCheckBox()
        self.robust_check.setChecked(True)
        basic_layout.addRow(_("rnv_parameter_dialog.enable_robust_estimation_label"), self.robust_check)

        ui.configure_form_row(basic_layout.labelForField(self.centering_combo), self.centering_combo)
        ui.configure_form_row(basic_layout.labelForField(self.scaling_combo), self.scaling_combo)
        ui.configure_form_row(basic_layout.labelForField(self.outlier_threshold_spin), self.outlier_threshold_spin)
        ui.configure_form_row(basic_layout.labelForField(self.robust_check), self.robust_check)
        basic_group.setLayout(basic_layout)
        main_layout.addWidget(basic_group)

        # Advanced Parameters
        advanced_group = QGroupBox(_("rnv_parameter_dialog.advanced_group"))
        advanced_layout = QFormLayout()

        # Trimmed mean percentage (for trimmed mean centering)
        self.trim_percent_spin = QDoubleSpinBox()
        self.trim_percent_spin.setRange(0, 50)
        self.trim_percent_spin.setValue(10)
        self.trim_percent_spin.setSuffix(" %")
        advanced_layout.addRow(_("rnv_parameter_dialog.trimmed_mean_percentage_label"), self.trim_percent_spin)

        # MAD constant (for MAD scaling)
        self.mad_constant_spin = QDoubleSpinBox()
        self.mad_constant_spin.setRange(0.1, 5.0)
        self.mad_constant_spin.setValue(1.4826)
        self.mad_constant_spin.setDecimals(4)
        self.mad_constant_spin.setSingleStep(0.1)
        advanced_layout.addRow(_("rnv_parameter_dialog.mad_constant_label"), self.mad_constant_spin)

        # Minimum scale value
        self.min_scale_spin = QDoubleSpinBox()
        self.min_scale_spin.setRange(1e-10, 1e-2)
        self.min_scale_spin.setValue(1e-6)
        self.min_scale_spin.setDecimals(10)
        self.min_scale_spin.setSingleStep(1e-7)
        advanced_layout.addRow(_("rnv_parameter_dialog.minimum_scale_value_label"), self.min_scale_spin)

        # Iterative refinement
        self.iterative_check = QCheckBox()
        self.iterative_check.setChecked(False)
        advanced_layout.addRow(_("rnv_parameter_dialog.iterative_refinement_label"), self.iterative_check)

        # Maximum iterations
        self.max_iter_spin = QSpinBox()
        self.max_iter_spin.setRange(1, 100)
        self.max_iter_spin.setValue(10)
        self.max_iter_spin.setEnabled(False)
        advanced_layout.addRow(_("rnv_parameter_dialog.maximum_iterations_label"), self.max_iter_spin)

        # Convergence tolerance
        self.tolerance_spin = QDoubleSpinBox()
        self.tolerance_spin.setRange(1e-8, 1e-3)
        self.tolerance_spin.setValue(1e-5)
        self.tolerance_spin.setDecimals(8)
        self.tolerance_spin.setEnabled(False)
        advanced_layout.addRow(_("rnv_parameter_dialog.convergence_tolerance_label"), self.tolerance_spin)

        ui.configure_form_row(advanced_layout.labelForField(self.trim_percent_spin), self.trim_percent_spin)
        ui.configure_form_row(advanced_layout.labelForField(self.mad_constant_spin), self.mad_constant_spin)
        ui.configure_form_row(advanced_layout.labelForField(self.min_scale_spin), self.min_scale_spin)
        ui.configure_form_row(advanced_layout.labelForField(self.iterative_check), self.iterative_check)
        ui.configure_form_row(advanced_layout.labelForField(self.max_iter_spin), self.max_iter_spin)
        ui.configure_form_row(advanced_layout.labelForField(self.tolerance_spin), self.tolerance_spin)
        advanced_group.setLayout(advanced_layout)
        main_layout.addWidget(advanced_group)

        # Algorithm Description
        description_group = QGroupBox(_("rnv_parameter_dialog.description_group"))
        description_layout = QVBoxLayout()

        self.description_text = QTextEdit()
        self.description_text.setReadOnly(True)
        ui.set_max_height(self.description_text, tok.TEXT_EDIT_MAX_HEIGHT_SM)
        self.description_text.setText(
            _("rnv_parameter_dialog.description_text_description_text_text")
        )
        description_layout.addWidget(self.description_text)

        description_group.setLayout(description_layout)
        main_layout.addWidget(description_group)

        # Preset Configurations
        preset_group = QGroupBox(_("rnv_parameter_dialog.preset_group"))
        preset_layout = QHBoxLayout()

        self.standard_preset_btn = QPushButton(_("rnv_parameter_dialog.standard_preset_btn"))
        self.standard_preset_btn.setProperty("role", "secondary")
        self.standard_preset_btn.clicked.connect(self.load_standard_preset)
        preset_layout.addWidget(self.standard_preset_btn)

        self.robust_preset_btn = QPushButton(_("rnv_parameter_dialog.robust_preset_btn"))
        self.robust_preset_btn.setProperty("role", "secondary")
        self.robust_preset_btn.clicked.connect(self.load_robust_preset)
        preset_layout.addWidget(self.robust_preset_btn)

        self.adaptive_preset_btn = QPushButton(_("rnv_parameter_dialog.adaptive_preset_btn"))
        self.adaptive_preset_btn.setProperty("role", "secondary")
        self.adaptive_preset_btn.clicked.connect(self.load_adaptive_preset)
        preset_layout.addWidget(self.adaptive_preset_btn)

        preset_group.setLayout(preset_layout)
        main_layout.addWidget(preset_group)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(content_widget)

        outer_layout = QVBoxLayout(self)
        outer_layout.addWidget(scroll_area)

        # Buttons
        footer_widget = QWidget()
        ui.set_min_height(footer_widget, tok.DIALOG_FOOTER_HEIGHT)
        footer_widget.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(ui.scaled_px(0), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(0), ui.scaled_px(tok.SPACE_SM))

        self.test_btn = QPushButton(_("rnv_parameter_dialog.test_btn"))
        self.test_btn.setProperty("role", "secondary")
        self.test_btn.clicked.connect(self.test_parameters)
        button_layout.addWidget(self.test_btn)

        button_layout.addStretch()

        self.ok_btn = QPushButton(_("rnv_parameter_dialog.ok_btn"))
        self.ok_btn.setProperty("role", "primary")
        self.ok_btn.clicked.connect(self.accept)
        button_layout.addWidget(self.ok_btn)

        self.cancel_btn = QPushButton(_("rnv_parameter_dialog.cancel_btn"))
        self.cancel_btn.setProperty("role", "secondary")
        self.cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_btn)

        footer_widget.setLayout(button_layout)
        outer_layout.addWidget(footer_widget)
        self.setLayout(outer_layout)

        # Connect signals
        self.centering_combo.currentIndexChanged.connect(self.update_description)
        self.scaling_combo.currentIndexChanged.connect(self.update_description)
        self.iterative_check.toggled.connect(self.on_iterative_changed)

    def on_iterative_changed(self, checked):
        """Handle iterative refinement checkbox"""
        self.max_iter_spin.setEnabled(checked)
        self.tolerance_spin.setEnabled(checked)

    def load_standard_preset(self):
        """Load standard RNV preset"""
        self.centering_combo.setCurrentIndex(1)  # Median
        self.scaling_combo.setCurrentIndex(1)    # MAD
        self.outlier_threshold_spin.setValue(2.5)
        self.robust_check.setChecked(True)
        self.trim_percent_spin.setValue(10)
        self.mad_constant_spin.setValue(1.4826)
        self.min_scale_spin.setValue(1e-6)
        self.iterative_check.setChecked(False)

    def load_robust_preset(self):
        """Load ultra robust preset"""
        self.centering_combo.setCurrentIndex(1)  # Median
        self.scaling_combo.setCurrentIndex(2)    # IQR
        self.outlier_threshold_spin.setValue(3.0)
        self.robust_check.setChecked(True)
        self.trim_percent_spin.setValue(20)
        self.min_scale_spin.setValue(1e-5)
        self.iterative_check.setChecked(True)
        self.max_iter_spin.setValue(15)
        self.tolerance_spin.setValue(1e-6)

    def load_adaptive_preset(self):
        """Load adaptive RNV preset"""
        self.centering_combo.setCurrentIndex(2)  # Trimmed Mean
        self.scaling_combo.setCurrentIndex(3)    # Robust Scale
        self.outlier_threshold_spin.setValue(2.0)
        self.robust_check.setChecked(True)
        self.trim_percent_spin.setValue(15)
        self.iterative_check.setChecked(True)
        self.max_iter_spin.setValue(20)
        self.tolerance_spin.setValue(1e-7)

    def update_description(self):
        """Update algorithm description"""
        centering = self.centering_combo.currentText()
        scaling = self.scaling_combo.currentText()

        desc = _("rnv_parameter_dialog.update_description_prefix")
        desc += _("rnv_parameter_dialog.update_description_centering").format(centering=centering) + "\n"
        desc += _("rnv_parameter_dialog.update_description_scaling").format(scaling=scaling) + "\n"

        if centering == _("rnv_parameter_dialog.mean_item"):
            desc += _("rnv_parameter_dialog.centering_mode_mean") + "\n"
        elif centering == _("rnv_parameter_dialog.median_item"):
            desc += _("rnv_parameter_dialog.centering_mode_median") + "\n"
        elif centering == _("rnv_parameter_dialog.trimmed_mean_item"):
            desc += _("rnv_parameter_dialog.centering_mode_trimmed") + "\n"
        elif centering == _("rnv_parameter_dialog.huber_item"):
            desc += _("rnv_parameter_dialog.centering_mode_huber") + "\n"

        if scaling == _("rnv_parameter_dialog.standard_deviation_item"):
            desc += _("rnv_parameter_dialog.scaling_mode_std") + "\n"
        elif scaling == _("rnv_parameter_dialog.mad_item"):
            desc += _("rnv_parameter_dialog.scaling_mode_mad") + "\n"
        elif scaling == _("rnv_parameter_dialog.iqr_item"):
            desc += _("rnv_parameter_dialog.scaling_mode_iqr") + "\n"
        elif scaling == _("rnv_parameter_dialog.robust_scale_item"):
            desc += _("rnv_parameter_dialog.scaling_mode_robust") + "\n"

        desc += "\n" + _("rnv_parameter_dialog.update_description_suffix")

        self.description_text.setText(desc)

    def test_parameters(self):
        """Test parameters"""
        from PyQt5.QtWidgets import QMessageBox

        params = self.get_parameters()

        try:
            # Create test data with outliers
            np.random.seed(42)
            test_data = np.random.random((5, 10)) * 100 + 50
            # Add outliers
            test_data[0, 0] = 1000  # Outlier
            test_data[2, 5] = -500  # Outlier

            # Simulate RNV processing
            result_info = []
            for i in range(test_data.shape[0]):
                spectrum = test_data[i, :]

                if params['centering'] == _("rnv_parameter_dialog.mean_item"):
                    center = np.mean(spectrum)
                elif params['centering'] == _("rnv_parameter_dialog.median_item"):
                    center = np.median(spectrum)
                else:
                    center = np.mean(spectrum)  # Simplified

                if params['scaling'] == _("rnv_parameter_dialog.mad_item"):
                    scale = np.median(np.abs(spectrum - center)) * params['mad_constant']
                elif params['scaling'] == _("rnv_parameter_dialog.standard_deviation_item"):
                    scale = np.std(spectrum)
                else:
                    scale = np.std(spectrum)  # Simplified

                if scale < params['min_scale']:
                    scale = params['min_scale']

                result_info.append(_("rnv_parameter_dialog.test_sample_format").format(i=i+1, center=center, scale=scale))

            msg = _("rnv_parameter_dialog.test_title") + "\n\n" + "\n".join(result_info)
            msg += _("rnv_parameter_dialog.test_method").format(centering=params['centering'], scaling=params['scaling'])
            msg += _("rnv_parameter_dialog.test_outlier_threshold").format(threshold=params['outlier_threshold'])

            QMessageBox.information(self, _("rnv_parameter_dialog.message"), msg)

        except Exception as e:
            QMessageBox.warning(self, _("rnv_parameter_dialog.message_2"), _("rnv_parameter_dialog.test_failed").format(error=user_facing_error(e)))

    def get_parameters(self):
        """Get parameters"""
        return {
            'centering': self.centering_combo.currentData(),
            'scaling': self.scaling_combo.currentData(),
            'outlier_threshold': self.outlier_threshold_spin.value(),
            'robust_estimation': self.robust_check.isChecked(),
            'trim_percent': self.trim_percent_spin.value(),
            'mad_constant': self.mad_constant_spin.value(),
            'min_scale': self.min_scale_spin.value(),
            'iterative': self.iterative_check.isChecked(),
            'max_iter': self.max_iter_spin.value(),
            'tolerance': self.tolerance_spin.value()
        }

    def set_parameters(self, params):
        """Set parameters"""
        if 'centering' in params:
            index = self.centering_combo.findData(params['centering'])
            if index >= 0:
                self.centering_combo.setCurrentIndex(index)

        if 'scaling' in params:
            index = self.scaling_combo.findData(params['scaling'])
            if index >= 0:
                self.scaling_combo.setCurrentIndex(index)

        self.outlier_threshold_spin.setValue(params.get('outlier_threshold', 2.5))
        self.robust_check.setChecked(params.get('robust_estimation', True))
        self.trim_percent_spin.setValue(params.get('trim_percent', 10))
        self.mad_constant_spin.setValue(params.get('mad_constant', 1.4826))
        self.min_scale_spin.setValue(params.get('min_scale', 1e-6))
        self.iterative_check.setChecked(params.get('iterative', False))
        self.max_iter_spin.setValue(params.get('max_iter', 10))
        self.tolerance_spin.setValue(params.get('tolerance', 1e-5))

        # Update description
        self.update_description()

if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)
    dialog = RNVParameterDialog()
    dialog.show()
    sys.exit(app.exec_())
