# app/views/data_view.py

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QTableView, QComboBox, QPushButton, QFormLayout,
    QSpinBox, QDoubleSpinBox, QLineEdit, QMessageBox, QCheckBox, QGroupBox, QGridLayout,
    QFileDialog, QSizePolicy, QFrame
)
from PyQt5.QtGui import QStandardItemModel, QStandardItem
from PyQt5.QtCore import Qt, pyqtSignal
import pandas as pd
import numpy as np
import os
from app.ui import design_tokens as tok
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _
from app.utils.exceptions import user_facing_error
from app.utils.label_processor import EnhancedLabelProcessor


class DataView(QWidget):
    def __init__(self):
        super(DataView, self).__init__()
        self.layout = QVBoxLayout()
        self.layout.setSpacing(ui.scaled_px(tok.SPACE_SM))
        self.layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))

        self.label = QLabel(_("data_view.label"))
        self.layout.addWidget(self.label)

        self.table_view = QTableView()
        self.layout.addWidget(self.table_view)

        self.setLayout(self.layout)

    def update_data(self, data: pd.DataFrame):
        if data.empty:
            self.label.setText(_("data_view.label_label_text"))
            self.table_view.setModel(None)
            return

        self.label.setText(_("data_view.label"))
        model = QStandardItemModel()
        model.setHorizontalHeaderLabels(data.columns.tolist())
        for row in data.itertuples(index=False):
            items = [QStandardItem(str(field)) for field in row]
            model.appendRow(items)
        self.table_view.setModel(model)
        self.table_view.resizeColumnsToContents()


class DataPartitioningView(QWidget):
    # Emitted when the user selects a different column as the target/label.
    label_column_changed = pyqtSignal(int)
    column_mapping_changed = pyqtSignal(dict)

    # =========================================================================
    # 主要 UI 修改位置（1）：页面整体采用紧凑、顶部对齐、自适应布局
    # =========================================================================
    def __init__(self, data_partitioning_plugins: dict):
        super(DataPartitioningView, self).__init__()
        self.plugins = data_partitioning_plugins

        # 主布局：紧凑、顶部对齐、自适应布局
        self.layout = QVBoxLayout()
        self.layout.setAlignment(Qt.AlignTop)
        self.layout.setSpacing(ui.scaled_px(tok.SPACE_MD))
        self.layout.setContentsMargins(
            ui.scaled_px(tok.SPACE_XL), ui.scaled_px(tok.SPACE_XL),
            ui.scaled_px(tok.SPACE_XL), ui.scaled_px(tok.SPACE_XL)
        )

        # 1. 页面标题（唯一标题）
        self.page_title = QLabel(_("data_view.page_title"))
        self.page_title.setObjectName("pageTitle")
        self.layout.addWidget(self.page_title)

        # 2. Partition Method 下拉框 + Load Data 按钮
        method_layout = QGridLayout()
        method_layout.setHorizontalSpacing(ui.scaled_px(tok.SPACE_SM))
        method_layout.setVerticalSpacing(ui.scaled_px(tok.SPACE_SM))

        method_label = QLabel(_("data_view.method_label"))
        method_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        method_label.setMinimumWidth(ui.scaled_px(125))
        method_label.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)

        self.method_combo = QComboBox()
        self.method_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._configure_param_widget(self.method_combo)

        built_in_methods = ["Train-Test Split", "K-Fold", "LOGO", "Random", "Stratified"]
        plugin_methods = list(self.plugins.keys())
        self.method_combo.addItems(built_in_methods + plugin_methods)

        self.load_data_btn = QPushButton(_("data_view.load_data_btn"))
        self.load_data_btn.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.load_data_btn.setProperty("role", "secondary")
        ui.set_min_height(self.load_data_btn, tok.ROW_HEIGHT_LG)

        method_layout.addWidget(method_label, 0, 0)
        method_layout.addWidget(self.method_combo, 0, 1)
        method_layout.addWidget(self.load_data_btn, 1, 0, 1, 2)
        method_layout.setColumnStretch(1, 1)
        method_layout.setColumnStretch(0, 0)

        # 2b. Label column selector
        label_col_label = QLabel(_("data_view.label_column_label"))
        label_col_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        label_col_label.setMinimumWidth(ui.scaled_px(125))
        label_col_label.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)

        self.label_column_combo = QComboBox()
        self.label_column_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._configure_param_widget(self.label_column_combo)
        self.label_column_combo.setEnabled(False)
        self.label_column_combo.currentIndexChanged.connect(self._on_label_column_changed)

        method_layout.addWidget(label_col_label, 2, 0)
        method_layout.addWidget(self.label_column_combo, 2, 1)
        method_layout.setColumnStretch(1, 1)

        # Column Mapping button (lets the user pick wavelength columns separately).
        self.column_mapping_btn = QPushButton(
            translator.lget('data_view.column_mapping_btn', 'Column Mapping…')
        )
        self.column_mapping_btn.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.column_mapping_btn.setProperty("role", "secondary")
        ui.set_min_height(self.column_mapping_btn, tok.ROW_HEIGHT_LG)
        self.column_mapping_btn.setEnabled(False)
        self.column_mapping_btn.clicked.connect(self._on_column_mapping_clicked)
        method_layout.addWidget(self.column_mapping_btn, 3, 0, 1, 2)

        # Physical identifiers are selected explicitly and remain metadata;
        # the split service removes them from predictive X.
        self.sample_id_combo = QComboBox()
        self.group_id_combo = QComboBox()
        for combo in (self.sample_id_combo, self.group_id_combo):
            combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            self._configure_param_widget(combo)
            combo.setEnabled(False)
            combo.addItem("(none)", None)
            combo.currentIndexChanged.connect(self._refresh_dataset_status)
        sample_label = QLabel("Physical sample ID column")
        sample_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        sample_label.setMinimumWidth(ui.scaled_px(90))
        sample_label.setWordWrap(True)
        group_label = QLabel("Group ID column")
        group_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        group_label.setMinimumWidth(ui.scaled_px(90))
        group_label.setWordWrap(True)
        method_layout.addWidget(sample_label, 4, 0)
        method_layout.addWidget(self.sample_id_combo, 4, 1)
        method_layout.addWidget(group_label, 5, 0)
        method_layout.addWidget(self.group_id_combo, 5, 1)
        self.group_validation_checkbox = QCheckBox(
            "Keep groups in one split/fold"
        )
        self.group_validation_checkbox.setToolTip(
            "Requires a complete explicit Group ID column. Missing or ambiguous IDs block splitting."
        )
        method_layout.addWidget(self.group_validation_checkbox, 6, 0, 1, 2)

        self.layout.addLayout(method_layout)

        # 3. Force Classification Task 复选框（普通视觉权重）
        self.force_classification_checkbox = QCheckBox(_("data_view.force_classification_checkbox"))
        self.force_classification_checkbox.setToolTip(_("data_view.force_classification_checkbox_force_classification_checkbox_tooltip"))
        self.force_classification_checkbox.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.layout.addWidget(self.force_classification_checkbox)

        # 4. Partition Parameters 参数区域
        params_title = QLabel(_("data_view.partition_parameters_title"))
        params_title.setObjectName("sectionTitle")
        self.layout.addWidget(params_title)

        self.params_form = QFormLayout()
        self.params_form.setSpacing(ui.scaled_px(tok.SPACE_SM))
        self.params_form.setContentsMargins(0, 0, 0, 0)
        self.params_form.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.params_form.setRowWrapPolicy(QFormLayout.WrapLongRows)
        self.param_widgets = {}
        self.init_param_widgets("Train-Test Split")
        self.layout.addLayout(self.params_form)

        # 5. Dataset Status 数据状态区域（语义化卡片）
        status_title = QLabel(_("data_view.dataset_status_title"))
        status_title.setObjectName("sectionTitle")
        self.layout.addWidget(status_title)

        self.info_frame = QFrame()
        self.info_frame.setObjectName("statusCard")
        self.info_frame.setFrameStyle(QFrame.NoFrame)
        info_layout = QVBoxLayout(self.info_frame)
        info_layout.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_SM),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_SM)
        )
        info_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))

        self.info_label = QLabel("")
        self.info_label.setObjectName("secondaryText")
        self.info_label.setWordWrap(True)
        self.info_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        info_layout.addWidget(self.info_label)
        self.layout.addWidget(self.info_frame)

        # 6. Partition Data 主按钮
        self.partition_data_btn = QPushButton(_("main_window.data_partition_btn"))
        self.partition_data_btn.setEnabled(False)
        self.partition_data_btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        ui.set_min_height(self.partition_data_btn, tok.ROW_HEIGHT_LG)
        self.layout.addWidget(self.partition_data_btn)

        # Add stretch so the layout expands to fill the parent group while keeping controls at the top.
        self.layout.addStretch(1)

        # Layout remains top-aligned; parent group now expands to fill the tab.
        self.setLayout(self.layout)

        # 初始状态：未加载数据
        self.set_no_data()

        self.method_combo.currentTextChanged.connect(self.on_method_change)

    def _on_label_column_changed(self, index: int):
        """Emit the label column index when the user changes the selector."""
        mapping = getattr(self, '_column_mapping', None)
        if mapping is not None:
            identity_columns = {
                value for value in (
                    self.sample_id_combo.currentData(), self.group_id_combo.currentData()
                ) if isinstance(value, int)
            }
            selected = mapping.get('wavelength_columns')
            remaining = None if selected is None else [
                position for position in selected
                if position != index and position not in identity_columns
            ]
            self._column_mapping = {
                'label_column': index,
                # An empty remainder means the former explicit feature list
                # cannot describe the new response. Re-infer all eligible
                # columns rather than leaving a silent zero-feature mapping.
                'wavelength_columns': remaining or None,
            }
            self._refresh_column_mapping_btn_text()
        if index >= 0:
            self.label_column_changed.emit(index)
        self._refresh_dataset_status()

    def _style_secondary_button(self, button):
        """次要按钮：描边样式；disabled 状态使用浅灰背景与灰色文字。"""
        button.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                color: {tok.COLOR_PRIMARY};
                border: 1px solid {tok.COLOR_PRIMARY};
                border-radius: {ui.scaled_px(tok.RADIUS_SM)}px;
                padding: {ui.scaled_px(tok.SPACE_XS)}px {ui.scaled_px(tok.SPACE_SM)}px;
            }}
            QPushButton:hover {{
                background-color: {tok.COLOR_BG_ALT};
            }}
            QPushButton:pressed {{
                background-color: {tok.COLOR_PRIMARY_PRESSED};
                color: #ffffff;
            }}
            QPushButton:disabled {{
                background-color: {tok.COLOR_DISABLED_BG};
                color: {tok.COLOR_DISABLED_TEXT};
                border-color: {tok.COLOR_BORDER_DISABLED};
            }}
        """)

    def set_no_data(self):
        """未加载数据状态：禁用 Partition Data，显示半粗体提示与浅灰说明。"""
        self.partition_data_btn.setEnabled(False)
        self.label_column_combo.clear()
        self.sample_id_combo.clear()
        self.sample_id_combo.addItem("(none)", None)
        self.group_id_combo.clear()
        self.group_id_combo.addItem("(none)", None)
        self.sample_id_combo.setEnabled(False)
        self.group_id_combo.setEnabled(False)
        self.group_validation_checkbox.setChecked(False)
        self.label_column_combo.setEnabled(False)
        self.column_mapping_btn.setEnabled(False)
        self._current_data = None
        self.info_frame.setProperty("status", "warning")
        self._refresh_style(self.info_frame)
        empty_text = (
            f"<span style='font-weight:600;color:{tok.COLOR_TEXT_HEADING};'>{_('data_view.no_dataset_loaded')}</span><br>"
            f"<span style='color:{tok.COLOR_TEXT_SECONDARY};'>{_('data_view.click_load_data')}</span>"
        )
        self.info_label.setText(empty_text)

    def _refresh_column_mapping_btn_text(self):
        """Update the column mapping button label to show the current summary."""
        if not hasattr(self, 'column_mapping_btn'):
            return
        mapping = getattr(self, '_column_mapping', None) or {}
        wavelength_cols = mapping.get('wavelength_columns') or []
        if wavelength_cols:
            text = translator.lget(
                'data_view.column_mapping_btn_with_count',
                'Columns ({0}): …',
            ).format(len(wavelength_cols))
        else:
            text = translator.lget('data_view.column_mapping_btn', 'Column Mapping…')
        self.column_mapping_btn.setText(text)

    def _on_column_mapping_clicked(self):
        """Open the column mapping dialog for the currently loaded data."""
        if getattr(self, '_current_data', None) is None:
            return
        from app.views.column_mapping_dialog import ColumnMappingDialog

        data = self._current_data
        existing = getattr(self, '_column_mapping', None) or {}
        label_idx = self.label_column_combo.currentIndex() if self.label_column_combo.currentIndex() >= 0 else 0
        default_wavelength_cols = existing.get('wavelength_columns')
        if not default_wavelength_cols:
            id_columns = {
                value for value in (
                    self.sample_id_combo.currentData(), self.group_id_combo.currentData()
                ) if isinstance(value, int)
            }
            # No confirmed custom roles: let the dialog open in default mode.
            # Passing a computed list here would incorrectly imply that the
            # user had explicitly confirmed those metadata/response columns.
            default_wavelength_cols = None
        else:
            id_columns = {
                value for value in (
                    self.sample_id_combo.currentData(), self.group_id_combo.currentData()
                ) if isinstance(value, int)
            }
            default_wavelength_cols = [i for i in default_wavelength_cols if i not in id_columns]
        dialog = ColumnMappingDialog(
            data.columns.tolist(),
            label_column_index=label_idx,
            selected_wavelength_columns=default_wavelength_cols,
            identity_column_indices=list(id_columns),
            parent=self,
        )
        if dialog.exec_() == dialog.Accepted:
            mapping = dialog.get_mapping()
            self.column_mapping_changed.emit(mapping)

    def set_column_mapping(self, mapping):
        """Cache the confirmed mapping and keep the response selector in sync."""
        self._column_mapping = {
            'label_column': int(mapping['label_column']),
            'wavelength_columns': (
                list(mapping['wavelength_columns'])
                if mapping.get('wavelength_columns') is not None else None
            ),
        }
        label_index = self._column_mapping['label_column']
        self.label_column_combo.blockSignals(True)
        self.label_column_combo.setCurrentIndex(label_index)
        self.label_column_combo.blockSignals(False)
        self._refresh_column_mapping_btn_text()
        self._refresh_dataset_status()

    def clear_column_mapping(self):
        """Return wavelength selection to the automatic axis/header rule."""
        self._column_mapping = None
        self._refresh_column_mapping_btn_text()
        self._refresh_dataset_status()

    def get_column_mapping(self):
        """Return the current column mapping as a dict."""
        mapping = getattr(self, '_column_mapping', None)
        if mapping is not None:
            return {
                'label_column': self.label_column_combo.currentIndex()
                if self.label_column_combo.currentIndex() >= 0 else mapping['label_column'],
                'wavelength_columns': (
                    list(mapping['wavelength_columns'])
                    if mapping['wavelength_columns'] is not None else None
                ),
            }
        return {
            'label_column': self.label_column_combo.currentIndex()
            if self.label_column_combo.currentIndex() >= 0 else 0,
            'wavelength_columns': None,
        }

    def set_data_loaded(self, file_path, data):
        """加载数据成功后状态：启用 Partition Data，以紧凑单行显示数据集信息。"""
        self.partition_data_btn.setEnabled(True)
        if data is None:
            self.set_no_data()
            return
        # A new source table invalidates positional roles from the old table.
        self._column_mapping = None
        self.info_frame.setProperty("status", "success")
        self._refresh_style(self.info_frame)

        # Populate label column selector from data columns.
        self.label_column_combo.blockSignals(True)
        self.label_column_combo.clear()
        self.label_column_combo.addItems(data.columns.tolist())
        label_idx = getattr(self, '_pending_label_index', 0)
        label_idx = max(0, min(label_idx, data.shape[1] - 1))
        self.label_column_combo.setCurrentIndex(label_idx)
        self.label_column_combo.setEnabled(True)
        self.label_column_combo.blockSignals(False)
        for combo in (self.sample_id_combo, self.group_id_combo):
            combo.blockSignals(True)
            combo.clear()
            combo.addItem("(none)", None)
            for column_index, column_name in enumerate(data.columns):
                combo.addItem(str(column_name), column_index)
            combo.setEnabled(True)
            combo.blockSignals(False)
        self.sample_id_combo.setCurrentIndex(0)
        self.group_id_combo.setCurrentIndex(0)
        self.group_validation_checkbox.setChecked(False)
        self.column_mapping_btn.setEnabled(True)
        self.label_column_changed.emit(label_idx)
        # Cache the data so the column mapping dialog can build its preview.
        self._current_data = data
        self._current_file_name = os.path.basename(file_path) if file_path else _("data_view.unknown_file")
        self._refresh_column_mapping_btn_text()
        self._refresh_dataset_status()

    def _refresh_dataset_status(self, *_args):
        """Describe the current response and the same spectral roles as DataModel."""
        data = getattr(self, '_current_data', None)
        if data is None or not hasattr(self, 'info_label'):
            return
        label_column = self.label_column_combo.currentIndex()
        if not 0 <= label_column < data.shape[1]:
            return
        from app.utils.column_mapping import spectral_column_positions
        identity_columns = {
            value for value in (
                self.sample_id_combo.currentData(), self.group_id_combo.currentData()
            ) if isinstance(value, int)
        }
        selected = (getattr(self, '_column_mapping', None) or {}).get('wavelength_columns')
        try:
            n_features = len(spectral_column_positions(data, label_column, identity_columns, selected))
        except ValueError:
            n_features = 0
        file_name = getattr(self, '_current_file_name', _("data_view.unknown_file"))
        n_samples = data.shape[0]

        task_type_text = _("data_view.unknown_task")
        extra_info = ""
        if data.shape[1] > 1:
            y_raw = data.iloc[:, label_column]
            try:
                processor = EnhancedLabelProcessor()
                detected = processor.detect_task_type(y_raw)
                if detected == "classification":
                    task_type_text = _("data_view.classification_task")
                    n_classes = y_raw.nunique() if hasattr(y_raw, "nunique") else len(np.unique(y_raw))
                    extra_info = f" |{_('data_view.class_count')}: {n_classes}"
                else:
                    task_type_text = _("data_view.regression_task")
                    if pd.api.types.is_numeric_dtype(y_raw):
                        extra_info = f" |{_('data_view.target_range')}: [{y_raw.min():.3f}, {y_raw.max():.3f}]"
                    else:
                        target_name = y_raw.name if hasattr(y_raw, "name") and y_raw.name else label_column
                        extra_info = f" |{_('data_view.target_column')}: {target_name}"
            except Exception:
                pass

        info_html = (
            f"<span style='font-weight:600;color:{tok.COLOR_TEXT_HEADING};'>{file_name}</span> |"
            f"{_('data_view.samples')}: {n_samples} |"
            f"{_('data_view.features')}: {n_features} |"
            f"{_('data_view.task_type')}: {task_type_text}{extra_info}"
        )
        self.info_label.setText(info_html)

    def _refresh_style(self, widget):
        style = widget.style()
        if style is not None:
            style.unpolish(widget)
            style.polish(widget)

    def update_data_info(self, data=None):
        """Backward-compatible data info updater."""
        if data is None:
            self.set_no_data()
        else:
            self.set_data_loaded(None, data)

    def add_custom_algorithm(self, code):
        """Add a custom data partitioning algorithm from trusted user code."""
        try:
            from app.utils.code_sandbox import execute_plugin_code

            mod = execute_plugin_code(code, module_name='custom_splitter')

            for item in mod.__dict__.values():
                if isinstance(item, type):
                    algorithm = item()
                    name = algorithm.get_name() if hasattr(algorithm, 'get_name') else getattr(algorithm, 'name', item.__name__)
                    if not hasattr(algorithm, 'split_data') and hasattr(algorithm, 'apply'):
                        algorithm.split_data = algorithm.apply
                    if not hasattr(algorithm, 'get_parameter_info') and hasattr(algorithm, 'get_params_info'):
                        algorithm.get_parameter_info = algorithm.get_params_info
                    self.plugins[name] = algorithm
                    self.method_combo.addItem(name)
                    return

            raise ValueError("No algorithm class found in converted code.")
        except Exception as e:
            raise Exception(f"Error loading custom splitter: {user_facing_error(e)}")

    def _clear_params_form(self):
        for i in reversed(range(self.params_form.count())):
            self.params_form.removeRow(i)

    def _should_use_single_column_params(self, controls):
        if len(controls) > 4:
            return True
        return any(len(label_text.rstrip(":")) > 12 for label_text, _ in controls)

    def _new_params_grid(self, single_column=False):
        grid = QGridLayout()
        grid.setHorizontalSpacing(ui.scaled_px(tok.SPACE_SM))
        grid.setVerticalSpacing(ui.scaled_px(tok.SPACE_SM))
        grid.setContentsMargins(0, 0, 0, 0)
        if single_column:
            grid.setColumnMinimumWidth(0, ui.scaled_px(tok.GRID_SINGLE_LABEL_COL_WIDTH))
            grid.setColumnMinimumWidth(1, ui.scaled_px(tok.GRID_SINGLE_CONTROL_COL_WIDTH))
            grid.setColumnStretch(1, 1)
        else:
            grid.setColumnMinimumWidth(0, ui.scaled_px(tok.GRID_LABEL_COL_WIDTH_SM))
            grid.setColumnMinimumWidth(1, ui.scaled_px(tok.GRID_CONTROL_COL_WIDTH_SM))
            grid.setColumnMinimumWidth(2, ui.scaled_px(tok.GRID_LABEL_COL_WIDTH_SM))
            grid.setColumnMinimumWidth(3, ui.scaled_px(tok.GRID_CONTROL_COL_WIDTH_SM))
            grid.setColumnStretch(1, 1)
            grid.setColumnStretch(3, 1)
        return grid

    # =========================================================================
    # 主要 UI 修改位置（2）：统一输入控件尺寸；SpinBox 去箭头；删除右侧空白方块
    # =========================================================================
    def _configure_param_widget(self, widget):
        widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        # Let Qt include stylesheet content minimum, padding and border in the
        # row height. A fixed 34px box can be smaller than its painted input.
        widget.setMinimumHeight(ui.scaled_px(34))

        if isinstance(widget, QSpinBox):
            widget.setButtonSymbols(QSpinBox.NoButtons)
            widget.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            ui.set_min_width(widget, tok.CONTROL_MIN_WIDTH_SM)
        elif isinstance(widget, QDoubleSpinBox):
            widget.setButtonSymbols(QDoubleSpinBox.NoButtons)
            widget.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            ui.set_min_width(widget, tok.CONTROL_MIN_WIDTH_SM)
        elif isinstance(widget, QLineEdit):
            ui.set_min_width(widget, tok.CONTROL_MIN_WIDTH_MD)
        elif isinstance(widget, QComboBox):
            # Partition Method / Stratification 等保留原生下拉箭头，不覆盖 drop-down 子控件
            ui.set_min_width(widget, tok.CONTROL_MIN_WIDTH)
        elif isinstance(widget, QCheckBox):
            widget.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
            widget.setMinimumHeight(0)
            # 复选框保持原生尺寸（约 16x16），不强制高度

    def _add_grid_param(self, grid, index, label_text, widget, single_column=False):
        row = index if single_column else index // 2
        label_col = 0 if single_column else (index % 2) * 2
        widget_col = label_col + 1

        if label_text:
            label = QLabel(label_text)
            label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            label.setMinimumWidth(ui.scaled_px(125))
            label.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
            grid.addWidget(label, row, label_col)

        self._configure_param_widget(widget)
        grid.addWidget(widget, row, widget_col)

    def _show_param_controls(self, controls):
        single_column = self._should_use_single_column_params(controls)
        grid = self._new_params_grid(single_column)
        for index, (label_text, widget) in enumerate(controls):
            self._add_grid_param(grid, index, label_text, widget, single_column)
        # Give the nested grid a widget boundary so QFormLayout cannot compress
        # its rows below their minimum sizes on a short scroll viewport.
        container = QWidget()
        container.setLayout(grid)
        container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        grid.setSizeConstraint(QGridLayout.SetMinimumSize)
        self.params_form.addRow(container)

    # =========================================================================
    # 主要 UI 修改位置（3）：参数标签通过翻译文件重命名；Shuffle 使用带文字复选框
    # =========================================================================
    def init_param_widgets(self, method):
        self._clear_params_form()
        self.param_widgets = {}

        if method in self.plugins:
            controls = []
            param_info = self.plugins[method].get_parameter_info()
            for param_name, info in param_info.items():
                widget = self.create_widget(info)
                self.param_widgets[param_name] = widget
                controls.append((f"{param_name}:", widget))
            self._show_param_controls(controls)
            return

        if method == "Train-Test Split":
            self.test_size_spin = QDoubleSpinBox()
            self.test_size_spin.setRange(0.01, 0.99)
            self.test_size_spin.setValue(0.2)
            self.test_size_spin.setSingleStep(0.05)

            self.random_state_spin = QSpinBox()
            self.random_state_spin.setRange(0, 10000)
            self.random_state_spin.setValue(42)

            self.min_samples_spin = QSpinBox()
            self.min_samples_spin.setRange(1, 100)
            self.min_samples_spin.setValue(5)

            # 带文字的复选框，放置在输入列左侧，无独立标签
            self.shuffle_checkbox = QCheckBox(_("data_view.shuffle_text"))
            self.shuffle_checkbox.setChecked(True)

            self.stratify_combo = QComboBox()
            self.stratify_combo.addItem(_("data_view.none_item"))
            self.stratify_combo.addItem(_("data_view.label_item"))

            self._show_param_controls([
                (_("data_view.test_label"), self.test_size_spin),
                (_("data_view.seed_label"), self.random_state_spin),
                (_("data_view.min_label"), self.min_samples_spin),
                ("", self.shuffle_checkbox),
                (_("data_view.stratify_label"), self.stratify_combo),
            ])

        elif method == "K-Fold":
            self.k_fold_spin = QSpinBox()
            self.k_fold_spin.setRange(2, 10)
            self.k_fold_spin.setValue(5)

            self.kf_random_state_spin = QSpinBox()
            self.kf_random_state_spin.setRange(0, 10000)
            self.kf_random_state_spin.setValue(42)

            self.kf_shuffle_checkbox = QCheckBox(_("data_view.shuffle_text"))
            self.kf_shuffle_checkbox.setChecked(True)

            self._show_param_controls([
                (_("data_view.k_label"), self.k_fold_spin),
                (_("data_view.seed_label"), self.kf_random_state_spin),
                ("", self.kf_shuffle_checkbox),
            ])

        elif method == "LOGO":
            self.logo_group_combo = QComboBox()
            self.logo_group_combo.addItem("label")
            self.logo_group_combo.addItem("batch")

            self._show_param_controls([
                (_("data_view.group_label"), self.logo_group_combo),
            ])

        elif method == "Random" or method == "Stratified":
            self.n_splits_spin = QSpinBox()
            self.n_splits_spin.setRange(2, 10)
            self.n_splits_spin.setValue(5)

            self.random_test_size_spin = QDoubleSpinBox()
            self.random_test_size_spin.setRange(0.01, 0.99)
            self.random_test_size_spin.setValue(0.2)
            self.random_test_size_spin.setSingleStep(0.05)

            self.random_state_seed_spin = QSpinBox()
            self.random_state_seed_spin.setRange(0, 10000)
            self.random_state_seed_spin.setValue(42)

            self._show_param_controls([
                (_("data_view.n_label"), self.n_splits_spin),
                (_("data_view.test_label"), self.random_test_size_spin),
                (_("data_view.seed_label"), self.random_state_seed_spin),
            ])

    def create_widget(self, info):
        if info['type'] == 'int':
            widget = QSpinBox()
            widget.setRange(info.get('min', 0), info.get('max', 1000))
            widget.setValue(info.get('default', 0))
        elif info['type'] == 'float':
            widget = QDoubleSpinBox()
            widget.setRange(info.get('min', 0.0), info.get('max', 1000.0))
            widget.setValue(info.get('default', 0.0))
        elif info['type'] == 'str':
            widget = QLineEdit()
            widget.setText(info.get('default', ''))
        elif info['type'] == 'bool':
            widget = QCheckBox()
            widget.setChecked(info.get('default', False))
        else:
            widget = QLineEdit()  # 默认使用文本输入框
        return widget

    def on_method_change(self, method):
        self.init_param_widgets(method)

    def get_selected_method(self):
        return self.method_combo.currentText()

    def get_parameters(self):
        """
        获取所有parameters。

        Returns:
            dict: A dictionary of parameters.
        """
        method = self.method_combo.currentText()
        params = {}
        params['force_classification'] = self.force_classification_checkbox.isChecked()
        params['target_column'] = self.label_column_combo.currentIndex()
        params['sample_id_column'] = self.sample_id_combo.currentData()
        params['group_id_column'] = self.group_id_combo.currentData()
        params['group_validation'] = self.group_validation_checkbox.isChecked()
        mapping = self.get_column_mapping()
        params['target_column'] = mapping['label_column']
        if mapping['wavelength_columns'] is not None:
            params['wavelength_columns'] = list(mapping['wavelength_columns'])

        if method == "Train-Test Split":
            params.update({
                'test_size': self.test_size_spin.value(),
                'random_state': self.random_state_spin.value(),
                'shuffle': self.shuffle_checkbox.isChecked(),
                'min_samples': self.min_samples_spin.value(),
                'target_column': self.label_column_combo.currentIndex()
            })

        elif method == "K-Fold":
            params.update({
                'n_splits': self.k_fold_spin.value(),
                'random_state': self.kf_random_state_spin.value(),
                'shuffle': self.kf_shuffle_checkbox.isChecked(),
                'target_column': self.label_column_combo.currentIndex()
            })

        elif method == "LOGO":
            params.update({
                'groups_column': self.group_id_combo.currentData(),
                'group_id_column': self.group_id_combo.currentData(),
                'group_validation': True,
                'target_column': self.label_column_combo.currentIndex()
            })

        elif method in self.plugins:
            # Custom plugin splitter: read values from the dynamically built widgets
            for param_name, widget in self.param_widgets.items():
                if isinstance(widget, (QSpinBox, QDoubleSpinBox)):
                    params[param_name] = widget.value()
                elif isinstance(widget, QCheckBox):
                    params[param_name] = widget.isChecked()
                elif isinstance(widget, QComboBox):
                    params[param_name] = widget.currentText()
                else:  # QLineEdit and other text-like widgets
                    params[param_name] = widget.text()

        return params
