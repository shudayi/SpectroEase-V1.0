from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _

from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                            QLineEdit, QPushButton, QComboBox, QMessageBox)
from config.llm_config import LLMConfig
from app.utils.responsive import fit_window_to_screen
from app.utils.worker import Worker
from app.utils.exceptions import user_facing_error

# Retain cancelled requests until their bounded network call has ended.
_ACTIVE_TEST_WORKERS = set()

class _LLMTestWorker(Worker):
    """Run the LLM connection test off the UI thread."""

    def __init__(self, api_key, parent=None, **draft_config):
        super().__init__(parent)
        self._api_key = api_key
        self._draft_config = draft_config

    def run_task(self):
        from app.services.llm_service import LLMService
        service = LLMService(self._api_key, **self._draft_config)
        return service.chat(
            message="Respond with a short confirmation that the API connection is working.",
            code=None
        )


class LLMConfigDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
        self.load_config()
        
    def init_ui(self):
        self.setWindowTitle(_('llm_config_dialog.title'))
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_CONFIG[0]), ui.scaled_px(tok.DIALOG_SIZE_CONFIG[1]), min_width=ui.scaled_px(360), min_height=ui.scaled_px(220))
        
        layout = QVBoxLayout()
        
        # API key configuration
        api_layout = QHBoxLayout()
        api_label = QLabel(_('llm_config_dialog.api_label'))
        self.api_key_input = QLineEdit()
        self.api_key_input.setEchoMode(QLineEdit.Password)
        api_layout.addWidget(api_label)
        api_layout.addWidget(self.api_key_input)
        layout.addLayout(api_layout)
        
        # Provider selection
        provider_layout = QHBoxLayout()
        provider_label = QLabel(_('llm_config_dialog.provider_label'))
        self.provider_combo = QComboBox()
        self.provider_combo.addItems([
            'DeepSeek', 'OpenAI', 'Ollama', 'MiniMax', 'Custom',
        ])
        provider_layout.addWidget(provider_label)
        provider_layout.addWidget(self.provider_combo)
        layout.addLayout(provider_layout)

        # Model selection
        model_layout = QHBoxLayout()
        model_label = QLabel(_('llm_config_dialog.model_label'))
        self.model_combo = QComboBox()
        self.model_combo.setEditable(True)
        self.model_combo.addItems(['deepseek-coder', 'deepseek-chat', 'MiniMax-M3', 'other'])
        model_layout.addWidget(model_label)
        model_layout.addWidget(self.model_combo)
        layout.addLayout(model_layout)

        # API base URL
        url_layout = QHBoxLayout()
        url_label = QLabel(_('llm_config_dialog.url_label'))
        self.url_input = QLineEdit()
        self.provider_combo.currentTextChanged.connect(self._on_provider_changed)
        self.url_input.setPlaceholderText(_('llm_config_dialog.url_input_url_input_placeholder'))
        url_layout.addWidget(url_label)
        url_layout.addWidget(self.url_input)
        layout.addLayout(url_layout)
        
        # Other parameters
        params_layout = QHBoxLayout()
        temp_label = QLabel(_('llm_config_dialog.temp_label'))
        self.temp_input = QLineEdit()
        self.temp_input.setPlaceholderText(_('llm_config_dialog.temp_input_temp_input_placeholder'))
        max_tokens_label = QLabel(_('llm_config_dialog.max_tokens_label'))
        self.max_tokens_input = QLineEdit()
        self.max_tokens_input.setPlaceholderText(_('llm_config_dialog.max_tokens_input_max_tokens_input_placeholder'))
        timeout_label = QLabel(_('llm_config_dialog.timeout_label'))
        self.timeout_input = QLineEdit()
        self.timeout_input.setPlaceholderText(_('llm_config_dialog.timeout_input_placeholder'))
        params_layout.addWidget(temp_label)
        params_layout.addWidget(self.temp_input)
        params_layout.addWidget(max_tokens_label)
        params_layout.addWidget(self.max_tokens_input)
        params_layout.addWidget(timeout_label)
        params_layout.addWidget(self.timeout_input)
        layout.addLayout(params_layout)
        
        # Test connection button
        self.test_button = QPushButton(_('llm_config_dialog.test_button'))
        self.test_button.setProperty("role", "secondary")
        self.test_button.clicked.connect(self._on_test_clicked)
        layout.addWidget(self.test_button)

        # Save and cancel buttons
        button_layout = QHBoxLayout()
        self.save_button = QPushButton(_('llm_config_dialog.save_button'))
        self.save_button.setProperty("role", "primary")
        self.save_button.clicked.connect(self.save_config)
        self.cancel_button = QPushButton(_('llm_config_dialog.cancel_button'))
        self.cancel_button.setProperty("role", "secondary")
        self.cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(self.save_button)
        button_layout.addWidget(self.cancel_button)
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        
        self.provider_combo.setCurrentText(LLMConfig.PROVIDER)
        self.api_key_input.setText(LLMConfig.API_KEY)
        
    def _on_provider_changed(self, provider):
        defaults = {
            'DeepSeek': ('https://api.deepseek.com/v1', None),
            'OpenAI': ('https://api.openai.com/v1', None),
            'Ollama': ('http://localhost:11434/v1', None),
            'MiniMax': ('https://api.minimax.io/anthropic', 'MiniMax-M3'),
        }
        if provider in defaults:
            base_url, model_name = defaults[provider]
            self.url_input.setText(base_url)
            if model_name:
                self.model_combo.setCurrentText(model_name)
        self.provider_combo.setToolTip(
            'Supports OpenAI-compatible chat/completions endpoints and MiniMax Token Plan Messages.'
        )

    def load_config(self):
        """Load settings from configuration file."""
        self.provider_combo.setCurrentText(LLMConfig.PROVIDER)
        self.api_key_input.setText(LLMConfig.API_KEY)
        self.model_combo.setCurrentText(LLMConfig.MODEL_NAME)
        self.url_input.setText(LLMConfig.API_BASE_URL)
        self.temp_input.setText(str(LLMConfig.TEMPERATURE))
        self.max_tokens_input.setText(str(LLMConfig.MAX_TOKENS))
        self.timeout_input.setText(str(LLMConfig.REQUEST_TIMEOUT))
        
    def save_config(self):
        """Save configuration to configuration file."""
        try:
            api_key = self.api_key_input.text()
            model_name = self.model_combo.currentText()
            api_base_url = self.url_input.text()
            temperature = float(self.temp_input.text() or "0.7")
            max_tokens = int(self.max_tokens_input.text() or "2000")
            request_timeout = int(self.timeout_input.text() or "60")

            LLMConfig.save_config(
                api_key=api_key,
                model_name=model_name,
                api_base_url=api_base_url,
                max_tokens=max_tokens,
                temperature=temperature,
                request_timeout=request_timeout,
                provider=self.provider_combo.currentText()
            )
            
            QMessageBox.information(self, _('llm_config_dialog.message'), _('llm_config_dialog.config_saved'))
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, _('llm_config_dialog.message_2'), _('llm_config_dialog.error_saving_config').format(error=user_facing_error(e)))
            
    def _on_test_clicked(self):
        """Test LLM API connection in a worker thread (keeps UI responsive and actually awaits)."""
        self.test_button.setEnabled(False)
        self._cleanup_test_worker()
        try:
            draft = {
                'base_url': self.url_input.text().strip(),
                'model_name': self.model_combo.currentText().strip(),
                'temperature': float(self.temp_input.text() or '0.7'),
                'max_tokens': int(self.max_tokens_input.text() or '2000'),
                'request_timeout': int(self.timeout_input.text() or '60'),
            }
            import math
            if not draft['base_url'].startswith(('http://', 'https://')) or not draft['model_name']:
                raise ValueError('Enter an HTTP(S) API URL and a model name before testing.')
            if not math.isfinite(draft['temperature']) or not 0 <= draft['temperature'] <= 2:
                raise ValueError('Temperature must be between 0 and 2.')
            if draft['max_tokens'] <= 0 or draft['request_timeout'] <= 0:
                raise ValueError('Token limit and timeout must be positive.')
        except ValueError as exc:
            self.test_button.setEnabled(True)
            self._on_test_error(str(exc))
            return
        self._test_worker = _LLMTestWorker(self.api_key_input.text(), parent=None, **draft)
        self._test_worker.result_ready.connect(self._on_test_result)
        self._test_worker.error_occurred.connect(self._on_test_error)
        self._test_worker.finished.connect(lambda: self.test_button.setEnabled(True))
        self._test_worker.start()

    def _cleanup_test_worker(self):
        """Cancel, wait, and disconnect a previous test worker."""
        if not hasattr(self, '_test_worker') or self._test_worker is None:
            return
        if self._test_worker.isRunning():
            self._test_worker.cancel()
            self._test_worker.wait(500)
        try:
            self._test_worker.result_ready.disconnect(self._on_test_result)
        except (AttributeError, TypeError, RuntimeError):
            pass
        try:
            self._test_worker.error_occurred.disconnect(self._on_test_error)
        except (AttributeError, TypeError, RuntimeError):
            pass
        try:
            self._test_worker.finished.disconnect()
        except (AttributeError, TypeError, RuntimeError):
            pass
        worker = self._test_worker
        if worker.isRunning():
            _ACTIVE_TEST_WORKERS.add(worker)
            worker.finished.connect(lambda retained=worker: _ACTIVE_TEST_WORKERS.discard(retained))
        self._test_worker = None

    def closeEvent(self, event):
        """Ensure the worker is not left running when the dialog closes."""
        self._cleanup_test_worker()
        super().closeEvent(event)

    def _on_test_result(self, result):
        if result:
            QMessageBox.information(self, _('llm_config_dialog.message'), _('llm_config_dialog.connection_test_successful'))
        else:
            QMessageBox.warning(self, _('llm_config_dialog.message_3'), _('llm_config_dialog.connection_test_failed'))

    def _on_test_error(self, error):
        QMessageBox.critical(
            self,
            _('llm_config_dialog.message_2'),
            _('llm_config_dialog.error_during_connection_test').format(error=user_facing_error(error))
        )
