# app/views/preprocessing_view.py

import numpy as np
import pandas as pd
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QPushButton, QLabel,
    QMessageBox, QDialog, QFormLayout, QSpinBox, QDoubleSpinBox, QComboBox,
    QHBoxLayout, QFrame, QCheckBox, QGroupBox, QTabWidget, QSizePolicy, QScrollArea
)
from PyQt5.QtCore import Qt
try:
    import pyqtgraph as pg
except ImportError:
    pg = None

from app.ui import design_tokens as tok
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _

class PreprocessingView(QWidget):
    def __init__(self, plugins=None):
        super().__init__()
        self.plugins = plugins if plugins else {}
        self.init_ui()

    def init_ui(self):
        """Initialize preprocessing UI interface"""

        main_layout = QVBoxLayout()
        main_layout.setSpacing(ui.scaled_px(tok.SPACE_SM))
        main_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))


        app_font = ui.get_scaled_font(tok.FONT_FAMILY_UI[0], tok.BASE_FONT_PT)
        self.setFont(app_font)


        tabs = QTabWidget()
        tabs.setDocumentMode(True)  # 更现代的外观

        # --- Basic Tab with ScrollArea ---
        basic_tab = QWidget()
        basic_tab_layout = QVBoxLayout(basic_tab) # Layout for the tab itself
        basic_tab_layout.setContentsMargins(0, 0, 0, 0)

        scroll_basic = QScrollArea()
        scroll_basic.setWidgetResizable(True)
        scroll_basic.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        content_widget_basic = QWidget()
        basic_layout = QVBoxLayout(content_widget_basic)
        basic_layout.setSpacing(ui.scaled_px(tok.SPACE_SM))
        basic_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))

        scroll_basic.setWidget(content_widget_basic)
        basic_tab_layout.addWidget(scroll_basic)

        # New: Spike removal group (Recommended for Raman, default closed)
        despiking_group = QGroupBox(_("preprocessing_view.despiking_group"))
        despiking_layout = QVBoxLayout()
        despiking_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        despiking_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        self.despiking_check = QCheckBox(_("preprocessing_view.despiking_check"))
        self.despiking_check.setChecked(False)  # 默认Close
        despiking_layout.addWidget(self.despiking_check)

        # 去峰Parameters
        despiking_params_layout = QHBoxLayout()
        despiking_params_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))

        despiking_method_label = QLabel(_("preprocessing_view.despiking_method_label"))
        despiking_params_layout.addWidget(despiking_method_label)

        self.despiking_method = QComboBox()
        for _text, _key in [(_("preprocessing_view.mad_item"), "mad"),
                            (_("preprocessing_view.localz_item"), "localz")]:
            self.despiking_method.addItem(_text, _key)
        despiking_params_layout.addWidget(self.despiking_method)

        despiking_window_label = QLabel(_("preprocessing_view.despiking_window_label"))
        despiking_params_layout.addWidget(despiking_window_label)

        self.despiking_window = QSpinBox()
        self.despiking_window.setRange(7, 15)
        self.despiking_window.setValue(11)
        self.despiking_window.setSingleStep(2)  # 确保奇数
        despiking_params_layout.addWidget(self.despiking_window)

        despiking_threshold_label = QLabel(_("preprocessing_view.despiking_threshold_label"))
        despiking_params_layout.addWidget(despiking_threshold_label)

        self.despiking_threshold = QDoubleSpinBox()
        self.despiking_threshold.setRange(3.0, 6.0)
        self.despiking_threshold.setValue(5.0)
        self.despiking_threshold.setSingleStep(0.5)
        despiking_params_layout.addWidget(self.despiking_threshold)

        despiking_layout.addLayout(despiking_params_layout)
        despiking_group.setLayout(despiking_layout)
        basic_layout.addWidget(despiking_group)


        baseline_group = QGroupBox(_("preprocessing_view.baseline_group"))
        baseline_layout = QVBoxLayout()
        baseline_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        baseline_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        self.baseline_check = QCheckBox(_("preprocessing_view.baseline_check"))
        baseline_layout.addWidget(self.baseline_check)

        # 基线校正Method选择
        baseline_method_layout = QHBoxLayout()
        baseline_method_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))

        baseline_method_label = QLabel(_("preprocessing_view.baseline_method_label"))
        baseline_method_layout.addWidget(baseline_method_label)

        self.baseline_method = QComboBox()
        for _text, _key in [(_("preprocessing_view.polynomial_item"), "Polynomial"),
                            (_("preprocessing_view.als_item"), "ALS"),
                            (_("preprocessing_view.airpls_item"), "airPLS")]:
            self.baseline_method.addItem(_text, _key)
        baseline_method_layout.addWidget(self.baseline_method)

        baseline_layout.addLayout(baseline_method_layout)

        baseline_params = QHBoxLayout()
        baseline_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        poly_label = QLabel(_("preprocessing_view.poly_label"))
        baseline_params.addWidget(poly_label)

        self.poly_order = QSpinBox()
        self.poly_order.setRange(1, 10)
        self.poly_order.setValue(3)
        baseline_params.addWidget(self.poly_order)

        baseline_layout.addLayout(baseline_params)
        baseline_group.setLayout(baseline_layout)
        basic_layout.addWidget(baseline_group)


        smoothing_group = QGroupBox(_("preprocessing_view.smoothing_group"))
        smoothing_layout = QVBoxLayout()
        smoothing_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        smoothing_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))

        self.smoothing_check = QCheckBox(_("preprocessing_view.smoothing_check"))
        smoothing_layout.addWidget(self.smoothing_check)


        method_params = QHBoxLayout()
        method_params.setSpacing(ui.scaled_px(tok.SPACE_XS))

        method_label = QLabel(_("preprocessing_view.method_label"))
        method_params.addWidget(method_label)

        self.smoothing_method = QComboBox()
        for _text, _key in [(_("preprocessing_view.savitzky_golay_item"), "Savitzky-Golay"),
                            (_("preprocessing_view.moving_average_item"), "Moving Average"),
                            (_("preprocessing_view.gaussian_item"), "Gaussian"),
                            (_("preprocessing_view.median_item"), "Median")]:
            self.smoothing_method.addItem(_text, _key)
        method_params.addWidget(self.smoothing_method)

        smoothing_layout.addLayout(method_params)


        window_params = QHBoxLayout()
        window_params.setSpacing(ui.scaled_px(tok.SPACE_XS))

        window_label = QLabel(_("preprocessing_view.window_label"))
        window_params.addWidget(window_label)

        self.window_size = QSpinBox()
        self.window_size.setRange(3, 51)
        self.window_size.setValue(15)
        self.window_size.setSingleStep(2)  # 确保是奇数
        window_params.addWidget(self.window_size)


        poly_sgf_label = QLabel(_("preprocessing_view.poly_sgf_label"))
        window_params.addWidget(poly_sgf_label)

        self.poly_sgf_order = QSpinBox()
        self.poly_sgf_order.setRange(1, 5)
        self.poly_sgf_order.setValue(2)
        window_params.addWidget(self.poly_sgf_order)

        smoothing_layout.addLayout(window_params)
        smoothing_group.setLayout(smoothing_layout)
        basic_layout.addWidget(smoothing_group)


        scatter_group = QGroupBox(_("preprocessing_view.scatter_group"))
        scatter_layout = QVBoxLayout()
        scatter_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        scatter_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        self.scatter_check = QCheckBox(_("preprocessing_view.scatter_check"))
        scatter_layout.addWidget(self.scatter_check)


        scatter_method_params = QHBoxLayout()
        scatter_method_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        scatter_method_label = QLabel(_("preprocessing_view.scatter_method_label"))
        scatter_method_params.addWidget(scatter_method_label)

        self.scatter_method = QComboBox()
        for _text, _key in [(_("preprocessing_view.msc_item"), "MSC"),
                            (_("preprocessing_view.snv_item"), "SNV"),
                            (_("preprocessing_view.emsc_item"), "EMSC"),
                            (_("preprocessing_view.rnv_item"), "RNV"),
                            (_("preprocessing_view.osc_item"), "OSC")]:
            self.scatter_method.addItem(_text, _key)
        scatter_method_params.addWidget(self.scatter_method)

        scatter_layout.addLayout(scatter_method_params)
        scatter_group.setLayout(scatter_layout)
        basic_layout.addWidget(scatter_group)

        basic_layout.addStretch() # Add a stretch to push content up
        tabs.addTab(basic_tab, _("preprocessing_view.basic_tab_tab"))

        # --- Advanced Tab with ScrollArea ---
        advanced_tab = QWidget()
        advanced_tab_layout = QVBoxLayout(advanced_tab)
        advanced_tab_layout.setContentsMargins(0, 0, 0, 0)

        scroll_advanced = QScrollArea()
        scroll_advanced.setWidgetResizable(True)
        scroll_advanced.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        content_widget_advanced = QWidget()
        advanced_layout = QVBoxLayout(content_widget_advanced)
        advanced_layout.setSpacing(ui.scaled_px(tok.SPACE_SM))
        advanced_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))


        normalization_group = QGroupBox(_("preprocessing_view.normalization_group"))
        normalization_layout = QVBoxLayout()
        normalization_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        normalization_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        self.normalization_check = QCheckBox(_("preprocessing_view.normalization_check"))
        normalization_layout.addWidget(self.normalization_check)


        norm_method_params = QHBoxLayout()
        norm_method_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        norm_method_label = QLabel(_("preprocessing_view.norm_method_label"))
        norm_method_params.addWidget(norm_method_label)

        self.normalization_method = QComboBox()
        for _text, _key in [(_("preprocessing_view.min_max_item"), "Min-Max"),
                            (_("preprocessing_view.vector_item"), "Vector"),
                            (_("preprocessing_view.area_item"), "Area"),
                            (_("preprocessing_view.maximum_item"), "Maximum")]:
            self.normalization_method.addItem(_text, _key)
        norm_method_params.addWidget(self.normalization_method)

        normalization_layout.addLayout(norm_method_params)
        normalization_group.setLayout(normalization_layout)
        advanced_layout.addWidget(normalization_group)


        standardization_group = QGroupBox(_("preprocessing_view.standardization_group"))
        standardization_layout = QVBoxLayout()
        standardization_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        standardization_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        self.standardization_check = QCheckBox(_("preprocessing_view.standardization_check"))
        standardization_layout.addWidget(self.standardization_check)


        std_method_params = QHBoxLayout()
        std_method_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        std_method_label = QLabel(_("preprocessing_view.std_method_label"))
        std_method_params.addWidget(std_method_label)

        self.standardization_method = QComboBox()
        for _text, _key in [(_("preprocessing_view.z_score_item"), "Z-Score"),
                            (_("preprocessing_view.robust_item"), "Robust"),
                            (_("preprocessing_view.min_max_item"), "Min-Max")]:
            self.standardization_method.addItem(_text, _key)
        std_method_params.addWidget(self.standardization_method)

        standardization_layout.addLayout(std_method_params)
        standardization_group.setLayout(standardization_layout)
        advanced_layout.addWidget(standardization_group)


        derivative_group = QGroupBox(_("preprocessing_view.derivative_group"))
        derivative_layout = QVBoxLayout()
        derivative_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        derivative_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        self.derivative_check = QCheckBox(_("preprocessing_view.derivative_check"))
        derivative_layout.addWidget(self.derivative_check)


        derivative_params = QHBoxLayout()
        derivative_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        derivative_order_label = QLabel(_("preprocessing_view.derivative_order_label"))
        derivative_params.addWidget(derivative_order_label)

        self.derivative_order = QSpinBox()
        self.derivative_order.setRange(1, 3)
        self.derivative_order.setValue(1)
        derivative_params.addWidget(self.derivative_order)


        derivative_method_label = QLabel(_("preprocessing_view.derivative_method_label"))
        derivative_params.addWidget(derivative_method_label)

        self.derivative_method = QComboBox()
        for _text, _key in [(_("preprocessing_view.savitzky_golay_item"), "Savitzky-Golay"),
                            (_("preprocessing_view.finite_diff_item"), "Finite Diff"),
                            (_("preprocessing_view.gap_segment_item"), "Gap-Segment")]:
            self.derivative_method.addItem(_text, _key)
        derivative_params.addWidget(self.derivative_method)

        derivative_layout.addLayout(derivative_params)
        derivative_group.setLayout(derivative_layout)
        advanced_layout.addWidget(derivative_group)

        advanced_layout.addStretch() # Add a stretch to push content up
        scroll_advanced.setWidget(content_widget_advanced)
        advanced_tab_layout.addWidget(scroll_advanced)
        tabs.addTab(advanced_tab, _("preprocessing_view.advanced_tab_tab"))

        # --- Special Tab with ScrollArea ---
        special_tab = QWidget()
        special_tab_layout = QVBoxLayout(special_tab)
        special_tab_layout.setContentsMargins(0, 0, 0, 0)

        scroll_special = QScrollArea()
        scroll_special.setWidgetResizable(True)
        scroll_special.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        content_widget_special = QWidget()
        special_layout = QVBoxLayout(content_widget_special)
        special_layout.setSpacing(ui.scaled_px(tok.SPACE_SM))
        special_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))


        outlier_group = QGroupBox(_("preprocessing_view.outlier_group"))
        outlier_layout = QVBoxLayout()
        outlier_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        outlier_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        self.outlier_check = QCheckBox(_("preprocessing_view.outlier_check"))
        outlier_layout.addWidget(self.outlier_check)


        outlier_method_params = QHBoxLayout()
        outlier_method_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        outlier_method_label = QLabel(_("preprocessing_view.outlier_method_label"))
        outlier_method_params.addWidget(outlier_method_label)

        self.outlier_method = QComboBox()
        for _text, _key in [(_("preprocessing_view.iqr_item"), "IQR"),
                            (_("preprocessing_view.z_score_item"), "Z-Score"),
                            (_("preprocessing_view.iso_item"), "ISO"),
                            (_("preprocessing_view.lof_item"), "LOF")]:
            self.outlier_method.addItem(_text, _key)
        outlier_method_params.addWidget(self.outlier_method)

        outlier_layout.addLayout(outlier_method_params)


        outlier_threshold_params = QHBoxLayout()
        outlier_threshold_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        outlier_threshold_label = QLabel(_("preprocessing_view.outlier_threshold_label"))
        outlier_threshold_params.addWidget(outlier_threshold_label)

        self.outlier_threshold = QDoubleSpinBox()
        self.outlier_threshold.setRange(1.0, 5.0)
        self.outlier_threshold.setValue(3.0)
        self.outlier_threshold.setSingleStep(0.1)
        outlier_threshold_params.addWidget(self.outlier_threshold)

        outlier_layout.addLayout(outlier_threshold_params)
        outlier_group.setLayout(outlier_layout)
        special_layout.addWidget(outlier_group)


        denoising_group = QGroupBox(_("preprocessing_view.denoising_group"))
        denoising_layout = QVBoxLayout()
        denoising_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        denoising_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        self.denoising_check = QCheckBox(_("preprocessing_view.denoising_check"))
        denoising_layout.addWidget(self.denoising_check)


        denoising_method_params = QHBoxLayout()
        denoising_method_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        denoising_method_label = QLabel(_("preprocessing_view.denoising_method_label"))
        denoising_method_params.addWidget(denoising_method_label)

        self.denoising_method = QComboBox()
        for _text, _key in [(_("preprocessing_view.wavelet_item"), "Wavelet"),
                            (_("preprocessing_view.fft_item"), "FFT"),
                            (_("preprocessing_view.wiener_item"), "Wiener"),
                            (_("preprocessing_view.nlm_item"), "NLM")]:
            self.denoising_method.addItem(_text, _key)
        denoising_method_params.addWidget(self.denoising_method)

        denoising_layout.addLayout(denoising_method_params)


        denoising_strength_params = QHBoxLayout()
        denoising_strength_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        denoising_strength_label = QLabel(_("preprocessing_view.denoising_strength_label"))
        denoising_strength_params.addWidget(denoising_strength_label)

        self.denoising_strength = QDoubleSpinBox()
        self.denoising_strength.setRange(0.1, 2.0)
        self.denoising_strength.setValue(0.5)
        self.denoising_strength.setSingleStep(0.1)
        denoising_strength_params.addWidget(self.denoising_strength)

        denoising_layout.addLayout(denoising_strength_params)
        denoising_group.setLayout(denoising_layout)
        special_layout.addWidget(denoising_group)


        alignment_group = QGroupBox(_("preprocessing_view.alignment_group"))
        alignment_layout = QVBoxLayout()
        alignment_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        alignment_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        self.alignment_check = QCheckBox(_("preprocessing_view.alignment_check"))
        alignment_layout.addWidget(self.alignment_check)


        alignment_method_params = QHBoxLayout()
        alignment_method_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        alignment_method_label = QLabel(_("preprocessing_view.alignment_method_label"))
        alignment_method_params.addWidget(alignment_method_label)

        self.alignment_method = QComboBox()
        for _text, _key in [(_("preprocessing_view.dtw_item"), "DTW"),
                            (_("preprocessing_view.cow_item"), "COW"),
                            (_("preprocessing_view.ics_item"), "ICS"),
                            (_("preprocessing_view.pafft_item"), "PAFFT")]:
            self.alignment_method.addItem(_text, _key)
        alignment_method_params.addWidget(self.alignment_method)

        alignment_layout.addLayout(alignment_method_params)


        reference_selection_params = QHBoxLayout()
        reference_selection_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        reference_label = QLabel(_("preprocessing_view.reference_label"))
        reference_selection_params.addWidget(reference_label)

        self.reference_method = QComboBox()
        for _text, _key in [(_("preprocessing_view.mean_item"), "Mean"),
                            (_("preprocessing_view.med_item"), "Med"),
                            (_("preprocessing_view.max_item"), "Max"),
                            (_("preprocessing_view.first_item"), "First")]:
            self.reference_method.addItem(_text, _key)
        reference_selection_params.addWidget(self.reference_method)

        alignment_layout.addLayout(reference_selection_params)
        alignment_group.setLayout(alignment_layout)
        special_layout.addWidget(alignment_group)

        # 拉曼专属预处理占位（需求C）
        raman_group = QGroupBox(_("preprocessing_view.raman_group"))
        raman_layout = QVBoxLayout()
        raman_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        raman_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        # Wavelength校准占位
        wavelength_calib_layout = QHBoxLayout()
        wavelength_calib_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))

        self.wavelength_calib_check = QCheckBox(_("preprocessing_view.wavelength_calib_check"))
        self.wavelength_calib_check.setChecked(False)  # 默认Close
        wavelength_calib_layout.addWidget(self.wavelength_calib_check)

        self.wavelength_calib_file_btn = QPushButton(_("preprocessing_view.wavelength_calib_file_btn"))
        self.wavelength_calib_file_btn.setEnabled(False)
        wavelength_calib_layout.addWidget(self.wavelength_calib_file_btn)

        self.wavelength_calib_file_label = QLabel(_("preprocessing_view.wavelength_calib_file_label"))
        wavelength_calib_layout.addWidget(self.wavelength_calib_file_label)

        raman_layout.addLayout(wavelength_calib_layout)

        # 强度校准占位
        intensity_calib_layout = QHBoxLayout()
        intensity_calib_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))

        self.intensity_calib_check = QCheckBox(_("preprocessing_view.intensity_calib_check"))
        self.intensity_calib_check.setChecked(False)  # 默认Close
        intensity_calib_layout.addWidget(self.intensity_calib_check)

        self.intensity_calib_file_btn = QPushButton(_("preprocessing_view.wavelength_calib_file_btn"))
        self.intensity_calib_file_btn.setEnabled(False)
        intensity_calib_layout.addWidget(self.intensity_calib_file_btn)

        self.intensity_calib_file_label = QLabel(_("preprocessing_view.wavelength_calib_file_label"))
        intensity_calib_layout.addWidget(self.intensity_calib_file_label)

        raman_layout.addLayout(intensity_calib_layout)

        # 添加说明文本
        raman_info_label = QLabel(_("preprocessing_view.raman_info_label"))
        raman_layout.addWidget(raman_info_label)

        raman_group.setLayout(raman_layout)
        special_layout.addWidget(raman_group)

        special_layout.addStretch() # Add a stretch to push content up
        scroll_special.setWidget(content_widget_special)
        special_tab_layout.addWidget(scroll_special)
        tabs.addTab(special_tab, _("preprocessing_view.special_tab_tab"))


        preview_tab = QWidget()
        preview_layout = QVBoxLayout()
        preview_layout.setSpacing(ui.scaled_px(tok.SPACE_SM))
        preview_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))


        preview_settings_group = QGroupBox(_("preprocessing_view.preview_settings_group"))
        preview_settings_layout = QVBoxLayout()
        preview_settings_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        preview_settings_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))


        preview_type_params = QHBoxLayout()
        preview_type_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        preview_type_label = QLabel(_("preprocessing_view.preview_type_label"))
        preview_type_params.addWidget(preview_type_label)

        self.preview_type = QComboBox()
        for _text, _key in [(_("preprocessing_view.original_item"), "Original"),
                            (_("preprocessing_view.processed_item"), "Processed"),
                            (_("preprocessing_view.comparison_item"), "Comparison")]:
            self.preview_type.addItem(_text, _key)
        preview_type_params.addWidget(self.preview_type)

        preview_settings_layout.addLayout(preview_type_params)


        preview_sample_params = QHBoxLayout()
        preview_sample_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        preview_sample_label = QLabel(_("preprocessing_view.preview_sample_label"))
        preview_sample_params.addWidget(preview_sample_label)

        self.preview_sample = QSpinBox()
        self.preview_sample.setRange(1, 100)
        self.preview_sample.setValue(1)
        preview_sample_params.addWidget(self.preview_sample)

        preview_settings_layout.addLayout(preview_sample_params)
        preview_settings_group.setLayout(preview_settings_layout)
        preview_layout.addWidget(preview_settings_group)


        preview_plot_group = QGroupBox(_("preprocessing_view.preview_plot_group"))
        preview_plot_layout = QVBoxLayout()
        preview_plot_layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        preview_plot_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))

        if pg is not None:
            self.preview_plot = pg.PlotWidget()
            self.preview_plot.setBackground('w')
            self.preview_plot.showGrid(x=True, y=True)
            self.preview_plot.setLabel('left', _("preprocessing_view.preview_plot_y_label"))
            self.preview_plot.setLabel('bottom', _("preprocessing_view.preview_plot_x_label"))
            preview_plot_layout.addWidget(self.preview_plot)
        else:
            # Fallback when pyqtgraph is not available
            self.preview_plot = None
            placeholder_label = QLabel(_("preprocessing_view.placeholder_label"))
            preview_plot_layout.addWidget(placeholder_label)

        preview_plot_group.setLayout(preview_plot_layout)
        preview_layout.addWidget(preview_plot_group)

        preview_tab.setLayout(preview_layout)
        tabs.addTab(preview_tab, _("preprocessing_view.preview_tab_tab"))

        main_layout.addWidget(tabs)


        button_layout = QHBoxLayout()
        button_layout.setSpacing(ui.scaled_px(tok.SPACE_SM))

        self.preview_button = QPushButton(_("preprocessing_view.preview_button"))
        button_layout.addWidget(self.preview_button)

        self.apply_button = QPushButton(_("preprocessing_view.apply_button"))
        button_layout.addWidget(self.apply_button)

        self.reset_button = QPushButton(_("preprocessing_view.reset_button"))
        button_layout.addWidget(self.reset_button)

        main_layout.addLayout(button_layout)

        self.setLayout(main_layout)

    def get_parameters(self):
        """获取所有预processingparameters"""
        params = {
            'despiking': {
                'enabled': self.despiking_check.isChecked(),
                'method': self.despiking_method.currentData() if self.despiking_check.isChecked() else None,
                'window': self.despiking_window.value() if self.despiking_check.isChecked() else None,
                'threshold': self.despiking_threshold.value() if self.despiking_check.isChecked() else None
            },
            'baseline_correction': {
                'enabled': self.baseline_check.isChecked(),
                'method': self.baseline_method.currentData() if self.baseline_check.isChecked() else None,
                'poly_order': self.poly_order.value() if self.baseline_check.isChecked() else None
            },
            'smoothing': {
                'enabled': self.smoothing_check.isChecked(),
                'method': self.smoothing_method.currentData() if self.smoothing_check.isChecked() else None,
                'window_size': self.window_size.value() if self.smoothing_check.isChecked() else None,
                'poly_order': self.poly_sgf_order.value() if self.smoothing_check.isChecked() and self.smoothing_method.currentData() == "Savitzky-Golay" else None
            },
            'scatter_correction': {
                'enabled': self.scatter_check.isChecked(),
                'method': self.scatter_method.currentData() if self.scatter_check.isChecked() else None
            },
            'normalization': {
                'enabled': self.normalization_check.isChecked(),
                'method': self.normalization_method.currentData() if self.normalization_check.isChecked() else None
            },
            'standardization': {
                'enabled': self.standardization_check.isChecked(),
                'method': self.standardization_method.currentData() if self.standardization_check.isChecked() else None
            },
            'derivative': {
                'enabled': self.derivative_check.isChecked(),
                'order': self.derivative_order.value() if self.derivative_check.isChecked() else None,
                'method': self.derivative_method.currentData() if self.derivative_check.isChecked() else None
            },
            'outlier_detection': {
                'enabled': self.outlier_check.isChecked(),
                'method': self.outlier_method.currentData() if self.outlier_check.isChecked() else None,
                'threshold': self.outlier_threshold.value() if self.outlier_check.isChecked() else None
            },
            'denoising': {
                'enabled': self.denoising_check.isChecked(),
                'method': self.denoising_method.currentData() if self.denoising_check.isChecked() else None,
                'strength': self.denoising_strength.value() if self.denoising_check.isChecked() else None
            },
            'peak_alignment': {
                'enabled': self.alignment_check.isChecked(),
                'method': self.alignment_method.currentData() if self.alignment_check.isChecked() else None,
                'reference': self.reference_method.currentData() if self.alignment_check.isChecked() else None
            },
            'raman_specific': {
                'wavelength_calibration': {
                    'enabled': self.wavelength_calib_check.isChecked(),
                    'file_path': getattr(self, 'wavelength_calib_file_path', None) if self.wavelength_calib_check.isChecked() else None
                },
                'intensity_calibration': {
                    'enabled': self.intensity_calib_check.isChecked(),
                    'file_path': getattr(self, 'intensity_calib_file_path', None) if self.intensity_calib_check.isChecked() else None
                }
            }
        }


        if hasattr(self, 'plugin_params') and self.plugin_params:
            params['plugins'] = self.plugin_params

        return params

    def reset_parameters(self):
        """重置所有parameters为默认值"""
        # 去峰Parameters重置
        self.despiking_check.setChecked(False)
        self.despiking_method.setCurrentIndex(0)
        self.despiking_window.setValue(11)
        self.despiking_threshold.setValue(5.0)

        # 基线校正Parameters重置
        self.baseline_check.setChecked(False)
        self.baseline_method.setCurrentIndex(0)
        self.poly_order.setValue(3)


        self.smoothing_check.setChecked(False)
        self.smoothing_method.setCurrentIndex(0)
        self.window_size.setValue(15)
        self.poly_sgf_order.setValue(2)


        self.scatter_check.setChecked(False)
        self.scatter_method.setCurrentIndex(0)


        self.normalization_check.setChecked(False)
        self.normalization_method.setCurrentIndex(0)


        self.standardization_check.setChecked(False)
        self.standardization_method.setCurrentIndex(0)


        self.derivative_check.setChecked(False)
        self.derivative_order.setValue(1)
        self.derivative_method.setCurrentIndex(0)


        self.outlier_check.setChecked(False)
        self.outlier_method.setCurrentIndex(0)
        self.outlier_threshold.setValue(3.0)


        self.denoising_check.setChecked(False)
        self.denoising_method.setCurrentIndex(0)
        self.denoising_strength.setValue(0.5)


        self.alignment_check.setChecked(False)
        self.alignment_method.setCurrentIndex(0)
        self.reference_method.setCurrentIndex(0)


        self.preview_type.setCurrentIndex(0)
        self.preview_sample.setValue(1)

        # 拉曼专属预处理Parameters重置
        self.wavelength_calib_check.setChecked(False)
        self.wavelength_calib_file_btn.setEnabled(False)
        self.wavelength_calib_file_label.setText(_("preprocessing_view.wavelength_calib_file_label"))
        if hasattr(self, 'wavelength_calib_file_path'):
            delattr(self, 'wavelength_calib_file_path')

        self.intensity_calib_check.setChecked(False)
        self.intensity_calib_file_btn.setEnabled(False)
        self.intensity_calib_file_label.setText(_("preprocessing_view.wavelength_calib_file_label"))
        if hasattr(self, 'intensity_calib_file_path'):
            delattr(self, 'intensity_calib_file_path')


        if hasattr(self, 'preview_plot'):
            self.preview_plot.clear()

    def update_preview(self, original_data, processed_data=None):
        """更新预览图表"""
        if not hasattr(self, 'preview_plot') or self.preview_plot is None:
            return

        self.preview_plot.clear()

        if original_data is None:
            return


        sample_idx = min(self.preview_sample.value() - 1, len(original_data) - 1)
        if sample_idx < 0:
            sample_idx = 0


        preview_type = self.preview_type.currentData()


        wavelengths = np.arange(original_data.shape[1])

        if preview_type == "Original":

            self.preview_plot.plot(wavelengths, original_data[sample_idx], pen='b', name='Original')

        elif preview_type == "Processed" and processed_data is not None:

            self.preview_plot.plot(wavelengths, processed_data[sample_idx], pen='r', name='Processed')

        elif preview_type == "Comparison" and processed_data is not None:

            self.preview_plot.plot(wavelengths, original_data[sample_idx], pen='b', name='Original')
            self.preview_plot.plot(wavelengths, processed_data[sample_idx], pen='r', name='Processed')

    def get_selected_methods(self):
        """获取选中的预processingmethod列表"""
        methods = []

        if self.despiking_check.isChecked():
            methods.append(f"Despiking ({self.despiking_method.currentText()})")

        if self.baseline_check.isChecked():
            methods.append(f"Baseline Correction ({self.baseline_method.currentText()})")

        if self.smoothing_check.isChecked():
            methods.append(f"{self.smoothing_method.currentText()} Smoothing")

        if self.scatter_check.isChecked():
            methods.append(f"{self.scatter_method.currentText()} Scatter Correction")

        if self.normalization_check.isChecked():
            methods.append(f"{self.normalization_method.currentText()} Normalization")

        if self.standardization_check.isChecked():
            methods.append(f"{self.standardization_method.currentText()} Standardization")

        if self.derivative_check.isChecked():
            methods.append(f"{self.derivative_order.value()} Order Derivative")

        if self.outlier_check.isChecked():
            methods.append(f"{self.outlier_method.currentText()} Outlier Detection")

        if self.denoising_check.isChecked():
            methods.append(f"{self.denoising_method.currentText()} Denoising")

        if self.alignment_check.isChecked():
            methods.append(f"{self.alignment_method.currentText()} Peak Alignment")

        return methods

    def display_error(self, message):
        """显示error消息"""
        QMessageBox.critical(self, _("preprocessing_view.message"), message)

    def update_preprocessed_data(self, data):
        """更新预processing后的data显示"""

        pass

    def show_parameters(self, method):
        """显示parameters设置对话框 - 兼容旧接口"""

        pass

    def add_custom_algorithm(self, code):
        """添加自定义预处理算法到插件库（注册后由插件表统一管理）"""
        try:
            from app.utils.code_sandbox import execute_plugin_code

            mod = execute_plugin_code(code, module_name='custom_preprocessor')

            for item in mod.__dict__.values():
                if isinstance(item, type):
                    algorithm = item()
                    name = algorithm.get_name() if hasattr(algorithm, 'get_name') else getattr(algorithm, 'name', item.__name__)
                    if not hasattr(algorithm, 'get_parameter_info') and hasattr(algorithm, 'get_params_info'):
                        algorithm.get_parameter_info = algorithm.get_params_info
                    self.plugins[name] = algorithm
                    return

            raise ValueError("No algorithm class found in converted code.")
        except Exception as e:
            raise Exception(f"Error loading custom preprocessor: {str(e)}")
