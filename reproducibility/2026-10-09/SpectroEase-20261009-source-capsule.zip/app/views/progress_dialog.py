from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QProgressBar, QLabel, QPushButton, QMessageBox
from PyQt5.QtCore import Qt, pyqtSignal
from app.utils.responsive import fit_window_to_screen
from app.utils.translator import translator, _


class ProgressDialog(QDialog):
    """Progress Bar Dialog with cancellation support."""

    cancelled = pyqtSignal()

    def __init__(self, title=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title if title else _("progress_dialog.title"))
        self.setModal(True)
        self._cancelling = False
        self.setup_ui()

    def setup_ui(self):
        """Setup UI"""
        layout = QVBoxLayout(self)

        # Status label
        self.status_label = QLabel(_("progress_dialog.status_label"))
        layout.addWidget(self.status_label)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        layout.addWidget(self.progress_bar)

        # Cancel button (emits ``cancelled``; the worker checks is_cancelled())
        self.cancel_btn = QPushButton(_("progress_dialog.cancel_btn"))
        self.cancel_btn.clicked.connect(self._on_cancel)
        layout.addWidget(self.cancel_btn)

        # Set window properties
        self.status_label.setWordWrap(True)
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_PROGRESS[0]), ui.scaled_px(tok.DIALOG_SIZE_PROGRESS[1]), min_width=ui.scaled_px(300), min_height=ui.scaled_px(110))
        self.setWindowFlags(Qt.Window | Qt.WindowTitleHint | Qt.WindowCloseButtonHint)

    def update_progress(self, value, status=None):
        """Update progress"""
        self.progress_bar.setValue(value)
        if status:
            self.status_label.setText(status)
        if value >= 100:
            self.cancel_btn.setEnabled(False)

    def _on_cancel(self):
        """User requested cancellation: emit the token and disable the button."""
        self._cancelling = True
        self.cancel_btn.setEnabled(False)
        self.cancelled.emit()

    @property
    def was_cancelled(self):
        """True after the user pressed Cancel (or confirmed window close)."""
        return self._cancelling

    def closeEvent(self, event):
        """Confirm before closing while a task is still running (no more dead-lock)."""
        if self.progress_bar.value() < 100 and not self._cancelling:
            reply = QMessageBox.question(
                self,
                _("progress_dialog.confirm_title"),
                _("progress_dialog.confirm_cancel"),
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if reply == QMessageBox.Yes:
                self._on_cancel()
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()
