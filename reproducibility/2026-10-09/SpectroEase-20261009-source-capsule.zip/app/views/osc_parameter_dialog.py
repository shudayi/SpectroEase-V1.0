#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
OSC (Orthogonal Signal Correction) Parameter Dialog
"""

from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QCheckBox, QDoubleSpinBox, QComboBox, QSpinBox,
    QPushButton, QGroupBox, QTextEdit, QFrame, QScrollArea, QWidget, QSizePolicy
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
import numpy as np
from app.utils.responsive import fit_window_to_screen
from app.utils.exceptions import user_facing_error

class OSCParameterDialog(QDialog):
    """OSC Parameter Setting Dialog"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(_("osc_parameter_dialog.title"))
        self.init_ui()
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_PARAM_LG[0]), ui.scaled_px(tok.DIALOG_SIZE_PARAM_LG[1]), min_width=ui.scaled_px(420), min_height=ui.scaled_px(420))

    def init_ui(self):
        """Initialize interface"""
        content_widget = QWidget()
        main_layout = QVBoxLayout(content_widget)
        main_layout.setSpacing(ui.scaled_px(tok.DIALOG_SECTION_SPACING))

        # Title
        title_label = QLabel(_("osc_parameter_dialog.title_label"))
        title_label.setAlignment(Qt.AlignCenter)
        __font = ui.get_scaled_font(tok.FONT_FAMILY_UI[0], tok.DIALOG_TITLE_FONT_PT)
        __font.setBold(True)
        title_label.setFont(__font)
        main_layout.addWidget(title_label)

        # Separator
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main_layout.addWidget(line)

        # Basic Parameters
        basic_group = QGroupBox(_("osc_parameter_dialog.basic_group"))
        basic_layout = QFormLayout()

        # Number of OSC components
        self.n_components_spin = QSpinBox()
        self.n_components_spin.setRange(1, 20)
        self.n_components_spin.setValue(2)
        basic_layout.addRow(_("osc_parameter_dialog.number_of_osc_components_label"), self.n_components_spin)

        # OSC algorithm
        self.algorithm_combo = QComboBox()
        for _text, _key in [(_("osc_parameter_dialog.standard_osc_item"), "Standard OSC"),
                            (_("osc_parameter_dialog.direct_osc_item"), "Direct OSC"),
                            (_("osc_parameter_dialog.recursive_osc_item"), "Recursive OSC"),
                            (_("osc_parameter_dialog.consensus_osc_item"), "Consensus OSC")]:
            self.algorithm_combo.addItem(_text, _key)
        self.algorithm_combo.setCurrentIndex(0)
        basic_layout.addRow(_("osc_parameter_dialog.osc_algorithm_label"), self.algorithm_combo)

        # Target tolerance
        self.tolerance_spin = QDoubleSpinBox()
        self.tolerance_spin.setRange(1e-8, 1e-2)
        self.tolerance_spin.setValue(1e-6)
        self.tolerance_spin.setDecimals(8)
        self.tolerance_spin.setSingleStep(1e-7)
        basic_layout.addRow(_("osc_parameter_dialog.convergence_tolerance_label"), self.tolerance_spin)

        # Maximum iterations
        self.max_iter_spin = QSpinBox()
        self.max_iter_spin.setRange(1, 1000)
        self.max_iter_spin.setValue(100)
        basic_layout.addRow(_("osc_parameter_dialog.maximum_iterations_label"), self.max_iter_spin)

        ui.configure_form_row(basic_layout.labelForField(self.n_components_spin), self.n_components_spin)
        ui.configure_form_row(basic_layout.labelForField(self.algorithm_combo), self.algorithm_combo)
        ui.configure_form_row(basic_layout.labelForField(self.tolerance_spin), self.tolerance_spin)
        ui.configure_form_row(basic_layout.labelForField(self.max_iter_spin), self.max_iter_spin)
        basic_group.setLayout(basic_layout)
        main_layout.addWidget(basic_group)

        # Advanced Parameters
        advanced_group = QGroupBox(_("osc_parameter_dialog.advanced_group"))
        advanced_layout = QFormLayout()

        # Deflation method
        self.deflation_combo = QComboBox()
        for _text, _key in [(_("osc_parameter_dialog.classical_item"), "Classical"),
                            (_("osc_parameter_dialog.improved_item"), "Improved"),
                            (_("osc_parameter_dialog.symmetric_item"), "Symmetric"),
                            (_("osc_parameter_dialog.nipals_item"), "NIPALS")]:
            self.deflation_combo.addItem(_text, _key)
        self.deflation_combo.setCurrentIndex(1)  # Improved
        advanced_layout.addRow(_("osc_parameter_dialog.deflation_method_label"), self.deflation_combo)

        # Variance threshold
        self.variance_threshold_spin = QDoubleSpinBox()
        self.variance_threshold_spin.setRange(0.01, 0.99)
        self.variance_threshold_spin.setValue(0.95)
        self.variance_threshold_spin.setDecimals(3)
        self.variance_threshold_spin.setSingleStep(0.01)
        advanced_layout.addRow(_("osc_parameter_dialog.variance_threshold_label"), self.variance_threshold_spin)

        # Center data
        self.center_check = QCheckBox()
        self.center_check.setChecked(True)
        advanced_layout.addRow(_("osc_parameter_dialog.center_data_label"), self.center_check)

        # Scale data
        self.scale_check = QCheckBox()
        self.scale_check.setChecked(False)
        advanced_layout.addRow(_("osc_parameter_dialog.scale_data_label"), self.scale_check)

        # Cross-validation
        self.cv_check = QCheckBox()
        self.cv_check.setChecked(True)
        advanced_layout.addRow(_("osc_parameter_dialog.cross_validation_label"), self.cv_check)

        # CV folds
        self.cv_folds_spin = QSpinBox()
        self.cv_folds_spin.setRange(2, 20)
        self.cv_folds_spin.setValue(5)
        advanced_layout.addRow(_("osc_parameter_dialog.cv_folds_label"), self.cv_folds_spin)

        # Orthogonality constraint
        self.orthogonal_spin = QDoubleSpinBox()
        self.orthogonal_spin.setRange(0.0, 1.0)
        self.orthogonal_spin.setValue(1.0)
        self.orthogonal_spin.setDecimals(3)
        self.orthogonal_spin.setSingleStep(0.1)
        advanced_layout.addRow(_("osc_parameter_dialog.orthogonality_constraint_label"), self.orthogonal_spin)

        # Regularization
        self.regularization_spin = QDoubleSpinBox()
        self.regularization_spin.setRange(0.0, 1.0)
        self.regularization_spin.setValue(0.0)
        self.regularization_spin.setDecimals(6)
        self.regularization_spin.setSingleStep(0.001)
        advanced_layout.addRow(_("osc_parameter_dialog.regularization_parameter_label"), self.regularization_spin)

        ui.configure_form_row(advanced_layout.labelForField(self.deflation_combo), self.deflation_combo)
        ui.configure_form_row(advanced_layout.labelForField(self.variance_threshold_spin), self.variance_threshold_spin)
        ui.configure_form_row(advanced_layout.labelForField(self.center_check), self.center_check)
        ui.configure_form_row(advanced_layout.labelForField(self.scale_check), self.scale_check)
        ui.configure_form_row(advanced_layout.labelForField(self.cv_check), self.cv_check)
        ui.configure_form_row(advanced_layout.labelForField(self.cv_folds_spin), self.cv_folds_spin)
        ui.configure_form_row(advanced_layout.labelForField(self.orthogonal_spin), self.orthogonal_spin)
        ui.configure_form_row(advanced_layout.labelForField(self.regularization_spin), self.regularization_spin)
        advanced_group.setLayout(advanced_layout)
        main_layout.addWidget(advanced_group)

        # Algorithm Description
        description_group = QGroupBox(_("osc_parameter_dialog.description_group"))
        description_layout = QVBoxLayout()

        self.description_text = QTextEdit()
        self.description_text.setReadOnly(True)
        ui.set_max_height(self.description_text, tok.TEXT_EDIT_MAX_HEIGHT_SM)
        self.description_text.setText(
            _("osc_parameter_dialog.description_text_description_text_text")
        )
        description_layout.addWidget(self.description_text)

        description_group.setLayout(description_layout)
        main_layout.addWidget(description_group)

        # Preset Configurations
        preset_group = QGroupBox(_("osc_parameter_dialog.preset_group"))
        preset_layout = QHBoxLayout()

        self.standard_preset_btn = QPushButton(_("osc_parameter_dialog.standard_preset_btn"))
        self.standard_preset_btn.setProperty("role", "secondary")
        self.standard_preset_btn.clicked.connect(self.load_standard_preset)
        preset_layout.addWidget(self.standard_preset_btn)

        self.conservative_preset_btn = QPushButton(_("osc_parameter_dialog.conservative_preset_btn"))
        self.conservative_preset_btn.setProperty("role", "secondary")
        self.conservative_preset_btn.clicked.connect(self.load_conservative_preset)
        preset_layout.addWidget(self.conservative_preset_btn)

        self.aggressive_preset_btn = QPushButton(_("osc_parameter_dialog.aggressive_preset_btn"))
        self.aggressive_preset_btn.setProperty("role", "secondary")
        self.aggressive_preset_btn.clicked.connect(self.load_aggressive_preset)
        preset_layout.addWidget(self.aggressive_preset_btn)

        preset_group.setLayout(preset_layout)
        main_layout.addWidget(preset_group)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(content_widget)

        outer_layout = QVBoxLayout(self)
        outer_layout.addWidget(scroll_area)

        # Buttons
        footer_widget = QWidget()
        ui.set_min_height(footer_widget, tok.DIALOG_FOOTER_HEIGHT)
        footer_widget.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(ui.scaled_px(0), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(0), ui.scaled_px(tok.SPACE_SM))

        self.test_btn = QPushButton(_("osc_parameter_dialog.test_btn"))
        self.test_btn.setProperty("role", "secondary")
        self.test_btn.clicked.connect(self.test_parameters)
        button_layout.addWidget(self.test_btn)

        button_layout.addStretch()

        self.ok_btn = QPushButton(_("osc_parameter_dialog.ok_btn"))
        self.ok_btn.setProperty("role", "primary")
        self.ok_btn.clicked.connect(self.accept)
        button_layout.addWidget(self.ok_btn)

        self.cancel_btn = QPushButton(_("osc_parameter_dialog.cancel_btn"))
        self.cancel_btn.setProperty("role", "secondary")
        self.cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_btn)

        footer_widget.setLayout(button_layout)
        outer_layout.addWidget(footer_widget)
        self.setLayout(outer_layout)

        # Connect signals
        self.algorithm_combo.currentIndexChanged.connect(self.update_description)
        self.deflation_combo.currentIndexChanged.connect(self.update_description)
        self.cv_check.toggled.connect(self.on_cv_changed)

    def on_cv_changed(self, checked):
        """Handle cross-validation checkbox"""
        self.cv_folds_spin.setEnabled(checked)

    def load_standard_preset(self):
        """Load standard OSC preset"""
        self.n_components_spin.setValue(2)
        self.algorithm_combo.setCurrentIndex(0)  # Standard OSC
        self.tolerance_spin.setValue(1e-6)
        self.max_iter_spin.setValue(100)
        self.deflation_combo.setCurrentIndex(1)  # Improved
        self.variance_threshold_spin.setValue(0.95)
        self.center_check.setChecked(True)
        self.scale_check.setChecked(False)
        self.cv_check.setChecked(True)
        self.cv_folds_spin.setValue(5)
        self.orthogonal_spin.setValue(1.0)
        self.regularization_spin.setValue(0.0)

    def load_conservative_preset(self):
        """Load conservative OSC preset"""
        self.n_components_spin.setValue(1)
        self.algorithm_combo.setCurrentIndex(0)  # Standard OSC
        self.tolerance_spin.setValue(1e-5)
        self.max_iter_spin.setValue(50)
        self.deflation_combo.setCurrentIndex(0)  # Classical
        self.variance_threshold_spin.setValue(0.99)
        self.center_check.setChecked(True)
        self.scale_check.setChecked(True)
        self.cv_check.setChecked(True)
        self.cv_folds_spin.setValue(10)
        self.orthogonal_spin.setValue(0.9)
        self.regularization_spin.setValue(0.01)

    def load_aggressive_preset(self):
        """Load aggressive OSC preset"""
        self.n_components_spin.setValue(5)
        self.algorithm_combo.setCurrentIndex(2)  # Recursive OSC
        self.tolerance_spin.setValue(1e-7)
        self.max_iter_spin.setValue(200)
        self.deflation_combo.setCurrentIndex(2)  # Symmetric
        self.variance_threshold_spin.setValue(0.90)
        self.center_check.setChecked(True)
        self.scale_check.setChecked(False)
        self.cv_check.setChecked(True)
        self.cv_folds_spin.setValue(3)
        self.orthogonal_spin.setValue(1.0)
        self.regularization_spin.setValue(0.0)

    def update_description(self):
        """Update algorithm description"""
        algorithm = self.algorithm_combo.currentText()
        deflation = self.deflation_combo.currentText()

        desc = _("osc_parameter_dialog.update_description_prefix")
        desc += _("osc_parameter_dialog.update_description_algorithm").format(algorithm=algorithm) + "\n"
        desc += _("osc_parameter_dialog.update_description_deflation").format(deflation=deflation) + "\n"

        if algorithm == _("osc_parameter_dialog.standard_osc_item"):
            desc += _("osc_parameter_dialog.mode_classical_osc") + "\n"
        elif algorithm == _("osc_parameter_dialog.direct_osc_item"):
            desc += _("osc_parameter_dialog.mode_direct") + "\n"
        elif algorithm == _("osc_parameter_dialog.recursive_osc_item"):
            desc += _("osc_parameter_dialog.mode_recursive") + "\n"
        elif algorithm == _("osc_parameter_dialog.consensus_osc_item"):
            desc += _("osc_parameter_dialog.mode_consensus") + "\n"

        if deflation == _("osc_parameter_dialog.classical_item"):
            desc += _("osc_parameter_dialog.deflation_traditional") + "\n"
        elif deflation == _("osc_parameter_dialog.improved_item"):
            desc += _("osc_parameter_dialog.deflation_enhanced") + "\n"
        elif deflation == _("osc_parameter_dialog.symmetric_item"):
            desc += _("osc_parameter_dialog.deflation_symmetric") + "\n"
        elif deflation == _("osc_parameter_dialog.nipals_item"):
            desc += _("osc_parameter_dialog.deflation_nipals") + "\n"

        desc += "\n" + _("osc_parameter_dialog.update_description_suffix")

        self.description_text.setText(desc)

    def test_parameters(self):
        """Test parameters"""
        from PyQt5.QtWidgets import QMessageBox

        params = self.get_parameters()

        try:
            # Validate parameters
            if params['n_components'] > 10 and params['variance_threshold'] > 0.95:
                QMessageBox.warning(self, _("osc_parameter_dialog.message"),
                                  _("osc_parameter_dialog.high_components_warning"))
                return

            if params['regularization'] > 0.1:
                QMessageBox.warning(self, _("osc_parameter_dialog.message"),
                                  _("osc_parameter_dialog.high_regularization_warning"))
                return

            # Simulate OSC processing info
            msg = _("osc_parameter_dialog.test_title") + "\n\n"
            msg += _("osc_parameter_dialog.update_description_algorithm").format(algorithm=params['algorithm']) + "\n"
            msg += _("osc_parameter_dialog.test_components").format(n=params['n_components']) + "\n"
            msg += _("osc_parameter_dialog.update_description_deflation").format(deflation=params['deflation']) + "\n"
            msg += _("osc_parameter_dialog.test_variance_threshold").format(threshold=params['variance_threshold']) + "\n"
            msg += _("osc_parameter_dialog.test_orthogonality").format(constraint=params['orthogonal_constraint']) + "\n"
            msg += _("osc_parameter_dialog.test_regularization").format(reg=params['regularization']) + "\n\n"
            msg += _("osc_parameter_dialog.test_valid")

            QMessageBox.information(self, _("osc_parameter_dialog.message_2"), msg)

        except Exception as e:
            QMessageBox.warning(self, _("osc_parameter_dialog.message_3"), _("osc_parameter_dialog.test_failed").format(error=user_facing_error(e)))

    def get_parameters(self):
        """Get parameters"""
        return {
            'n_components': self.n_components_spin.value(),
            'algorithm': self.algorithm_combo.currentData(),
            'tolerance': self.tolerance_spin.value(),
            'max_iter': self.max_iter_spin.value(),
            'deflation': self.deflation_combo.currentData(),
            'variance_threshold': self.variance_threshold_spin.value(),
            'center': self.center_check.isChecked(),
            'scale': self.scale_check.isChecked(),
            'cross_validation': self.cv_check.isChecked(),
            'cv_folds': self.cv_folds_spin.value(),
            'orthogonal_constraint': self.orthogonal_spin.value(),
            'regularization': self.regularization_spin.value()
        }

    def set_parameters(self, params):
        """Set parameters"""
        self.n_components_spin.setValue(params.get('n_components', 2))

        if 'algorithm' in params:
            index = self.algorithm_combo.findData(params['algorithm'])
            if index >= 0:
                self.algorithm_combo.setCurrentIndex(index)

        self.tolerance_spin.setValue(params.get('tolerance', 1e-6))
        self.max_iter_spin.setValue(params.get('max_iter', 100))

        if 'deflation' in params:
            index = self.deflation_combo.findData(params['deflation'])
            if index >= 0:
                self.deflation_combo.setCurrentIndex(index)

        self.variance_threshold_spin.setValue(params.get('variance_threshold', 0.95))
        self.center_check.setChecked(params.get('center', True))
        self.scale_check.setChecked(params.get('scale', False))
        self.cv_check.setChecked(params.get('cross_validation', True))
        self.cv_folds_spin.setValue(params.get('cv_folds', 5))
        self.orthogonal_spin.setValue(params.get('orthogonal_constraint', 1.0))
        self.regularization_spin.setValue(params.get('regularization', 0.0))

        # Update description
        self.update_description()

if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)
    dialog = OSCParameterDialog()
    dialog.show()
    sys.exit(app.exec_())
