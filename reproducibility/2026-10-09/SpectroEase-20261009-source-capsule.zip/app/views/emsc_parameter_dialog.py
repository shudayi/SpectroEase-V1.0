#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
EMSC (Extended Multiplicative Scatter Correction) Parameter Dialog
"""

from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QCheckBox, QDoubleSpinBox, QComboBox, QSpinBox,
    QPushButton, QGroupBox, QTextEdit, QFrame, QScrollArea, QWidget, QSizePolicy
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
import numpy as np
from app.utils.responsive import fit_window_to_screen
from app.utils.exceptions import user_facing_error

class EMSCParameterDialog(QDialog):
    """EMSC Parameter Setting Dialog"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(_("emsc_parameter_dialog.title"))
        self.init_ui()
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_PARAM_LG[0]), ui.scaled_px(tok.DIALOG_SIZE_PARAM_LG[1]), min_width=ui.scaled_px(420), min_height=ui.scaled_px(420))

    def init_ui(self):
        """Initialize interface"""
        content_widget = QWidget()
        main_layout = QVBoxLayout(content_widget)
        main_layout.setSpacing(ui.scaled_px(tok.DIALOG_SECTION_SPACING))

        # Title
        title_label = QLabel(_("emsc_parameter_dialog.title_label"))
        title_label.setAlignment(Qt.AlignCenter)
        __font = ui.get_scaled_font(tok.FONT_FAMILY_UI[0], tok.DIALOG_TITLE_FONT_PT)
        __font.setBold(True)
        title_label.setFont(__font)
        main_layout.addWidget(title_label)

        # Separator
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main_layout.addWidget(line)

        # Basic Parameters
        basic_group = QGroupBox(_("emsc_parameter_dialog.basic_group"))
        basic_layout = QFormLayout()

        # Reference spectrum selection
        self.reference_combo = QComboBox()
        for _text, _key in [(_("emsc_parameter_dialog.mean_spectrum_item"), "Mean Spectrum"),
                            (_("emsc_parameter_dialog.median_spectrum_item"), "Median Spectrum"),
                            (_("emsc_parameter_dialog.first_sample_item"), "First Sample"),
                            (_("emsc_parameter_dialog.custom_reference_item"), "Custom Reference")]:
            self.reference_combo.addItem(_text, _key)
        self.reference_combo.setCurrentIndex(0)
        basic_layout.addRow(_("emsc_parameter_dialog.reference_spectrum_label"), self.reference_combo)

        # Polynomial order
        self.poly_order_spin = QSpinBox()
        self.poly_order_spin.setRange(0, 5)
        self.poly_order_spin.setValue(2)
        basic_layout.addRow(_("emsc_parameter_dialog.polynomial_order_label"), self.poly_order_spin)

        # Include wavelength terms
        self.wavelength_check = QCheckBox()
        self.wavelength_check.setChecked(True)
        basic_layout.addRow(_("emsc_parameter_dialog.include_wavelength_terms_label"), self.wavelength_check)

        # Include pathlength variation
        self.pathlength_check = QCheckBox()
        self.pathlength_check.setChecked(True)
        basic_layout.addRow(_("emsc_parameter_dialog.include_pathlength_variation_label"), self.pathlength_check)

        ui.configure_form_row(basic_layout.labelForField(self.reference_combo), self.reference_combo)
        ui.configure_form_row(basic_layout.labelForField(self.poly_order_spin), self.poly_order_spin)
        ui.configure_form_row(basic_layout.labelForField(self.wavelength_check), self.wavelength_check)
        ui.configure_form_row(basic_layout.labelForField(self.pathlength_check), self.pathlength_check)
        basic_group.setLayout(basic_layout)
        main_layout.addWidget(basic_group)

        # Advanced Parameters
        advanced_group = QGroupBox(_("emsc_parameter_dialog.advanced_group"))
        advanced_layout = QFormLayout()

        # Wavelength range
        self.wavelength_start_spin = QDoubleSpinBox()
        self.wavelength_start_spin.setRange(0, 10000)
        self.wavelength_start_spin.setValue(400)
        self.wavelength_start_spin.setSuffix(" nm")
        advanced_layout.addRow(_("emsc_parameter_dialog.wavelength_start_label"), self.wavelength_start_spin)

        self.wavelength_end_spin = QDoubleSpinBox()
        self.wavelength_end_spin.setRange(0, 10000)
        self.wavelength_end_spin.setValue(2500)
        self.wavelength_end_spin.setSuffix(" nm")
        advanced_layout.addRow(_("emsc_parameter_dialog.wavelength_end_label"), self.wavelength_end_spin)

        # Interference matrix
        self.interference_check = QCheckBox()
        self.interference_check.setChecked(False)
        advanced_layout.addRow(_("emsc_parameter_dialog.use_interference_matrix_label"), self.interference_check)

        # Regularization parameter
        self.regularization_spin = QDoubleSpinBox()
        self.regularization_spin.setRange(0, 1)
        self.regularization_spin.setValue(0.01)
        self.regularization_spin.setDecimals(6)
        self.regularization_spin.setSingleStep(0.001)
        advanced_layout.addRow(_("emsc_parameter_dialog.regularization_parameter_label"), self.regularization_spin)

        # Maximum iterations
        self.max_iter_spin = QSpinBox()
        self.max_iter_spin.setRange(1, 1000)
        self.max_iter_spin.setValue(100)
        advanced_layout.addRow(_("emsc_parameter_dialog.maximum_iterations_label"), self.max_iter_spin)

        # Convergence tolerance
        self.tolerance_spin = QDoubleSpinBox()
        self.tolerance_spin.setRange(1e-10, 1e-2)
        self.tolerance_spin.setValue(1e-6)
        self.tolerance_spin.setDecimals(10)
        self.tolerance_spin.setSingleStep(1e-7)
        advanced_layout.addRow(_("emsc_parameter_dialog.convergence_tolerance_label"), self.tolerance_spin)

        ui.configure_form_row(advanced_layout.labelForField(self.wavelength_start_spin), self.wavelength_start_spin)
        ui.configure_form_row(advanced_layout.labelForField(self.wavelength_end_spin), self.wavelength_end_spin)
        ui.configure_form_row(advanced_layout.labelForField(self.interference_check), self.interference_check)
        ui.configure_form_row(advanced_layout.labelForField(self.regularization_spin), self.regularization_spin)
        ui.configure_form_row(advanced_layout.labelForField(self.max_iter_spin), self.max_iter_spin)
        ui.configure_form_row(advanced_layout.labelForField(self.tolerance_spin), self.tolerance_spin)
        advanced_group.setLayout(advanced_layout)
        main_layout.addWidget(advanced_group)

        # Algorithm Description
        description_group = QGroupBox(_("emsc_parameter_dialog.description_group"))
        description_layout = QVBoxLayout()

        self.description_text = QTextEdit()
        self.description_text.setReadOnly(True)
        ui.set_max_height(self.description_text, tok.TEXT_EDIT_MAX_HEIGHT_SM)
        self.description_text.setText(
            _("emsc_parameter_dialog.description_text_description_text_text")
        )
        description_layout.addWidget(self.description_text)

        description_group.setLayout(description_layout)
        main_layout.addWidget(description_group)

        # Preset Configurations
        preset_group = QGroupBox(_("emsc_parameter_dialog.preset_group"))
        preset_layout = QHBoxLayout()

        self.standard_preset_btn = QPushButton(_("emsc_parameter_dialog.standard_preset_btn"))
        self.standard_preset_btn.setProperty("role", "secondary")
        self.standard_preset_btn.clicked.connect(self.load_standard_preset)
        preset_layout.addWidget(self.standard_preset_btn)

        self.simple_preset_btn = QPushButton(_("emsc_parameter_dialog.simple_preset_btn"))
        self.simple_preset_btn.setProperty("role", "secondary")
        self.simple_preset_btn.clicked.connect(self.load_simple_preset)
        preset_layout.addWidget(self.simple_preset_btn)

        self.advanced_preset_btn = QPushButton(_("emsc_parameter_dialog.advanced_preset_btn"))
        self.advanced_preset_btn.setProperty("role", "secondary")
        self.advanced_preset_btn.clicked.connect(self.load_advanced_preset)
        preset_layout.addWidget(self.advanced_preset_btn)

        preset_group.setLayout(preset_layout)
        main_layout.addWidget(preset_group)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(content_widget)

        outer_layout = QVBoxLayout(self)
        outer_layout.addWidget(scroll_area)

        # Buttons
        footer_widget = QWidget()
        ui.set_min_height(footer_widget, tok.DIALOG_FOOTER_HEIGHT)
        footer_widget.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(ui.scaled_px(0), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(0), ui.scaled_px(tok.SPACE_SM))

        self.test_btn = QPushButton(_("emsc_parameter_dialog.test_btn"))
        self.test_btn.setProperty("role", "secondary")
        self.test_btn.clicked.connect(self.test_parameters)
        button_layout.addWidget(self.test_btn)

        button_layout.addStretch()

        self.ok_btn = QPushButton(_("emsc_parameter_dialog.ok_btn"))
        self.ok_btn.setProperty("role", "primary")
        self.ok_btn.clicked.connect(self.accept)
        button_layout.addWidget(self.ok_btn)

        self.cancel_btn = QPushButton(_("emsc_parameter_dialog.cancel_btn"))
        self.cancel_btn.setProperty("role", "secondary")
        self.cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_btn)

        footer_widget.setLayout(button_layout)
        outer_layout.addWidget(footer_widget)
        self.setLayout(outer_layout)

        # Connect signals
        self.reference_combo.currentIndexChanged.connect(self.update_description)
        self.poly_order_spin.valueChanged.connect(self.update_description)
        self.wavelength_check.toggled.connect(self.update_description)

    def load_standard_preset(self):
        """Load standard EMSC preset"""
        self.reference_combo.setCurrentIndex(0)  # Mean Spectrum
        self.poly_order_spin.setValue(2)
        self.wavelength_check.setChecked(True)
        self.pathlength_check.setChecked(True)
        self.interference_check.setChecked(False)
        self.regularization_spin.setValue(0.01)
        self.max_iter_spin.setValue(100)
        self.tolerance_spin.setValue(1e-6)

    def load_simple_preset(self):
        """Load simple EMSC preset"""
        self.reference_combo.setCurrentIndex(0)  # Mean Spectrum
        self.poly_order_spin.setValue(1)
        self.wavelength_check.setChecked(False)
        self.pathlength_check.setChecked(True)
        self.interference_check.setChecked(False)
        self.regularization_spin.setValue(0.001)

    def load_advanced_preset(self):
        """Load advanced EMSC preset"""
        self.reference_combo.setCurrentIndex(0)  # Mean Spectrum
        self.poly_order_spin.setValue(3)
        self.wavelength_check.setChecked(True)
        self.pathlength_check.setChecked(True)
        self.interference_check.setChecked(True)
        self.regularization_spin.setValue(0.1)
        self.max_iter_spin.setValue(200)
        self.tolerance_spin.setValue(1e-8)

    def update_description(self):
        """Update algorithm description"""
        reference = self.reference_combo.currentText()
        poly_order = self.poly_order_spin.value()
        wavelength = self.wavelength_check.isChecked()

        desc = _("emsc_parameter_dialog.update_description_prefix")
        desc += _("emsc_parameter_dialog.update_description_reference").format(reference=reference) + "\n"
        desc += _("emsc_parameter_dialog.update_description_poly_order").format(poly_order=poly_order) + "\n"
        desc += _("emsc_parameter_dialog.update_description_wavelength_terms").format(terms=_("emsc_parameter_dialog.included") if wavelength else _("emsc_parameter_dialog.excluded")) + "\n"

        if poly_order == 0:
            desc += _("emsc_parameter_dialog.mode_basic_msc") + "\n"
        elif poly_order == 1:
            desc += _("emsc_parameter_dialog.mode_linear") + "\n"
        elif poly_order >= 2:
            desc += _("emsc_parameter_dialog.mode_nonlinear") + "\n"

        desc += "\n" + _("emsc_parameter_dialog.update_description_suffix")

        self.description_text.setText(desc)

    def test_parameters(self):
        """Test parameters"""
        from PyQt5.QtWidgets import QMessageBox

        params = self.get_parameters()

        try:
            # Validate parameters
            if params['poly_order'] > 3 and params['regularization'] < 0.001:
                QMessageBox.warning(self, _("emsc_parameter_dialog.message"),
                                  _("emsc_parameter_dialog.high_poly_low_reg_warning"))
                return

            if params['wavelength_start'] >= params['wavelength_end']:
                QMessageBox.warning(self, _("emsc_parameter_dialog.message_2"),
                                  _("emsc_parameter_dialog.wavelength_range_error"))
                return

            # Simulate EMSC processing info
            msg = _("emsc_parameter_dialog.test_title") + "\n\n"
            msg += _("emsc_parameter_dialog.update_description_reference").format(reference=params['reference']) + "\n"
            msg += _("emsc_parameter_dialog.update_description_poly_order").format(poly_order=params['poly_order']) + "\n"
            msg += _("emsc_parameter_dialog.test_wavelength_range").format(start=params['wavelength_start'], end=params['wavelength_end']) + "\n"
            msg += _("emsc_parameter_dialog.test_regularization").format(reg=params['regularization']) + "\n"
            msg += _("emsc_parameter_dialog.test_max_iter").format(iter=params['max_iter']) + "\n\n"
            msg += _("emsc_parameter_dialog.test_valid")

            QMessageBox.information(self, _("emsc_parameter_dialog.message_3"), msg)

        except Exception as e:
            QMessageBox.warning(self, _("emsc_parameter_dialog.message_4"), _("emsc_parameter_dialog.test_failed").format(error=user_facing_error(e)))

    def get_parameters(self):
        """Get parameters"""
        return {
            'reference': self.reference_combo.currentData(),
            'poly_order': self.poly_order_spin.value(),
            'include_wavelength': self.wavelength_check.isChecked(),
            'include_pathlength': self.pathlength_check.isChecked(),
            'wavelength_start': self.wavelength_start_spin.value(),
            'wavelength_end': self.wavelength_end_spin.value(),
            'use_interference': self.interference_check.isChecked(),
            'regularization': self.regularization_spin.value(),
            'max_iter': self.max_iter_spin.value(),
            'tolerance': self.tolerance_spin.value()
        }

    def set_parameters(self, params):
        """Set parameters"""
        if 'reference' in params:
            index = self.reference_combo.findData(params['reference'])
            if index >= 0:
                self.reference_combo.setCurrentIndex(index)

        self.poly_order_spin.setValue(params.get('poly_order', 2))
        self.wavelength_check.setChecked(params.get('include_wavelength', True))
        self.pathlength_check.setChecked(params.get('include_pathlength', True))
        self.wavelength_start_spin.setValue(params.get('wavelength_start', 400))
        self.wavelength_end_spin.setValue(params.get('wavelength_end', 2500))
        self.interference_check.setChecked(params.get('use_interference', False))
        self.regularization_spin.setValue(params.get('regularization', 0.01))
        self.max_iter_spin.setValue(params.get('max_iter', 100))
        self.tolerance_spin.setValue(params.get('tolerance', 1e-6))

        # Update description
        self.update_description()

if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)
    dialog = EMSCParameterDialog()
    dialog.show()
    sys.exit(app.exec_())
