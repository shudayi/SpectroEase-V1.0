from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _

from PyQt5.QtWidgets import QDialog, QVBoxLayout, QTextEdit, QPushButton, QHBoxLayout
from app.utils.responsive import fit_window_to_screen

class OptimizationResultDialog(QDialog):
    def __init__(self, parent, optimized_code):
        super().__init__(parent)
        self.optimized_code = optimized_code
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle(_('optimization_result_dialog.title'))
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_CODE_PREVIEW[0]), ui.scaled_px(tok.DIALOG_SIZE_CODE_PREVIEW[1]), min_width=ui.scaled_px(420), min_height=ui.scaled_px(300))

        layout = QVBoxLayout()


        self.code_edit = QTextEdit()
        self.code_edit.setPlainText(self.optimized_code)
        self.code_edit.setReadOnly(True)
        layout.addWidget(self.code_edit)


        button_layout = QHBoxLayout()

        apply_button = QPushButton(_('optimization_result_dialog.apply_button'))
        apply_button.clicked.connect(self.apply_changes)

        cancel_button = QPushButton(_('optimization_result_dialog.cancel_button'))
        cancel_button.clicked.connect(self.reject)

        button_layout.addWidget(apply_button)
        button_layout.addWidget(cancel_button)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def apply_changes(self):

        self.accept() 
