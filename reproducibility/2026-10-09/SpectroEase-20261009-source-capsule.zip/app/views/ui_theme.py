"""Public theme entry point (thin re-export).

The real design system lives in ``app.ui`` (``design_tokens`` /
``style_sheet_builder`` / ``theme_manager``). This module only re-exports
the two public functions so callers have one stable import location.
The previous ``APP_STYLESHEET`` constant was unused (zero references
project-wide) and has been removed.
"""

from app.ui.theme_manager import apply_theme_to_app, get_app_stylesheet

__all__ = ["apply_theme_to_app", "get_app_stylesheet"]
