from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QComboBox, QPushButton, QFileDialog
)
from app.utils.responsive import fit_window_to_screen
from app.utils.translator import translator, _

class DataImportDialog(QDialog):
    """Data Import Dialog"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.file_path = None
        self.format_type = None
        self.init_ui()
        
    def init_ui(self):
        """Initialize UI"""
        self.setWindowTitle(_("data_import_dialog.title"))
        self.setModal(True)
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_IMPORT[0]), ui.scaled_px(tok.DIALOG_SIZE_IMPORT[1]), min_width=ui.scaled_px(360), min_height=ui.scaled_px(160))
        
        layout = QVBoxLayout()
        
        # File selection
        file_layout = QHBoxLayout()
        self.file_label = QLabel(_("data_import_dialog.file_label"))
        self.file_label.setWordWrap(True)
        file_layout.addWidget(self.file_label)
        
        browse_btn = QPushButton(_("data_import_dialog.browse_btn"))
        browse_btn.clicked.connect(self.browse_file)
        file_layout.addWidget(browse_btn)
        
        layout.addLayout(file_layout)
        
        # Format selection
        format_layout = QHBoxLayout()
        format_layout.addWidget(QLabel(_("data_import_dialog.file_format")))
        
        self.format_combo = QComboBox()
        self.format_combo.addItems([
            "CSV",
            "TXT",
            "XLSX",
            "JSON",
            "NPZ",
            "PARQUET",
            "SPC",
            "JDX",
            "OPUS",
            "MAT",
        ])
        format_layout.addWidget(self.format_combo)
        
        layout.addLayout(format_layout)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        ok_btn = QPushButton(_("data_import_dialog.ok_btn"))
        ok_btn.clicked.connect(self.accept)
        button_layout.addWidget(ok_btn)
        
        cancel_btn = QPushButton(_("data_import_dialog.cancel_btn"))
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)
        
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        
    def browse_file(self):
        """Browse file."""
        file_path, selected_filter = QFileDialog.getOpenFileName(
            self, _("data_import_dialog.dialog_caption"), "",
            _("data_import_dialog.file_filter")
        )
        if file_path:
            self.file_path = file_path
            self.file_label.setText(file_path)

            # Set format based on file extension
            ext = file_path.split('.')[-1].lower()
            format_map = {
                'csv': 'CSV',
                'txt': 'TXT',
                'tsv': 'TXT',
                'xlsx': 'XLSX',
                'xls': 'XLSX',
                'json': 'JSON',
                'npz': 'NPZ',
                'npy': 'NPZ',
                'parquet': 'PARQUET',
                'feather': 'PARQUET',
                'csv.gz': 'CSV',
                'spc': 'SPC',
                'jdx': 'JDX',
                'dx': 'JDX',
                'opus': 'OPUS',
                'mat': 'MAT',
            }
            target = format_map.get(ext)
            if target is not None:
                idx = self.format_combo.findText(target)
                if idx >= 0:
                    self.format_combo.setCurrentIndex(idx)
                else:
                    self.format_combo.addItem(target)
                    self.format_combo.setCurrentText(target)

    def get_file_path(self):
        """获取文件路径"""
        return self.file_path

    def get_format_type(self):
        """获取文件格式"""
        return self.format_combo.currentText().lower()

