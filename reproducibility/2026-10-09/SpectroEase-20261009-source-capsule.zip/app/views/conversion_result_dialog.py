from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _

from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QTextEdit,
                            QPushButton, QHBoxLayout, QLabel)
from PyQt5.QtGui import QFont, QIcon
from PyQt5.QtCore import Qt
from app.utils.responsive import fit_window_to_screen


class ConversionResultDialog(QDialog):
    def __init__(self, parent, converted_code: str, algorithm_type: str):
        super().__init__(parent)
        self.converted_code = converted_code
        self.algorithm_type = algorithm_type
        self.init_ui()
    def __init__(self, parent, converted_code: str, algorithm_type: str):
        super().__init__(parent)
        self.converted_code = converted_code
        self.algorithm_type = algorithm_type
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle(_('conversion_result_dialog.title').format(algorithm_type=self.algorithm_type))
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_CODE_RESULT[0]), ui.scaled_px(tok.DIALOG_SIZE_CODE_RESULT[1]), min_width=ui.scaled_px(520), min_height=ui.scaled_px(360))

        layout = QVBoxLayout()

        # Result description
        result_label = QLabel(_('conversion_result_dialog.result_label'))
        layout.addWidget(result_label)

        # Code display area
        self.code_edit = QTextEdit()
        self.code_edit.setPlainText(self.converted_code)
        self.code_edit.setReadOnly(True)
        self.code_edit.setFont(ui.get_scaled_font("Consolas", 10))
        layout.addWidget(self.code_edit)

        # Tip information
        tip_label = QLabel(_('conversion_result_dialog.tip_label'))
        layout.addWidget(tip_label)

        # Button area
        button_layout = QHBoxLayout()

        self.apply_button = QPushButton(_('conversion_result_dialog.apply_button'))
        self.apply_button.setProperty("role", "success")
        self.apply_button.clicked.connect(self.accept)

        self.copy_button = QPushButton(_('conversion_result_dialog.copy_button'))
        self.copy_button.setProperty("role", "primary")
        self.copy_button.clicked.connect(self.copy_code)

        self.cancel_button = QPushButton(_('conversion_result_dialog.cancel_button'))
        self.cancel_button.setProperty("role", "quiet")
        self.cancel_button.clicked.connect(self.reject)

        button_layout.addWidget(self.apply_button)
        button_layout.addWidget(self.copy_button)
        button_layout.addWidget(self.cancel_button)
        button_layout.setContentsMargins(ui.scaled_px(0), ui.scaled_px(15), ui.scaled_px(0), ui.scaled_px(0))

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def copy_code(self):
        """
        Copy the converted code to the clipboard.
        """
        from PyQt5.QtWidgets import QApplication
        from app.ui.style_sheet_builder import set_role
        QApplication.clipboard().setText(self.converted_code)

        self.copy_button.setText(_("conversion_result_dialog.copy_success"))
        set_role(self.copy_button, "success")

        from PyQt5.QtCore import QTimer
        QTimer.singleShot(1000, lambda: self.reset_copy_button())

    def reset_copy_button(self):
        """Restore the copy button state."""
        from app.ui.style_sheet_builder import set_role
        self.copy_button.setText(_("conversion_result_dialog.copy_code"))
        set_role(self.copy_button, "primary")
