# app/views/column_mapping_dialog.py
"""Column mapping dialog.

Allows the user to specify the response and wavelength/spectral columns.
The default selects all eligible columns except the response and chosen
sample/group identity columns.
"""

from __future__ import annotations

from typing import List, Optional, Tuple

from PyQt5.QtWidgets import (
    QDialog, QDialogButtonBox, QVBoxLayout, QHBoxLayout, QLabel,
    QListWidget, QListWidgetItem, QPushButton, QWidget, QGroupBox,
    QRadioButton, QButtonGroup, QSizePolicy,
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

from app.ui import design_tokens as tok
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _
from app.utils.responsive import fit_window_to_screen


class ColumnMappingDialog(QDialog):
    """Let the user pick which column is the label and which are features."""

    def __init__(
        self,
        columns: List[str],
        label_column_index: int = 0,
        selected_wavelength_columns: Optional[List[int]] = None,
        parent: Optional[QWidget] = None,
        identity_column_indices: Optional[List[int]] = None,
    ):
        super().__init__(parent)
        self._columns = list(columns)
        self._identity_columns = {
            int(index) for index in (identity_column_indices or [])
            if isinstance(index, int) and 0 <= index < len(self._columns)
        }
        self._result = {
            'label_column': max(0, min(label_column_index, len(columns) - 1))
            if columns else 0,
            'wavelength_columns': [],
        }

        self.setWindowTitle(_('column_mapping_dialog.title'))
        self.setModal(True)
        fit_window_to_screen(self, ui.scaled_px(480), ui.scaled_px(520), min_width=ui.scaled_px(380), min_height=ui.scaled_px(420))

        root = QVBoxLayout(self)
        root.setContentsMargins(
            ui.scaled_px(tok.SPACE_LG), ui.scaled_px(tok.SPACE_LG),
            ui.scaled_px(tok.SPACE_LG), ui.scaled_px(tok.SPACE_LG),
        )
        root.setSpacing(ui.scaled_px(tok.SPACE_MD))

        # Top description
        intro = QLabel(_('column_mapping_dialog.intro'))
        intro.setObjectName("secondaryText")
        intro.setWordWrap(True)
        root.addWidget(intro)

        if not columns:
            empty = QLabel(_('column_mapping_dialog.empty_columns'))
            empty.setObjectName("secondaryText")
            root.addWidget(empty)
        else:
            # Label column group
            label_group = QGroupBox(_('column_mapping_dialog.label_column'))
            label_layout = QVBoxLayout(label_group)
            label_layout.setContentsMargins(
                ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
                ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            )

            self._label_list = QListWidget()
            self._label_list.setSelectionMode(QListWidget.SingleSelection)
            for idx, col in enumerate(columns):
                item = QListWidgetItem(f"{idx}: {col}")
                item.setData(Qt.UserRole, idx)
                self._label_list.addItem(item)
            self._label_list.setCurrentRow(self._result['label_column'])
            self._label_list.currentRowChanged.connect(self._on_label_changed)
            self._label_list.setMaximumHeight(ui.scaled_px(120))
            label_layout.addWidget(self._label_list)
            root.addWidget(label_group)

            # Wavelength columns group
            wl_group = QGroupBox(_('column_mapping_dialog.wavelength_columns'))
            wl_layout = QVBoxLayout(wl_group)
            wl_layout.setContentsMargins(
                ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
                ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            )

            # Selection mode
            mode_row = QHBoxLayout()
            self._fb_label_radio = QRadioButton(
                _('column_mapping_dialog.use_all_others')
            )
            self._custom_radio = QRadioButton(
                _('column_mapping_dialog.use_custom_list')
            )
            # Reopening a confirmed custom mapping must preserve its exact
            # feature roles instead of reselecting every metadata column.
            self._fb_label_radio.setChecked(selected_wavelength_columns is None)
            self._custom_radio.setChecked(selected_wavelength_columns is not None)
            self._mode_group = QButtonGroup(self)
            self._mode_group.addButton(self._fb_label_radio, 0)
            self._mode_group.addButton(self._custom_radio, 1)
            self._fb_label_radio.toggled.connect(self._on_mode_changed)
            mode_row.addWidget(self._fb_label_radio)
            mode_row.addWidget(self._custom_radio)
            mode_row.addStretch(1)
            wl_layout.addLayout(mode_row)

            self._wl_list = QListWidget()
            self._wl_list.setSelectionMode(QListWidget.MultiSelection)
            for idx, col in enumerate(columns):
                item = QListWidgetItem(f"{idx}: {col}")
                item.setData(Qt.UserRole, idx)
                if idx in self._identity_columns:
                    item.setFlags(item.flags() & ~Qt.ItemIsEnabled & ~Qt.ItemIsSelectable)
                    item.setToolTip(
                        'Selected as a sample or group identifier; not a spectral feature.'
                    )
                self._wl_list.addItem(item)

            initial_selected = (
                selected_wavelength_columns if selected_wavelength_columns is not None
                else self._default_wavelength_positions()
            )
            for idx in initial_selected:
                if 0 <= idx < len(columns) and idx not in self._identity_columns and idx != self._result['label_column']:
                    item = self._wl_list.item(idx)
                    if item is not None:
                        item.setSelected(True)

            self._wl_list.itemSelectionChanged.connect(self._on_wavelength_selection_changed)
            self._wl_list.setMinimumHeight(ui.scaled_px(160))
            wl_layout.addWidget(self._wl_list)

            # Action buttons
            buttons_row = QHBoxLayout()
            self._select_all_btn = QPushButton(
                _('column_mapping_dialog.select_all')
            )
            self._clear_btn = QPushButton(
                _('column_mapping_dialog.clear_selection')
            )
            self._select_all_btn.clicked.connect(self._on_select_all)
            self._clear_btn.clicked.connect(self._on_clear_selection)
            buttons_row.addWidget(self._select_all_btn)
            buttons_row.addWidget(self._clear_btn)
            buttons_row.addStretch(1)
            wl_layout.addLayout(buttons_row)

            root.addWidget(wl_group)

            # Summary
            self._summary_label = QLabel('')
            self._summary_label.setObjectName("secondaryText")
            self._summary_label.setWordWrap(True)
            root.addWidget(self._summary_label)

        # Dialog buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        button_box.accepted.connect(self._on_accept)
        button_box.rejected.connect(self.reject)
        ok_btn = button_box.button(QDialogButtonBox.Ok)
        if ok_btn is not None:
            ok_btn.setText(_('column_mapping_dialog.apply'))
            ok_btn.setProperty("role", "primary")
        cancel_btn = button_box.button(QDialogButtonBox.Cancel)
        if cancel_btn is not None:
            cancel_btn.setText(_('column_mapping_dialog.cancel'))
            cancel_btn.setProperty("role", "secondary")
        root.addWidget(button_box)

        self._update_summary()
        self._on_mode_changed()

    # ------------------------------------------------------------------ helpers

    def _on_label_changed(self, row: int):
        if row < 0 or row >= len(self._columns):
            return
        self._result['label_column'] = row
        # In "use all others" mode, refresh wavelength selection exclusion.
        self._wl_list.blockSignals(True)
        for i in range(self._wl_list.count()):
            item = self._wl_list.item(i)
            position = item.data(Qt.UserRole)
            if self._fb_label_radio.isChecked():
                item.setSelected(position in self._default_wavelength_positions())
            elif position == row:
                item.setSelected(False)
        self._wl_list.blockSignals(False)
        self._on_wavelength_selection_changed()

    def _default_wavelength_positions(self):
        return [
            i for i in range(len(self._columns))
            if i != self._result['label_column'] and i not in self._identity_columns
        ]

    def _on_mode_changed(self):
        use_all = self._fb_label_radio.isChecked()
        self._wl_list.setEnabled(not use_all)
        self._select_all_btn.setEnabled(not use_all)
        self._clear_btn.setEnabled(not use_all)
        if use_all:
            self._wl_list.blockSignals(True)
            for i in range(self._wl_list.count()):
                item = self._wl_list.item(i)
                item.setSelected(item.data(Qt.UserRole) in self._default_wavelength_positions())
            self._wl_list.blockSignals(False)
        self._on_wavelength_selection_changed()

    def _on_select_all(self):
        self._wl_list.blockSignals(True)
        for i in range(self._wl_list.count()):
            item = self._wl_list.item(i)
            item.setSelected(item.data(Qt.UserRole) in self._default_wavelength_positions())
        self._wl_list.blockSignals(False)
        self._on_wavelength_selection_changed()

    def _on_clear_selection(self):
        self._wl_list.blockSignals(True)
        for i in range(self._wl_list.count()):
            self._wl_list.item(i).setSelected(False)
        self._wl_list.blockSignals(False)
        self._on_wavelength_selection_changed()

    def _on_wavelength_selection_changed(self):
        if self._fb_label_radio.isChecked():
            selected = [
                i for i in range(len(self._columns))
                if i in self._default_wavelength_positions()
            ]
        else:
            selected = []
            for i in range(self._wl_list.count()):
                item = self._wl_list.item(i)
                if item.isSelected():
                    selected.append(item.data(Qt.UserRole))
        selected = [
            i for i in selected
            if i != self._result['label_column'] and i not in self._identity_columns
        ]
        self._result['wavelength_columns'] = selected
        self._update_summary()

    def _update_summary(self):
        if not self._columns:
            return
        idx = self._result['label_column']
        label_name = self._columns[idx] if 0 <= idx < len(self._columns) else '?'
        n_feats = len(self._result['wavelength_columns'])
        self._summary_label.setText(
            translator.lget(
                'column_mapping_dialog.summary',
                'Label: {0}  ·  Features: {1}',
            ).format(label_name, n_feats)
        )

    def _on_accept(self):
        self.accept()

    # ------------------------------------------------------------------ public

    def get_mapping(self) -> dict:
        return dict(self._result)
