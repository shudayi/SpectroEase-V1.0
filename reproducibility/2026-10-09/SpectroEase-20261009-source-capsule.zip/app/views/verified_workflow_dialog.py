"""Responsive verified algorithm onboarding and actual split execution."""
import json
from pathlib import Path
import numpy as np
from PyQt5.QtCore import QThread, pyqtSignal, Qt
from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPlainTextEdit,
    QPushButton, QCheckBox, QComboBox, QScrollArea, QWidget, QFileDialog, QApplication, QTabWidget, QSizePolicy)
from app.services.verified_algorithm_service import Candidate, VerifiedAlgorithmService
from app.utils.responsive import fit_window_to_screen


class _Job(QThread):
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, callback, parent=None):
        super().__init__(parent)
        self.callback = callback

    def run(self):
        try:
            self.done.emit(self.callback())
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class VerifiedWorkflowDialog(QDialog):
    """User-supplied reference fixtures are required; edits invalidate approval."""
    def __init__(self, storage_dir, data_model=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Verified algorithm workflow")
        self.service = VerifiedAlgorithmService(storage_dir)
        self.data_model = data_model
        self.report = None
        self._verified_text = None
        self.job = None
        outer = QVBoxLayout(self)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        content = QWidget(); layout = QVBoxLayout(content)
        note = QLabel("Trusted code only. Supply independently obtained reference outputs in the JSON fixture. Verification checks the declared contract; it does not certify all possible inputs.")
        note.setWordWrap(True); layout.addWidget(note)
        self.editor = QPlainTextEdit(); self.editor.setObjectName("verifiedCandidateJson")
        self.editor.setMinimumHeight(160)
        self.editor.setPlainText(json.dumps(dict(kind="stateful_preprocessing", name="Training mean centering", python_source="import numpy as np\ndef fit(X, y, params):\n    return {'mean': np.mean(X, axis=0).tolist()}\ndef transform(X, state, params):\n    return X - np.asarray(state['mean'])\n", parameter_schema={}, parameters={}, train_X=[[1,2],[3,4]], probe_X=[[5,6],[7,8]], reference_output=[[3,3],[5,5]]), indent=2))
        self.editor.textChanged.connect(self._invalidate)
        layout.addWidget(self.editor)
        row = QVBoxLayout()
        self.import_button = QPushButton("Import candidate JSON")
        self.verify_button = QPushButton("Verify candidate")
        self.accept_button = QPushButton("Accept verified candidate")
        for button in (self.import_button, self.verify_button, self.accept_button): row.addWidget(button)
        layout.addLayout(row)
        self.confirm = QCheckBox("Approve this verified configuration")
        self.confirm.toggled.connect(self._approval_changed); layout.addWidget(self.confirm)
        self.import_button.clicked.connect(self._import)
        self.verify_button.clicked.connect(self._verify)
        self.accept_button.clicked.connect(self._accept)
        self.verification_output = QPlainTextEdit()
        self.verification_output.setReadOnly(True); self.verification_output.setMinimumHeight(100)
        layout.addWidget(self.verification_output)
        scroll.setWidget(content)
        self.tabs = QTabWidget()
        self.tabs.addTab(scroll, "Verification")
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        content = QWidget(); layout = QVBoxLayout(content)
        self.selectors = {}
        for key, title in (("preprocessing", "Fitted preprocessing (optional)"), ("feature_selection", "Feature selection (optional)"), ("model", "Classifier / regressor"), ("metric", "Metric (optional)")):
            label = QLabel(title); layout.addWidget(label)
            combo = QComboBox(); combo.setMinimumContentsLength(10)
            combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
            combo.setObjectName("verifiedWorkflow_" + key)
            self.selectors[key] = combo; layout.addWidget(combo)
        row = QVBoxLayout()
        self.reload_button = QPushButton("Reverify accepted registry")
        self.run_button = QPushButton("Run on current verified raw split")
        row.addWidget(self.reload_button); row.addWidget(self.run_button); layout.addLayout(row)
        self.reload_button.clicked.connect(self._reload)
        self.run_button.clicked.connect(self._run_workflow)
        persistence = QVBoxLayout()
        self.save_button = QPushButton("Save fitted workflow")
        self.load_button = QPushButton("Load and replay workflow")
        self.save_button.clicked.connect(self._save_workflow)
        self.load_button.clicked.connect(self._load_workflow)
        persistence.addWidget(self.save_button); persistence.addWidget(self.load_button)
        self.export_button = QPushButton("Export evaluation predictions CSV")
        self.export_button.clicked.connect(self._export_predictions)
        persistence.addWidget(self.export_button)
        layout.addLayout(persistence)
        self.summary = QLabel("Run an accepted workflow to display its held-out evaluation.")
        self.summary.setWordWrap(True); layout.addWidget(self.summary)
        from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
        from app.ui.mpl_theme import create_figure
        self.figure = create_figure(base_inches=(5, 3.4))
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.canvas.setMinimumHeight(260)
        self.canvas.setMinimumWidth(0)
        self.canvas.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Expanding)
        layout.addWidget(self.canvas)
        self.evaluation_snapshot = None
        self.status = QLabel("Ready. The example fixture is illustrative and has not been accepted.")
        self.status.setWordWrap(True)
        self.status.setTextFormat(Qt.PlainText)
        self.status.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        self.output = QPlainTextEdit(); self.output.setReadOnly(True); self.output.setMinimumHeight(130)
        layout.addWidget(self.output)
        scroll.setWidget(content); self.tabs.addTab(scroll, "Workflow")
        outer.addWidget(self.tabs); outer.addWidget(self.status)
        close = QPushButton("Close"); close.clicked.connect(self.close); outer.addWidget(close)
        fit_window_to_screen(self, 850, 740, min_width=360, min_height=240)
        self._invalidate()
        self._reload()

    def showEvent(self, event):
        super().showEvent(event)
        fit_window_to_screen(self, 850, 740, min_width=360, min_height=240)
        handle = self.windowHandle()
        if handle is not None and not getattr(self, "_screen_signal_connected", False):
            handle.screenChanged.connect(self._screen_changed)
            self._screen_signal_connected = True

    def _screen_changed(self, screen):
        fit_window_to_screen(self, 850, 740, min_width=360, min_height=240, screen=screen)

    def _invalidate(self):
        self.report = None; self._verified_text = None
        if hasattr(self, "verification_output"): self.verification_output.clear()
        self.confirm.setChecked(False); self.accept_button.setEnabled(False)

    def _approval_changed(self):
        self.accept_button.setEnabled(bool(self.report and self.report.passed and self.confirm.isChecked() and not self.job))

    def _busy(self, value):
        for widget in (self.editor, self.import_button, self.verify_button, self.reload_button, self.run_button, self.save_button, self.load_button, self.export_button, self.confirm): widget.setEnabled(not value)
        self.accept_button.setEnabled(False)
        for widget in self.selectors.values(): widget.setEnabled(not value)

    def _start(self, callback, finished):
        if self.job: return
        self._busy(True); self.status.setText("Working…")
        self.job = _Job(callback, self)
        self.job.done.connect(finished)
        self.job.failed.connect(self._error)
        self.job.finished.connect(self._finished)
        self.job.start()

    def _finished(self):
        job = self.job; self.job = None
        self._busy(False); self._approval_changed()
        if job: job.deleteLater()

    def _error(self, message):
        text = str(message)
        self.status.setText(text[:400] + ("…" if len(text) > 400 else ""))
        self.status.setToolTip(text[:4000])
        if len(text) > 400: self.output.setPlainText(text[:32000])

    def _import(self):
        path, _ = QFileDialog.getOpenFileName(self, "Candidate fixture", "", "JSON (*.json)")
        if path:
            try: self.editor.setPlainText(Path(path).read_text(encoding="utf-8"))
            except Exception as exc: self._error(str(exc))

    def _verify(self):
        try:
            text = self.editor.toPlainText()
            candidate = Candidate(**json.loads(text))
        except Exception as exc:
            self._error(str(exc)); return
        self._invalidate()
        def completed(report):
            self.report = report; self._verified_text = text
            self.verification_output.setPlainText(json.dumps([dict(name=c.name, passed=c.passed, detail=c.detail) for c in report.checks], indent=2, ensure_ascii=False))
            self.status.setText("Verification passed; explicit approval required." if report.passed else "Verification failed; acceptance disabled.")
        self._start(lambda: self.service.verify(candidate), completed)

    def _accept(self):
        if not self.report or not self.report.passed or not self.confirm.isChecked() or self.editor.toPlainText() != self._verified_text: return
        report = self.report
        def completed(candidate_id):
            self.status.setText("Accepted: " + candidate_id + ". Reverify registry to select it.")
            self._invalidate()
        self._start(lambda: self.service.accept(report, report.candidate.python_source, user_confirmed=True), completed)

    def _reload(self):
        def load():
            self.service.clear_verification_cache()
            return [(identifier, self.service.reload(identifier)) for identifier in self.service.list_accepted()]
        def completed(records):
            for key, combo in self.selectors.items():
                combo.clear(); combo.addItem("Select model" if key == "model" else "None", None)
                kinds = {"stateful_preprocessing"} if key == "preprocessing" else {"classification", "regression"} if key == "model" else {key}
                for identifier, candidate in records:
                    if candidate.kind in kinds: combo.addItem(candidate.name + " [" + candidate.kind + "]", identifier)
            self.status.setText(f"Registry reverified: {len(records)} accepted candidates.")
        self._start(load, completed)

    @staticmethod
    def _check_row_alignment(model, ids):
        for position, suffix in enumerate(("train", "test")):
            keys = ids[position]
            X, y = getattr(model, "X_" + suffix), getattr(model, "y_" + suffix)
            if keys is None or len(keys) != len(X) or len(keys) != len(y):
                raise ValueError("Current split row provenance is missing or misaligned.")
            if hasattr(X, "index") and list(X.index) != keys:
                raise ValueError("Current split row provenance is misaligned; recreate the verified raw split.")
            if hasattr(y, "index") and list(y.index) != keys:
                raise ValueError("Current split target provenance is misaligned; recreate the verified raw split.")

    def _run_workflow(self):
        try:
            model = self.data_model
            if model is None or not model.has_verified_split(): raise ValueError("Create a verified train/test split first.")
            if model.partitioned_input_representation != "raw_spectrum": raise ValueError("Create a fresh raw split; prepared matrices cannot be silently processed again.")
            selection = {key: combo.currentData() for key, combo in self.selectors.items()}
            if not selection['model']: raise ValueError("Select an accepted classifier or regressor.")
            arrays = [np.asarray(getattr(model, key)).copy() for key in ('X_train', 'y_train', 'X_test', 'y_test')]
            partition = model.get_partitioned_data()
            ids = [list(partition[key]) if partition.get(key) is not None else None for key in ("train_row_keys", "test_row_keys")]
            self._check_row_alignment(model, ids)
            axes = [list(getattr(model, key).columns) if hasattr(getattr(model, key), "columns") else None for key in ("X_train", "X_test")]
        except Exception as exc:
            self._error(str(exc)); return
        def run():
            from app.services.verified_workflow_service import VerifiedWorkflowService
            result = VerifiedWorkflowService(self.service).run(selection, *arrays, train_ids=ids[0], test_ids=ids[1], axis=axes[0], test_axis=axes[1])
            result["model_kind"] = self.service.reload(selection["model"]).kind
            return result
        def completed(result):
            self.last_result = result
            self.evaluation_snapshot = {"truth": arrays[3].tolist(), "predictions": list(result["predictions"]), "row_ids": list(result["test_ids"])}
            self._show_evaluation(result, arrays[3])
            self.output.setPlainText(json.dumps(result, indent=2, ensure_ascii=False, default=lambda obj: obj.tolist() if hasattr(obj, 'tolist') else str(obj)))
            self.status.setText("Workflow completed using training-fitted state. Results are shown below.")
        self._start(run, completed)

    def _save_workflow(self):
        if not hasattr(self, "last_result"):
            self._error("Run a fitted workflow before saving."); return
        path, _ = QFileDialog.getSaveFileName(self, "Save fitted workflow", "", "JSON (*.json)")
        if not path: return
        result = self.last_result
        def save():
            from app.services.verified_workflow_service import VerifiedWorkflowService
            VerifiedWorkflowService(self.service).save(result, path)
            return path
        self._start(save, lambda value: self.status.setText("Saved fitted workflow: " + value))

    def _load_workflow(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load fitted workflow", "", "JSON (*.json)")
        if not path: return
        model = self.data_model
        if model is None or not model.has_verified_split() or model.partitioned_input_representation != "raw_spectrum":
            self._error("Create a verified raw split before replaying saved state."); return
        X = np.asarray(model.X_test).copy()
        test_axis = list(model.X_test.columns) if hasattr(model.X_test, "columns") else None
        partition = model.get_partitioned_data()
        test_ids = list(partition["test_row_keys"]) if partition.get("test_row_keys") is not None else None
        try:
            self._check_row_alignment(model, [list(partition["train_row_keys"]), test_ids])
        except Exception as exc:
            self._error(str(exc)); return
        def replay():
            from app.services.verified_workflow_service import VerifiedWorkflowService
            service = VerifiedWorkflowService(self.service)
            result = service.load(path)
            if test_ids is not None and set(test_ids).intersection(result.get("training_ids", [])):
                raise ValueError("Current test row IDs overlap saved training rows; replay refused.")
            return result, service.predict(result, X, axis=test_axis)
        def completed(value):
            self.last_result, prediction = value
            self.evaluation_snapshot = None
            self.figure.clear(); self.canvas.draw_idle()
            self.summary.setText("Inference-only replay; no fresh held-out metrics are computed.")
            self.output.setPlainText(json.dumps({"replayed_predictions": prediction}, indent=2, default=lambda obj: obj.tolist() if hasattr(obj, 'tolist') else str(obj)))
            self.status.setText("Inference-only replay on current test input; this is not a fresh independent evaluation.")
        self._start(replay, completed)

    def _show_evaluation(self, result, truth):
        from app.ui.mpl_theme import apply_axes_style
        prediction = np.asarray(result["predictions"])
        kind = result["model_kind"]
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        apply_axes_style(ax)
        if kind == "regression":
            truth = np.asarray(truth, dtype=float)
            ax.scatter(truth, prediction, s=22, alpha=.8, color="#2878B5")
            low, high = float(min(truth.min(), prediction.min())), float(max(truth.max(), prediction.max()))
            if low == high: low, high = low - .5, high + .5
            ax.plot([low,high], [low,high], color="#666666", linestyle="--", linewidth=1)
            ax.set_xlabel("Observed target"); ax.set_ylabel("Predicted target")
        else:
            from sklearn.metrics import confusion_matrix
            labels = np.unique(np.concatenate([np.asarray(truth), prediction]))
            matrix = confusion_matrix(truth, prediction, labels=labels)
            ax.imshow(matrix, cmap="Blues", aspect="auto", vmin=0, vmax=max(1, int(matrix.max())))
            positions = np.arange(len(labels))
            ax.set_xticks(positions, labels=[str(value) for value in labels], rotation=45, ha="right")
            ax.set_yticks(positions, labels=[str(value) for value in labels])
            if len(labels) <= 15:
                for row in positions:
                    for column in positions:
                        ax.text(column,row,str(matrix[row,column]),ha="center",va="center",color="white" if matrix[row,column] > matrix.max()/2 else "black")
            ax.grid(False)
            ax.set_xlabel("Predicted class"); ax.set_ylabel("Observed class")
        ax.set_title(f"Held-out evaluation: n = {len(prediction)}")
        self.figure.tight_layout(pad=1.4); self.canvas.draw_idle()
        metrics = "; ".join(f"{key}: {value:.6g}" if isinstance(value, (int,float)) else f"{key}: {value}" for key,value in result["metrics"].items())
        self.summary.setText(f"Held-out rows: {len(prediction)}. {metrics}")

    def _export_predictions(self):
        if self.evaluation_snapshot is None:
            self._error("Run a fresh evaluation before exporting prediction/target pairs."); return
        path, _ = QFileDialog.getSaveFileName(self, "Export evaluation predictions", "", "CSV (*.csv)")
        if not path: return
        snapshot = dict(self.evaluation_snapshot)
        def save():
            import csv
            with open(path, "w", encoding="utf-8-sig", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(["internal_row_key", "observed", "predicted"])
                writer.writerows(zip(snapshot["row_ids"], snapshot["truth"], snapshot["predictions"]))
            return path
        self._start(save, lambda value: self.status.setText("Evaluation predictions exported: " + value))

    def reject(self):
        if self.job and self.job.isRunning():
            self.status.setText("A bounded task is running. Close after it finishes.")
            return
        super().reject()

    def closeEvent(self, event):
        if self.job and self.job.isRunning():
            self.status.setText("A bounded task is running. Close after it finishes."); event.ignore()
        else: event.accept()
