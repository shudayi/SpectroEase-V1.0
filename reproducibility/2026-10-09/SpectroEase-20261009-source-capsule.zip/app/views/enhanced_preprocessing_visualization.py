# -*- coding: utf-8 -*-
"""
Enhanced Preprocessing Visualization with Y-axis locking and complete legends
Addresses Editor Comment 3 about preprocessing visualization issues
"""
from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _

import logging
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QCheckBox, QLabel, QDialogButtonBox
from PyQt5.QtCore import Qt
from app.utils.responsive import fit_window_to_screen
from app.utils.exceptions import user_facing_error

# Set up logging
logger = logging.getLogger(__name__)

class EnhancedPreprocessingVisualization(QDialog):
    """Enhanced preprocessing visualization dialog with locked Y-axis and complete legends."""
    
    def __init__(self, data_model, wavelengths, labels, methods_applied, parent=None):
        super().__init__(parent)
        self.data_model = data_model
        self.wavelengths = wavelengths
        self.labels = labels
        self.methods_applied = methods_applied
        
        self.setWindowTitle(_("enhanced_preprocessing_visualization.title"))
        fit_window_to_screen(self, ui.scaled_px(1000), ui.scaled_px(700), min_width=ui.scaled_px(720), min_height=ui.scaled_px(520))
        
        self.init_ui()
        self.y_axis_locked = True  # Default to locked Y-axis
        self.original_y_limits = None
        
        self.plot_preprocessing_comparison()
        
    def init_ui(self):
        """Initialize the visualization UI"""
        layout = QVBoxLayout()
        
        # Control panel
        control_layout = QHBoxLayout()
        
        # Y-axis lock checkbox
        self.y_lock_checkbox = QCheckBox(_("enhanced_preprocessing_visualization.y_lock_checkbox"))
        self.y_lock_checkbox.setChecked(True)
        self.y_lock_checkbox.toggled.connect(self.toggle_y_axis_lock)
        control_layout.addWidget(self.y_lock_checkbox)
        
        # Processing queue display
        self.queue_label = QLabel(_("enhanced_preprocessing_visualization.queue_label"))
        control_layout.addWidget(self.queue_label)

        # Scaling indicator
        self.scaling_indicator = QLabel("")
        self.scaling_indicator.setObjectName("statusChip")
        self.scaling_indicator.setProperty("status", "warning")
        control_layout.addWidget(self.scaling_indicator)

        control_layout.addStretch()
        layout.addLayout(control_layout)

        # Matplotlib figure
        self.figure = create_figure(tok.MPL_FIGSIZE_XL, tok.MPL_BASE_DPI)
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)

        # Dialog buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok)
        button_box.accepted.connect(self.accept)
        ok_btn = button_box.button(QDialogButtonBox.Ok)
        if ok_btn is not None:
            ok_btn.setProperty("role", "primary")
        layout.addWidget(button_box)
        
        self.setLayout(layout)
        
    def toggle_y_axis_lock(self, checked):
        """Toggle Y-axis locking"""
        self.y_axis_locked = checked
        if checked:
            self.y_lock_checkbox.setText(_("enhanced_preprocessing_visualization.y_lock_checkbox_y_lock_checkbox_text"))
        else:
            self.y_lock_checkbox.setText(_("enhanced_preprocessing_visualization.y_lock_checkbox"))
    
    def update_processing_queue(self, methods_list):
        """Update the processing queue display"""
        if methods_list:
            queue_text = " ->".join(methods_list)
            self.queue_label.setText(_("enhanced_preprocessing_visualization.processing_queue_prefix") + queue_text)
        else:
            self.queue_label.setText(_("enhanced_preprocessing_visualization.queue_label"))
    
    def update_scaling_indicator(self, has_scaling_normalization):
        """Update scaling/normalization indicator"""
        if has_scaling_normalization:
            self.scaling_indicator.setText(_("enhanced_preprocessing_visualization.scaling_indicator_scaling_indicator_text"))
        else:
            self.scaling_indicator.setText("")
    
    def plot_preprocessing_comparison(self):
        """Plot preprocessing comparison with enhanced features."""
        self.figure.clear()

        if self.data_model.X is None:
            ax = self.figure.add_subplot(111)
            ax.text(0.5, 0.5, _('enhanced_preprocessing_visualization.error_original_data'),
                    horizontalalignment='center', verticalalignment='center',
                    transform=ax.transAxes, color='red')
            self.canvas.draw()
            return
        
        original_spectra = self.data_model.X.values
        
        if self.data_model.X_processed is not None:
            processed_spectra = self.data_model.X_processed.values
        else:
            processed_spectra = original_spectra  # Use original as placeholder
            logger.info("X_processed is not available. Using original data (X) as a placeholder for visualization.")
            print("Log: X_processed is not available. Using original data (X) as a placeholder for visualization.")

        # Use a unified data alignment tool with import protection
        try:
            from app.utils.data_alignment import DataDimensionAligner
            
            aligned_wavelengths, aligned_original, aligned_processed = DataDimensionAligner.align_spectral_data(
                self.wavelengths, original_spectra, processed_spectra
            )
            wavelengths = aligned_wavelengths
            original_spectra = aligned_original
            processed_spectra = aligned_processed
            
        except ImportError:
            ax = self.figure.add_subplot(111)
            error_text = _('enhanced_preprocessing_visualization.error_import_aligner')
            ax.text(0.5, 0.5, error_text, horizontalalignment='center', verticalalignment='center',
                    transform=ax.transAxes, color='red', wrap=True)
            self.canvas.draw()
            return
        except Exception as e:
            ax = self.figure.add_subplot(111)
            error_text = _('enhanced_preprocessing_visualization.error_alignment').format(error=user_facing_error(e))
            ax.text(0.5, 0.5, error_text, horizontalalignment='center', verticalalignment='center',
                    transform=ax.transAxes, color='red', wrap=True)
            self.canvas.draw()
            return
        
        # Update processing queue display
        if self.methods_applied:
            self.update_processing_queue(self.methods_applied)
            scaling_methods = ['normalization', 'standardization', 'min-max', 'vector', 'area', 'maximum', 'z-score', 'robust']
            has_scaling = any(any(sm in method.lower() for sm in scaling_methods) for method in self.methods_applied)
            self.update_scaling_indicator(has_scaling)
        
        ax = self.figure.add_subplot(111)
        
        # Use get_cmap for type safety
        colors = plt.get_cmap("tab10")(np.linspace(0, 1, 10))
        
        # Plot both original and processed spectra for comparison
        self._plot_spectra_set(ax, wavelengths, original_spectra, self.labels, colors, _("enhanced_preprocessing_visualization.original_prefix"), 'solid')
        self._plot_spectra_set(ax, wavelengths, processed_spectra, self.labels, colors, _("enhanced_preprocessing_visualization.processed_prefix"), 'dashed')
        
        # Add mean comparison
        original_mean = np.mean(original_spectra, axis=0)
        processed_mean = np.mean(processed_spectra, axis=0)
        
        ax.plot(wavelengths, original_mean, color='blue', linewidth=3,
               label=_('enhanced_preprocessing_visualization.original_mean_label'), alpha=0.8)
        ax.plot(wavelengths, processed_mean, color='red', linewidth=3,
               label=_('enhanced_preprocessing_visualization.processed_mean_label'), alpha=0.8)
        
        # Add standard deviation bands
        original_std = np.std(original_spectra, axis=0)
        processed_std = np.std(processed_spectra, axis=0)
        
        ax.fill_between(wavelengths,
                      original_mean - original_std,
                      original_mean + original_std,
                      color='blue', alpha=0.2, label=_('enhanced_preprocessing_visualization.original_sd_label'))
        ax.fill_between(wavelengths,
                      processed_mean - processed_std,
                      processed_mean + processed_std,
                      color='red', alpha=0.2, label=_('enhanced_preprocessing_visualization.processed_sd_label'))
        
        ax.set_xlabel(_('enhanced_preprocessing_visualization.wavelength_nm_label'), fontsize=12, fontweight='medium')
        ax.set_ylabel(_('enhanced_preprocessing_visualization.absorbance_label'), fontsize=12, fontweight='medium')
        ax.set_title(_('enhanced_preprocessing_visualization.preprocessing_comparison_title'), fontsize=14, fontweight='bold')
        
        if self.y_axis_locked:
            if self.original_y_limits is None and original_spectra is not None and original_spectra.size > 0:
                y_min, y_max = np.min(original_spectra), np.max(original_spectra)
                y_padding = (y_max - y_min) * 0.05
                self.original_y_limits = (y_min - y_padding, y_max + y_padding)
            
            if self.original_y_limits:
                ax.set_ylim(self.original_y_limits)
        else:
            self.original_y_limits = None
        
        legend_elements = ax.get_legend_handles_labels()
        if legend_elements[0]:
            legend = ax.legend(loc='best', frameon=True, framealpha=0.9, 
                             fontsize='small', title='Legend')
            legend.get_title().set_fontweight('bold')
            
            ax.text(0.02, 0.98, _('enhanced_preprocessing_visualization.solid_dashed_note'),
                   transform=ax.transAxes, fontsize=9, verticalalignment='top',
                   bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))
        
        ax.grid(True, linestyle='-', linewidth=0.5, alpha=0.3)
        for spine in ax.spines.values():
            spine.set_linewidth(1.2)
        
        self.figure.tight_layout()
        self.canvas.draw()
    
    def _plot_spectra_set(self, ax, wavelengths, spectra, labels, colors, prefix, linestyle):
        """Helper to plot a set of spectra with consistent styling."""
        if spectra is None or spectra.size == 0:
            return
        max_spectra_to_show = min(5, spectra.shape[0])
        
        for i in range(max_spectra_to_show):
            color = colors[i % len(colors)]
            
            if labels is not None and i < len(labels):
                label = f"{prefix} - {labels[i]}"
            else:
                label = f"{prefix} - " + _('enhanced_preprocessing_visualization.spectrum_label').format(index=i+1)
            
            ax.plot(wavelengths, spectra[i], color=color, linewidth=1.5, 
                   linestyle=linestyle, label=label, alpha=0.7)
    
    def reset_y_axis_limits(self):
        """Reset stored Y-axis limits."""
        self.original_y_limits = None
