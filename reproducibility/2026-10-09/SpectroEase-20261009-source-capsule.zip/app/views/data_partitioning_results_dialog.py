# -*- coding: utf-8 -*-
"""
Data Partitioning Results Dialog

Displays the outcome of a data partitioning operation (train/test split, k-fold,
etc.) in a dedicated view-layer dialog.  The controller is responsible only for
collecting the plain partitioning result and showing this dialog.
"""

from typing import Dict, Any, Optional
import os

import numpy as np
import pandas as pd
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QTabWidget, QWidget, QGroupBox,
    QFileDialog, QMessageBox
)

from app.ui import design_tokens as tok
from app.utils import ui_scaling as ui
from app.utils.responsive import fit_window_to_screen


class DataPartitioningResultsDialog(QDialog):
    """Dialog for displaying data partitioning results and saving subsets."""

    def __init__(
        self,
        partitioned_data: Dict[str, Any],
        method: str,
        task_type: str,
        parent=None
    ):
        super().__init__(parent)
        self.partitioned_data = partitioned_data
        self.method = method
        self.task_type = task_type

        self.X_train = partitioned_data.get("X_train")
        self.X_test = partitioned_data.get("X_test")
        self.y_train = partitioned_data.get("y_train")
        self.y_test = partitioned_data.get("y_test")
        self.label_mapping = partitioned_data.get("label_mapping")

        self._y_train_display = self._prepare_display_labels(self.y_train)
        self._y_test_display = self._prepare_display_labels(self.y_test)

        self.init_ui()

    def init_ui(self):
        """Build the dialog UI."""
        self.setWindowTitle(f"Data Partitioning Results - {self.method}")
        self.setModal(True)

        fit_window_to_screen(
            self,
            ui.scaled_px(tok.DIALOG_SIZE_XL[0]),
            ui.scaled_px(tok.DIALOG_SIZE_XL[1]),
            min_width=ui.scaled_px(tok.DIALOG_MIN_WIDTH),
            min_height=ui.scaled_px(tok.DIALOG_MIN_HEIGHT)
        )

        layout = QVBoxLayout(self)

        # Title
        title_label = QLabel("Data Partitioning Results")
        title_label.setObjectName("pageTitle")
        layout.addWidget(title_label)

        # Statistics
        layout.addWidget(self._create_stats_group())

        # Distribution
        distribution_group = self._create_distribution_group()
        if distribution_group is not None:
            layout.addWidget(distribution_group)

        # Preview tabs
        layout.addWidget(self._create_preview_tabs())

        # Buttons
        layout.addLayout(self._create_button_layout())

    def _create_stats_group(self) -> QGroupBox:
        """Create the partitioning statistics group."""
        stats_group = QGroupBox("Partitioning Statistics")
        stats_layout = QVBoxLayout(stats_group)

        total_samples = self.X_train.shape[0] + self.X_test.shape[0]
        train_ratio = self.X_train.shape[0] / total_samples if total_samples else 0.0
        test_ratio = self.X_test.shape[0] / total_samples if total_samples else 0.0

        stats_text = (
            f"Method: {self.method}\n"
            f"Training set: {self.X_train.shape[0]} samples, {self.X_train.shape[1]} features\n"
            f"Test set: {self.X_test.shape[0]} samples, {self.X_test.shape[1]} features\n"
            f"Training ratio: {train_ratio:.1%}\n"
            f"Test ratio: {test_ratio:.1%}\n"
            f"Total samples: {total_samples}\n"
            f"Total features: {self.X_train.shape[1]}"
        )

        stats_label = QLabel(stats_text)
        stats_label.setObjectName("statusCard")
        stats_label.setWordWrap(True)
        stats_layout.addWidget(stats_label)
        return stats_group

    def _prepare_display_labels(self, y_data):
        """Map numeric classification labels back to original string labels."""
        if y_data is None or self.task_type != "classification" or not self.label_mapping:
            return y_data

        index_to_label = self.label_mapping.get("index_to_label", {})
        if not index_to_label:
            return y_data

        try:
            if isinstance(y_data, pd.Series):
                return y_data.map(lambda x: index_to_label.get(int(x), str(x)))
            return np.array([index_to_label.get(int(label), str(label)) for label in y_data])
        except (ValueError, TypeError):
            return y_data

    def _create_distribution_group(self) -> Optional[QGroupBox]:
        """Create regression or classification distribution display."""
        if self.y_train is None or self.y_test is None:
            return None

        if self.task_type == "regression":
            return self._create_regression_stats_group()
        return self._create_classification_label_group()

    def _create_regression_stats_group(self) -> QGroupBox:
        """Create regression target distribution table."""
        dist_group = QGroupBox("Target Value Distribution (Regression)")
        dist_layout = QVBoxLayout(dist_group)

        stats_table = QTableWidget()
        stats_table.setRowCount(4)
        stats_table.setColumnCount(2)
        stats_table.setHorizontalHeaderLabels(["Training Set", "Test Set"])
        stats_table.setVerticalHeaderLabels(["Mean", "Std Dev", "Min", "Max"])

        try:
            train_stats = pd.Series(self.y_train).describe()
            test_stats = pd.Series(self.y_test).describe()

            stats_data = [
                ("Mean", train_stats.get("mean", float("nan")), test_stats.get("mean", float("nan"))),
                ("Std Dev", train_stats.get("std", float("nan")), test_stats.get("std", float("nan"))),
                ("Min", train_stats.get("min", float("nan")), test_stats.get("min", float("nan"))),
                ("Max", train_stats.get("max", float("nan")), test_stats.get("max", float("nan"))),
            ]

            for i, (stat_name, train_val, test_val) in enumerate(stats_data):
                stats_table.setVerticalHeaderItem(i, QTableWidgetItem(stat_name))
                train_item = QTableWidgetItem(f"{train_val:.4f}")
                train_item.setFlags(train_item.flags() & ~Qt.ItemIsEditable)
                stats_table.setItem(i, 0, train_item)
                test_item = QTableWidgetItem(f"{test_val:.4f}")
                test_item.setFlags(test_item.flags() & ~Qt.ItemIsEditable)
                stats_table.setItem(i, 1, test_item)
        except Exception as e:
            stats_table.setSpan(0, 0, 4, 2)
            error_item = QTableWidgetItem(f"Could not compute stats: {e}")
            error_item.setFlags(error_item.flags() & ~Qt.ItemIsEditable)
            stats_table.setItem(0, 0, error_item)

        stats_table.resizeColumnsToContents()
        dist_layout.addWidget(stats_table)
        return dist_group

    def _create_classification_label_group(self) -> QGroupBox:
        """Create classification label distribution table."""
        label_group = QGroupBox("Label Distribution (Classification)")
        label_layout = QVBoxLayout(label_group)

        y_train_disp = self._y_train_display
        y_test_disp = self._y_test_display

        if hasattr(y_train_disp, "value_counts"):
            train_counts = y_train_disp.value_counts()
            test_counts = y_test_disp.value_counts() if y_test_disp is not None else pd.Series(dtype=int)
        else:
            unique_train, counts_train = np.unique(y_train_disp, return_counts=True)
            train_counts = pd.Series(counts_train, index=unique_train)
            if y_test_disp is not None:
                unique_test, counts_test = np.unique(y_test_disp, return_counts=True)
                test_counts = pd.Series(counts_test, index=unique_test)
            else:
                test_counts = pd.Series(dtype=int)

        label_table = QTableWidget()
        all_labels = sorted(set(train_counts.index) | set(test_counts.index), key=str)
        label_table.setRowCount(len(all_labels))
        label_table.setColumnCount(4)
        label_table.setHorizontalHeaderLabels(["Label", "Total", "Training Set", "Test Set"])

        for i, label in enumerate(all_labels):
            train_count = int(train_counts.get(label, 0))
            test_count = int(test_counts.get(label, 0))
            total_count = train_count + test_count

            items = [
                QTableWidgetItem(str(label)),
                QTableWidgetItem(str(total_count)),
                QTableWidgetItem(str(train_count)),
                QTableWidgetItem(str(test_count)),
            ]
            for col, item in enumerate(items):
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                label_table.setItem(i, col, item)

        label_table.resizeColumnsToContents()
        label_layout.addWidget(label_table)
        return label_group

    def _create_preview_tabs(self) -> QTabWidget:
        """Create training/test preview tabs."""
        tab_widget = QTabWidget()
        max_features = min(20, self.X_train.shape[1])

        train_tab = QWidget()
        train_layout = QVBoxLayout(train_tab)
        train_layout.addWidget(
            self._create_preview_table(self.X_train, self._y_train_display, max_features)
        )
        tab_widget.addTab(train_tab, f"Training Set Preview ({self.X_train.shape[0]} samples)")

        test_tab = QWidget()
        test_layout = QVBoxLayout(test_tab)
        test_layout.addWidget(
            self._create_preview_table(self.X_test, self._y_test_display, max_features)
        )
        tab_widget.addTab(test_tab, f"Test Set Preview ({self.X_test.shape[0]} samples)")

        return tab_widget

    def _create_preview_table(self, X_data, y_data_disp, max_features: int) -> QTableWidget:
        """Create a read-only preview table for X/y data."""
        table = QTableWidget()
        n_rows = min(10, X_data.shape[0])
        table.setRowCount(n_rows)
        table.setColumnCount(max_features + (1 if y_data_disp is not None else 0))

        headers = [f"Feature{i + 1}" for i in range(max_features)]
        if y_data_disp is not None:
            headers.append("Label")
        table.setHorizontalHeaderLabels(headers)

        for i in range(n_rows):
            for j in range(max_features):
                value = X_data.iloc[i, j] if hasattr(X_data, "iloc") else X_data[i, j]
                item = QTableWidgetItem(f"{value:.4f}")
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                table.setItem(i, j, item)
            if y_data_disp is not None:
                y_value = y_data_disp.iloc[i] if hasattr(y_data_disp, "iloc") else y_data_disp[i]
                item = QTableWidgetItem(str(y_value))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                table.setItem(i, max_features, item)

        return table

    def _create_button_layout(self) -> QHBoxLayout:
        """Create the bottom button layout."""
        button_layout = QHBoxLayout()
        button_layout.setSpacing(ui.scaled_px(tok.SPACE_MD))

        save_train_btn = QPushButton("Save Training Set")
        save_train_btn.setProperty("role", "primary")
        save_train_btn.clicked.connect(
            lambda: self._save_partition_data(self.X_train, self.y_train, "Training Set")
        )
        button_layout.addWidget(save_train_btn)

        save_test_btn = QPushButton("Save Test Set")
        save_test_btn.setProperty("role", "success")
        save_test_btn.clicked.connect(
            lambda: self._save_partition_data(self.X_test, self.y_test, "Test Set")
        )
        button_layout.addWidget(save_test_btn)

        save_all_btn = QPushButton("Save All")
        save_all_btn.setProperty("role", "secondary")
        save_all_btn.clicked.connect(self._save_all_partition_data)
        button_layout.addWidget(save_all_btn)

        button_layout.addStretch()

        close_btn = QPushButton("Close")
        close_btn.setProperty("role", "quiet")
        close_btn.clicked.connect(self.accept)
        button_layout.addWidget(close_btn)

        return button_layout

    def _style_button(self, button: QPushButton, color: str, hover_color: str):
        """Deprecated inline styler kept for backward compatibility."""
        radius = ui.scaled_px(tok.SPACE_XS)
        padding_h = ui.scaled_px(tok.SPACE_MD)
        padding_v = ui.scaled_px(tok.SPACE_SM)
        button.setStyleSheet(
            f"QPushButton {{ background-color: {color}; color: white; border: none; "
            f"padding: {padding_v}px {padding_h}px; border-radius: {radius}px; font-weight: bold; }}"
            f"QPushButton:hover {{ background-color: {hover_color}; }}"
        )

    def _save_partition_data(self, X_data, y_data, data_type: str):
        """Save a single partition subset to a CSV/Excel file."""
        try:
            file_path, _ = QFileDialog.getSaveFileName(
                self,
                f"Save {data_type}",
                f"{data_type.lower().replace(' ', '_')}.csv",
                "CSV Files (*.csv);;Excel Files (*.xlsx);;All Files (*.*)"
            )

            if not file_path:
                return

            if hasattr(X_data, "copy"):
                data_to_save = X_data.copy()
            else:
                data_to_save = pd.DataFrame(X_data)

            if y_data is not None:
                label_col_name = y_data.name if hasattr(y_data, "name") and y_data.name else "target"
                if hasattr(data_to_save, "insert"):
                    data_to_save.insert(0, label_col_name, y_data)
                else:
                    data_to_save = pd.DataFrame(data_to_save)
                    data_to_save.insert(0, label_col_name, y_data)

            if file_path.endswith(".xlsx"):
                data_to_save.to_excel(file_path, index=False)
            else:
                data_to_save.to_csv(file_path, index=False)

            QMessageBox.information(self, "Save Successful", f"{data_type} saved to:\n{file_path}")

        except Exception as e:
            QMessageBox.critical(self, "Save Failed", f"Error saving {data_type}:\n{str(e)}")

    def _save_all_partition_data(self):
        """Save training/test sets and split info to a selected directory."""
        try:
            dir_path = QFileDialog.getExistingDirectory(self, "Select Save Folder")
            if not dir_path:
                return

            X_train = self.X_train
            X_test = self.X_test
            y_train = self.y_train
            y_test = self.y_test

            train_data = X_train.copy() if hasattr(X_train, "copy") else pd.DataFrame(X_train)
            if y_train is not None:
                train_data.insert(0, "target", y_train)
            train_path = os.path.join(dir_path, "train_data.csv")
            train_data.to_csv(train_path, index=False)

            test_data = X_test.copy() if hasattr(X_test, "copy") else pd.DataFrame(X_test)
            if y_test is not None:
                test_data.insert(0, "target", y_test)
            test_path = os.path.join(dir_path, "test_data.csv")
            test_data.to_csv(test_path, index=False)

            total_samples = X_train.shape[0] + X_test.shape[0]
            train_ratio = X_train.shape[0] / total_samples if total_samples else 0.0
            test_ratio = X_test.shape[0] / total_samples if total_samples else 0.0

            info_path = os.path.join(dir_path, "split_info.txt")
            with open(info_path, "w", encoding="utf-8") as f:
                f.write("Data Partitioning Information\n")
                f.write("=" * 50 + "\n")
                f.write(f"Training set: {X_train.shape[0]} samples, {X_train.shape[1]} features\n")
                f.write(f"Test set: {X_test.shape[0]} samples, {X_test.shape[1]} features\n")
                f.write(f"Training ratio: {train_ratio:.1%}\n")
                f.write(f"Test ratio: {test_ratio:.1%}\n")

            QMessageBox.information(
                self,
                "Save Successful",
                f"All data saved to:\n{dir_path}\n\nFiles:\n- train_data.csv\n- test_data.csv\n- split_info.txt"
            )

        except Exception as e:
            QMessageBox.critical(self, "Save Failed", f"Error saving data:\n{str(e)}")
