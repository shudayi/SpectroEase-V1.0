from app.ui import design_tokens as tok
from app.ui.mpl_theme import (
    create_figure, apply_light_theme, get_series_style,
    apply_axes_style, collect_plot_style_metadata,
)
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                           QLabel, QComboBox, QSpinBox, QDoubleSpinBox, QCheckBox,
                           QGroupBox, QSplitter, QFileDialog, QToolBar, QScrollArea, QFrame,
                           QSizePolicy, QDialog, QFormLayout, QDialogButtonBox,
                           QMessageBox, QBoxLayout, QStyle)
from PyQt5.QtCore import Qt, QSize, QTimer
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.widgets import SpanSelector
from plugins.preprocessing.spectrum_visualizer import SpectrumVisualizer
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
import matplotlib
import pandas as pd
from sklearn.metrics import confusion_matrix
from app.utils.unified_data_processor import UnifiedDataProcessor
from app.utils.spectral_units import normalize_unit, axis_label, convert_array
import logging
from pathlib import Path
matplotlib.use('Qt5Agg')

class VisualizationWidget(QWidget):
    """Spectral data visualization enhancement component"""

    def __init__(self, parent=None, x_unit='nm'):
        super().__init__(parent)
        self.figure = create_figure(tok.MPL_FIGSIZE_MD, tok.MPL_BASE_DPI)
        self.canvas = FigureCanvas(self.figure)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.ax = self.figure.add_subplot(111)
        self.x_unit = normalize_unit(x_unit) if x_unit else 'nm'
        self.spectral_y_label = _("visualization_widget.spectral_value_label")
        self._plot_source = None
        self._plot_layout_timer = QTimer(self)
        self._plot_layout_timer.setSingleShot(True)
        self._plot_layout_timer.setInterval(80)
        self._plot_layout_timer.timeout.connect(self._relayout_chart_for_viewport)
        self.canvas.mpl_connect("resize_event", self._schedule_canvas_layout)
        self.init_ui()
        self.current_theme = "default"
        self.current_plot_type = "Spectrum Plot"
        self.current_chart_kind = "Spectrum Plot"
        self._current_plot_metadata = {}
        self.unified_processor = UnifiedDataProcessor()

        # Initialize visualization control service (Editor Comment 3)
        from app.services.visualization_control_service import visualization_control
        self.viz_control = visualization_control

        # Connect to visualization control signals
        self.viz_control.y_axis_lock_changed.connect(self.on_y_axis_lock_changed)

    def _schedule_canvas_layout(self, event=None):
        """Reflow after the actual canvas viewport changes size."""
        self._plot_layout_timer.start()

    def set_spectral_y_label(self, label):
        """Set a source-defined measurement label without inferring absorbance."""
        label = str(label).strip()
        if not label:
            raise ValueError("Spectral measurement label cannot be empty")
        self.spectral_y_label = label
        return self.refresh_current_plot()

    def set_x_unit(self, unit):
        """Update the displayed X unit and redraw from canonical nm inputs."""
        new_unit = normalize_unit(unit)
        if new_unit == self.x_unit:
            return False
        self.x_unit = new_unit
        return self.refresh_current_plot()

    def _convert_wavelengths(self, wavelengths):
        """Convert canonical nanometer coordinates to the selected X unit."""
        if wavelengths is None or len(wavelengths) == 0:
            return wavelengths
        try:
            return convert_array(np.asarray(wavelengths, dtype=float), 'nm', self.x_unit)
        except (ValueError, TypeError):
            return wavelengths

    def _display_ordered_spectra(self, wavelengths_nm, *feature_arrays):
        """Convert nm coordinates and apply the same stable order to feature arrays."""
        display_coordinates = np.asarray(self._convert_wavelengths(wavelengths_nm), dtype=float)
        order = np.argsort(display_coordinates, kind="stable")
        ordered_arrays = [np.asarray(values)[..., order] for values in feature_arrays]
        return display_coordinates[order], ordered_arrays

    def refresh_current_plot(self):
        """Re-render the last spectral view from its saved canonical inputs."""
        source = self._plot_source
        if not source:
            return False

        kind = source["kind"]
        if kind == "spectrum":
            self.plot_spectra(
                source["wavelengths_nm"], source["spectra"],
                title=source["title"], labels=source["labels"],
                original_spectra=source["original_spectra"],
                comparison_mode=source["comparison_mode"],
            )
        elif kind == "comparison":
            self.plot_spectra_comparison(
                source["wavelengths_nm"], source["original_spectra"],
                source["processed_spectra"], title=source["title"],
            )
        elif kind == "preprocessing_preview":
            self.update_preprocessing_preview(
                data_model=source["data_model"],
                wavelengths=source["wavelengths_nm"],
                preview_mode=source["preview_mode"],
                methods_applied=source["methods_applied"],
            )
        else:
            return False
        return True

    def _x_axis_label(self):
        """Return the human-readable X-axis label for the current unit."""
        return axis_label(self.x_unit)

    def toggle_y_axis_lock(self):
        """Toggle Y-axis lock state (Editor Comment 3)"""
        self.viz_control.toggle_y_axis_lock()
    
    def on_y_axis_lock_changed(self, locked):
        """Handle Y-axis lock state change"""
        self.y_axis_lock_btn.setChecked(locked)
        self.y_axis_lock_btn.setText(_("visualization_widget.y_axis_lock_btn") if locked else _("visualization_widget.y_axis_lock_btn_auto"))
        
        # Refresh current plot if available
        if self._plot_source is not None:
            self.refresh_current_plot()
        
    def init_ui(self):
        """Initialize the UI"""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(*(ui.scaled_px(tok.SPACE_MD) for _ in range(4)))
        main_layout.setSpacing(ui.scaled_px(tok.SPACE_SM))

        header = QHBoxLayout()
        title_label = QLabel(_("visualization_widget.spectrum_data_title"))
        title_label.setObjectName("pageTitle")
        header.addWidget(title_label)
        header.addStretch()
        self.chart_state_label = QLabel(_("visualization_widget.no_valid_spectral_data"))
        self.chart_state_label.setObjectName("statusChip")
        header.addWidget(self.chart_state_label)
        main_layout.addLayout(header)

        controls_row = QBoxLayout(QBoxLayout.LeftToRight)
        controls_row.setSpacing(ui.scaled_px(tok.SPACE_SM))
        self._controls_row = controls_row
        self._controls_compact_threshold = 900
        primary_controls = QHBoxLayout()
        primary_controls.setSpacing(ui.scaled_px(tok.SPACE_SM))
        self.y_axis_lock_btn = QPushButton(_("visualization_widget.y_axis_lock_btn"))
        self.y_axis_lock_btn.setObjectName("chartAxisLock")
        self.y_axis_lock_btn.setProperty("role", "secondary")
        self.y_axis_lock_btn.setCheckable(True)
        self.y_axis_lock_btn.setChecked(True)
        self.y_axis_lock_btn.setToolTip(_("visualization_widget.y_axis_lock_btn_y_axis_lock_btn_tooltip"))
        self.y_axis_lock_btn.clicked.connect(self.toggle_y_axis_lock)
        primary_controls.addWidget(self.y_axis_lock_btn)

        plot_type_label = QLabel(_("visualization_widget.plot_type_label"))
        plot_type_label.setObjectName("secondaryText")
        primary_controls.addWidget(plot_type_label)
        self.plot_type_combo = QComboBox()
        self.plot_type_combo.addItems(["Spectrum Plot", "Line Plot", "Scatter Plot", "Heatmap", "3D Plot", "Bar Chart"])
        self.plot_type_combo.setCurrentText("Spectrum Plot")
        ui.set_min_width(self.plot_type_combo, tok.COMBOBOX_MIN_WIDTH_MD)
        self.plot_type_combo.currentTextChanged.connect(self.update_plot_type)
        primary_controls.addWidget(self.plot_type_combo)

        theme_controls = QHBoxLayout()
        theme_controls.setSpacing(ui.scaled_px(tok.SPACE_SM))
        theme_label = QLabel(_("visualization_widget.theme_label"))
        theme_label.setObjectName("secondaryText")
        theme_controls.addWidget(theme_label)
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["default", "ggplot", "seaborn-v0_8", "bmh", "grayscale"])
        ui.set_min_width(self.theme_combo, tok.COMBOBOX_MIN_WIDTH)
        self.theme_combo.currentTextChanged.connect(self.update_theme)
        theme_controls.addWidget(self.theme_combo)
        controls_row.addLayout(primary_controls)
        controls_row.addLayout(theme_controls)
        controls_row.addStretch(1)
        main_layout.addLayout(controls_row)

        self.nav_toolbar = NavigationToolbar(self.canvas, self)
        self.nav_toolbar.setObjectName("chartToolbar")
        self.nav_toolbar.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.nav_toolbar.setToolButtonStyle(Qt.ToolButtonIconOnly)
        # Keep the navigation toolbar icons at >= 20 px even on compact
        # screens where the global scale factor would otherwise compress them.
        nav_icon = max(20, ui.scaled_px(tok.ICON_SIZE_MD))
        self.nav_toolbar.setIconSize(QSize(nav_icon, nav_icon))
        # Keep the native toolbar's quick-save action from bypassing the
        # physical-size/export profile below.
        for action in self.nav_toolbar.actions():
            if "save" in action.text().lower():
                action.setVisible(False)
        toolbar_row = QHBoxLayout()
        toolbar_row.setSpacing(ui.scaled_px(tok.SPACE_SM))
        toolbar_row.addWidget(self.nav_toolbar, stretch=1)
        self.export_figure_button = QPushButton(_("visualization_widget.export_figure"))
        self.export_figure_button.setObjectName("exportFigureButton")
        self.export_figure_button.setIcon(self.style().standardIcon(QStyle.SP_DialogSaveButton))
        self.export_figure_button.setToolTip(_("visualization_widget.export_figure_tooltip"))
        self.export_figure_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.export_figure_button.clicked.connect(self.show_export_dialog)
        toolbar_row.addWidget(self.export_figure_button)
        main_layout.addLayout(toolbar_row)

        plot_area = QFrame()
        plot_area.setObjectName("surfaceCard")
        plot_layout = QVBoxLayout(plot_area)
        plot_layout.setContentsMargins(*(ui.scaled_px(tok.SPACE_LG) for _ in range(4)))
        plot_layout.addWidget(self.canvas)
        main_layout.addWidget(plot_area, stretch=1)
        self.setup_plot_style()
        self._update_controls_layout(self.width())

    def _update_controls_layout(self, width):
        """Wrap chart controls when the panel is too narrow for one row."""
        target = (
            QBoxLayout.TopToBottom
            if width < self._controls_compact_threshold
            else QBoxLayout.LeftToRight
        )
        if self._controls_row.direction() != target:
            self._controls_row.setDirection(target)
            self._controls_row.invalidate()
            self.updateGeometry()
        
    def setup_plot_style(self):
        # Theme defaults must not escape this widget into unrelated charts.
        theme = getattr(self, 'current_theme', 'default')
        self.figure.patch.set_facecolor(tok.COLOR_SURFACE)
        apply_axes_style(
            self.ax,
            grid=(getattr(self, "current_chart_kind", "") != "Confusion matrix"
                  and getattr(self, "current_plot_type", "") != "Heatmap"),
        )
        if theme != 'default':
            with plt.style.context(theme):
                self.ax.set_facecolor(matplotlib.rcParams['axes.facecolor'])
                if matplotlib.rcParams['axes.grid'] and self.current_plot_type != 'Heatmap':
                    self.ax.grid(True, color=matplotlib.rcParams['grid.color'],
                                 linestyle=matplotlib.rcParams['grid.linestyle'],
                                 alpha=matplotlib.rcParams['grid.alpha'])
                else:
                    self.ax.grid(False)
        if hasattr(self, "canvas") and self.canvas is not None:
            self.canvas.draw()

    def resizeEvent(self, event):
        """Redraw the Matplotlib canvas in its current Qt logical viewport."""
        super().resizeEvent(event)
        self._update_controls_layout(event.size().width())
        canvas = getattr(self, "canvas", None)
        if canvas is not None:
            canvas.draw_idle()
            if self.figure.axes:
                self._plot_layout_timer.start()

    def _record_plot_style_metadata(self, *, category_order=None, colormap=None):
        """Attach actual rendered style information to the next export sidecar."""
        if category_order is None:
            category_order = self._current_plot_metadata.get("category_labels")
        self._current_plot_metadata.update(
            collect_plot_style_metadata(
                self.ax,
                category_order=category_order,
                colormap=colormap,
            )
        )

    def changeEvent(self, event):
        """Refresh the chart when the system palette or DPI changes so it stays crisp."""
        from PyQt5.QtCore import QEvent
        if event is not None:
            try:
                event_type = event.type()
            except Exception:
                event_type = None
            watched = []
            for name in ("DpiChange", "DevicePixelRatioChange", "StyleChange", "PaletteChange"):
                watched.append(getattr(QEvent, name, None))
            if event_type in watched:
                self.setup_plot_style()
                if hasattr(self, "canvas") and self.canvas is not None:
                    self.canvas.draw_idle()
                    if hasattr(self, "_plot_layout_timer") and self.figure.axes:
                        self._plot_layout_timer.start()
        super().changeEvent(event)
        
    def _palette(self):
        if self.current_theme == "grayscale":
            return tuple(str(value) for value in np.linspace(0.15, 0.75, len(tok.COLOR_BLIND_PALETTE)))
        return tok.COLOR_BLIND_PALETTE

    def _series_style(self, index, point_count):
        style = dict(get_series_style(index, point_count))
        style["color"] = self._palette()[index % len(self._palette())]
        return style

    def _heatmap_cmap(self):
        return "gray" if self.current_theme == "grayscale" else tok.MPL_SPECTRA_HEATMAP_CMAP

    def _layout_chart(self):
        from app.ui.mpl_layout import layout_figure
        layout_figure(self.figure, legend_fontsize=8)

    def _relayout_chart_for_viewport(self):
        """Reflow axes and legends after a settled resize or DPI transition."""
        if not self.figure.axes:
            return
        self._layout_chart()
        self.canvas.draw_idle()

    def _reset_axes(self):
        self.figure.clear()
        self.ax = self.figure.add_subplot(111)

    def update_theme(self, theme):
        """Update plot theme"""
        self.current_theme = theme
        # A global style change also changes report and other window defaults.
        # This widget owns its palette and axes styling explicitly.
        self.refresh_current_plot()
        self.setup_plot_style()
        self.canvas.draw()
        
    def update_plot_type(self, plot_type):
        """Update plot type"""
        self.current_plot_type = plot_type
        if self._plot_source is not None and self._plot_source["kind"] == "spectrum":
            self.refresh_current_plot()
        
    def plot_spectra(self, wavelengths, spectra, title=None, labels=None,
                     original_spectra=None, comparison_mode=False):
        """Plot spectra data

        Args:
            wavelengths: wavelength data array
            spectra: spectral data array
            title: chart title
            labels: samples labels array, used to select spectra to display based on category
            original_spectra: original spectra for comparison mode
            comparison_mode: whether to show comparison between original and processed
        """
        self._plot_source = None
        # Each chart owns its axes, including any colorbar or 3D projection.
        self.figure.clear()
        self.ax = self.figure.add_subplot(111)
        if title is None:
            title = _("visualization_widget.spectrum_data_title")

        try:
            wavelengths = np.asarray(wavelengths, dtype=float)
            spectra = np.asarray(spectra, dtype=float)
            if not np.isfinite(wavelengths).all() or not np.isfinite(spectra).all():
                raise ValueError("Wavelengths and spectra must contain finite values.")
            if labels is not None and len(labels) != spectra.shape[0]:
                raise ValueError("The number of labels must match the number of spectra.")
            if comparison_mode:
                original_spectra = np.asarray(original_spectra, dtype=float)
                if original_spectra.shape != spectra.shape or not np.isfinite(original_spectra).all():
                    raise ValueError("Comparison spectra must have matching shapes and finite values.")
        except (TypeError, ValueError, IndexError) as exc:
            from app.utils.data_alignment import DataDimensionAligner
            DataDimensionAligner.create_error_plot(self.ax, str(exc), _("visualization_widget.visualization_error_title"))
            self.canvas.draw()
            return
        
        if labels is not None:
            try:
                labels = np.array([str(label) for label in labels], dtype='<U50')
                logging.info(f"Labels safely converted to string array: {labels[:3] if len(labels) > 0 else []}")
            except Exception as label_error:
                logging.warning(f"Label conversion warning: {label_error}")
                labels = None
        
        # 使用数据对齐工具处理维度问题
        if wavelengths is not None and spectra is not None:
            try:
                from app.utils.data_alignment import DataDimensionAligner
                
                # 验证数据
                validation_info = DataDimensionAligner.validate_spectral_data(wavelengths, spectra, "processed_spectra")
                
                if not validation_info['valid']:
                    error_msg = '; '.join(validation_info['errors'])
                    DataDimensionAligner.create_error_plot(self.ax, error_msg, _("visualization_widget.visualization_error_title"))
                    self.canvas.draw()
                    return
                
                # 打印警告信息
                for warning in validation_info['warnings']:
                    logging.warning(warning)
                
                # 对齐数据维度
                if comparison_mode and original_spectra is not None:
                    # 比较模式：对齐三个数组
                    aligned_wavelengths, aligned_original, aligned_processed = DataDimensionAligner.align_spectral_data(
                        wavelengths, original_spectra, spectra
                    )
                    wavelengths = aligned_wavelengths
                    original_spectra = aligned_original
                    spectra = aligned_processed
                    
                    logging.info("Comparison mode dimension alignment completed:")
                    logging.info(f"   Wavelengths: {len(wavelengths)}")
                    logging.info(f"   Original spectra: {original_spectra.shape}")
                    logging.info(f"   Processed spectra: {spectra.shape}")
                    
                else:
                    # 普通模式：对齐两个数组
                    aligned_wavelengths, aligned_spectra = DataDimensionAligner.align_spectral_data(
                        wavelengths, spectra
                    )
                    wavelengths = aligned_wavelengths
                    spectra = aligned_spectra
                    
                    logging.info("Normal mode dimension alignment completed:")
                    logging.info(f"   Wavelengths: {len(wavelengths)}")
                    logging.info(f"   Spectra: {spectra.shape}")
            
            except Exception as e:
                logging.error(f"Error in data dimension alignment: {e}", exc_info=True)
                # 创建错误显示
                DataDimensionAligner.create_error_plot(self.ax, str(e), _("visualization_widget.visualization_error_title"))
                self.canvas.draw()
                return
        
        logging.debug("Visualization received wavelength data")
        if wavelengths is not None:
            logging.debug(f"   Wavelength count: {len(wavelengths)}")
            logging.debug(f"   Wavelength range: {wavelengths.min():.1f} - {wavelengths.max():.1f}")
            logging.debug(f"   First 5 wavelengths: {wavelengths[:5]}")
            logging.debug(f"   Last 5 wavelengths: {wavelengths[-5:]}")
        else:
            logging.debug("   Wavelengths is None!")
        
        source_wavelengths_nm = (
            np.asarray(wavelengths, dtype=float).copy() if wavelengths is not None else None
        )
        source_spectra = np.asarray(spectra).copy() if spectra is not None else None
        source_original_spectra = (
            np.asarray(original_spectra).copy() if original_spectra is not None else None
        )
        if source_wavelengths_nm is not None and source_spectra is not None:
            self._plot_source = {
                "kind": "spectrum",
                "wavelengths_nm": source_wavelengths_nm.copy(),
                "spectra": source_spectra.copy(),
                "labels": np.asarray(labels).copy() if labels is not None else None,
                "original_spectra": (
                    source_original_spectra.copy()
                    if source_original_spectra is not None else None
                ),
                "comparison_mode": bool(comparison_mode),
                "title": title,
            }
            arrays_to_order = [source_spectra]
            if source_original_spectra is not None:
                arrays_to_order.append(source_original_spectra)
            wavelengths, ordered_arrays = self._display_ordered_spectra(
                source_wavelengths_nm, *arrays_to_order
            )
            spectra = ordered_arrays[0]
            if source_original_spectra is not None:
                original_spectra = ordered_arrays[1]
            self.wavelengths = source_wavelengths_nm.copy()
            self.spectra = source_spectra.copy()
        else:
            self._plot_source = None
            self.wavelengths = source_wavelengths_nm
            self.spectra = source_spectra

        self.current_chart_kind = self.current_plot_type
        self._current_plot_metadata = {
            "sample_count": int(spectra.shape[0]) if spectra is not None and spectra.ndim >= 2 else None,
            "feature_count": int(spectra.shape[1]) if spectra is not None and spectra.ndim >= 2 else None,
            "x_unit": self.x_unit,
        }
        if wavelengths is not None and len(wavelengths):
            self._current_plot_metadata["wavelength_range"] = [
                float(np.min(wavelengths)), float(np.max(wavelengths))
            ]
        if labels is not None:
            try:
                self._current_plot_metadata["category_count"] = int(len(np.unique(labels)))
            except (TypeError, ValueError):
                pass
        if hasattr(self, 'chart_state_label'):
            self.chart_state_label.setText(
                _("visualization_widget.no_valid_spectral_data")
                if wavelengths is None or spectra is None or len(wavelengths) == 0 or spectra.shape[0] == 0
                else _("visualization_widget.spectrum_data_title")
            )

        self.ax.clear()
        
        colors = self._palette()
        
        if wavelengths is None or spectra is None or len(wavelengths) == 0 or spectra.shape[0] == 0:
            self.ax.text(0.5, 0.5, _("visualization_widget.no_valid_spectral_data"),
                       horizontalalignment='center', verticalalignment='center')
            self.canvas.draw()
            return
            
        if not np.all(np.diff(wavelengths) > 0):
            sort_idx = np.argsort(wavelengths)
            wavelengths = wavelengths[sort_idx]
            spectra = spectra[:, sort_idx]
        
        selected_indices = []
        
        if labels is not None:
            labels = np.array(labels).flatten()
            unique_labels = np.unique(labels)
            
            try:
                def safe_convert_to_float(arr):
                    """Safely convert array to float, if contains non-numeric return original array"""
                    result = []
                    has_string_labels = False
                    
                    for item in arr:
                        try:
                            str_item = str(item).strip()
                            str_item = str_item.strip("'\"")
                            if str_item and not str_item.replace('.', '').replace('-', '').replace('e', '').replace('E', '').replace('+', '').isdigit():
                                has_string_labels = True
                                break
                            float_val = float(item)
                            result.append(float_val)
                        except (ValueError, TypeError):
                            has_string_labels = True
                            break
                    
                    if has_string_labels:
                        return np.array(arr)
                    else:
                        return np.array(result) if result else None
                
                numeric_labels = safe_convert_to_float(labels)
                
                if numeric_labels is not None and numeric_labels.dtype.kind in ['U', 'S', 'O']:
                    is_categorical = True
                    logging.info("Label classification detection: Non-numeric labels detected, determined as categorical")
                elif numeric_labels is not None:
                    try:
                        if numeric_labels.dtype.kind in ['U', 'S', 'O']:
                            is_categorical = True
                        else:
                            unique_count = len(unique_labels)
                            total_count = len(labels)
                            
                            condition1 = unique_count <= 20
                            condition2 = unique_count < total_count * 0.3
                            condition3 = np.sum(np.equal(numeric_labels, np.round(numeric_labels))) > total_count * 0.9
                            
                            try:
                                numeric_unique = np.array([float(x) for x in unique_labels])
                                sorted_unique = np.sort(numeric_unique)
                                
                                if len(sorted_unique) >= 2:
                                    is_sequential = np.allclose(np.diff(sorted_unique), 1) and all(x == int(x) for x in sorted_unique)
                                    is_small_integers = all(x == int(x) and 0 <= x <= 100 for x in sorted_unique)
                                    condition4 = is_sequential or (is_small_integers and unique_count <= 10)
                                else:
                                    condition4 = False
                            except (ValueError, TypeError):
                                condition4 = False
                            
                            is_categorical = condition1 and condition2 and (condition3 or condition4)
                            
                            logging.debug("Classification analysis:")
                            logging.debug(f"  Unique count: {unique_count}, Total count: {total_count}")
                            logging.debug(f"  Condition1 (<=20 unique): {condition1}")
                            logging.debug(f"  Condition2 (<30% unique): {condition2}")
                            logging.debug(f"  Condition3 (>90% integers): {condition3}")
                            logging.debug(f"  Condition4 (classification pattern): {condition4}")
                            logging.debug(f"  Final decision: {'Categorical' if is_categorical else 'Continuous (Quantitative)'}")
                    except Exception as e:
                        logging.error(f"Error in numeric label analysis: {e}", exc_info=True)
                        is_categorical = True
                                     
                    logging.info(f"Final classification: {'Categorical labels' if is_categorical else 'Continuous values (Quantitative task)'}")
                else:
                    is_categorical = True
                    logging.info("Label classification detection: Conversion failed, determined as categorical")
            except:
                is_categorical = True
                logging.info("Label classification detection: Non-numeric labels, determined as categorical")
            
            if is_categorical:
                self._current_plot_metadata["category_labels"] = [
                    str(label) for label in unique_labels
                ]
                logging.info(f"Plotting by category, {len(unique_labels)} categories total")
                for label in unique_labels:
                    label_indices = np.where(labels == label)[0]
                    if len(label_indices) > 0:
                        selected_idx = label_indices[0]
                        selected_indices.append(selected_idx)
                        logging.debug(f"  Category {label}: Selected sample {selected_idx}")
            else:
                logging.info(f"Quantitative task: Plotting first {min(10, spectra.shape[0])} spectra")
                selected_indices = list(range(min(10, spectra.shape[0])))
        else:
            is_categorical = False
            logging.info("No labels, selecting first spectra")
            selected_indices = list(range(min(10, spectra.shape[0])))
        
        if len(selected_indices) == 0:
            selected_indices = list(range(min(10, spectra.shape[0])))
        
        if self.current_plot_type == "Line Plot" or self.current_plot_type == "Spectrum Plot":
            if comparison_mode and original_spectra is not None:
                # 比较模式：绘制原始和处理后的光谱
                # 首先绘制原始光谱（实线）
                for i, idx in enumerate(selected_indices):
                    if labels is not None and is_categorical:
                        label = f"{_('visualization_widget.original_prefix')} - {labels[idx]}"
                    else:
                        label = f"{_('visualization_widget.original_prefix')} - " + _('visualization_widget.spectrum_label').format(index=i+1)

                    series_style = self._series_style(i, len(wavelengths))
                    self.ax.plot(wavelengths, original_spectra[idx], linewidth=1.5, alpha=0.7,
                               color=series_style["color"], linestyle="-",
                               marker=series_style["marker"],
                               markevery=series_style.get("markevery"),
                               markersize=series_style.get("markersize", 3.5), label=label)

                # 然后绘制处理后的光谱（虚线）
                for i, idx in enumerate(selected_indices):
                    if labels is not None and is_categorical:
                        label = f"{_('visualization_widget.processed_prefix')} - {labels[idx]}"
                    else:
                        label = f"{_('visualization_widget.processed_prefix')} - " + _('visualization_widget.spectrum_label').format(index=i+1)

                    series_style = self._series_style(i, len(wavelengths))
                    self.ax.plot(wavelengths, spectra[idx], linewidth=1.5, alpha=0.7,
                               color=series_style["color"], linestyle="--",
                               marker=series_style["marker"],
                               markevery=series_style.get("markevery"),
                               markersize=series_style.get("markersize", 3.5), label=label)

                # 添加均值比较
                original_mean = np.mean(original_spectra[selected_indices], axis=0)
                processed_mean = np.mean(spectra[selected_indices], axis=0)

                self.ax.plot(wavelengths, original_mean, color=self._palette()[0], linewidth=3,
                           label=_('visualization_widget.original_mean_label'), alpha=0.9, linestyle='-')
                self.ax.plot(wavelengths, processed_mean, color=self._palette()[1], linewidth=3,
                           label=_('visualization_widget.processed_mean_label'), alpha=0.9, linestyle='--')
                
                # 计算Y轴范围（包括原始数据、处理后数据和均值数据）
                all_spectra = np.vstack([original_spectra[selected_indices], spectra[selected_indices]])
                # 同时包括均值数据以确保完整显示
                all_data_with_means = np.vstack([all_spectra, [original_mean], [processed_mean]])
                y_min, y_max = np.min(all_data_with_means), np.max(all_data_with_means)
                
            else:
                # 普通模式：只绘制当前光谱
                for i, idx in enumerate(selected_indices):
                    if labels is not None and is_categorical:
                        label = f"{labels[idx]}"
                    else:
                        label = _('visualization_widget.spectrum_label').format(index=i+1)
                    
                    series_style = self._series_style(i, len(wavelengths))
                    self.ax.plot(wavelengths, spectra[idx], linewidth=1.5, alpha=0.85,
                               color=series_style["color"], linestyle=series_style["linestyle"],
                               marker=series_style["marker"],
                               markevery=series_style.get("markevery"),
                               markersize=series_style.get("markersize", 3.5), label=label)
                
                displayed_spectra = spectra[selected_indices]
                y_min, y_max = np.min(displayed_spectra), np.max(displayed_spectra)
            
            # Apply Y-axis limits using visualization control service (Editor Comment 3)
            if comparison_mode:
                # Set original Y-limits for locking
                self.viz_control.set_original_y_limits(original_spectra[selected_indices], spectra[selected_indices])
                
                # Get Y-limits based on lock state
                y_min, y_max = self.viz_control.get_y_limits(
                    original_spectra[selected_indices], 
                    spectra[selected_indices],
                    [original_mean], 
                    [processed_mean]
                )
            else:
                # For normal mode, calculate Y-limits
                y_min, y_max = self.viz_control.calculate_y_limits(spectra[selected_indices])
            
            if y_min is not None and y_max is not None:
                self.ax.set_ylim(y_min, y_max)
            
            # Add visualization control annotations
            annotations = self.viz_control.create_plot_annotations(self.ax, comparison_mode)
            
            # Update preprocessing queue for display
            if comparison_mode:
                self.viz_control.update_preprocessing_queue(
                    getattr(self, 'current_preprocessing_methods', []),
                    getattr(self, 'scaling_active', False)
                )
            
            self.ax.ticklabel_format(useOffset=False, style='plain')
            
            self.ax.set_xlabel(self._x_axis_label(), fontsize=11, fontweight='medium')
            self.ax.set_ylabel(self.spectral_y_label, fontsize=11, fontweight='medium')

            # 比较模式下添加说明文字
            if comparison_mode and original_spectra is not None:
                self.ax.text(0.02, 0.98, _('visualization_widget.solid_dashed_lines_note'),
                           transform=self.ax.transAxes, fontsize=9, verticalalignment='top',
                           bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))
            
        elif self.current_plot_type == "Scatter Plot":
            if len(wavelengths) > 500:
                step = max(1, len(wavelengths) // 100)
            else:
                step = 1
            
            point_size = 30 if step > 1 else 15
            alpha = 0.8
            
            logging.info(f"Scatter plot sampling info: Original wavelength count = {len(wavelengths)}, Sampling step = {step}, Points after sampling = {len(wavelengths[::step])}")
            
            for i, idx in enumerate(selected_indices):
                if labels is not None and is_categorical:
                    label = f"{labels[idx]}"
                else:
                    label = f"Spectrum {i+1}"
                
                series_style = self._series_style(i, len(wavelengths))
                scatter = self.ax.scatter(
                    wavelengths[::step], 
                    spectra[idx, ::step], 
                    s=point_size, 
                    alpha=alpha,
                    color=series_style["color"],
                    label=label,
                    marker=series_style["marker"] if series_style["marker"] != "None" else "o"
                )
                
                logging.debug(f"Spectrum {idx+1}: {len(wavelengths[::step])} points")
            
            self.ax.set_xlim(np.min(wavelengths), np.max(wavelengths))
            
            displayed_spectra = spectra[selected_indices]
            y_min, y_max = np.min(displayed_spectra), np.max(displayed_spectra)
            y_range = y_max - y_min
            y_padding = max(y_range * 0.05, 0.001)
            self.ax.set_ylim(y_min - y_padding, y_max + y_padding)
            
            self.ax.grid(True, linestyle='-', linewidth=0.8, alpha=0.5)
            
            self.ax.ticklabel_format(useOffset=False, style='plain')
            
            self.ax.set_xlabel(self._x_axis_label(), fontsize=11, fontweight='medium')
            self.ax.set_ylabel(self.spectral_y_label, fontsize=11, fontweight='medium')
            
        elif self.current_plot_type == "Heatmap":
            max_spectra = min(spectra.shape[0], 20)
            
            extent = [np.min(wavelengths), np.max(wavelengths), 0, max_spectra]
            
            im = self.ax.imshow(spectra[:max_spectra], aspect='auto', origin='lower',
                              interpolation='nearest', cmap=self._heatmap_cmap(),
                              extent=tuple(extent))
                              
            self.ax.ticklabel_format(axis='x', useOffset=False, style='plain')
            
            self.ax.set_yticks(np.arange(0.5, max_spectra, 1))
            self.ax.set_yticklabels(np.arange(1, max_spectra+1, 1))
            
            self.ax.set_xlabel(self._x_axis_label(), fontsize=11, fontweight='medium')
            self.ax.set_ylabel(_("visualization_widget.spectrum_index_label"), fontsize=11, fontweight='medium')
            cbar = self.figure.colorbar(im, ax=self.ax)
            cbar.set_label(self.spectral_y_label, fontsize=10)
            
        elif self.current_plot_type == "3D Plot":
            self.ax.remove()
            self.ax = self.figure.add_subplot(111, projection='3d')
            
            if len(wavelengths) > 500:
                step = len(wavelengths) // 500
            else:
                step = 1
            
            max_spectra = min(spectra.shape[0], 10)
            
            for i in range(max_spectra):
                if labels is not None and is_categorical:
                    label = f"{labels[i]}"
                else:
                    label = f"Spectrum {i+1}"
                
                series_style = self._series_style(i, len(wavelengths[::step]))
                self.ax.plot(wavelengths[::step], [i] * len(wavelengths[::step]),
                          spectra[i, ::step], linewidth=2,
                          color=series_style["color"], linestyle=series_style["linestyle"],
                          label=label)
            
            self.ax.set_xlabel(self._x_axis_label(), fontsize=11, fontweight='medium')
            self.ax.set_ylabel(_("visualization_widget.spectrum_index_label"), fontsize=11, fontweight='medium')
            self.ax.set_zlabel(self.spectral_y_label, fontsize=11, fontweight='medium')
            self.ax.legend(loc='best', fontsize='small')
            
        elif self.current_plot_type == "Bar Chart":
            means = np.mean(spectra, axis=1)
            max_spectra = min(len(means), 15)
            
            x_labels = []
            for i in range(max_spectra):
                if labels is not None and is_categorical:
                    x_labels.append(f"{labels[i]}")
                else:
                    x_labels.append(f"Spectrum {i+1}")
            
            bars = self.ax.bar(range(1, max_spectra+1), means[:max_spectra],
                      color=colors[:max_spectra], alpha=0.85, width=0.6)
            
            self.ax.set_xticks(range(1, max_spectra+1))
            import textwrap
            self._current_plot_metadata['bar_labels'] = x_labels
            short_labels = [f'{i+1}: ' + (str(v) if len(str(v)) <= 14 else str(v)[:13]+'…')
                            for i, v in enumerate(x_labels)]
            self.ax.set_xticklabels(short_labels, rotation=45, ha='right', fontsize=9)
            
            self.ax.set_xlabel(_("visualization_widget.spectrum_axis_label"), fontsize=11, fontweight='medium')
            self.ax.set_ylabel(self.spectral_y_label, fontsize=11, fontweight='medium')
        
        self.ax.set_title(title, fontsize=13, fontweight='bold')
        
        apply_axes_style(self.ax, grid=self.current_plot_type != "Heatmap")
        for spine in self.ax.spines.values():
            spine.set_linewidth(1.2)
        
        if self.current_plot_type in ["Line Plot", "Scatter Plot", "Spectrum Plot"]:
            self.ax.legend(loc='best', frameon=True, framealpha=0.7, fontsize='small')
            
        if self.current_plot_type in ["Line Plot", "Scatter Plot", "Spectrum Plot", "Heatmap", "3D Plot"] and wavelengths is not None and len(wavelengths) > 0:
            x_min, x_max = np.min(wavelengths), np.max(wavelengths)
            self.ax.set_xlim(x_min, x_max)
            
        self._layout_chart()
        category_order = self._current_plot_metadata.get("category_labels")
        if self.current_plot_type == "Bar Chart":
            category_order = [item.get_text() for item in self.ax.get_xticklabels()]
        self._record_plot_style_metadata(
            category_order=category_order,
            colormap=(self._heatmap_cmap()
                      if self.current_plot_type == "Heatmap" else None)
        )
        self.canvas.draw()
        
    def plot_spectra_comparison(self, wavelengths, original_spectra, processed_spectra,
                               title=None):
        """Plot original and processed spectra comparison"""
        self._plot_source = None
        self._reset_axes()
        if title is None:
            title = _("visualization_widget.spectra_comparison_title")
        if (wavelengths is None or original_spectra is None or processed_spectra is None or 
            len(wavelengths) == 0 or original_spectra.size == 0 or processed_spectra.size == 0):
            self.ax.text(0.5, 0.5, _("visualization_widget.no_valid_comparison_data"),
                      horizontalalignment='center', verticalalignment='center')
            self.canvas.draw()
            return

        try:
            wavelengths = np.array(wavelengths, dtype=float)
            
            def safe_extract_numeric_data(data):
                """Safely extract numerical data, excluding label columns"""
                if isinstance(data, (list, tuple)):
                    data = np.array(data)
                
                if data.ndim == 1:
                    try:
                        return np.array(data, dtype=float)
                    except (ValueError, TypeError):
                        try:
                            return np.array(data[1:], dtype=float)
                        except:
                            raise ValueError("Data contains non-numeric values that cannot be converted")
                else:
                    try:
                        return np.array(data, dtype=float)
                    except (ValueError, TypeError):
                        try:
                            if data.shape[1] > 1:
                                numeric_data = data[:, 1:]
                                return np.array(numeric_data, dtype=float)
                            else:
                                raise ValueError("Data appears to be labels only")
                        except:
                            raise ValueError("Data contains non-numeric values in spectral columns")
            
            original_spectra = safe_extract_numeric_data(original_spectra)
            processed_spectra = safe_extract_numeric_data(processed_spectra)
            
            logging.info("Successfully extracted numerical spectral data:")
            logging.info(f"    Original spectrum: {original_spectra.shape}")
            logging.info(f"    Processed spectrum: {processed_spectra.shape}")
            logging.info(f"    Wavelength count: {len(wavelengths)}")
            
        except Exception as conversion_error:
            logging.error(f"Spectral data conversion failed: {conversion_error}", exc_info=True)
            self.ax.text(0.5, 0.5, _('visualization_widget.data_conversion_failed').format(error=str(conversion_error)),
                      horizontalalignment='center', verticalalignment='center')
            self.canvas.draw()
            return
        
        if original_spectra.ndim == 1:
            original_spectra = original_spectra.reshape(1, -1)
        if processed_spectra.ndim == 1:
            processed_spectra = processed_spectra.reshape(1, -1)
            
        if len(wavelengths) != original_spectra.shape[1]:
            if len(wavelengths) > original_spectra.shape[1]:
                wavelengths = wavelengths[:original_spectra.shape[1]]
            else:
                original_spectra = original_spectra[:, :len(wavelengths)]
                
        if len(wavelengths) != processed_spectra.shape[1]:
            if len(wavelengths) > processed_spectra.shape[1]:
                wavelengths = wavelengths[:processed_spectra.shape[1]]
            else:
                processed_spectra = processed_spectra[:, :len(wavelengths)]
                
        source_wavelengths_nm = np.asarray(wavelengths, dtype=float).copy()
        source_original_spectra = np.asarray(original_spectra).copy()
        source_processed_spectra = np.asarray(processed_spectra).copy()
        self._plot_source = {
            "kind": "comparison",
            "wavelengths_nm": source_wavelengths_nm.copy(),
            "original_spectra": source_original_spectra.copy(),
            "processed_spectra": source_processed_spectra.copy(),
            "title": title,
        }
        wavelengths, ordered_arrays = self._display_ordered_spectra(
            source_wavelengths_nm, source_original_spectra, source_processed_spectra
        )
        original_spectra, processed_spectra = ordered_arrays
        self.wavelengths = source_wavelengths_nm.copy()
        self.spectra = source_processed_spectra.copy()

        self.ax.clear()
        
        original_mean = np.mean(original_spectra, axis=0)
        processed_mean = np.mean(processed_spectra, axis=0)
        
        original_style = self._series_style(0, len(wavelengths))
        processed_style = self._series_style(1, len(wavelengths))
        self.ax.plot(wavelengths, original_mean, color=original_style["color"], linestyle='-',
                   linewidth=2.0, alpha=0.9,
                   label=_("visualization_widget.original_mean_label"))
        self.ax.plot(wavelengths, processed_mean, color=processed_style["color"], linestyle='--',
                   linewidth=2.0, alpha=0.9,
                   label=_("visualization_widget.processed_mean_label"))

        if original_spectra.shape[0] > 1:
            for i in range(min(3, original_spectra.shape[0])):
                self.ax.plot(wavelengths, original_spectra[i], color=original_style["color"],
                           linestyle=':', linewidth=0.8, alpha=0.35)
                self.ax.plot(wavelengths, processed_spectra[i], color=processed_style["color"],
                           linestyle='-.', linewidth=0.8, alpha=0.35)
        
        apply_axes_style(self.ax)
        for spine in self.ax.spines.values():
            spine.set_linewidth(1.2)
            
        self.ax.set_xlim(np.min(wavelengths), np.max(wavelengths))
        
        all_data = np.concatenate([original_spectra.flatten(), processed_spectra.flatten()])
        self.ax.set_ylim(np.min(all_data), np.max(all_data))
        
        self.ax.ticklabel_format(useOffset=False, style='plain')
            
        self.ax.set_xlabel(self._x_axis_label(), fontsize=11, fontweight='medium')
        self.ax.set_ylabel(self.spectral_y_label, fontsize=11, fontweight='medium')
        self.ax.set_title(title, fontsize=13, fontweight='bold')
        
        self.ax.legend(loc='best', frameon=True, framealpha=0.7, fontsize=10)

        self.current_chart_kind = "Spectrum comparison"
        self._current_plot_metadata = {
            "sample_count": int(original_spectra.shape[0]),
            "feature_count": int(original_spectra.shape[1]),
            "x_unit": self.x_unit,
            "wavelength_range": [float(np.min(wavelengths)), float(np.max(wavelengths))],
        }
        
        self._layout_chart()
        self._record_plot_style_metadata()
        self.canvas.draw()
        
    def zoom_in(self):
        """Zoom in the plot"""
        self.ax.set_autoscale_on(False)
        x_min, x_max = self.ax.get_xlim()
        y_min, y_max = self.ax.get_ylim()
        
        x_range = x_max - x_min
        y_range = y_max - y_min
        
        self.ax.set_xlim(x_min + x_range * 0.1, x_max - x_range * 0.1)
        self.ax.set_ylim(y_min + y_range * 0.1, y_max - y_range * 0.1)
        
        self.canvas.draw()
        
    def zoom_out(self):
        """Zoom out the plot"""
        self.ax.set_autoscale_on(False)
        x_min, x_max = self.ax.get_xlim()
        y_min, y_max = self.ax.get_ylim()
        
        x_range = x_max - x_min
        y_range = y_max - y_min
        
        self.ax.set_xlim(x_min - x_range * 0.1, x_max + x_range * 0.1)
        self.ax.set_ylim(y_min - y_range * 0.1, y_max + y_range * 0.1)
        
        self.canvas.draw()
        
    def save_plot(self, file_path):
        """Save current plot using the shared export service."""
        try:
            from app.services.plot_export_service import ExportProfile, export_figure

            requested_format = Path(file_path).suffix.lstrip(".").lower() or "png"
            profile = ExportProfile(
                width_mm=tok.MPL_EXPORT_DOUBLE_COLUMN_MM,
                height_mm=tok.MPL_EXPORT_DOUBLE_COLUMN_HEIGHT_MM,
                format=requested_format,
                dpi=tok.MPL_EXPORT_DEFAULT_DPI,
                publication_style=True,
            )
            export_figure(
                self.figure,
                file_path,
                profile=profile,
                chart_type=self.current_chart_kind,
                metadata=self._current_plot_metadata,
            )
            return True
        except Exception as e:
            logging.error(f"Error saving plot: {e}", exc_info=True)
            return False

    def show_export_dialog(self):
        """Collect an export profile and save the current chart plus metadata."""
        if not self.figure.axes:
            QMessageBox.information(self, "Export figure", "There is no plotted figure to export yet.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Export publication-ready figure")
        form = QFormLayout(dialog)
        form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        form.setRowWrapPolicy(QFormLayout.WrapLongRows)

        profile_combo = QComboBox(dialog)
        profile_combo.addItems([
            f"Single-column reference — {tok.MPL_EXPORT_SINGLE_COLUMN_MM:g} × {tok.MPL_EXPORT_SINGLE_COLUMN_HEIGHT_MM:.1f} mm",
            f"Double-column reference — {tok.MPL_EXPORT_DOUBLE_COLUMN_MM:g} × {tok.MPL_EXPORT_DOUBLE_COLUMN_HEIGHT_MM:g} mm",
            "Custom size",
        ])
        form.addRow("Reference size", profile_combo)

        width_spin = QDoubleSpinBox(dialog)
        width_spin.setRange(tok.MPL_EXPORT_MIN_WIDTH_MM, tok.MPL_EXPORT_MAX_WIDTH_MM)
        width_spin.setDecimals(1)
        width_spin.setSuffix(" mm")
        width_spin.setValue(tok.MPL_EXPORT_SINGLE_COLUMN_MM)
        form.addRow("Custom width", width_spin)
        width_spin.setEnabled(False)

        height_spin = QDoubleSpinBox(dialog)
        height_spin.setRange(tok.MPL_EXPORT_MIN_HEIGHT_MM, tok.MPL_EXPORT_MAX_HEIGHT_MM)
        height_spin.setDecimals(2)
        height_spin.setSuffix(" mm")
        height_spin.setValue(tok.MPL_EXPORT_SINGLE_COLUMN_HEIGHT_MM)
        form.addRow("Custom height", height_spin)
        height_spin.setEnabled(False)

        profile_widths = (
            tok.MPL_EXPORT_SINGLE_COLUMN_MM,
            tok.MPL_EXPORT_DOUBLE_COLUMN_MM,
        )
        profile_heights = (
            tok.MPL_EXPORT_SINGLE_COLUMN_HEIGHT_MM,
            tok.MPL_EXPORT_DOUBLE_COLUMN_HEIGHT_MM,
        )

        def update_custom_size_controls(index):
            if index < 2:
                width_spin.setValue(profile_widths[index])
                height_spin.setValue(profile_heights[index])
            width_spin.setEnabled(index == 2)
            height_spin.setEnabled(index == 2)

        profile_combo.currentIndexChanged.connect(update_custom_size_controls)

        format_combo = QComboBox(dialog)
        format_combo.addItem("PDF (editable vector)", "pdf")
        format_combo.addItem("SVG (editable vector)", "svg")
        format_combo.addItem("PNG (raster)", "png")
        format_combo.addItem("TIFF (raster)", "tiff")
        form.addRow("Format", format_combo)

        dpi_spin = QSpinBox(dialog)
        dpi_spin.setRange(72, 1200)
        dpi_spin.setValue(tok.MPL_EXPORT_DEFAULT_DPI)
        form.addRow("DPI", dpi_spin)

        style_check = QCheckBox(
            "Apply publication styling", dialog
        )
        style_check.setChecked(True)
        form.addRow("Style", style_check)

        note = QLabel(
            "The reference widths follow common single/double-column examples; the application suggests a 3:2 size. "
            "Custom exports set both physical dimensions, independent of screen size and chart aspect ratio. "
            "DPI sets PNG/TIFF pixels and raster artwork embedded in PDF/SVG; vector lines and text stay resolution independent.",
            dialog,
        )
        note.setWordWrap(True)
        note.setMinimumWidth(0)
        from PyQt5.QtWidgets import QSizePolicy
        note.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        form.addRow(note)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel, parent=dialog)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        from app.utils.responsive import fit_window_to_screen
        fit_window_to_screen(dialog, 640, 500, min_width=420, min_height=400)
        if dialog.exec_() != QDialog.Accepted:
            return

        width_mm = width_spin.value()
        height_mm = height_spin.value()
        chosen_format = format_combo.currentData()
        suffix = ".tif" if chosen_format == "tiff" else f".{chosen_format}"
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save figure",
            f"spectroease_figure{suffix}",
            {
                "pdf": "PDF files (*.pdf)",
                "svg": "SVG files (*.svg)",
                "png": "PNG files (*.png)",
                "tiff": "TIFF files (*.tif *.tiff)",
            }[chosen_format],
        )
        if not file_path:
            return

        try:
            from app.services.plot_export_service import ExportProfile, export_figure

            profile = ExportProfile(
                width_mm=width_mm,
                height_mm=height_mm,
                format=chosen_format,
                dpi=dpi_spin.value(),
                publication_style=style_check.isChecked(),
            )
            result = export_figure(
                self.figure,
                file_path,
                profile=profile,
                chart_type=self.current_chart_kind,
                metadata=self._current_plot_metadata,
            )
        except Exception as exc:
            logging.error("Figure export failed: %s", exc, exc_info=True)
            QMessageBox.critical(self, "Export failed", str(exc))
            return

        QMessageBox.information(
            self,
            "Figure exported",
            f"Figure: {result['figure_path']}\nMetadata: {result['sidecar_path']}\n"
            f"Size: {result['width_mm']:.1f} × {result['height_mm']:.1f} mm",
        )

    def update_preprocessing_preview(self, data_model, wavelengths, preview_mode, methods_applied=None):
        """
        Updates the plot to show original, processed, or a comparison of spectral data
        based on the selected preview mode, with improved legend handling.
        """
        self._plot_source = None
        self._reset_axes()
        source_wavelengths_nm = (
            np.asarray(wavelengths, dtype=float).copy() if wavelengths is not None else None
        )
        self.ax.clear()

        try:
            from app.utils.data_alignment import DataDimensionAligner
        except ImportError:
            self.ax.text(0.5, 0.5, _('visualization_widget.error_import_aligner'), ha='center', va='center', color='red')
            self.canvas.draw()
            return

        # 1. Get data from data_model
        X_original = data_model.get_X()
        X_processed = data_model.X_processed
        y_labels = data_model.get_y()

        # 2. Handle missing data
        if X_original is None or wavelengths is None:
            self.ax.text(0.5, 0.5, _('visualization_widget.error_original_data'), ha='center', va='center')
            self.canvas.draw()
            return
        
        if y_labels is not None:
            y_labels = np.array(y_labels)

        # Per PRD: When X_processed is empty, use X as a placeholder and log it.
        if X_processed is None:
            logging.info("X_processed is empty. Using original data (X) as a placeholder for visualization.")
            X_processed = X_original.copy()

        # 3. Align dimensions
        try:
            X_original_np = np.array(X_original)
            X_processed_np = np.array(X_processed)
            wavelengths_np = np.array(wavelengths)

            aligned_wavelengths, aligned_original, aligned_processed = DataDimensionAligner.align_spectral_data(
                wavelengths_np, X_original_np, X_processed_np
            )
        except Exception as e:
            DataDimensionAligner.create_error_plot(self.ax, f"Dimension Alignment Failed: {e}", _("visualization_widget.visualization_error_title"))
            self.canvas.draw()
            return

        source_wavelengths_nm = np.asarray(aligned_wavelengths, dtype=float).copy()
        display_wavelengths, ordered_arrays = self._display_ordered_spectra(
            source_wavelengths_nm, aligned_original, aligned_processed
        )
        aligned_original, aligned_processed = ordered_arrays
        aligned_wavelengths = display_wavelengths
        self._plot_source = {
            "kind": "preprocessing_preview",
            "data_model": data_model,
            "wavelengths_nm": source_wavelengths_nm.copy(),
            "preview_mode": preview_mode,
            "methods_applied": list(methods_applied or []),
        }
        self.wavelengths = source_wavelengths_nm.copy()
        self.spectra = np.asarray(aligned_processed).copy()

        # 4. Plotting logic
        show_original = preview_mode in ["Original", "Comparison"]
        show_processed = preview_mode in ["Processed", "Comparison"]
        
        num_to_plot = min(5, aligned_original.shape[0])
        mean_original, mean_processed = None, None

        # Plot individual spectra with proper labels
        for i in range(num_to_plot):
            series_style = self._series_style(i, len(aligned_wavelengths))
            sample_label = _('visualization_widget.sample_label').format(index=i+1)

            if show_original:
                label = f"{sample_label} {_('visualization_widget.original_suffix')}" if preview_mode == "Comparison" else str(sample_label)
                self.ax.plot(aligned_wavelengths, aligned_original[i],
                             color=series_style["color"], linestyle='-',
                             marker=series_style["marker"],
                             markevery=series_style.get("markevery"),
                             markersize=series_style.get("markersize", 3.5),
                             linewidth=0.8, alpha=0.7, label=label)

            if show_processed:
                label = f"{sample_label} {_('visualization_widget.processed_suffix')}" if preview_mode == "Comparison" else str(sample_label)
                linestyle = '--' if preview_mode == "Comparison" else '-'
                self.ax.plot(aligned_wavelengths, aligned_processed[i],
                             color=series_style["color"], linestyle=linestyle,
                             marker=series_style["marker"],
                             markevery=series_style.get("markevery"),
                             markersize=series_style.get("markersize", 3.5),
                             linewidth=1.0, alpha=0.8, label=label)

        # Plot mean and std bands without adding to legend in comparison mode
        if show_original:
            mean_original = np.mean(aligned_original, axis=0)
            std_original = np.std(aligned_original, axis=0)
            self.ax.plot(aligned_wavelengths, mean_original, color='black', linestyle='-', linewidth=2.5, alpha=0.6, label=_('visualization_widget.original_mean') if preview_mode != "Comparison" else '_nolegend_')
            self.ax.fill_between(aligned_wavelengths, mean_original - std_original, mean_original + std_original, color='gray', alpha=0.15, label='_nolegend_')

        if show_processed:
            mean_processed = np.mean(aligned_processed, axis=0)
            std_processed = np.std(aligned_processed, axis=0)
            linestyle = '--' if preview_mode == "Comparison" else '-'
            self.ax.plot(aligned_wavelengths, mean_processed, color='black', linestyle=linestyle, linewidth=2.5, alpha=0.6, label=_('visualization_widget.processed_mean') if preview_mode != "Comparison" else '_nolegend_')
            self.ax.fill_between(aligned_wavelengths, mean_processed - std_processed, mean_processed + std_processed, color='gray', alpha=0.15, label='_nolegend_')

        # 5. Set title and labels
        if preview_mode == "Comparison":
            title = _("visualization_widget.preprocessing_comparison_title")
        elif preview_mode == "Original":
            title = _("visualization_widget.original_spectra_title")
        else: # Processed
            title = _("visualization_widget.processed_spectra_title")

        if methods_applied:
            title += f": {', '.join(methods_applied)}"

        self.ax.set_title(title, fontsize=13, fontweight='bold')
        self.ax.set_xlabel(self._x_axis_label(), fontsize=11)
        self.ax.set_ylabel(_("visualization_widget.intensity_label"), fontsize=11)
        apply_axes_style(self.ax)
        self.ax.legend()

        # 6. Handle Y-axis locking
        if hasattr(self, 'viz_control'):
             self.viz_control.set_original_y_limits(aligned_original, aligned_processed)
             
             original_data_for_lim = [mean_original] if mean_original is not None else []
             processed_data_for_lim = [mean_processed] if mean_processed is not None else []

             y_min, y_max = self.viz_control.get_y_limits(
                 aligned_original if show_original else None, 
                 aligned_processed if show_processed else None,
                 original_data_for_lim,
                 processed_data_for_lim
             )
             if y_min is not None and y_max is not None:
                self.ax.set_ylim(y_min, y_max)
        
        self._layout_chart()
        self.current_chart_kind = "Preprocessing preview"
        self._current_plot_metadata = {
            "sample_count": int(aligned_original.shape[0]),
            "feature_count": int(aligned_original.shape[1]),
            "x_unit": self.x_unit,
            "wavelength_range": [
                float(np.min(aligned_wavelengths)), float(np.max(aligned_wavelengths))
            ],
        }
        self._record_plot_style_metadata()
        self.canvas.draw()

    def clear(self):
        """Clear current plot content, including any colorbar axes."""
        self.current_chart_kind = "Matplotlib figure"
        self._current_plot_metadata = {}
        self._plot_source = None
        self._reset_axes()
        self.canvas.draw()
        return True
        
    def plot_scatter(self, x_data, y_data, title=None, xlabel=None, ylabel=None):
        """Plot scatter plot, used for actual value vs prediction value in regression analysis

        Args:
            x_data: X-axis data (usually actual value)
            y_data: Y-axis data (usually prediction value)
            title: Chart title
            xlabel: X-axis labels
            ylabel: Y-axis labels
        """
        if title is None:
            title = _("visualization_widget.scatter_plot_item")
        if xlabel is None:
            xlabel = _("visualization_widget.x_label")
        if ylabel is None:
            ylabel = _("visualization_widget.y_label")
        self._plot_source = None
        self._reset_axes()
        
        self.ax.scatter(
            x_data, y_data, s=20, alpha=0.75, c=self._palette()[5],
            edgecolors='k', linewidths=0.45, label=f"{ylabel} vs {xlabel}"
        )
        
        min_val = min(np.min(x_data), np.min(y_data))
        max_val = max(np.max(x_data), np.max(y_data))
        self.ax.plot([min_val, max_val], [min_val, max_val], color=self._palette()[0],
                     linestyle='--', alpha=0.75, linewidth=1.2, label="1:1 reference")
        
        self.ax.set_title(title, fontsize=14, fontweight='bold')
        self.ax.set_xlabel(xlabel, fontsize=12)
        self.ax.set_ylabel(ylabel, fontsize=12)
        
        apply_axes_style(self.ax)
        self.ax.legend(loc='best', frameon=False, fontsize='small')
        
        self.current_chart_kind = "Regression scatter"
        self._current_plot_metadata = {
            "point_count": int(min(np.size(x_data), np.size(y_data))),
        }
        self._layout_chart()
        self._record_plot_style_metadata()
        self.canvas.draw()
        
    def plot_confusion_matrix(self, confusion_matrix, class_names=None, title=None):
        """Plot confusion matrix

        Args:
            confusion_matrix: Confusion matrix array
            class_names: List of class names
            title: Chart title
        """
        self._plot_source = None
        if title is None:
            title = _("visualization_widget.confusion_matrix_item")
        if confusion_matrix is None:
            logging.error("Confusion matrix data is empty")
            self.ax.text(0.5, 0.5, _("visualization_widget.no_confusion_matrix_data"),
                       horizontalalignment='center', verticalalignment='center')
            self.canvas.draw()
            return
            
        logging.debug("Confusion matrix plotting debug info:")
        logging.debug(f"VisualizationWidget: Input class_names: {class_names}")
        logging.debug(f"Confusion matrix shape: {confusion_matrix.shape}")

        # Ensure any previous plot (including colorbars/legends) is removed.
        self.clear()

        matrix_size = confusion_matrix.shape[0]
        
        if class_names is None:
            class_names = [_('visualization_widget.class_default').format(index=i) for i in range(matrix_size)]
            logging.warning("No class names provided, using default indices")
        
        if len(class_names) != matrix_size:
            logging.warning(f"Label count mismatch: {len(class_names)} vs {matrix_size}")
            
            if len(class_names) > matrix_size:
                class_names = class_names[:matrix_size]
                logging.info(f"Truncate labels to {matrix_size} classes")
            else:
                original_count = len(class_names)
                for i in range(matrix_size - original_count):
                    class_names.append(_('visualization_widget.missing_label').format(index=original_count + i))
                logging.info(f"Supplement labels to {matrix_size} classes")
        
        cleaned_class_names = []
        for i, name in enumerate(class_names):
            str_name = str(name).strip()
            
            str_name = str_name.replace('\n', ' ').replace('\t', ' ')
            
            cleaned_class_names.append(str_name)
        
        class_names = cleaned_class_names
        self.current_chart_kind = "Confusion matrix"
        self._current_plot_metadata = {
            "class_count": int(matrix_size),
            "matrix_shape": [int(dim) for dim in confusion_matrix.shape],
            "class_names": list(class_names),
            "category_order": list(class_names),
        }
        logging.debug(f"Cleaned labels: {class_names}")
        
        if len(class_names) != matrix_size:
            logging.warning("Final label count still mismatch, force repair")
            if len(class_names) > matrix_size:
                class_names = class_names[:matrix_size]
            else:
                while len(class_names) < matrix_size:
                    class_names.append(_('visualization_widget.fix_label').format(index=len(class_names)))
        
        logging.debug(f"Final label list ({len(class_names)}): {class_names}")
        
        num_classes = matrix_size
        
        if num_classes <= 10:
            logging.info("Using small confusion matrix plotting")
            self._plot_small_confusion_matrix(confusion_matrix, class_names, title)
        elif num_classes <= 25:
            logging.info("Using medium confusion matrix plotting")
            self._plot_medium_confusion_matrix(confusion_matrix, class_names, title)
        else:
            logging.info("Using large confusion matrix plotting")
            self._plot_large_confusion_matrix(confusion_matrix, class_names, title)

        apply_axes_style(self.ax, grid=False)
        self._layout_chart()
        self._record_plot_style_metadata(
            category_order=class_names,
            colormap=tok.MPL_CONFUSION_CMAP,
        )
        self.canvas.draw_idle()
        
        logging.info(f"VisualizationWidget: Confusion matrix plotting completed, classes: {num_classes}")
        
    def _plot_small_confusion_matrix(self, cm, class_names, title):
        """Plot small confusion matrix (≤10 classes)"""
        logging.debug(f"Plotting small confusion matrix: {cm.shape}, labels: {len(class_names)}")
        
        cmap = plt.get_cmap(tok.MPL_CONFUSION_CMAP)
        
        im = self.ax.imshow(cm, interpolation='nearest', cmap=cmap)
        
        try:
            cbar = self.figure.colorbar(im, ax=self.ax, fraction=0.046, pad=0.04)
            cbar.set_label(_('visualization_widget.count_label'), rotation=270, labelpad=15)
        except Exception as e:
            logging.warning(f"Color bar addition failed: {e}")

        self.ax.set_title(title, fontsize=12, fontweight='bold', pad=20)
        self.ax.set_xlabel(_('visualization_widget.predicted_axis_label'), fontsize=10)
        self.ax.set_ylabel(_('visualization_widget.true_axis_label'), fontsize=10)
        
        tick_marks = np.arange(len(class_names))
        self.ax.set_xticks(tick_marks)
        self.ax.set_xticklabels(class_names, rotation=45, ha='right', fontsize=9)
        self.ax.set_yticks(tick_marks)
        self.ax.set_yticklabels(class_names, fontsize=9)
        
        thresh = cm.max() / 2.
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                self.ax.text(j, i, format(cm[i, j], 'd'),
                           ha="center", va="center",
                           color="white" if cm[i, j] > thresh else "black",
                           fontsize=8)
        
        self.ax.set_xticks(np.arange(-0.5, len(class_names), 1), minor=True)
        self.ax.set_yticks(np.arange(-0.5, len(class_names), 1), minor=True)
        self.ax.grid(which='minor', color='gray', linestyle='-', linewidth=0.2, alpha=0.5)
        
        self.canvas.draw()
        
    def _plot_medium_confusion_matrix(self, cm, class_names, title):
        """Plot medium confusion matrix (11-25 classes) - improved version"""
        logging.debug(f"Plotting medium confusion matrix: {cm.shape}, labels: {len(class_names)}")
        
        cmap = plt.get_cmap(tok.MPL_CONFUSION_CMAP)
        im = self.ax.imshow(cm, interpolation='nearest', cmap=cmap)
        
        try:
            cbar = self.figure.colorbar(im, ax=self.ax, fraction=0.046, pad=0.04)
            cbar.set_label(_('visualization_widget.count_label'), rotation=270, labelpad=15)
        except Exception as e:
            logging.warning(f"Color bar addition failed: {e}")

        self.ax.set_title(title, fontsize=11, fontweight='bold')
        self.ax.set_xlabel(_('visualization_widget.predicted_axis_label'), fontsize=9)
        self.ax.set_ylabel(_('visualization_widget.true_axis_label'), fontsize=9)
        
        tick_marks = np.arange(len(class_names))
        self.ax.set_xticks(tick_marks)
        self.ax.set_xticklabels(class_names, rotation=90, ha='center', fontsize=7)
        self.ax.set_yticks(tick_marks)
        self.ax.set_yticklabels(class_names, fontsize=7)
        
        thresh = cm.max() / 2.
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                if i == j or cm[i, j] > thresh or cm[i, j] > 0:
                    self.ax.text(j, i, format(cm[i, j], 'd'),
                               ha="center", va="center",
                               color="white" if cm[i, j] > thresh else "black",
                               fontsize=6)
        
        self._layout_chart()
        
        self.canvas.draw()
        
    def _plot_large_confusion_matrix(self, cm, class_names, title):
        """Plot large confusion matrix (>25 classes) - improved version"""
        logging.debug(f"Plotting large confusion matrix: {cm.shape}, labels: {len(class_names)}")
        
        cmap = plt.get_cmap(tok.MPL_CONFUSION_CMAP)
        im = self.ax.imshow(cm, interpolation='nearest', cmap=cmap)
        
        try:
            cbar = self.figure.colorbar(im, ax=self.ax, fraction=0.046, pad=0.04)
            cbar.set_label(_('visualization_widget.count_label'), rotation=270, labelpad=15)
        except Exception as e:
            logging.warning(f"Color bar addition failed: {e}")

        self.ax.set_title(title, fontsize=10, fontweight='bold')
        self.ax.set_xlabel(_('visualization_widget.predicted_axis_label'), fontsize=8)
        self.ax.set_ylabel(_('visualization_widget.true_axis_label'), fontsize=8)
        
        num_classes = len(class_names)
        if num_classes > 30:
            step = max(1, num_classes // 15)
            
            tick_indices = list(range(0, num_classes, step))
            if tick_indices[-1] != num_classes - 1:
                tick_indices.append(num_classes - 1)
            
            tick_labels = [class_names[i] for i in tick_indices]
            
            self.ax.set_xticks(tick_indices)
            self.ax.set_xticklabels(tick_labels, rotation=90, ha='center', fontsize=6)
            self.ax.set_yticks(tick_indices)
            self.ax.set_yticklabels(tick_labels, fontsize=6)
        else:
            tick_marks = np.arange(len(class_names))
            self.ax.set_xticks(tick_marks)
            self.ax.set_xticklabels(class_names, rotation=90, ha='center', fontsize=5)
            self.ax.set_yticks(tick_marks)
            self.ax.set_yticklabels(class_names, fontsize=5)
        
        self._layout_chart()
        
        self.canvas.draw() 
