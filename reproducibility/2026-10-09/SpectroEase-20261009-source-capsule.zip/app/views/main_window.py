from app.views.pca_explorer_dialog import PCAExplorerDialog
import logging
from app.ui import design_tokens as tok
from app.utils import ui_scaling as ui
from app.utils.ui_scaling import ui_scaling_manager
from app.utils.translator import translator, _
from app.utils.worker import Worker, run_heavy
import sys  # Import system module for accessing system features
import os  # Import operating system module for handling files and directories
import weakref
import json

  

import pandas as pd  # Import Pandas library for data processing
import numpy as np  # Import NumPy library for numerical calculations
import matplotlib.pyplot as plt  # Import Matplotlib library for plotting
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from PyQt5.QtCore import Qt, QSize, QThread, QTimer, pyqtSignal
from PyQt5.QtGui import QColor, QFont, QIcon, QKeySequence, QPalette, QPixmap
from PyQt5.QtWidgets import (
    QAbstractItemView, QAction, QApplication, QCheckBox, QComboBox, QDialog,
    QDialogButtonBox, QDockWidget, QDoubleSpinBox, QFileDialog, QFormLayout,
    QFrame, QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QLayout,
    QListWidget, QMainWindow, QMenu, QMessageBox, QProgressBar, QPushButton,
    QShortcut, QSizePolicy, QSlider, QSpinBox, QSplitter,
    QStatusBar, QTabWidget, QTableWidget, QTableWidgetItem, QTextEdit,
    QScrollArea, QToolBar, QVBoxLayout, QWidget
)
import matplotlib
matplotlib.use('Qt5Agg')

# Add project root directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))  # Get absolute path of current file
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))  # Get project root directory
if project_root not in sys.path:  # If project root directory is not in Python path
    sys.path.insert(0, project_root)  # Add project root directory to Python path

# Ensure app directory is in Python path
app_dir = os.path.dirname(os.path.dirname(current_dir))  # Get app directory
if app_dir not in sys.path:  # If app directory is not in Python path
    sys.path.insert(0, app_dir)  # Add app directory to Python path



from app.controllers.main_controller import MainController  # Import main controller
from app.services.feature_extraction_service import FeatureExtractionService
from app.views.data_view import DataPartitioningView  # Data partitioning view
from app.views.preprocessing_view import PreprocessingView
from app.views.feature_selection_view import FeatureSelectionView  # Import feature selection view
from app.views.feature_extraction_view import FeatureExtractionView  # Import feature extraction view (Editor Comment 4)
from app.views.modeling_view import ModelingView  # Import modeling view
from app.views.evaluation_view import EvaluationView  # Import evaluation view
from app.views.hyperparameter_optimization_view import HyperparameterOptimizationView  # Import hyperparameter optimization view
from app.views.llm_dialog import LLMDialog  # Import LLM dialog
from app.views.algorithm_onboarding_dialog import AlgorithmOnboardingDialog
from app.services.algorithm_onboarding_service import AlgorithmOnboardingService
from config.llm_config import LLMConfig  # Import LLM configuration
from app.services.llm_service import LLMService  # Import LLM service
from app.services.onnx_service import ONNXService  # Import ONNX service


# Import various plugins
from plugins.preprocessing.spectrum_converter import SpectrumConverter  # Import spectrum converter
from plugins.preprocessing.spectrum_visualizer import SpectrumVisualizer  # Import spectrum visualizer
from plugins.preprocessing.spectrum_preprocessor import SpectrumPreprocessor  # Import spectrum preprocessor
from plugins.feature_selection.spectrum_feature_extractor import SpectrumFeatureExtractor  # Import spectrum feature extractor
from plugins.modeling.quantitative_analyzer import QuantitativeAnalyzer  # Import quantitative analyzer
from plugins.modeling.qualitative_analyzer import QualitativeAnalyzer  # Import qualitative analyzer
from plugins.reporting.spectrum_report_generator import SpectrumReportGenerator  # Import spectrum report generator
from app.views.visualization_widget import VisualizationWidget  # Import visualization widget
from app.views.progress_dialog import ProgressDialog  # Import progress dialog
from app.models.preprocessing_model import PreprocessingModel  # Import preprocessing model
from app.ui import theme_manager

# The results panel needs a wider minimum than the workflow form. Switch to a
# vertical splitter before two-pane mode makes the chart horizontally scroll.
COMPACT_LAYOUT_BREAKPOINT = 1440
COMPACT_WINDOW_MIN_WIDTH = 720
COMPACT_WINDOW_MIN_HEIGHT = 480


def _cv_unavailable_transform_reason(feature_source, feature_data_options, data_model):
    """Return a reason when active GUI state was learned before inner CV."""
    selected_cache = (feature_data_options or {}).get('selected_features')
    has_selected_matrix = getattr(data_model, 'X_train_selected', None) is not None
    if feature_source == 'selected_features' or selected_cache is not None or has_selected_matrix:
        return (
            "PCA or feature selection was fitted before inner CV. Re-run analysis on the "
            "unselected train partition; fold-local selector integration is not available yet."
        )
    if feature_source == 'pca_features':
        return (
            "PCA features were computed before inner CV. Re-run analysis on the unselected "
            "train partition; fold-local PCA integration is not available yet."
        )
    return None


def _execute_fold_safe_cv(analyzer, X, y, task_type, cv_folds, sample_ids,
                          outer_test_sample_ids, unsafe_transform_reason=None,
                          physical_sample_ids=None, outer_test_physical_sample_ids=None,
                          group_ids=None, outer_test_group_ids=None,
                          group_validation=False):
    """Run analyzer CV with inner-fold state or return an explicit unavailable result."""
    if unsafe_transform_reason:
        return {
            'cv_available': False,
            'cv_unavailable_reason': unsafe_transform_reason,
            'cv_folds': cv_folds,
            'task_type': task_type,
        }
    if task_type == 'regression':
        return analyzer.cross_validate(
            X, y, n_splits=cv_folds, sample_ids=sample_ids,
            outer_test_sample_ids=outer_test_sample_ids,
            physical_sample_ids=physical_sample_ids,
            outer_test_physical_sample_ids=outer_test_physical_sample_ids,
            group_ids=group_ids, outer_test_group_ids=outer_test_group_ids,
            group_validation=group_validation,
        )
    return analyzer.cross_validate(
        X, y, cv=cv_folds, sample_ids=sample_ids,
        outer_test_sample_ids=outer_test_sample_ids,
        physical_sample_ids=physical_sample_ids,
        outer_test_physical_sample_ids=outer_test_physical_sample_ids,
        group_ids=group_ids, outer_test_group_ids=outer_test_group_ids,
        group_validation=group_validation,
    )

def get_result_table_height(screen_height):
    """Return scaled result table height tier based on available screen height."""
    if screen_height <= 800:
        return ui.scaled_px(tok.RESULT_TABLE_HEIGHT_SM)
    elif screen_height <= 950:
        return ui.scaled_px(tok.RESULT_TABLE_HEIGHT_MD)
    elif screen_height <= 1200:
        return ui.scaled_px(tok.RESULT_TABLE_HEIGHT_LG)
    else:
        return ui.scaled_px(tok.RESULT_TABLE_HEIGHT_XL)


class _ReportWorker(Worker):
    """Generate the PDF report off the UI thread (run_task must not touch QWidget/pyplot).

    Emits ``progress(int)`` so the UI progress dialog reflects real progress,
    ``result_ready(object)`` on successful completion, and ``error_occurred(str)``
    when the report generation fails.
    """

    progress = pyqtSignal(int)

    def __init__(self, spectra_data, preprocessing_results, feature_extraction_results,
                 analysis_results, title, parent=None, reproducibility_info=None, diagnostics=None):
        super().__init__(parent)
        self._args = (spectra_data, preprocessing_results, feature_extraction_results,
                      analysis_results)
        self._title = title
        self._reproducibility_info = reproducibility_info
        self._diagnostics = diagnostics

    def run(self):
        """Run the report generation and emit progress/status signals.

        Mirrors the base ``Worker.run`` logic while adding progress emissions so
        the modal progress dialog stays in sync with the work.
        """
        try:
            self.progress.emit(50)
            result = self.run_task()
            if self.is_cancelled():
                return
            self.progress.emit(90)
            self.result_ready.emit(result)
        except Exception as e:
            if not self.is_cancelled():
                self.error_occurred.emit(str(e))

    def run_task(self):
        return SpectrumReportGenerator().generate_report(*self._args, title=self._title,
            reproducibility_info=self._reproducibility_info, diagnostics=self._diagnostics)


class MainWindow(QMainWindow):  # Define main window class, inheriting from QMainWindow
    def __init__(self, translator, preprocessing_plugins, feature_selection_plugins, 
                 modeling_plugins, data_partitioning_plugins, llm_service):
        super().__init__()  # Call parent class constructor
        # Set application icon
        icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'logo.png')  # Get path to icon
        self.setWindowIcon(QIcon(icon_path))  # Set window icon
        # Initialize various plugins and services
        self.translator = translator  # Translator
        self.preprocessing_plugins = preprocessing_plugins  # Preprocessing plugins
        self.feature_selection_plugins = feature_selection_plugins  # Feature selection plugins
        self.modeling_plugins = modeling_plugins  # Modeling plugins
        self.data_partitioning_plugins = data_partitioning_plugins  # Data partitioning plugins
        self.llm_service = llm_service  # LLM service
        self.algorithm_onboarding_service = AlgorithmOnboardingService()
        self.onboarded_plugin_reports = {}
        self.onboarding_reload_errors = []
        self.reload_onboarded_plugins()
        self.onnx_service = ONNXService(save_directory="models")  # Initialize ONNX service
        self.spectra_data = None  # Initialize spectral data
        self.wavelengths = None  # Initialize wavelengths
        self.current_spectra = None  # Initialize current spectral data
        
        # Feature engineering data management (Editor Comment 4)
        self.feature_data_options = {
            'original': None,      # Original spectral data
            'preprocessed': None,  # Preprocessed data
            'pca_features': None,  # PCA features
            'selected_features': None  # Feature-selected data
        }
        self.current_feature_source = 'original'  # Current data source for modeling
        self.model_parameter_values = {}
        # Track top-level dialogs/windows with weak references to avoid memory leaks
        self.pca_dialogs = weakref.WeakValueDictionary()
        self.feature_vis_windows = weakref.WeakValueDictionary()
        self._responsive_ready = False
        self._window_handle = None
        self._watched_screen = None
        self._screen_refresh_pending = False
        # Initialize views.
        # NOTE: The following views are instantiated for algorithm registration
        # and signal routing but are not currently mounted in the main UI layout.
        # They are retained to preserve the custom-algorithm flow and controller
        # signal wiring. See issue U-9 for the planned cleanup/mount decision.
        self.preprocessing_view = PreprocessingView(self.preprocessing_plugins)
        self.feature_selection_view = FeatureSelectionView(self.feature_selection_plugins)
        self.feature_extraction_view = FeatureExtractionView()
        self.modeling_view = ModelingView(self.modeling_plugins)
        self.evaluation_view = EvaluationView()
        self.hyperopt_view = HyperparameterOptimizationView()
        # This view is mounted in the Data tab layout.
        self.data_partitioning_view = DataPartitioningView(self.data_partitioning_plugins)
        # Set application style
        self.set_application_style()  # Call method to set style
        self.init_ui()  # Initialize user interface
        self.controller = MainController(self, self.translator)  # Create main controller
        # Create a logger for the main window and pass it to the services.
        self.logger = logging.getLogger(self.__class__.__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)

        self.feature_extraction_service = FeatureExtractionService(
            data_model=self.controller.data_controller.data_model, 
            logger=self.logger,
            parent_view=self
        )
        self.connect_signals()  # Connect signals and slots
          
        self.scatter_method.currentTextChanged.connect(lambda _text: self.on_scatter_method_changed(self.scatter_method.currentData()))
          
        self.snv_parameters = {
            'center': True,
            'scale': True,
            'min_std': 1e-6,
            'axis': 1,
            'copy': True
        }

    def _track_toplevel_widget(self, ref_container, widget, max_count=5):
        """Track a top-level widget in a WeakValueDictionary and auto-cleanup on destroy."""
        # Ensure closing the widget destroys the underlying C++ object so the
        # WeakValueDictionary drops the reference automatically.
        widget.setAttribute(Qt.WA_DeleteOnClose, True)
        # If at capacity, close the oldest tracked widget.
        if len(ref_container) >= max_count:
            for key, oldest in list(ref_container.items()):
                if oldest is not None:
                    oldest.close()
                    break
        ref_container[id(widget)] = widget

    def set_application_style(self):
        """Set a consistent desktop analysis theme."""
        from app.ui import mpl_theme
        mpl_theme.apply_light_theme()
        self.setStyleSheet(theme_manager.get_app_stylesheet())

    def init_ui(self):
        """Initialize user interface"""
        self.setWindowTitle(_("main_window.title"))  # Set window title to "SpectroEase"
        
        # Apply tier-aware responsive sizing (compact / standard / wide / ultrawide)
        from app.utils.ui_scaling import ui_scaling_manager, scaled_px
        from app.ui import design_tokens as tok
        ui_scaling_manager.refresh()
        win_w, win_h = ui_scaling_manager.get_main_window_size(base_width=2000, base_height=1200)
        available = ui_scaling_manager.screen_info.get("available_geometry")
        min_w, min_h = self._minimum_size_for_available_geometry(available)
        self.setMinimumSize(min_w, min_h)
        self.resize(max(win_w, min_w), max(win_h, min_h))
        if available is not None:
            self.move(
                available.x() + max(0, (available.width() - self.width()) // 2),
                available.y() + max(0, (available.height() - self.height()) // 2),
            )
        
        # Set responsive font
        app_font = ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT)
        self.setFont(app_font)  # Apply this font to entire window
        
        # Scaling details are logged by ui_scaling.apply_responsive_sizing
        
        # Create a horizontal splitter to separate left and right content
        splitter = QSplitter(Qt.Horizontal)
        self._main_splitter = splitter
        self.setCentralWidget(splitter)  # Set splitter as central widget of main window
        # Group the workflow into tabs instead of one long scrolling column.
        self.workflow_tabs = QTabWidget()
        data_content = QWidget()
        preprocess_content = QWidget()
        model_content = QWidget()

        left_layout = QVBoxLayout(data_content)
        left_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))
        left_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))
        preprocess_panel_layout = QVBoxLayout(preprocess_content)
        preprocess_panel_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))
        preprocess_panel_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))
        model_layout = QVBoxLayout(model_content)
        model_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))
        model_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))

        self.workflow_tabs.addTab(data_content, _("main_window.data_tab_tab"))
        self.workflow_tabs.addTab(preprocess_content, _("main_window.preprocess_tab_tab"))
        self.workflow_tabs.addTab(model_content, _("main_window.model_tab_tab"))
        workflow_widths = ui_scaling_manager.get_workflow_width_budget(self.width())
        left_min_width = workflow_widths["min"]
        left_preferred_width = workflow_widths["preferred"]
        left_max_width = workflow_widths["max"]
        self.workflow_tabs.setMinimumWidth(left_min_width)
        self.workflow_tabs.setMaximumWidth(left_max_width)
        # Adjust size of left label and control
        min_label_width = ui.scaled_px(tok.LABEL_MIN_WIDTH)  # was 78
        min_combobox_width = ui.scaled_px(tok.COMBOBOX_MIN_WIDTH)  # was 132
        self.data_partitioning_group = self._create_data_partitioning_group()
        left_layout.addWidget(self.data_partitioning_group)
        # Preprocessing group - Create a group box to manage preprocessing-related widgets
        self.preprocessing_group = QGroupBox(_("main_window.preprocessing_group"))
        self.preprocessing_layout = QVBoxLayout()  # Create a vertical layout manager and save as instance variable
        self.preprocessing_layout.setSpacing(0)  # Completely remove spacing
        self.preprocessing_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS))
        # Create preprocessing tab
        self.preprocessing_tabs = QTabWidget()
        self.preprocessing_tabs.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.preprocessing_tabs.setContentsMargins(ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS))  # Leave 2px space on all sides
        # Compress spacing between Preprocessing and tabs
        self.preprocessing_layout.setSpacing(0)  # Completely remove spacing
        # Basic preprocessing tab
        basic_tab = QWidget()  # Create a new tab
        basic_layout = QVBoxLayout()  # Single column fits the workflow width budget
        basic_layout.setSpacing(ui.scaled_px(tok.SPACE_SM))
        basic_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))  # Add margins
        
        # Left column
        left_column = QVBoxLayout()
        left_column.setSpacing(ui.scaled_px(tok.SPACE_MD))
        
        # Right column  
        right_column = QVBoxLayout()
        right_column.setSpacing(ui.scaled_px(tok.SPACE_MD))
        
        # All components use uniform height setting
        row_height = ui.scaled_px(tok.ROW_HEIGHT_MD)  # was 25
        
        # --- Spike Removal Group (Left Column) ---
        despiking_group = QGroupBox(_("main_window.despiking_group"))
        despiking_outer_layout = QVBoxLayout()
        despiking_outer_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))
        despiking_outer_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))

        self.despiking_check = QCheckBox(_("main_window.despiking_check"))
        self.despiking_check.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))
        self.despiking_check.setChecked(False)  # Default off
        despiking_outer_layout.addWidget(self.despiking_check)

        self.despiking_params_container = QWidget()
        despiking_form_layout = QFormLayout(self.despiking_params_container)
        despiking_form_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))
        despiking_form_layout.setContentsMargins(0, ui.scaled_px(tok.SPACE_XS), 0, 0)
        despiking_form_layout.setLabelAlignment(Qt.AlignLeft)

        # Method selection
        self.despiking_method = QComboBox()
        for _text, _key in [(_("main_window.mad_item"), "MAD"),
            (_("main_window.local_z_score_item"), "Local Z-score")]:
            self.despiking_method.addItem(_text, _key)
        ui.set_min_height(self.despiking_method, tok.ROW_HEIGHT_BASE)
        ui.set_min_width(self.despiking_method, tok.CONTROL_MIN_WIDTH)
        despiking_form_layout.addRow(_("main_window.method_label"), self.despiking_method)

        # Window size
        self.despiking_window = QSpinBox()
        self.despiking_window.setRange(7, 15)
        self.despiking_window.setValue(7)
        self.despiking_window.setSingleStep(2)
        ui.set_min_height(self.despiking_window, tok.ROW_HEIGHT_BASE)
        ui.set_min_width(self.despiking_window, tok.CONTROL_MIN_WIDTH)
        despiking_form_layout.addRow(_("main_window.window_label"), self.despiking_window)

        # Threshold
        self.despiking_threshold = QDoubleSpinBox()
        self.despiking_threshold.setRange(3.0, 6.0)
        self.despiking_threshold.setValue(5.0)
        self.despiking_threshold.setSingleStep(0.5)
        ui.set_min_height(self.despiking_threshold, tok.ROW_HEIGHT_BASE)
        ui.set_min_width(self.despiking_threshold, tok.CONTROL_MIN_WIDTH)
        despiking_form_layout.addRow(_("main_window.threshold_label"), self.despiking_threshold)

        despiking_outer_layout.addWidget(self.despiking_params_container)
        despiking_group.setLayout(despiking_outer_layout)
        
        # Enable/disable parameters based on checkbox
        self.despiking_params_container.setEnabled(False)
        self.despiking_check.toggled.connect(self.despiking_params_container.setEnabled)
        
        left_column.addWidget(despiking_group)
        
        # --- Baseline Correction Group (Rebuilt with QFormLayout) ---
        baseline_group = QGroupBox(_("main_window.baseline_group"))
        baseline_outer_layout = QVBoxLayout()
        baseline_outer_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))
        baseline_outer_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))

        self.baseline_check = QCheckBox(_("main_window.baseline_check"))
        self.baseline_check.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))
        baseline_outer_layout.addWidget(self.baseline_check)

        self.baseline_params_container = QWidget()
        baseline_form_layout = QFormLayout(self.baseline_params_container)
        baseline_form_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))
        baseline_form_layout.setContentsMargins(0, ui.scaled_px(tok.SPACE_XS), 0, 0)
        baseline_form_layout.setLabelAlignment(Qt.AlignLeft)

        # Method selection for baseline correction
        self.baseline_method = QComboBox()
        for _text, _key in [(_("main_window.polynomial_item"), "Polynomial"),
            (_("main_window.als_item"), "ALS"),
            (_("main_window.airpls_item"), "airPLS")]:
            self.baseline_method.addItem(_text, _key)
        ui.set_min_height(self.baseline_method, tok.ROW_HEIGHT_BASE)
        ui.set_min_width(self.baseline_method, tok.CONTROL_MIN_WIDTH)
        baseline_form_layout.addRow(_("main_window.method_label"), self.baseline_method)

        self.poly_order = QSpinBox()
        self.poly_order.setRange(1, 10)
        ui.set_min_height(self.poly_order, tok.ROW_HEIGHT_BASE)
        ui.set_min_width(self.poly_order, tok.CONTROL_MIN_WIDTH)
        baseline_form_layout.addRow(_("main_window.polynomial_order_label"), self.poly_order)
        baseline_outer_layout.addWidget(self.baseline_params_container)
        baseline_group.setLayout(baseline_outer_layout)

        self.baseline_check.toggled.connect(self.baseline_params_container.setEnabled)
        self.baseline_params_container.setEnabled(False)

        left_column.addWidget(baseline_group)
        # --- Scatter Correction Group (Rebuilt with QFormLayout) ---
        scatter_group = QGroupBox(_("main_window.scatter_group"))
        scatter_outer_layout = QVBoxLayout()
        scatter_outer_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))
        scatter_outer_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))

        self.scatter_check = QCheckBox(_("main_window.scatter_check"))
        self.scatter_check.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))
        scatter_outer_layout.addWidget(self.scatter_check)

        self.scatter_params_container = QWidget()
        scatter_form_layout = QFormLayout(self.scatter_params_container)
        scatter_form_layout.setSpacing(ui.scaled_px(tok.SPACE_MD))
        scatter_form_layout.setContentsMargins(0, ui.scaled_px(tok.SPACE_XS), 0, 0)
        scatter_form_layout.setLabelAlignment(Qt.AlignLeft)

        self.scatter_method = QComboBox()
        for _text, _key in [(_("main_window.msc_item"), "MSC"),
            (_("main_window.snv_item"), "SNV"),
            (_("main_window.emsc_item"), "EMSC"),
            (_("main_window.rnv_item"), "RNV"),
            (_("main_window.osc_item"), "OSC")]:
            self.scatter_method.addItem(_text, _key)
        osc_index = self.scatter_method.findData('OSC')
        self.scatter_method.model().item(osc_index).setEnabled(False)
        self.scatter_method.setItemData(osc_index, 'OSC requires training targets and a fitted-state workflow, unavailable in this preprocessing route.', Qt.ToolTipRole)
        ui.set_min_height(self.scatter_method, tok.ROW_HEIGHT_BASE)
        ui.set_min_width(self.scatter_method, tok.CONTROL_MIN_WIDTH)

        self.settings_btn = QPushButton(_("main_window.settings_btn"))
        ui.set_min_height(self.settings_btn, tok.ROW_HEIGHT_BASE)
        ui.set_min_width(self.settings_btn, tok.BUTTON_MIN_WIDTH)
        self.settings_btn.clicked.connect(self.open_scatter_parameters)   
        scatter_method_layout = QHBoxLayout()
        scatter_method_layout.setContentsMargins(0, 0, 0, 0)
        scatter_method_layout.addWidget(self.scatter_method)
        scatter_method_layout.addWidget(self.settings_btn)
        scatter_method_layout.addStretch()
        scatter_form_layout.addRow(_("main_window.method_label"), scatter_method_layout)
        scatter_outer_layout.addWidget(self.scatter_params_container)
        scatter_group.setLayout(scatter_outer_layout)
        self.scatter_check.toggled.connect(self.scatter_params_container.setEnabled)
        self.scatter_params_container.setEnabled(False)
        right_column.addWidget(scatter_group)
          
        smooth_group = QGroupBox(_("main_window.smooth_group"))
        smooth_outer_layout = QVBoxLayout()   
        smooth_outer_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))
        smooth_outer_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))

          
        self.smooth_check = QCheckBox(_("main_window.smooth_check"))
        self.smooth_check.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))
        ui.set_min_height(self.smooth_check, tok.ROW_HEIGHT_BASE)
        smooth_outer_layout.addWidget(self.smooth_check)

          
        self.smoothing_params_container = QWidget()   
        smooth_form_layout = QFormLayout(self.smoothing_params_container)
        smooth_form_layout.setSpacing(ui.scaled_px(tok.SPACE_MD))
        smooth_form_layout.setContentsMargins(0, ui.scaled_px(tok.SPACE_XS), 0, 0)   
        smooth_form_layout.setLabelAlignment(Qt.AlignLeft)   

          
        self.smooth_method = QComboBox()
        for _text, _key in [(_("main_window.s_golay_item"), "S-Golay"),
            (_("main_window.moving_avg_item"), "Moving Avg"),
            (_("main_window.median_item"), "Median"),
            (_("main_window.wavelet_item"), "Wavelet")]:
            self.smooth_method.addItem(_text, _key)
        ui.set_min_height(self.smooth_method, tok.ROW_HEIGHT_BASE)
        ui.set_min_width(self.smooth_method, tok.CONTROL_MIN_WIDTH)
        smooth_form_layout.addRow(_("main_window.method_label"), self.smooth_method)
          
        self.window_size = QSpinBox()
        self.window_size.setRange(3, 51)
        self.window_size.setValue(11)
        self.window_size.setSingleStep(2)
        ui.set_min_height(self.window_size, tok.ROW_HEIGHT_BASE)
        ui.set_min_width(self.window_size, tok.CONTROL_MIN_WIDTH)
        smooth_form_layout.addRow(_("main_window.window_label"), self.window_size)
          
        self.poly_order_label = QLabel(_("main_window.poly_order_label"))
        self.smooth_poly_order = QSpinBox()
        self.smooth_poly_order.setRange(2, 5)
        self.smooth_poly_order.setValue(2)
        ui.set_min_height(self.smooth_poly_order, tok.ROW_HEIGHT_BASE)
        ui.set_min_width(self.smooth_poly_order, tok.CONTROL_MIN_WIDTH)
        self.poly_order_row = smooth_form_layout.addRow(self.poly_order_label, self.smooth_poly_order)

        smooth_outer_layout.addWidget(self.smoothing_params_container)
        smooth_group.setLayout(smooth_outer_layout)
          
        self.smooth_check.toggled.connect(self.smoothing_params_container.setEnabled)
        self.smooth_method.currentTextChanged.connect(lambda _text: self._toggle_poly_order_visibility(self.smooth_method.currentData()))

          
        self.smoothing_params_container.setEnabled(False)
        self._toggle_poly_order_visibility(self.smooth_method.currentData())

        right_column.addWidget(smooth_group)

        # Add columns to basic layout
        basic_layout.addLayout(left_column)
        basic_layout.addLayout(right_column)
        basic_tab.setLayout(basic_layout)
        basic_tab.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.preprocessing_tabs.addTab(basic_tab, _("main_window.basic_tab"))
          
        advanced_tab = QWidget()    
        advanced_layout = QVBoxLayout()    
        advanced_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))    
        advanced_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))    
          
        standardize_group = QGroupBox(_("main_window.standardize_group"))
        standardize_layout = QVBoxLayout()    
        standardize_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))    
        standardize_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS))    
        self.standardize_check = QCheckBox(_("main_window.standardize_check"))    
        self.standardize_check.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))    
        standardize_params = QHBoxLayout()    
        standardize_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))    
        std_method_label = QLabel(_("main_window.method_label"))    
        std_method_label.setMinimumWidth(min_label_width)    
        std_method_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)    
        standardize_params.addWidget(std_method_label)    
        self.standardize_method = QComboBox()    
        for _text, _key in [(_("main_window.z_score_item"), "Z-Score"),
            (_("main_window.robust_item"), "Robust"),
            (_("main_window.min_max_item"), "Min-Max")]:
            self.standardize_method.addItem(_text, _key)    
        self.standardize_method.setMinimumWidth(min_combobox_width)    
        standardize_params.addWidget(self.standardize_method)    
        standardize_layout.addWidget(self.standardize_check)    
        standardize_layout.addLayout(standardize_params)    
        standardize_group.setLayout(standardize_layout)    
        advanced_layout.addWidget(standardize_group)    
          
        norm_group = QGroupBox(_("main_window.norm_group"))
        norm_layout = QVBoxLayout()    
        norm_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))    
        norm_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS))    
        self.norm_check = QCheckBox(_("main_window.norm_check"))    
        self.norm_check.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))    
        norm_params = QHBoxLayout()    
        norm_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))    
        norm_method_label = QLabel(_("main_window.method_label"))    
        norm_method_label.setMinimumWidth(min_label_width)    
        norm_method_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)    
        norm_params.addWidget(norm_method_label)    
        self.norm_method = QComboBox()    
        for _text, _key in [(_("main_window.min_max_item"), "Min-Max"),
            (_("main_window.vector_item"), "Vector"),
            (_("main_window.area_item"), "Area"),
            (_("main_window.maximum_item"), "Maximum")]:
            self.norm_method.addItem(_text, _key)    
        self.norm_method.setMinimumWidth(min_combobox_width)    
        norm_params.addWidget(self.norm_method)    
        norm_layout.addWidget(self.norm_check)    
        norm_layout.addLayout(norm_params)    
        norm_group.setLayout(norm_layout)    
        advanced_layout.addWidget(norm_group)    
          
        derivative_group = QGroupBox(_("main_window.derivative_group"))
        derivative_layout = QVBoxLayout()    
        derivative_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))    
        derivative_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS), ui.scaled_px(tok.SPACE_XXS))    
        self.derivative_check = QCheckBox(_("main_window.derivative_check"))    
        self.derivative_check.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))    
        derivative_params = QHBoxLayout()    
        derivative_params.setSpacing(ui.scaled_px(tok.SPACE_XXS))    
        derivative_order_label = QLabel(_("main_window.derivative_order_label"))    
        derivative_order_label.setMinimumWidth(min_label_width)    
        derivative_order_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)    
        derivative_params.addWidget(derivative_order_label)    
        self.derivative_order = QSpinBox()    
        self.derivative_order.setRange(1, 3)    
        ui.set_min_width(self.derivative_order, 60)    
        derivative_params.addWidget(self.derivative_order)    
        derivative_layout.addWidget(self.derivative_check)    
        derivative_layout.addLayout(derivative_params)    
        derivative_group.setLayout(derivative_layout)    
        advanced_layout.addWidget(derivative_group)    
        advanced_tab.setLayout(advanced_layout)
        advanced_tab.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.preprocessing_tabs.addTab(advanced_tab, _("main_window.advanced_tab"))
          
        special_tab = QWidget()    
        special_layout = QVBoxLayout()    
        special_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))    
        special_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))    
          
        special_form_layout = QVBoxLayout()
        special_form_layout.setSpacing(ui.scaled_px(tok.SPACE_SM))
          
        left_column = QVBoxLayout()    
        left_column.setSpacing(ui.scaled_px(tok.SPACE_SM))    
          
        outlier_group = QGroupBox(_("main_window.outlier_group"))
        outlier_layout = QVBoxLayout()    
        outlier_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))    
        outlier_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))    
        self.outlier_check = QCheckBox(_("main_window.outlier_check"))    
        self.outlier_check.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))    
        outlier_params = QHBoxLayout()    
        outlier_params.setSpacing(ui.scaled_px(tok.SPACE_XS))    
        outlier_threshold_label = QLabel(_("main_window.threshold_label"))    
        outlier_threshold_label.setMinimumWidth(min_label_width)    
        outlier_threshold_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)    
        outlier_threshold_label.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))    
        outlier_params.addWidget(outlier_threshold_label)    
        self.outlier_threshold = QDoubleSpinBox()    
        self.outlier_threshold.setRange(1.0, 5.0)    
        self.outlier_threshold.setValue(3.0)    
        self.outlier_threshold.setSingleStep(0.1)    
        ui.set_min_width(self.outlier_threshold, 60)    
        outlier_params.addWidget(self.outlier_threshold)    
        outlier_layout.addWidget(self.outlier_check)    
        outlier_layout.addLayout(outlier_params)    
        outlier_group.setLayout(outlier_layout)    
        left_column.addWidget(outlier_group)    
          
        denoise_group = QGroupBox(_("main_window.denoise_group"))
        denoise_layout = QVBoxLayout()    
        denoise_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))    
        denoise_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))    
        self.denoise_check = QCheckBox(_("main_window.denoise_check"))    
        self.denoise_check.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))    
        denoise_params = QHBoxLayout()    
        denoise_params.setSpacing(ui.scaled_px(tok.SPACE_XS))    
        denoise_strength_label = QLabel(_("main_window.denoise_strength_label"))    
        denoise_strength_label.setMinimumWidth(min_label_width)    
        denoise_strength_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)    
        denoise_strength_label.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))    
        denoise_params.addWidget(denoise_strength_label)    
        self.denoise_strength = QDoubleSpinBox()    
        self.denoise_strength.setRange(0.0, 1.0)
        self.denoise_check.setToolTip('Approximate moving-average blend; strength 0 preserves input and 1 uses the smoothed spectrum.')    
        self.denoise_strength.setValue(0.5)    
        self.denoise_strength.setSingleStep(0.1)    
        ui.set_min_width(self.denoise_strength, 60)    
        denoise_params.addWidget(self.denoise_strength)    
        denoise_layout.addWidget(self.denoise_check)    
        denoise_layout.addLayout(denoise_params)    
        denoise_group.setLayout(denoise_layout)    
        left_column.addWidget(denoise_group)    
        special_form_layout.addLayout(left_column)    
          
        right_column = QVBoxLayout()    
        right_column.setSpacing(ui.scaled_px(tok.SPACE_SM))    
          
        alignment_group = QGroupBox(_("main_window.alignment_group"))
        alignment_layout = QVBoxLayout()    
        alignment_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))    
        alignment_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))    
        self.alignment_check = QCheckBox(_("main_window.alignment_check"))    
        self.alignment_check.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))    
        alignment_params = QHBoxLayout()    
        alignment_params.setSpacing(ui.scaled_px(tok.SPACE_XS))    
        alignment_method_label = QLabel(_("main_window.method_label"))    
        alignment_method_label.setMinimumWidth(min_label_width)    
        alignment_method_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)    
        alignment_method_label.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))    
        alignment_params.addWidget(alignment_method_label)    
        self.alignment_method = QComboBox()    
        for _text, _key in [(_("main_window.dtw_item"), "DTW"),
            (_("main_window.cow_item"), "COW"),
            (_("main_window.ics_item"), "ICS"),
            (_("main_window.pafft_item"), "PAFFT")]:
            self.alignment_method.addItem(_text, _key)    
        for alignment_key in ('COW', 'ICS'):
            index = self.alignment_method.findData(alignment_key)
            self.alignment_method.setItemText(index, self.alignment_method.itemText(index) + ' (approximate)')
            self.alignment_method.setItemData(index, 'Approximate local segment shifting; does not implement the original full method.', Qt.ToolTipRole)
        pafft_index = self.alignment_method.findData('PAFFT')
        if pafft_index >= 0:
            self.alignment_method.model().item(pafft_index).setEnabled(False)
            self.alignment_method.setItemData(pafft_index, 'PAFFT is not implemented in this version.', Qt.ToolTipRole)
        self.alignment_method.setMinimumWidth(min_combobox_width)    
        alignment_params.addWidget(self.alignment_method)    
        alignment_layout.addWidget(self.alignment_check)    
        alignment_layout.addLayout(alignment_params)    
        alignment_group.setLayout(alignment_layout)    
        right_column.addWidget(alignment_group)    
          
        reference_group = QGroupBox(_("main_window.reference_group"))
        reference_layout = QVBoxLayout()    
        reference_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))    
        reference_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))    
        reference_method_layout = QHBoxLayout()    
        reference_method_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))    
        reference_method_label = QLabel(_("main_window.method_label"))    
        reference_method_label.setMinimumWidth(min_label_width)    
        reference_method_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)    
        reference_method_label.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))    
        reference_method_layout.addWidget(reference_method_label)    
        self.reference_method = QComboBox()    
        for _text, _key in [(_("main_window.mean_item"), "Mean"),
            (_("main_window.med_item"), "Med"),
            (_("main_window.max_item"), "Max"),
            (_("main_window.first_item"), "First")]:
            self.reference_method.addItem(_text, _key)    
        self.reference_method.setEnabled(False)
        self.reference_method.setToolTip('Standalone reference selection is not implemented; MSC/EMSC parameters select their own reference.')
        self.reference_method.setMinimumWidth(min_combobox_width)    
        reference_method_layout.addWidget(self.reference_method)    
        reference_layout.addLayout(reference_method_layout)    
        reference_group.setLayout(reference_layout)    
        right_column.addWidget(reference_group)    
        special_form_layout.addLayout(right_column)    
        special_layout.addLayout(special_form_layout)
        
        # Raman Specific Preprocessing Placeholders
        raman_group = QGroupBox(_("main_window.raman_group"))
        raman_layout = QVBoxLayout()
        raman_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))
        raman_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))
        
        # Wavelength calibration placeholder
        wavelength_layout = QVBoxLayout()
        self.wavelength_calib_check = QCheckBox(_("main_window.wavelength_calib_check"))
        self.wavelength_calib_check.setChecked(False)
        self.wavelength_calib_check.setEnabled(False)
        self.wavelength_calib_check.setToolTip('Calibration is not implemented in this version.')
        wavelength_layout.addWidget(self.wavelength_calib_check)
        
        self.wavelength_calib_file_btn = QPushButton(_("main_window.wavelength_calib_file_btn"))
        self.wavelength_calib_file_btn.setEnabled(False)
        ui.set_min_width(self.wavelength_calib_file_btn, tok.CONTROL_MIN_WIDTH)
        wavelength_layout.addWidget(self.wavelength_calib_file_btn)
        raman_layout.addLayout(wavelength_layout)
        
        # Intensity calibration placeholder  
        intensity_layout = QVBoxLayout()
        self.intensity_calib_check = QCheckBox(_("main_window.intensity_calib_check"))
        self.intensity_calib_check.setChecked(False)
        self.intensity_calib_check.setEnabled(False)
        self.intensity_calib_check.setToolTip('Calibration is not implemented in this version.')
        intensity_layout.addWidget(self.intensity_calib_check)
        
        self.intensity_calib_file_btn = QPushButton(_("main_window.wavelength_calib_file_btn"))
        self.intensity_calib_file_btn.setEnabled(False)
        ui.set_min_width(self.intensity_calib_file_btn, tok.CONTROL_MIN_WIDTH)
        intensity_layout.addWidget(self.intensity_calib_file_btn)
        raman_layout.addLayout(intensity_layout)
        
        # Info label
        raman_info_label = QLabel(_("main_window.raman_info_label"))
        raman_info_label.setWordWrap(True)
        raman_info_label.setStyleSheet(f"color: {tok.COLOR_TEXT_SECONDARY}; font-style: italic;")
        raman_layout.addWidget(raman_info_label)
        
        # Connect checkboxes to enable/disable buttons
        self.wavelength_calib_check.toggled.connect(self.wavelength_calib_file_btn.setEnabled)
        self.intensity_calib_check.toggled.connect(self.intensity_calib_file_btn.setEnabled)
        
        raman_group.setLayout(raman_layout)
        special_layout.addWidget(raman_group)
        
        special_tab.setLayout(special_layout)
        special_tab.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.preprocessing_tabs.addTab(special_tab, _("main_window.special_tab"))
        self.preprocessing_layout.addWidget(self.preprocessing_tabs, stretch=1)
          
        checkboxes = [
            self.despiking_check, self.baseline_check, self.scatter_check, self.smooth_check, 
            self.standardize_check, self.norm_check, self.derivative_check,
            self.outlier_check, self.denoise_check, self.alignment_check,
            self.wavelength_calib_check, self.intensity_calib_check
        ]
        for checkbox in checkboxes:    
            checkbox.setFont(ui.get_scaled_font("Segoe UI", tok.BASE_FONT_PT))    
              
            checkbox.setStyleSheet(f"QCheckBox {{ padding: {ui.scaled_px(tok.SPACE_XXS)}px; margin: {ui.scaled_px(tok.SPACE_XXS)}px; }}")    
          
        preview_group = QGroupBox(_("main_window.preview_group"))
        preview_layout = QHBoxLayout()
        preview_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))
        preview_layout.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))

        display_label = QLabel(_("main_window.display_label"))
        ui.set_min_height(display_label, tok.ROW_HEIGHT_BASE)
        preview_layout.addWidget(display_label)
        self.preview_mode = QComboBox()
        for _text, _key in [(_("main_window.original_item"), "Original"),
            (_("main_window.processed_item"), "Processed"),
            (_("main_window.comparison_item"), "Comparison")]:
            self.preview_mode.addItem(_text, _key)
        ui.set_min_height(self.preview_mode, tok.ROW_HEIGHT_BASE)
        ui.set_min_width(self.preview_mode, tok.CONTROL_MIN_WIDTH_MD)
        preview_layout.addWidget(self.preview_mode)

        preview_btn = QPushButton(_("data_quality_dialog.preview_button"))
        ui.set_min_height(preview_btn, tok.ROW_HEIGHT_BASE)
        preview_btn.clicked.connect(self.preview_preprocessing)
        preview_layout.addWidget(preview_btn)
        preview_group.setLayout(preview_layout)
        self.preprocessing_layout.addWidget(preview_group)

        # Verified user algorithms use the live controller/registry path. Keep
        # this selector compact and separate from the built-in parameter tabs.
        self.verified_algorithm_group = QGroupBox("Verified custom preprocessing")
        verified_layout = QVBoxLayout(self.verified_algorithm_group)
        verified_layout.setSpacing(ui.scaled_px(tok.SPACE_XXS))
        verified_layout.setContentsMargins(
            ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS),
            ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS),
        )
        verified_note = QLabel(
            "This selector lists verified stateless plugins. Use Verified fitted workflow for training-state algorithms."
        )
        verified_note.setWordWrap(True)
        verified_layout.addWidget(verified_note)

        onboarding_row = QHBoxLayout()
        self.open_algorithm_onboarding_button = QPushButton("Add / verify algorithm…")
        self.open_algorithm_onboarding_button.setObjectName("openAlgorithmOnboardingButton")
        self.open_algorithm_onboarding_button.clicked.connect(self.show_algorithm_onboarding_dialog)
        ui.set_min_height(self.open_algorithm_onboarding_button, tok.ROW_HEIGHT_BASE)
        onboarding_row.addWidget(self.open_algorithm_onboarding_button)
        self.verified_workflow_button = QPushButton("Verified fitted workflow…")
        self.verified_workflow_button.setObjectName("openVerifiedWorkflowButton")
        self.verified_workflow_button.clicked.connect(self.show_verified_workflow_dialog)
        verified_layout.addWidget(self.verified_workflow_button)
        self.refresh_onboarded_plugins_button = QPushButton("Reload accepted")
        self.refresh_onboarded_plugins_button.setObjectName("reloadAcceptedPluginsButton")
        self.refresh_onboarded_plugins_button.clicked.connect(self.reload_onboarded_plugins)
        ui.set_min_height(self.refresh_onboarded_plugins_button, tok.ROW_HEIGHT_BASE)
        onboarding_row.addWidget(self.refresh_onboarded_plugins_button)
        verified_layout.addLayout(onboarding_row)

        self.onboarded_plugin_combo = QComboBox()
        self.onboarded_plugin_combo.setObjectName("verifiedPreprocessingSelector")
        self.onboarded_plugin_combo.setMinimumContentsLength(12)
        verified_layout.addWidget(self.onboarded_plugin_combo)
        self.onboarded_plugin_params = QLineEdit("{}")
        self.onboarded_plugin_params.setObjectName("verifiedPreprocessingParameters")
        self.onboarded_plugin_params.setPlaceholderText("JSON parameter values, for example: {\"scale\": 1.0}")
        self.onboarded_plugin_params.setToolTip("Parameter values are checked against the accepted typed schema.")
        verified_layout.addWidget(self.onboarded_plugin_params)
        self.onboarded_plugin_status = QLabel("No accepted stateless preprocessing plugins loaded.")
        self.onboarded_plugin_status.setObjectName("verifiedPreprocessingStatus")
        self.onboarded_plugin_status.setWordWrap(True)
        verified_layout.addWidget(self.onboarded_plugin_status)
        self.apply_onboarded_plugin_button = QPushButton("Apply selected verified plugin")
        self.apply_onboarded_plugin_button.setObjectName("applyVerifiedPreprocessingButton")
        self.apply_onboarded_plugin_button.setProperty("role", "primary")
        self.apply_onboarded_plugin_button.clicked.connect(self.apply_onboarded_plugin)
        self.apply_onboarded_plugin_button.setEnabled(False)
        ui.set_min_height(self.apply_onboarded_plugin_button, tok.ROW_HEIGHT_BASE)
        verified_layout.addWidget(self.apply_onboarded_plugin_button)
        self.onboarded_plugin_combo.currentIndexChanged.connect(self._onboarded_plugin_selection_changed)
        self.preprocessing_layout.addWidget(self.verified_algorithm_group)
        self.refresh_onboarded_plugin_selector()

        button_group = QHBoxLayout()
        button_group.setSpacing(ui.scaled_px(tok.SPACE_XS))
        button_group.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))
        self.preprocess_btn = QPushButton(_("main_window.preprocess_btn"))
        self.preprocess_btn.setProperty("role", "primary")
        ui.set_min_height(self.preprocess_btn, tok.ROW_HEIGHT_MD)
        self.preprocess_btn.clicked.connect(self.apply_preprocessing)
        button_group.addWidget(self.preprocess_btn)
        reset_btn = QPushButton(_("main_window.reset_btn"))
        reset_btn.setProperty("role", "secondary")
        ui.set_min_height(reset_btn, tok.ROW_HEIGHT_BASE)
        reset_btn.clicked.connect(self.reset_preprocessing_params)
        button_group.addWidget(reset_btn)
        help_btn = QPushButton(_("main_window.help_btn"))
        help_btn.setProperty("role", "quiet")
        ui.set_min_height(help_btn, tok.ROW_HEIGHT_BASE)
        help_btn.clicked.connect(self.show_preprocessing_help)
        button_group.addWidget(help_btn)
        self.preprocessing_layout.addLayout(button_group)
        self.preprocessing_group.setLayout(self.preprocessing_layout)
        # Preserve control row minimums; the surrounding scroll area handles overflow.
        for container in [self.preprocessing_group, *self.preprocessing_group.findChildren(QWidget)]:
            child_layout = container.layout()
            if child_layout is not None:
                child_layout.setSizeConstraint(QLayout.SetMinimumSize)
        preprocess_panel_layout.addWidget(self.preprocessing_group)

        button_group.setContentsMargins(ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS), ui.scaled_px(tok.SPACE_XS))
        self.preprocessing_layout.setSpacing(0)

        ui.set_min_height(self.preprocess_btn, tok.ROW_HEIGHT_MD)
        ui.set_min_height(reset_btn, tok.ROW_HEIGHT_MD)
          
        # Feature Engineering Group (restore original design style)
        self.feature_group = self._create_feature_group()

        # Method selection (keep previous style, simplified to a dropdown)

        # Parameter input
        # Feature controls are created in _create_feature_group().

        # Apply button (keep original style)
        model_layout.addWidget(self.feature_group)
          
        self.analysis_group = self._create_analysis_group(
            min_label_width=min_label_width,
            min_combobox_width=min_combobox_width,
            row_height=row_height,
        )
          
        # Analysis controls are created in _create_analysis_group().
          
          
        model_layout.addWidget(self.analysis_group)
          
        self.preprocessing_group.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.data_partitioning_group.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.feature_group.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self.analysis_group.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
          
        report_btn = QPushButton(_("main_window.report_btn"))
        report_btn.setProperty("role", "secondary")
        ui.set_min_height(report_btn, tok.ROW_HEIGHT_BASE)
        report_btn.clicked.connect(self.generate_report)
        model_layout.addWidget(report_btn)
        self.export_results_btn = QPushButton('Export Results CSV / Excel…')
        self.export_results_btn.setProperty('role', 'secondary')
        self.export_results_btn.clicked.connect(self.export_analysis_results)
        model_layout.addWidget(self.export_results_btn)
        self.export_onnx_btn = QPushButton('Export Fitted Model to ONNX…')
        self.export_onnx_btn.setProperty('role', 'secondary')
        self.export_onnx_btn.setToolTip(
            'Save the fitted analyzer transforms and estimator to ONNX; '
            'see the contract JSON for the required input representation.'
        )
        self.export_onnx_btn.clicked.connect(self.export_fitted_analyzer_onnx)
        model_layout.addWidget(self.export_onnx_btn)
        self.diagnostics_btn = QPushButton('Model Diagnostics…')
        self.diagnostics_btn.clicked.connect(self.show_model_diagnostics)
        model_layout.addWidget(self.diagnostics_btn)

        right_panel = self._create_results_panel()

        # Keep both panes reachable when the Qt logical work area is narrow or
        # short.  In compact mode the splitter becomes vertical; these scroll
        # areas preserve access to the full workflow and chart controls.
        self.workflow_scroll_area = QScrollArea()
        self.workflow_scroll_area.setWidgetResizable(True)
        self.workflow_scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.workflow_scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.workflow_scroll_area.setWidget(self.workflow_tabs)

        self.results_scroll_area = QScrollArea()
        self.results_scroll_area.setWidgetResizable(True)
        self.results_scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.results_scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.results_scroll_area.setWidget(right_panel)

        splitter.addWidget(self.workflow_scroll_area)
        splitter.addWidget(self.results_scroll_area)

        left_initial_width = max(left_min_width, min(left_preferred_width, left_max_width))
        splitter.setSizes([left_initial_width, max(1, self.width() - left_initial_width)])
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(ui.scaled_px(tok.SPACE_SM))
        splitter.setStyleSheet(
            f"QSplitter::handle {{ background: {tok.COLOR_BG_ALT}; }}"
        )

        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 4)
          
        self.setup_toolbar()

        self.setup_menu_bar()

        self.setup_status_bar()
          
        self.setup_shortcuts()    
          
        self.setup_operation_history()    
          
        self.update_analysis_methods(self.analysis_type.currentData())
        self._responsive_ready = True
        self._update_responsive_layout(force=True)

    def _minimum_size_for_available_geometry(self, available):
        """Choose a usable minimum and cap it to the current logical work area."""
        if available is None:
            return COMPACT_WINDOW_MIN_WIDTH, COMPACT_WINDOW_MIN_HEIGHT

        # A compact layout is available even on a large monitor: below the
        # splitter breakpoint the two panes stack and both can scroll.  Keep a
        # modest shell floor, then cap it to the current logical work area.
        base_width = COMPACT_WINDOW_MIN_WIDTH
        base_height = COMPACT_WINDOW_MIN_HEIGHT
        margin = ui.scaled_px(tok.DIALOG_SCREEN_MARGIN)
        usable_width = max(1, available.width() - margin)
        usable_height = max(1, available.height() - margin)
        return min(base_width, usable_width), min(base_height, usable_height)

    def _current_qt_screen(self):
        """Resolve the QScreen belonging to this window, falling back to primary."""
        if self._window_handle is not None:
            screen = self._window_handle.screen()
            if screen is not None:
                return screen
        screen_getter = getattr(self, "screen", None)
        if callable(screen_getter):
            screen = screen_getter()
            if screen is not None:
                return screen
        app = QApplication.instance()
        return app.primaryScreen() if app is not None else None

    def _bind_screen_signals(self, screen):
        if screen is self._watched_screen:
            return
        if self._watched_screen is not None:
            for name in ("availableGeometryChanged", "geometryChanged", "logicalDotsPerInchChanged"):
                signal = getattr(self._watched_screen, name, None)
                if signal is not None:
                    try:
                        signal.disconnect(self._on_screen_metrics_changed)
                    except (TypeError, RuntimeError):
                        pass
        self._watched_screen = screen
        if screen is not None:
            for name in ("availableGeometryChanged", "geometryChanged", "logicalDotsPerInchChanged"):
                signal = getattr(screen, name, None)
                if signal is not None:
                    try:
                        signal.connect(self._on_screen_metrics_changed)
                    except (TypeError, RuntimeError):
                        pass

    def _connect_window_screen_signals(self):
        handle_getter = getattr(self, "windowHandle", None)
        handle = handle_getter() if callable(handle_getter) else None
        if handle is not None and handle is not self._window_handle:
            if self._window_handle is not None:
                try:
                    self._window_handle.screenChanged.disconnect(self._on_window_screen_changed)
                except (AttributeError, TypeError, RuntimeError):
                    pass
            self._window_handle = handle
            try:
                handle.screenChanged.connect(self._on_window_screen_changed)
            except (AttributeError, TypeError, RuntimeError):
                pass
        self._bind_screen_signals(self._current_qt_screen())

    def _on_window_screen_changed(self, screen):
        self._bind_screen_signals(screen)
        self._refresh_screen_context(screen=screen, clamp_window=True)

    def _on_screen_metrics_changed(self, *_args):
        self._refresh_screen_context(screen=self._watched_screen, clamp_window=True)

    def _schedule_screen_refresh(self):
        if self._screen_refresh_pending:
            return
        self._screen_refresh_pending = True
        QTimer.singleShot(0, self._run_scheduled_screen_refresh)

    def _run_scheduled_screen_refresh(self):
        self._screen_refresh_pending = False
        screen = self._current_qt_screen()
        screen_changed = screen is not self._watched_screen
        self._connect_window_screen_signals()
        self._refresh_screen_context(screen=screen, clamp_window=screen_changed)

    def _refresh_screen_context(self, screen=None, clamp_window=False):
        """Refresh logical screen metrics and screen-dependent main layout."""
        if screen is None:
            screen = self._current_qt_screen()
        if screen is None:
            return

        ui_scaling_manager.refresh_for_screen(screen)
        self._bind_screen_signals(screen)
        available = screen.availableGeometry()
        min_w, min_h = self._minimum_size_for_available_geometry(available)
        self.setMinimumSize(min_w, min_h)

        if clamp_window and self.isVisible():
            usable_w = max(min_w, available.width() - ui.scaled_px(tok.DIALOG_SCREEN_MARGIN))
            usable_h = max(min_h, available.height() - ui.scaled_px(tok.DIALOG_SCREEN_MARGIN))
            new_w = min(max(self.width(), min_w), usable_w)
            new_h = min(max(self.height(), min_h), usable_h)
            if (new_w, new_h) != (self.width(), self.height()):
                self.resize(new_w, new_h)
            x = min(max(self.x(), available.x()), available.x() + max(0, available.width() - self.width()))
            y = min(max(self.y(), available.y()), available.y() + max(0, available.height() - self.height()))
            if (x, y) != (self.x(), self.y()):
                self.move(x, y)

        if hasattr(self, "result_table"):
            table_height = ui_scaling_manager.get_table_height_for_height(available.height())
            self.result_table.setMinimumHeight(table_height)
            self.result_table.setMaximumHeight(max(table_height, ui.scaled_px(tok.RESULT_TABLE_HEIGHT_LG)))
        self._update_responsive_layout()

    def _update_responsive_layout(self, force=False):
        """Switch the main splitter between side-by-side and scrollable compact layouts."""
        splitter = getattr(self, "_main_splitter", None)
        if splitter is None or not hasattr(self, "workflow_tabs"):
            return

        screen_info = ui_scaling_manager.screen_info
        available = screen_info.get("available_geometry")
        screen_width = available.width() if available is not None else self.width()
        compact = self.width() < COMPACT_LAYOUT_BREAKPOINT or screen_width < COMPACT_LAYOUT_BREAKPOINT
        target_orientation = Qt.Vertical if compact else Qt.Horizontal
        orientation_changed = splitter.orientation() != target_orientation
        if orientation_changed:
            splitter.setOrientation(target_orientation)

        # Compact screens benefit from a taller spectrum canvas; the results
        # pane remains vertically scrollable for tables and secondary plots.
        visualization = getattr(self, "visualization_widget", None)
        if visualization is not None:
            visualization.setMinimumHeight(460 if compact else 0)

        budget = ui_scaling_manager.get_workflow_width_budget(self.width())
        if not compact:
            content_minimum = self.workflow_tabs.minimumSizeHint().width() + 4
            budget['min'] = max(budget['min'], content_minimum)
            budget['max'] = max(budget['max'], budget['min'])
            budget['preferred'] = max(budget['preferred'], budget['min'])
        if compact:
            self.workflow_tabs.setMinimumWidth(min(budget["min"], max(1, self.width() - 32)))
            self.workflow_tabs.setMaximumWidth(16777215)
            self.workflow_scroll_area.setMinimumWidth(0)
        else:
            self.workflow_tabs.setMinimumWidth(budget["min"])
            self.workflow_tabs.setMaximumWidth(budget["max"])
            scrollbar_width = self.workflow_scroll_area.verticalScrollBar().sizeHint().width()
            self.workflow_scroll_area.setMinimumWidth(budget['min'] + scrollbar_width + 4)

        results_panel = getattr(self, '_results_panel', None)
        if results_panel is not None:
            results_panel.layout().activate()
            results_panel.setMinimumHeight(results_panel.layout().minimumSize().height())

        if orientation_changed or force:
            if compact:
                # Use the actual splitter allocation, including the toolbar
                # and layout margins already deducted by Qt. Otherwise Qt
                # proportionally rescales these sizes and a 160 px pane can
                # become 159 px on the smallest window.
                available_height = max(1, splitter.height() - splitter.handleWidth())
                # Leave enough room for the tab header, group header and at
                # least a few form rows on high-DPI laptop work areas. A tiny
                # 20% pane otherwise showed only headers at 512 logical px.
                # Both panes can scroll, and the splitter remains adjustable.
                first = min(360, max(160, int(available_height * 0.44)))
                splitter.setSizes([first, max(1, available_height - first)])
            else:
                left_width = max(budget["min"], min(budget["preferred"], budget["max"]))
                splitter.setSizes([left_width, max(1, self.width() - left_width)])

    def showEvent(self, event):
        super().showEvent(event)
        self._connect_window_screen_signals()
        self._schedule_screen_refresh()

    def moveEvent(self, event):
        super().moveEvent(event)
        if getattr(self, "_responsive_ready", False):
            self._schedule_screen_refresh()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if getattr(self, "_responsive_ready", False):
            self._update_responsive_layout()

    def _create_feature_group(self):
        """Create the compact feature engineering section."""
        group = QGroupBox(_("main_window.feature_group_label"))
        layout = QFormLayout()
        layout.setSpacing(ui.scaled_px(tok.SPACE_SM))
        layout.setContentsMargins(ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM))
        layout.setLabelAlignment(Qt.AlignLeft)

        self.feature_method = QComboBox()
        for _text, _key in [(_("main_window.pca_item"), "PCA"),
            (_("main_window.plsr_feature_item"), "PLSR"),
            (_("main_window.peak_detection_item"), "Peak Detection"),
            (_("main_window.wavelet_item"), "Wavelet")]:
            self.feature_method.addItem(_text, _key)
        ui.set_min_height(self.feature_method, tok.ROW_HEIGHT_MD)
        ui.set_min_width(self.feature_method, tok.CONTROL_MIN_WIDTH_LG)
        self.feature_method.currentIndexChanged.connect(self._update_feature_param_label)

        self.feature_param_spin = QSpinBox()
        self.feature_param_spin.setRange(1, 100)
        self.feature_param_spin.setValue(10)
        ui.set_min_height(self.feature_param_spin, tok.ROW_HEIGHT_MD)
        ui.set_min_width(self.feature_param_spin, tok.CONTROL_MIN_WIDTH)

        self.feature_param_label = QLabel(_("main_window.components_label"))
        layout.addRow(_("main_window.method_label"), self.feature_method)
        layout.addRow(self.feature_param_label, self.feature_param_spin)

        self.feature_btn = QPushButton(_("main_window.feature_apply_btn"))
        ui.set_min_height(self.feature_btn, tok.ROW_HEIGHT_LG)
        self.feature_btn.clicked.connect(self._on_feature_btn_clicked)
        layout.addRow(self.feature_btn)

        group.setLayout(layout)
        group.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self._update_feature_param_label()
        return group

    def _update_feature_param_label(self):
        """Update the feature-parameter label to match the selected method."""
        if not hasattr(self, 'feature_method') or not hasattr(self, 'feature_param_label'):
            return
        method = self.feature_method.currentData()
        label_key = "main_window.components_label"
        if method == "PCA":
            label_key = "main_window.pca_components_label"
        elif method == "PLSR":
            label_key = "main_window.plsr_components_label"
        elif method == "Peak Detection":
            label_key = "main_window.peak_components_label"
        elif method == "Wavelet":
            label_key = "main_window.wavelet_components_label"
        self.feature_param_label.setText(_(label_key))

    def _create_analysis_group(self, min_label_width, min_combobox_width, row_height):
        """Create the analysis and hyperparameter controls."""
        group = QGroupBox(_("main_window.group_2"))
        group.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)

        layout = QVBoxLayout()
        layout.setSpacing(ui.scaled_px(tok.SPACE_SM))
        layout.setContentsMargins(ui.scaled_px(tok.GROUP_BOX_CONTENT_MARGIN), ui.scaled_px(tok.GROUP_BOX_CONTENT_MARGIN), ui.scaled_px(tok.GROUP_BOX_CONTENT_MARGIN), ui.scaled_px(tok.GROUP_BOX_CONTENT_MARGIN))

        form = QFormLayout()
        form.setSpacing(ui.scaled_px(tok.SPACE_XS))
        form.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)

        type_label = QLabel(_("main_window.type_label"))
        self.analysis_type = QComboBox()
        for _text, _key in [(_("main_window.quantitative_item"), "Quantitative"),
            (_("main_window.qualitative_item"), "Qualitative")]:
            self.analysis_type.addItem(_text, _key)
        ui.configure_form_row(type_label, self.analysis_type, label_base_w=min_label_width, control_base_w=min_combobox_width, row_base_h=row_height)
        self.analysis_type.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        form.addRow(type_label, self.analysis_type)

        method_label = QLabel(_("main_window.method_label"))
        self.analysis_method = QComboBox()
        ui.configure_form_row(method_label, self.analysis_method, label_base_w=min_label_width, control_base_w=min_combobox_width, row_base_h=row_height)
        self.analysis_method.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        form.addRow(method_label, self.analysis_method)
        self.model_params_btn = QPushButton('Model parameters…')
        self.model_params_btn.clicked.connect(self.open_model_parameters)
        form.addRow(self.model_params_btn)
        layout.addLayout(form)

        hyperparameter_group = QGroupBox(_("main_window.hyperparameter_group"))
        hyperparameter_layout = QVBoxLayout()
        hyperparameter_layout.setContentsMargins(ui.scaled_px(tok.GROUP_BOX_CONTENT_MARGIN), ui.scaled_px(tok.GROUP_BOX_CONTENT_MARGIN), ui.scaled_px(tok.GROUP_BOX_CONTENT_MARGIN), ui.scaled_px(tok.GROUP_BOX_CONTENT_MARGIN))
        hyperparameter_layout.setSpacing(ui.scaled_px(tok.SPACE_XS))

        hp_form = QFormLayout()
        hp_form.setSpacing(ui.scaled_px(tok.SPACE_XS))
        hp_form.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)

        opt_method_label = QLabel(_("main_window.method_label"))
        self.optimization_method = QComboBox()
        for _text, _key in [(_("main_window.grid_search_item"), "Grid Search"),
            (_("main_window.random_search_item"), "Random Search"),
            (_("main_window.bayesian_item") + " (Optuna TPE)", "Bayesian"),
            ("Optuna TPE", "Optuna")]:
            self.optimization_method.addItem(_text, _key)
        ui.configure_form_row(opt_method_label, self.optimization_method, label_base_w=min_label_width, control_base_w=min_combobox_width, row_base_h=row_height)
        self.optimization_method.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        hp_form.addRow(opt_method_label, self.optimization_method)

        metric_label = QLabel(_("main_window.metric_label"))
        self.evaluation_metric = QComboBox()
        for _text, _key in [(_("main_window.rmse_item"), "RMSE"),
            (_("main_window.r2_item"), "R2"),
            (_("main_window.accuracy_item"), "Accuracy"),
            ("F1", "F1")]:
            self.evaluation_metric.addItem(_text, _key)
        ui.configure_form_row(metric_label, self.evaluation_metric, label_base_w=min_label_width, control_base_w=min_combobox_width, row_base_h=row_height)
        self.evaluation_metric.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        hp_form.addRow(metric_label, self.evaluation_metric)
        hyperparameter_layout.addLayout(hp_form)

        cv_iter_row = QHBoxLayout()
        cv_iter_row.setSpacing(ui.scaled_px(tok.SPACE_XS))
        cv_label = QLabel(_("main_window.cv_label"))
        self.cv_folds = QSpinBox()
        self.cv_folds.setRange(2, 10)
        self.cv_folds.setValue(5)
        ui.configure_form_row(cv_label, self.cv_folds, label_base_w=tok.LABEL_MIN_WIDTH_SM, control_base_w=tok.CONTROL_MIN_WIDTH, row_base_h=row_height)
        cv_iter_row.addWidget(cv_label)
        cv_iter_row.addWidget(self.cv_folds)

        iter_label = QLabel(_("main_window.iter_label"))
        self.max_iterations = QSpinBox()
        self.max_iterations.setRange(10, 1000)
        self.max_iterations.setValue(100)
        self.max_iterations.setSingleStep(10)
        ui.configure_form_row(iter_label, self.max_iterations, label_base_w=tok.LABEL_MIN_WIDTH_SM, control_base_w=tok.CONTROL_MIN_WIDTH, row_base_h=row_height)
        cv_iter_row.addWidget(iter_label)
        cv_iter_row.addWidget(self.max_iterations)
        cv_iter_row.addStretch()
        hyperparameter_layout.addLayout(cv_iter_row)

        hyperparameter_group.setLayout(hyperparameter_layout)
        layout.addWidget(hyperparameter_group)

        self.analyze_btn = QPushButton(_("main_window.analyze_btn"))
        ui.set_min_height(self.analyze_btn, tok.ROW_HEIGHT_LG)
        self.analyze_btn.clicked.connect(self.start_analysis)
        layout.addWidget(self.analyze_btn)

        self.optimize_btn = QPushButton(_("main_window.optimize_btn"))
        ui.set_min_height(self.optimize_btn, tok.ROW_HEIGHT_LG)
        self.optimize_btn.setEnabled(False)
        self.optimize_btn.clicked.connect(self.optimize_current_model)
        layout.addWidget(self.optimize_btn)

        group.setLayout(layout)
        return group

    def _create_data_partitioning_group(self):
        """Create the data partitioning section."""
        group = QWidget()
        group.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)

        layout = QVBoxLayout()
        layout.setSpacing(0)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.data_partitioning_view)

        group.setLayout(layout)
        return group

    def _create_results_panel(self):
        """Create the visualization and result table panel (chart-first surface)."""
        right_panel = QFrame()
        right_panel.setObjectName("resultsSurface")
        right_layout = QVBoxLayout(right_panel)
        right_layout.setSpacing(ui.scaled_px(tok.SPACE_MD))
        right_layout.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD)
        )

        try:
            from config.settings import Settings
            _settings = Settings()
            x_unit = _settings.preferred_x_unit
        except Exception:
            x_unit = 'nm'
        self.visualization_widget = VisualizationWidget(x_unit=x_unit)
        # Keep a usable scientific chart. The containing results scroll area
        # provides access to its toolbar, canvas and table on short screens.
        self.visualization_widget.canvas.setMinimumHeight(220)
        self._results_panel = right_panel
        right_layout.addWidget(self.visualization_widget, stretch=4)

        result_section = QFrame()
        result_section.setObjectName("surfaceCard")
        result_layout = QVBoxLayout(result_section)
        result_layout.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD)
        )
        result_layout.setSpacing(ui.scaled_px(tok.SPACE_SM))

        result_title = QLabel(_("main_window.results_section_title"))
        result_title.setObjectName("sectionTitle")
        result_layout.addWidget(result_title)

        self.result_table = QTableWidget()
        available_geometry = ui_scaling_manager.screen_info.get("available_geometry")
        available_height = available_geometry.height() if available_geometry is not None else self.height()
        table_height = ui_scaling_manager.get_table_height_for_height(available_height)
        self.result_table.setMinimumHeight(table_height)
        self.result_table.setMaximumHeight(max(table_height, ui.scaled_px(tok.RESULT_TABLE_HEIGHT_LG)))
        self.result_table.setColumnCount(3)
        self.result_table.setHorizontalHeaderLabels([_("main_window.algorithm_header"), _("main_window.r2_score_header"), _("main_window.rmse_item")])

        header = self.result_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.Stretch)

        self.result_table.setAlternatingRowColors(True)
        self.result_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.result_table.verticalHeader().setVisible(False)
        result_layout.addWidget(self.result_table)
        right_layout.addWidget(result_section, stretch=1)

        return right_panel

    def setup_toolbar(self):
        """Setup the main toolbar with action buttons"""
        toolbar = QToolBar()
        # Use a fixed minimum icon size so the toolbar stays usable on
        # compact screens where the global scale factor can compress
        # the design-token size to 14-16 px.
        base_icon = max(20, ui.scaled_px(tok.ICON_SIZE_LG))
        toolbar.setIconSize(QSize(base_icon, base_icon))
        toolbar.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        toolbar.setMovable(False)
        toolbar.setFloatable(False)
        self.addToolBar(toolbar)
          
        llm_action = QAction(_("main_window.llm_action"), self)
        llm_action.setStatusTip(_("main_window.status_tip"))
        llm_action.setToolTip(_("main_window.status_tip"))
        llm_action.triggered.connect(self.show_llm_dialog)
        llm_action.setProperty("ai", True)
        toolbar.addAction(llm_action)

        llm_config_action = QAction(_("main_window.llm_config_action"), self)
        llm_config_action.setStatusTip(_("main_window.status_tip_2"))
        llm_config_action.setToolTip(_("main_window.status_tip_2"))
        llm_config_action.triggered.connect(self.show_llm_config)
        llm_config_action.setProperty("ai", True)
        toolbar.addAction(llm_config_action)
        toolbar.addSeparator()
          
        zoom_in_action = QAction(_("main_window.zoom_in_action"), self)
        zoom_in_action.setStatusTip(_("main_window.status_tip_3"))
        zoom_in_action.setToolTip(_("main_window.status_tip_3"))
        zoom_in_action.setShortcut(QKeySequence("Ctrl++"))
        zoom_in_action.triggered.connect(self.zoom_in)
        toolbar.addAction(zoom_in_action)
        zoom_out_action = QAction(_("main_window.zoom_out_action"), self)
        zoom_out_action.setStatusTip(_("main_window.status_tip_4"))
        zoom_out_action.setToolTip(_("main_window.status_tip_4"))
        zoom_out_action.setShortcut(QKeySequence("Ctrl+-"))
        zoom_out_action.triggered.connect(self.zoom_out)
        toolbar.addAction(zoom_out_action)
        toolbar.addSeparator()
          
        save_image_action = QAction(_("main_window.save_image_action"), self)
        save_image_action.setStatusTip(_("main_window.status_tip_5"))
        save_image_action.setToolTip(_("main_window.status_tip_5"))
        save_image_action.setShortcut(QKeySequence("Ctrl+Shift+S"))
        save_image_action.triggered.connect(self.save_plot)
        toolbar.addAction(save_image_action)
        save_data_action = QAction(_("main_window.save_data_action"), self)
        save_data_action.setStatusTip(_("main_window.status_tip_6"))
        save_data_action.setToolTip(_("main_window.status_tip_6"))
        save_data_action.setShortcut(QKeySequence("Ctrl+S"))
        save_data_action.triggered.connect(self.save_data)
        toolbar.addAction(save_data_action)
        toolbar.addSeparator()
          
        history_action = QAction(_("main_window.history_action"), self)
        history_action.setStatusTip(_("main_window.status_tip_7"))
        history_action.setToolTip(_("main_window.status_tip_7"))
        history_action.setShortcut(QKeySequence("Ctrl+H"))
        history_action.triggered.connect(self.show_history)
        toolbar.addAction(history_action)
          
        back_action = QAction(_("main_window.back_action"), self)
        back_action.setStatusTip(_("main_window.status_tip_8"))
        back_action.setToolTip(_("main_window.status_tip_8"))
        back_action.setShortcut(QKeySequence("Ctrl+Z"))
        back_action.triggered.connect(self.undo_last_operation)
        toolbar.addAction(back_action)

    def setup_menu_bar(self):
        """Build menu bar (Tools > Settings…)."""
        menu_bar = self.menuBar()
        existing_tools = None
        for action in menu_bar.actions():
            if action.text().replace('&', '') == _('main_window.tools_settings_menu').replace('&', ''):
                existing_tools = action.menu()
                break

        tools_menu = existing_tools if existing_tools is not None else menu_bar.addMenu(
            _('main_window.tools_settings_menu')
        )

        settings_action = QAction(
            _('main_window.tools_settings_action'), self
        )
        settings_action.setShortcut(QKeySequence('Ctrl+,'))
        settings_action.triggered.connect(self.show_settings_dialog)
        tools_menu.addAction(settings_action)

    def setup_status_bar(self):
        """Setup the status bar to show application status"""
        status_bar = self.statusBar()    
          
        self.data_status = QLabel(_("main_window.data_status"))    
        status_bar.addPermanentWidget(self.data_status)    
          
        self.progress_bar = QProgressBar()    
        ui.set_max_width(self.progress_bar, 200)    
        status_bar.addPermanentWidget(self.progress_bar)    
          
        self.tip_label = QLabel("")    
        status_bar.addWidget(self.tip_label)    
    def setup_shortcuts(self):
        """Setup keyboard shortcuts for common actions"""
          
        import_shortcut = QShortcut(QKeySequence("Ctrl+O"), self)    
        import_shortcut.activated.connect(self.import_data)    
          
        save_shortcut = QShortcut(QKeySequence("Ctrl+S"), self)    
        save_shortcut.activated.connect(self.save_data)    
          
        back_shortcut = QShortcut(QKeySequence("Ctrl+Z"), self)    
        back_shortcut.activated.connect(self.undo_last_operation)    
    def setup_operation_history(self):
        """Setup operation history tracking"""
        self.operation_history = []  # Initialize operation history list
        history_btn = QPushButton(_("main_window.history_btn"))    
        history_btn.clicked.connect(self.show_history)    
        self.statusBar().addPermanentWidget(history_btn)    
    def zoom_in(self):
        """Zoom in on the current visualization"""
        self.visualization_widget.zoom_in()    
    def zoom_out(self):
        """Zoom out on the current visualization"""
        self.visualization_widget.zoom_out()    
    def save_plot(self):
        """Save the current plot to file"""
        file_path, selected_filter = QFileDialog.getSaveFileName(    
            self, _("main_window.dialog_caption"), "", _("main_window.file_filter")    
        )
        if file_path:
            if not self.visualization_widget.save_plot(file_path):
                QMessageBox.critical(self, _("main_window.message"), "Could not export the current plot.")    
    def save_data(self):
        """Save the current data to file"""
        file_path, selected_filter = QFileDialog.getSaveFileName(    
            self, _("main_window.save_data_action"), "", _("main_window.file_filter_2")    
        )
        if file_path:    
            try:
                export_spectra = getattr(self, 'processed_spectra', None)
                if export_spectra is None:
                    export_spectra = self.current_spectra
                if export_spectra is None or self.wavelengths is None:
                    raise ValueError('Load spectral data before exporting.')
                SpectrumConverter.save_spectrum_file(
                    self.wavelengths, export_spectra,
                    file_path, format_type=file_path.split('.')[-1].lower()    
                )
                self.statusBar().showMessage(f"Data saved: {file_path}")    
            except Exception as e:    
                QMessageBox.critical(self, _("main_window.message"), _("main_window.save_failed").format(error=str(e)))    
    def undo_last_operation(self):
        """Restore a full preprocessing snapshot and invalidate downstream models."""
        if not self.operation_history:
            return
        record = self.operation_history[-1]
        snapshot = record.get('snapshot')
        if snapshot is None:
            QMessageBox.information(self, "Undo", "This legacy history entry contains only a plot matrix and cannot restore the analysis state. Reimport the source data to reset the workflow.")
            return
        import copy
        data_model = self.controller.data_controller.data_model
        revision = data_model.get_state_revision()
        self.invalidate_dataset_feature_state(clear_history=False)
        with data_model._lock:
            for key, value in copy.deepcopy(snapshot['data_model']).items():
                setattr(data_model, key, value)
            data_model._row_key_data_ref = data_model.data
            data_model._state_revision = revision + 1
        for key, value in copy.deepcopy(snapshot['view']).items():
            setattr(self, key, value)
        if not hasattr(self.controller.preprocessing_controller, 'preprocessing_model'):
            self.controller.preprocessing_controller.preprocessing_model = PreprocessingModel()
        self.controller.preprocessing_controller.preprocessing_model.applied_methods = copy.deepcopy(snapshot['applied_methods'])
        self.controller.preprocessing_controller.preprocessing_model.applied_steps = copy.deepcopy(snapshot.get('applied_steps', []))
        self.operation_history.pop()
        from PyQt5.QtCore import QSignalBlocker
        view = self.data_partitioning_view
        blockers = [QSignalBlocker(obj) for obj in (view, view.label_column_combo, view.sample_id_combo, view.group_id_combo, view.group_validation_checkbox)]
        view.update_data_info(data_model.data)
        view.label_column_combo.setCurrentIndex(data_model.label_column_index)
        for combo, position in ((view.sample_id_combo, data_model.sample_id_column_index),
                                (view.group_id_combo, data_model.group_id_column_index)):
            combo.setCurrentIndex(max(0, combo.findData(position)))
        view.group_validation_checkbox.setChecked(data_model.group_validation)
        del blockers
        display = self.processed_spectra if self.processed_spectra is not None else self.current_spectra
        self.visualization_widget.plot_spectra(self.wavelengths, display)
        self.statusBar().showMessage("Preprocessing undone. Run analysis again before using model results.")

    def _capture_preprocessing_snapshot(self):
        import copy
        model = self.controller.data_controller.data_model
        with model._lock:
            data_state = copy.deepcopy({key: value for key, value in vars(model).items()
                                        if key not in ('_lock', '_row_key_data_ref')})
        view_state = {key: copy.deepcopy(getattr(self, key, None)) for key in
                      ('current_spectra', 'processed_spectra', 'wavelengths', 'original_spectra',
                       'feature_data_options', 'current_feature_source')}
        return {'data_model': data_state, 'view': view_state,
                'applied_methods': copy.deepcopy(getattr(getattr(self.controller.preprocessing_controller, 'preprocessing_model', None), 'applied_methods', {})),
                'applied_steps': copy.deepcopy(getattr(getattr(self.controller.preprocessing_controller, 'preprocessing_model', None), 'applied_steps', []))}

    def show_history(self):
        """Show operation history dialog"""
        if not self.operation_history:    
            QMessageBox.information(self, _("main_window.history_action"), _("main_window.no_history"))    
            return
        history_text = _("main_window.history_dialog_text") + "\n\n"    
        for operation in self.operation_history:    
            history_text += f"Time: {operation['time']}\n"    
            history_text += f"Operation: {operation['operation']}\n\n"    
        QMessageBox.information(self, _("main_window.history_action"), history_text)    

    def connect_signals(self):

        self.data_partitioning_view.load_data_btn.clicked.connect(self.import_data)
        self.data_partitioning_view.partition_data_btn.clicked.connect(self.partition_data_with_params)
        self.data_partitioning_view.label_column_changed.connect(
            self.on_label_column_changed
        )
        self.data_partitioning_view.column_mapping_changed.connect(self.on_column_mapping_changed)


        # Connect feature extraction signal (Editor Comment 4)
        self.feature_extraction_view.extraction_requested.connect(self.handle_feature_extraction)



        self.analysis_type.currentTextChanged.connect(lambda _text: self.update_analysis_methods(self.analysis_type.currentData()))

        # Moved from unreachable code after return in get_current_feature_data
        self.hyperopt_view.apply_button.clicked.connect(
            lambda: self.controller.check_model_trained() and
            self.controller.hyperopt_controller.apply_optimization()
        )

        self.evaluation_view.evaluate_button.clicked.connect(
            lambda: self.controller.check_model_trained() and
            self.controller.evaluation_controller.evaluate_model()
        )

    
    def handle_feature_extraction(self, method, params):
        """Handle feature extraction request (Editor Comment 4)"""
        try:
            data_controller = getattr(getattr(self, 'controller', None), 'data_controller', None)
            data_model = getattr(data_controller, 'data_model', None)
            if data_model is not None and not self._require_verified_model_split(
                    data_model, "feature extraction", report_error=True):
                return

            if self.current_spectra is None:
                QMessageBox.warning(self, _("main_window.message_2"), _("main_window.load_spectral_data_first"))
                return
            
            from app.services.feature_extraction_service import feature_extraction_service
            
            # Prepare data (exclude label column if present)
            X = self.current_spectra.copy()
            if hasattr(self, 'target_column_index') and self.target_column_index is not None:
                if self.target_column_index < X.shape[1]:
                    X = X.drop(X.columns[self.target_column_index], axis=1)
            
            print(f"Starting {method.upper()} feature extraction...")
            print(f"   Input data shape: {X.shape}")

            if method == 'pca':
                self.progress_dialog = ProgressDialog(_("main_window.feature_extraction_progress_title"), self)
                self.progress_dialog.show()
                results = run_heavy(
                    lambda: feature_extraction_service.extract_pca_features(
                        X,
                        n_components=params.get('n_components'),
                        cev_threshold=params.get('cev_threshold', 0.95)
                    ),
                    progress_dialog=self.progress_dialog,
                )
                self.progress_dialog.close()
                if results is None:
                    return  # cancelled by user

                # Integrate into the feature data management system.
                self.feature_data_options['pca_features'] = results['transformed_data']
                self.pca_results = results  # Keep full results for analysis

                print(f"Feature extraction completed: {results['n_components']} components extracted")
                print(f"   Original spectra preserved: {self.current_spectra.shape}")
                print(f"   PCA features stored: {self.feature_data_options['pca_features'].shape}")

                # Display results in feature extraction view
                self.feature_extraction_view.display_pca_results(results)

                # Ask whether to use PCA features for subsequent analysis
                reply = QMessageBox.question(
                    self, _("main_window.message_3"),
                    f"Successfully extracted {results['n_components']} principal components "
                    f"explaining {results['cumulative_explained_variance'][-1]:.1%} of variance.\n\n"
                    f"Would you like to use these PCA features for subsequent modeling?\n\n"
                    f"- Yes: Use {results['n_components']} PCA components for modeling\n"
                    f"- No: Keep using original {self.current_spectra.shape[1]} wavelengths",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.Yes
                )
                
                if reply == QMessageBox.Yes:
                    self.current_feature_source = 'pca_features'
                    QMessageBox.information(
                        self, _("main_window.message_4"),
                        f"Now using {results['n_components']} PCA components for modeling.\n"
                        f"You can proceed with data partitioning and modeling."
                    )
                else:
                    QMessageBox.information(
                        self, _("main_window.message_5"),
                        f"PCA features are available but original data will be used for modeling.\n"
                        f"You can switch to PCA features later if needed."
                    )
                
            else:
                QMessageBox.warning(self, _("main_window.message_2"), _("main_window.method_not_implemented").format(method=method))
                
        except Exception as e:
            error_msg = _("main_window.feature_extraction_failed").format(error=str(e))
            print(f"ERROR: {error_msg}")
            QMessageBox.critical(self, _("main_window.message_6"), error_msg)

    def get_current_feature_data(self):
        """Get the currently selected feature data for modeling"""
        if hasattr(self, 'controller') and hasattr(self.controller, 'data_controller'):
            data_model = self.controller.data_controller.data_model
            has_split_attempt = getattr(data_model, 'has_split_attempt', None)
            split_attempt = (
                bool(has_split_attempt()) if callable(has_split_attempt)
                else data_model.has_partitioned_data() or any(
                    getattr(data_model, name, None) is not None
                    for name in ('X_train', 'y_train', 'X_test', 'y_test')
                )
            )
            has_verified_split = getattr(data_model, 'has_verified_split', None)
            verified_split = (
                bool(has_verified_split()) if callable(has_verified_split)
                else data_model.has_partitioned_data()
                and getattr(data_model, 'row_alignment_verified', False)
                and all(getattr(data_model, name, None) is not None
                        for name in ('X_train', 'y_train', 'X_test', 'y_test'))
            )
            if split_attempt:
                if not verified_split:
                    self.display_error(
                        "The current split has no verified row alignment. Recreate the split before modeling."
                    )
                    return None
                return {
                    'X_train': data_model.X_train,
                    'y_train': data_model.y_train,
                    'X_test': data_model.X_test,
                    'y_test': data_model.y_test,
                }
        if self.current_feature_source == 'selected_features' and self.feature_data_options['selected_features'] is not None:
            # Feature-selected data is already split; return train/test directly.
            selected_data = self.feature_data_options['selected_features']
            print(f"Using selected features for analysis:")
            print(f"   Train: {selected_data['X_train'].shape}")
            print(f"   Test: {selected_data['X_test'].shape if selected_data['X_test'] is not None else 'None'}")
            print(f"   Selected features: {len(selected_data['selected_features'])}")
            return selected_data  # Return dict containing train/test data
        elif self.current_feature_source == 'pca_features' and self.feature_data_options['pca_features'] is not None:
            print(f"Using PCA features for analysis: {self.feature_data_options['pca_features'].shape}")
            return self.feature_data_options['pca_features']
        elif self.current_feature_source == 'preprocessed' and self.feature_data_options['preprocessed'] is not None:
            print(f"Using preprocessed data for analysis: {self.feature_data_options['preprocessed'].shape}")
            return self.feature_data_options['preprocessed']
        else:
            print(f"Using original spectral data for analysis: {self.current_spectra.shape}")
            return self.current_spectra

    def display_message(self, message, title="Information"):
        """Display an information message to the user"""
        if title == "Error":
            QMessageBox.critical(self, _("main_window.error_title"), message)
        elif title == "Warning":
            QMessageBox.warning(self, _("main_window.warning_title"), message)
        else:
            QMessageBox.information(self, _("main_window.information_title"), message)

    def update_data_view(self, data):
        """Update data view and auto-visualize"""
        try:
            has_data = data is not None
            data_model = self.controller.data_controller.data_model
            if has_data:
                feature_frame = data_model.get_X()
                feature_count = feature_frame.shape[1] if feature_frame is not None else 0
                if self.translator.language == 'zh':
                    self.data_status.setText(f'数据：{len(data)} 个样本，{feature_count} 个光谱变量')
                else:
                    self.data_status.setText(f'Data: {len(data)} samples, {feature_count} spectral features')
            else:
                self.data_status.setText(_("main_window.data_status"))
            for button_name in (
                "preprocess_btn", "settings_btn", "report_btn",
            ):
                btn = getattr(self, button_name, None)
                if btn is not None:
                    btn.setEnabled(has_data)
            # Auto-update visualization
            if hasattr(self, 'visualization_widget') and data is not None:
                wavelengths = None
                spectra_data = None
                labels = None

                # Use the configured label column instead of assuming column 0.
                label_col = getattr(data_model, 'label_column_index', 0)

                # Correctly extract wavelengths and data from the incoming DataFrame
                if data.shape[1] > 1:
                    wavelengths = feature_frame.columns
                    spectra_data = feature_frame.to_numpy(copy=True)
                    labels = data.iloc[:, label_col].values
                else:
                    # No label column
                    wavelengths = data.columns
                    spectra_data = data.values
                    labels = None

                # Convert wavelengths to a numeric numpy array
                try:
                    numeric_wavelengths = pd.to_numeric(wavelengths).to_numpy()
                except (ValueError, TypeError):
                    print("WARNING: Could not convert wavelengths to numeric. Using as is.")
                    numeric_wavelengths = wavelengths.to_numpy()

                # Set instance attributes for use throughout the application
                self.current_spectra = spectra_data
                self.sample_labels = labels
                self.wavelengths = numeric_wavelengths
                self.original_spectra = spectra_data.copy() # Keep a pristine copy of original data

                # Update visualization
                self.visualization_widget.plot_spectra(
                    self.wavelengths,
                    spectra_data,
                    title=_("main_window.loaded_spectral_data_title"),
                    labels=labels
                )

                print("Data visualization auto-updated")
                print(f"current_spectra set: {self.current_spectra.shape}")
        except Exception as e:
            print(f"WARNING: Data view update failed: {e}")
            import traceback
            traceback.print_exc()

    def export_analysis_results(self):
        """Export committed model evaluation/CV metrics with their provenance."""
        model = self.controller.modeling_controller.modeling_model
        results = getattr(model, 'evaluation_results', {}) or {}
        task = results.get('task_type') or getattr(model, 'analysis_type', '') or 'unknown'
        algorithm = getattr(model, 'method', '') or 'unknown'
        rows = []
        def collect(values, prefix='', source='cross_validation'):
            if not isinstance(values, dict):
                return
            for key, value in values.items():
                metric = f'{prefix}.{key}' if prefix else str(key)
                if key in ('task_type', 'method', 'folds', 'n_splits', 'random_state') or any(
                    token in str(key).lower() for token in ('sample_id', 'group_id', 'indices', 'confusion_matrix')
                ):
                    continue
                metric_source = 'test' if str(key).startswith('test_') else source
                if isinstance(value, dict):
                    collect(value, metric, metric_source)
                elif isinstance(value, (int, float, np.number)) and not isinstance(value, (bool, np.bool_)):
                    rows.append({'algorithm': algorithm, 'task': task, 'metric': metric,
                                 'value': float(value), 'source': metric_source})
                elif isinstance(value, (list, tuple, np.ndarray)) and any(
                    token in metric.lower() for token in ('score', 'rmse', 'mae', 'mse', 'r2', 'accuracy', 'precision', 'recall', 'f1', 'auc')
                ):
                    for index, item in enumerate(value):
                        if isinstance(item, (int, float, np.number)):
                            rows.append({'algorithm': algorithm, 'task': task, 'metric': f'{metric}[{index}]',
                                         'value': float(item), 'source': metric_source})
        collect(results)
        if not rows:
            QMessageBox.information(self, 'Export Results', 'Run model analysis before exporting evaluation results.')
            return
        path, selected_filter = QFileDialog.getSaveFileName(
            self, 'Export Results', '', 'CSV files (*.csv);;Excel files (*.xlsx)')
        if not path:
            return
        extension = os.path.splitext(path)[1].lower()
        if not extension:
            extension = '.xlsx' if 'xlsx' in selected_filter else '.csv'
            path += extension
        try:
            frame = pd.DataFrame(rows, columns=['algorithm', 'task', 'metric', 'value', 'source'])
            if extension == '.xlsx':
                frame.to_excel(path, index=False)
            elif extension == '.csv':
                frame.to_csv(path, index=False, encoding='utf-8-sig')
            else:
                raise ValueError('Choose a CSV (.csv) or Excel (.xlsx) output file.')
            self.statusBar().showMessage(f'Results exported: {path}', 5000)
        except Exception as exc:
            QMessageBox.critical(self, 'Export Results', str(exc))

    def _compute_model_diagnostics(self, progress_dialog=None):
        model = self.controller.modeling_controller.modeling_model
        predictor = getattr(model, 'fitted_predictor', None)
        inputs = getattr(model, 'diagnostic_inputs', None)
        if predictor is None or not inputs or inputs.get('X_test') is None or inputs.get('y_test') is None:
            return None
        if getattr(model, 'diagnostics', None) is not None:
            return model.diagnostics
        from app.services.diagnostics_service import generate_diagnostics
        owns_progress = progress_dialog is None
        progress = progress_dialog or ProgressDialog('Computing model diagnostics', self)
        if owns_progress:
            progress.show()
        try:
            diagnostics = run_heavy(lambda: generate_diagnostics(predictor,
                inputs['X_test'], inputs['y_test'], inputs['task_type'],
                X_train=inputs['X_train'], y_train=inputs['y_train']), progress_dialog=progress)
        finally:
            if owns_progress:
                progress.update_progress(100);progress.close()
        if diagnostics is not None:
            model.diagnostics = diagnostics
        return diagnostics

    def show_model_diagnostics(self):
        """Inspect diagnostics from the committed predictor's exact fit inputs."""
        model = self.controller.modeling_controller.modeling_model
        predictor = getattr(model, 'fitted_predictor', None)
        inputs = getattr(model, 'diagnostic_inputs', None)
        if predictor is None or not inputs or inputs.get('X_test') is None or inputs.get('y_test') is None:
            QMessageBox.information(self, 'Model Diagnostics', 'Run analysis with a held-out test set before opening diagnostics.')
            return
        try:
            from app.services.diagnostics_service import diagnostic_figures
            if self._compute_model_diagnostics() is None:
                return
            dialog = QDialog(self)
            dialog.setWindowTitle('Model Diagnostics')
            layout = QVBoxLayout(dialog)
            tabs = QTabWidget(dialog)
            summary = QTextEdit(dialog);summary.setReadOnly(True)
            details = {key: model.diagnostics.get(key) for key in ('task_type','notes','unavailable','confidence_level')}
            summary.setPlainText(json.dumps(details, ensure_ascii=False, indent=2))
            tabs.addTab(summary, 'Scope and availability')
            for name, figure in diagnostic_figures(model.diagnostics).items():
                canvas = FigureCanvas(figure);canvas.setMinimumHeight(220)
                page = QWidget(dialog);page_layout = QVBoxLayout(page)
                page_layout.addWidget(NavigationToolbar(canvas, page))
                page_layout.addWidget(canvas)
                tabs.addTab(page, name.replace('_',' ').title())
            layout.addWidget(tabs)
            close = QDialogButtonBox(QDialogButtonBox.Close, parent=dialog)
            close.rejected.connect(dialog.reject);layout.addWidget(close)
            screen = QApplication.primaryScreen().availableGeometry()
            dialog.resize(min(900,screen.width()-40),min(650,screen.height()-40))
            dialog.exec_()
            return dialog
        except Exception as exc:
            QMessageBox.critical(self, 'Model Diagnostics', str(exc))

    def export_fitted_analyzer_onnx(self):
        """Export the current fitted analyzer with a visible ONNX contract."""
        modeling_model = self.controller.modeling_controller.modeling_model
        analyzer = getattr(modeling_model, 'analyzer', None)
        inputs = getattr(modeling_model, 'diagnostic_inputs', None) or {}
        X_train = inputs.get('X_train')
        if analyzer is None or X_train is None:
            QMessageBox.information(
                self,
                'Export Fitted Model to ONNX',
                'Run model analysis before exporting a fitted ONNX predictor.',
            )
            return None
        import threading
        from app.utils.worker import run_heavy
        cancel_event = threading.Event()
        self._onnx_cancel_event = cancel_event
        progress = ProgressDialog('Exporting fitted ONNX model', self)
        progress.progress_bar.setRange(0, 0)
        progress.cancelled.connect(cancel_event.set)
        progress.show()
        self.export_onnx_btn.setEnabled(False)
        try:
            path = run_heavy(lambda: self.onnx_service.export_analyzer_to_onnx(
                analyzer, X_train,
                model_name=type(getattr(analyzer, 'model', analyzer)).__name__,
                method=getattr(analyzer, 'method', None),
                cancel_event=cancel_event,
            ), progress)
        finally:
            progress.progress_bar.setRange(0, 100)
            progress.update_progress(100)
            progress.close()
            self._onnx_cancel_event = None
            self.export_onnx_btn.setEnabled(True)
        if cancel_event.is_set():
            return None
        if not path:
            QMessageBox.critical(
                self,
                'ONNX Export Failed',
                getattr(self.onnx_service, 'last_error', None) or 'The fitted analyzer could not be converted.',
            )
            return None
        QMessageBox.information(
            self,
            'ONNX Export Complete',
            f'ONNX Runtime parity passed. File: {path}\n'
            f'Contract: {os.path.splitext(path)[0]}_onnx_contract.json',
        )
        return path

    def closeEvent(self, event):
        cancel_event = getattr(self, '_onnx_cancel_event', None)
        if cancel_event is not None:
            cancel_event.set()
        super().closeEvent(event)

    def update_split_view(self, train_data, test_data):
        """Update the view with training and testing data splits"""
          
        pass

    def show_llm_dialog(self):
        """Show the LLM (Large Language Model) dialog"""
        dialog = LLMDialog(self, self.llm_service)    
        dialog.exec_()    

    def reload_onboarded_plugins(self):
        """Reload accepted records only after the onboarding service revalidates them."""
        service = getattr(self, "algorithm_onboarding_service", None)
        if service is None:
            return {}
        for candidate_id in list(getattr(self, "onboarded_plugin_reports", {})):
            service.disable_plugin(candidate_id)
        self.onboarded_plugin_reports = {}
        self.onboarding_reload_errors = []
        storage_dir = service.storage_dir
        try:
            plugin_dirs = sorted(path for path in storage_dir.iterdir() if path.is_dir())
        except FileNotFoundError:
            plugin_dirs = []
        except OSError as exc:
            self.onboarding_reload_errors.append(str(exc))
            plugin_dirs = []

        for plugin_dir in plugin_dirs:
            if not (plugin_dir / "plugin.json").is_file():
                continue
            candidate_id = plugin_dir.name
            try:
                report = service.load_accepted_candidate(candidate_id, register=True)
                if report.passed and report.candidate.algorithm_category == "stateless_preprocessing":
                    self.onboarded_plugin_reports[candidate_id] = report
                else:
                    service.disable_plugin(candidate_id)
                    self.onboarding_reload_errors.append(f"{candidate_id}: candidate did not pass reload checks")
            except Exception as exc:
                service.disable_plugin(candidate_id)
                self.onboarding_reload_errors.append(f"{candidate_id}: {exc}")

        if hasattr(self, "onboarded_plugin_combo"):
            self.refresh_onboarded_plugin_selector()
        return dict(self.onboarded_plugin_reports)

    def refresh_onboarded_plugin_selector(self):
        """Show only records that the service freshly revalidated."""
        combo = getattr(self, "onboarded_plugin_combo", None)
        if combo is None:
            return
        selected = combo.currentData()
        combo.blockSignals(True)
        combo.clear()
        combo.addItem("Select accepted stateless plugin…", None)
        for candidate_id, report in sorted(self.onboarded_plugin_reports.items()):
            combo.addItem(report.candidate.name, candidate_id)
        index = combo.findData(selected)
        combo.setCurrentIndex(index if index >= 0 else 0)
        combo.blockSignals(False)
        self._onboarded_plugin_selection_changed()
        count = len(self.onboarded_plugin_reports)
        if count:
            status = f"{count} accepted stateless plugin(s) passed fresh verification."
        elif self.onboarding_reload_errors:
            status = "No plugin was exposed; one or more saved records failed reload verification."
        else:
            status = "No accepted stateless preprocessing plugins loaded."
        if hasattr(self, "onboarded_plugin_status"):
            self.onboarded_plugin_status.setText(status)

    def _onboarded_plugin_selection_changed(self, *_args):
        combo = getattr(self, "onboarded_plugin_combo", None)
        if combo is None:
            return
        candidate_id = combo.currentData()
        report = self.onboarded_plugin_reports.get(candidate_id)
        enabled = bool(report and report.passed)
        if hasattr(self, "apply_onboarded_plugin_button"):
            self.apply_onboarded_plugin_button.setEnabled(enabled)
        if hasattr(self, "onboarded_plugin_params"):
            values = {}
            schema = report.candidate.parameter_schema if report else {}
            if isinstance(schema, dict):
                values = {
                    name: spec["default"]
                    for name, spec in schema.items()
                    if isinstance(spec, dict) and "default" in spec
                }
            if report:
                values.update(dict(report.candidate.parameters))
            self.onboarded_plugin_params.setText(json.dumps(values, ensure_ascii=False))

    def show_verified_workflow_dialog(self):
        """Open five-role verification and execution on the current keyed split."""
        from app.views.verified_workflow_dialog import VerifiedWorkflowDialog
        data_model = self.controller.data_controller.data_model
        storage = self.algorithm_onboarding_service.storage_dir.parent / "verified_fitted"
        dialog = VerifiedWorkflowDialog(storage, data_model=data_model, parent=self)
        dialog.exec_()

    def show_algorithm_onboarding_dialog(self):
        """Open the active preprocessing onboarding flow, with current spectral context."""
        initial_X = None
        axis = None
        axis_unit = getattr(getattr(self, "visualization_widget", None), "x_unit", "nm")
        try:
            data_model = self.controller.data_controller.data_model
            X_frame = data_model.get_X()
            axis_values = data_model.get_wavelengths()
            if X_frame is not None and len(X_frame) >= 2:
                initial_X = X_frame.iloc[: min(8, len(X_frame))].to_numpy(dtype=float)
            if axis_values is not None:
                numeric_axis = pd.to_numeric(pd.Series(axis_values), errors="coerce").to_numpy(dtype=float)
                if len(numeric_axis) and np.isfinite(numeric_axis).all():
                    axis = numeric_axis
        except Exception:
            pass

        llm_service = self.llm_service
        if llm_service is None and str(LLMConfig.API_KEY or "").strip():
            llm_service = LLMService(LLMConfig.API_KEY)
        dialog = AlgorithmOnboardingDialog(
            self.algorithm_onboarding_service,
            llm_service,
            initial_X=initial_X,
            axis=axis,
            axis_unit=axis_unit,
            parent=self,
        )
        if dialog.exec_() == QDialog.Accepted:
            self.reload_onboarded_plugins()

    def apply_onboarded_plugin(self):
        """Dispatch one accepted stateless plugin through controller and DataModel."""
        candidate_id = self.onboarded_plugin_combo.currentData()
        report = self.onboarded_plugin_reports.get(candidate_id)
        if not report or not report.passed:
            QMessageBox.warning(self, "Verified preprocessing", "Select a plugin that passed fresh verification.")
            return False
        from app.services.preprocessing_registry import get_entry
        entry = get_entry(candidate_id)
        if entry is None or entry.category != "plugin" or entry.quality != "verified-stateless":
            QMessageBox.warning(self, "Verified preprocessing", "The selected plugin is not registered as verified stateless code.")
            return False
        if not self.controller.check_data_ready():
            return False
        try:
            self._pending_preprocessing_snapshot = self._capture_preprocessing_snapshot()
            params = json.loads(self.onboarded_plugin_params.text() or "{}")
            if not isinstance(params, dict):
                raise ValueError("Parameter values must be a JSON object")
            methods = [candidate_id]
            params_dict = {candidate_id: params}
            self.progress_dialog = ProgressDialog("Applying verified preprocessing", self)
            self.progress_dialog.show()
            self._preprocessing_worker = self.controller.preprocessing_controller.start_preprocessing_worker(
                methods,
                params_dict,
                on_result=lambda result: self._on_preprocessing_result(methods, result),
                on_error=self._on_preprocessing_error,
            )
            self.progress_dialog.cancelled.connect(self._preprocessing_worker.cancel)
            return True
        except Exception as exc:
            if hasattr(self, "progress_dialog") and self.progress_dialog:
                self.progress_dialog.close()
            QMessageBox.critical(self, "Verified preprocessing", f"Could not apply plugin: {exc}")
            return False

    def add_converted_algorithm(self, algorithm_type: str, code: str):
        """Add a converted algorithm to the appropriate plugin list"""
        try:
              
            if algorithm_type == "Preprocessing":
                self.preprocessing_view.add_custom_algorithm(code)    
            elif algorithm_type == "Feature Selection":
                self.feature_selection_view.add_custom_algorithm(code)    
            elif algorithm_type == "Modeling":
                self.modeling_view.add_custom_algorithm(code)    
            elif algorithm_type == "Data Splitting":
                self.data_partitioning_view.add_custom_algorithm(code)    
            QMessageBox.information(self, _("main_window.message_7"), _("main_window.algorithm_added"))    
        except Exception as e:    
            QMessageBox.critical(self, _("main_window.message"), _("main_window.algorithm_add_failed").format(error=str(e)))    

    def show_llm_config(self):
        """Show the LLM configuration dialog"""
        from app.views.llm_config_dialog import LLMConfigDialog
        dialog = LLMConfigDialog(self)
        if dialog.exec_() == QDialog.Accepted:

            self.llm_service = LLMService(LLMConfig.API_KEY)

    def show_settings_dialog(self):
        """Open the application settings dialog (Tools > Settings)."""
        try:
            from config.settings import Settings
            from app.views.settings_dialog import SettingsDialog
            from app.ui import theme_manager
            from PyQt5.QtWidgets import QApplication

            settings = Settings()
            previous_theme = settings.theme
            dialog = SettingsDialog(settings=settings, parent=self)
            dialog.exec_()
            self._apply_language(settings.language)
            # Refresh widgets that depend on settings.
            if hasattr(self, 'visualization_widget'):
                self.visualization_widget.set_x_unit(settings.preferred_x_unit)
            if settings.theme != previous_theme:
                theme_manager.apply_theme_to_app(QApplication.instance(), settings.theme)
                if hasattr(self, 'visualization_widget'):
                    self.visualization_widget.setup_plot_style()
                    if hasattr(self.visualization_widget, 'canvas'):
                        self.visualization_widget.canvas.draw_idle()
        except Exception as exc:
            QMessageBox.critical(
                self,
                _('settings_dialog.save_error_title'),
                _('settings_dialog.save_error_message').format(error=str(exc)),
            )

    def _apply_language(self, language):
        """Update existing translated labels without rebuilding workflow state."""
        old_values = dict(translator.translations)
        translator.set_language(language)
        if self.translator is not translator:
            self.translator.set_language(language)
        reverse = {value: key for key, value in old_values.items() if isinstance(value, str)}
        def translated(text):
            key = reverse.get(text)
            return translator.translate(key) if key else text
        user_combos = {self.data_partitioning_view.label_column_combo,
                       self.data_partitioning_view.sample_id_combo,
                       self.data_partitioning_view.group_id_combo,
                       self.onboarded_plugin_combo}
        for obj in [self, *self.findChildren(QWidget), *self.findChildren(QAction)]:
            if isinstance(obj, (QLineEdit, QTextEdit)):
                continue
            for getter, setter in (('text', 'setText'), ('windowTitle', 'setWindowTitle'),
                                   ('toolTip', 'setToolTip'), ('title', 'setTitle')):
                if hasattr(obj, getter) and hasattr(obj, setter):
                    value = getattr(obj, getter)()
                    updated = translated(value)
                    if updated != value:
                        getattr(obj, setter)(updated)
            if isinstance(obj, QComboBox) and obj not in user_combos:
                from PyQt5.QtCore import QSignalBlocker
                blocker = QSignalBlocker(obj)
                for index in range(obj.count()):
                    obj.setItemText(index, translated(obj.itemText(index)))
                del blocker
            if isinstance(obj, QTabWidget):
                for index in range(obj.count()):
                    obj.setTabText(index, translated(obj.tabText(index)))

    def import_data(self):
        """Load spectral data with spectral type configuration"""
        # Call the data controller's load_data method which includes spectral configuration
        if hasattr(self, 'controller') and self.controller:
            success = self.controller.data_controller.load_data()
            if success:
                # Data loaded successfully, update partitioning view status and enable partition button
                data_controller = self.controller.data_controller
                self.data_partitioning_view.set_data_loaded(
                    getattr(data_controller.data_model, 'file_path', None),
                    data_controller.data_model.data
                )
                print(_("main_window.data_loaded_success"))
        else:
            QMessageBox.warning(self, _("main_window.message"), _("main_window.controller_not_initialized"))
    
    def update_ui_after_data_load(self):
        """Update UI components after data is loaded"""
        # This method can be called by the controller if needed
        pass
    

    def apply_preprocessing(self):
        """Apply preprocessing using the fixed controller"""
        if not self.controller.check_data_ready():
            QMessageBox.warning(self, _("main_window.message_2"), _("main_window.load_data_first"))
            return
        try:
            self._pending_preprocessing_snapshot = self._capture_preprocessing_snapshot()
            # Show progress dialog
            self.progress_dialog = ProgressDialog(_("main_window.preprocessing_progress_title"), self)
            self.progress_dialog.show()
            # Get preprocessing parameters
            params_dict = {
                'despiking': {
                    'enabled': self.despiking_check.isChecked(),
                    'method': self.despiking_method.currentData(),
                    'window': self.despiking_window.value(),
                    'threshold': self.despiking_threshold.value()
                },
                'baseline_correction': {
                    'enabled': self.baseline_check.isChecked(),
                    'method': self.baseline_method.currentData(),
                    'polynomial_order': self.poly_order.value()
                },
                'smoothing': {
                    'enabled': self.smooth_check.isChecked(),
                    'method': self.smooth_method.currentData(),
                    'window_length': self.window_size.value(),
                    'polyorder': self.smooth_poly_order.value()
                },
                'scatter_correction': {
                    'enabled': self.scatter_check.isChecked(),
                    'method': self.scatter_method.currentData()
                },
                'standardization': {
                    'enabled': self.standardize_check.isChecked(),
                    'method': self.standardize_method.currentData()
                },
                'normalization': {
                    'enabled': self.norm_check.isChecked(),
                    'method': self.norm_method.currentData()
                },
                'derivative': {
                    'enabled': self.derivative_check.isChecked(),
                    'order': self.derivative_order.value()
                },
                'outlier_detection': {'enabled': self.outlier_check.isChecked(), 'method': 'Z-score', 'threshold': self.outlier_threshold.value()},
                'denoising': {'enabled': self.denoise_check.isChecked(), 'strength': self.denoise_strength.value()},
                'alignment': {'enabled': self.alignment_check.isChecked(), 'method': self.alignment_method.currentData()},
            }
            if self.wavelength_calib_check.isChecked() or self.intensity_calib_check.isChecked():
                raise ValueError('Wavelength and intensity calibration require validated calibration fixtures and are not implemented in this version.')
            # Extract enabled methods
            methods = []
            for method_name, params in params_dict.items():
                if params.get('enabled', False):
                    methods.append(method_name)
            print(f"Applying preprocessing methods: {methods}")
            print(f"Recorded {len(methods)} preprocessing methods to applied_methods")
            # Update progress
            self.progress_dialog.update_progress(25, _("main_window.preprocessing_in_progress"))
            # Use the controller's off-thread preprocessing worker and apply the
            # result dict on the UI thread.
            self._preprocessing_worker = self.controller.preprocessing_controller.start_preprocessing_worker(
                methods, params_dict,
                on_result=lambda result: self._on_preprocessing_result(methods, result),
                on_error=self._on_preprocessing_error,
            )
            self.progress_dialog.cancelled.connect(self._preprocessing_worker.cancel)
        except Exception as e:
            if hasattr(self, 'progress_dialog') and self.progress_dialog:
                self.progress_dialog.update_progress(100)
                self.progress_dialog.close()
            QMessageBox.critical(self, _("main_window.message"), _("main_window.preprocessing_failed").format(error=str(e)))

    def _finish_preprocessing(self, methods, success):
        """Preprocessing worker finished: run the UI updates that used to execute synchronously."""
        try:
            if success:
                # Record operation in history before updating data
                if hasattr(self, 'current_spectra') and self.current_spectra is not None:
                    import datetime
                    operation_record = {
                        'time': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        'operation': f"Preprocessing: {', '.join(methods)}",
                        'data': self.current_spectra.copy(),
                        'snapshot': getattr(self, '_pending_preprocessing_snapshot', None)
                    }
                    self.operation_history.append(operation_record)
                    self._pending_preprocessing_snapshot = None
                    # Keep only last 10 operations to avoid memory issues
                    if len(self.operation_history) > 10:
                        self.operation_history.pop(0)
                
                # Update progress
                self.progress_dialog.update_progress(75, _("main_window.updating_visualization"))
                # Update current data reference
                data_model = self.controller.data_controller.data_model
                current_data = data_model.get_data()
                if current_data is not None:
                    self.current_spectra = data_model.get_X().to_numpy(copy=True)
                    if data_model.has_partitioned_data():
                        # This matrix is only for the preview canvas. Modeling
                        # consumes the keyed X_train/X_test kept on DataModel.
                        preview = data_model.X_processed
                        self.processed_spectra = None if preview is None else preview.values
                        if (
                            getattr(data_model, 'partitioned_input_representation', 'raw_spectrum')
                            != 'raw_spectrum'
                            and self.current_feature_source == 'original'
                        ):
                            self.current_feature_source = 'preprocessed'
                    else:
                        preview = data_model.get_preprocessed_data()
                        self.processed_spectra = (
                            preview.values if preview is not None
                            else data_model.get_X().values
                        )
                # Update visualization if available
                if hasattr(self, 'visualization_widget') and hasattr(self, 'original_spectra'):
                    try:
                        # Use unified data processor to get safe labels
                        from app.utils.unified_data_processor import unified_processor

                        safe_labels = None
                        if unified_processor.is_initialized:
                            safe_labels = unified_processor.get_safe_labels_for_visualization()
                            print(f"Using unified processor safe labels: {safe_labels[:3] if len(safe_labels) > 0 else []}")

                        if hasattr(self, 'processed_spectra') and self.processed_spectra is not None:
                            # A full-data preview after partitioning is not a
                            # modeling input. Keep this cache only for an
                            # unpartitioned exploratory preview.
                            if not data_model.has_partitioned_data():
                                self.feature_data_options['preprocessed'] = self.processed_spectra.copy()
                                if self.current_feature_source == 'original':
                                    self.current_feature_source = 'preprocessed'
                                    self.statusBar().showMessage(_("main_window.switched_to_preprocessed"), 5000)

                            # Ensure original_spectra also excludes labels
                            original_spectra_clean = self.original_spectra
                            if hasattr(self, 'original_spectra') and self.original_spectra.shape[1] > 100:  # If too many columns, may contain labels
                                if self.original_spectra.shape[1] == self.processed_spectra.shape[1] + 1:
                                    original_spectra_clean = self.original_spectra[:, 1:]  # exclude first column labels
                                    print(f"Original spectra after excluding label column: {original_spectra_clean.shape}")

                            self.visualization_widget.plot_spectra_comparison(
                                self.wavelengths,
                                original_spectra_clean,
                                self.processed_spectra,
                                title=_("main_window.preprocessing_result_title")
                            )
                        else:
                            # If no processed data, only display original data
                            self.visualization_widget.plot_spectra(
                                self.wavelengths,
                                self.original_spectra,
                                title=_("main_window.original_spectra_title"),
                                labels=safe_labels  # use safe labels
                            )
                    except Exception as viz_error:
                        print(f"Visualization update failed: {viz_error}")
                        import traceback
                        traceback.print_exc()
                # Complete
                self.progress_dialog.update_progress(100, _("main_window.preprocessing_complete"))
                self.progress_dialog.close()
                self.statusBar().showMessage(_("main_window.preprocessing_complete"))
                QMessageBox.information(self, _("main_window.message_7"), _("main_window.preprocessing_success").format(count=len(methods)))
            else:
                self.progress_dialog.close()
                QMessageBox.critical(self, _("main_window.message"), _("main_window.preprocessing_failed_console"))
        except Exception as e:
            if hasattr(self, 'progress_dialog') and self.progress_dialog:
                self.progress_dialog.close()
            QMessageBox.critical(self, _("main_window.message"), _("main_window.preprocessing_failed").format(error=str(e)))
            print(f"Preprocessing error: {e}")
            import traceback
            traceback.print_exc()

    def _on_preprocessing_result(self, methods, result):
        """Apply the preprocessing result dict on the UI thread and finish."""
        if result is None or not result.get('success'):
            error = str(result.get('error', 'Preprocessing failed')) if isinstance(result, dict) else 'Preprocessing failed'
            self._on_preprocessing_error(error)
            return
        applied = self.controller.data_controller.data_model.set_preprocessing_result(result)
        if not applied:
            self._on_preprocessing_error(
                "Preprocessing output was discarded because the dataset or split changed while it was running."
            )
            return
        # A committed new input invalidates every prediction/selection derived
        # from the previous input, while the split and undo snapshot survive.
        data_model = self.controller.data_controller.data_model
        with data_model._lock:
            data_model.X_train_selected = None
            data_model.X_test_selected = None
            data_model.selected_features = None
            data_model._state_revision += 1
        self.invalidate_dataset_feature_state(clear_history=False)
        self.current_spectra = data_model.get_X().to_numpy(copy=True)
        self.controller.preprocessing_controller.record_applied_methods(result)
        self._finish_preprocessing(methods, True)

    def _on_preprocessing_error(self, error):
        """Preprocessing worker failed."""
        if hasattr(self, 'progress_dialog') and self.progress_dialog:
            self.progress_dialog.update_progress(100)
            self.progress_dialog.close()
        QMessageBox.critical(self, _("main_window.message"), _("main_window.preprocessing_failed").format(error=str(error)))

    def extract_features(self):
        """Extract features from the spectral data"""
        QMessageBox.information(self, _("main_window.message_8"), _("main_window.feature_redirect"))
        return

    def update_analysis_methods(self, analysis_type):
        """Update available analysis methods based on analysis type"""
        self.analysis_method.clear()    
        if analysis_type == "Quantitative":    
            for _text, _key in [('Multiple linear regression', 'mlr'), ('Ridge regression', 'ridge'),
                ('Lasso regression', 'lasso'), ('Elastic Net regression', 'elasticnet'),
                ('Decision tree regression', 'dt'), (_("main_window.plsr_item"), "PLSR"),
                (_("main_window.svr_item"), "SVR"),
                (_("main_window.rf_item"), "RF"),
                (_("main_window.nn_item"), "NN"),
                (_("main_window.gpr_item"), "GPR"),
                (_("main_window.xgboost_item"), "XGBoost"),
                (_("main_window.lightgbm_item"), "LightGBM")]:
                self.analysis_method.addItem(_text, _key)
            self.evaluation_metric.clear()    
            for _text, _key in [(_("main_window.rmse_item"), "RMSE"),
                (_("main_window.mae_item"), "MAE"),
                (_("main_window.r2_item"), "R2"),
                (_("main_window.r_item"), "R"),
                (_("main_window.re_item"), "RE")]:
                self.evaluation_metric.addItem(_text, _key)
        else:    
            for _text, _key in [('Logistic regression', 'logistic'), (_("main_window.svm_item"), "SVM"),
                (_("main_window.rf_item"), "RF"),
                (_("main_window.knn_item"), "KNN"),
                (_("main_window.dt_item"), "DT"),
                (_("main_window.nn_item"), "NN"),
                (_("main_window.xgboost_item"), "XGBoost"),
                (_("main_window.lightgbm_item"), "LightGBM")]:
                self.analysis_method.addItem(_text, _key)
            self.evaluation_metric.clear()    
            for _text, _key in [(_("main_window.accuracy_item"), "Accuracy"),
                (_("main_window.precision_item"), "Precision"),
                (_("main_window.recall_item"), "Recall"),
                ("F1", "F1"),
                (_("main_window.auc_item"), "AUC")]:
                self.evaluation_metric.addItem(_text, _key)

        # Keep the established default despite adding the paper's inventory.
        default_key = 'PLSR' if analysis_type == 'Quantitative' else 'SVM'
        self.analysis_method.setCurrentIndex(self.analysis_method.findData(default_key))
        self._mark_optional_analysis_methods()

    def _model_parameter_schema(self, method=None):
        method = str(method or self.analysis_method.currentData()).lower()
        # (kind, default, minimum, maximum) or (choice, default, options).
        schemas = {
            'mlr': {'fit_intercept': ('bool', True)},
            'ridge': {'alpha': ('float', 1.0, 0.0, 1000000.0), 'fit_intercept': ('bool', True)},
            'lasso': {'alpha': ('float', 0.01, 0.000001, 1000000.0), 'max_iter': ('int', 10000, 100, 1000000)},
            'elasticnet': {'alpha': ('float', 0.01, 0.000001, 1000000.0), 'l1_ratio': ('float', 0.5, 0.0, 1.0), 'max_iter': ('int', 10000, 100, 1000000)},
            'dt': {'max_depth': ('int', 8, 1, 100), 'min_samples_leaf': ('int', 2, 1, 10000)},
            'logistic': {'C': ('float', 1.0, 0.000001, 1000000.0), 'max_iter': ('int', 2000, 100, 1000000)},
            'plsr': {'n_components': ('int', 3, 1, 1000)},
            'svr': {'C': ('float', 10.0, 0.000001, 1000000.0), 'epsilon': ('float', 0.1, 0.0, 1000.0)},
            'svm': {'C': ('float', 10.0, 0.000001, 1000000.0)},
            'rf': {'n_estimators': ('int', 100, 1, 10000), 'max_depth': ('int', 10, 1, 100)},
            'nn': {'max_iter': ('int', 2000, 100, 1000000)},
            'gpr': {'alpha': ('float', 0.000001, 0.000000001, 100.0), 'normalize_y': ('bool', False)},
            'lda': {'tol': ('float', 0.0001, 0.000000001, 0.1)},
            'qda': {'reg_param': ('float', 0.1, 0.0, 1.0)},
            'knn': {'n_neighbors': ('int', 5, 1, 1000)},
            'xgboost': {'n_estimators': ('int', 100, 1, 10000), 'max_depth': ('int', 6, 1, 100), 'learning_rate': ('float', 0.1, 0.000001, 1.0)},
            'lightgbm': {'n_estimators': ('int', 100, 1, 10000), 'learning_rate': ('float', 0.1, 0.000001, 1.0)},
        }
        return schemas.get(method, {})

    def open_model_parameters(self):
        """Edit parameters for the mounted selected estimator."""
        method = str(self.analysis_method.currentData()).lower()
        schema = self._model_parameter_schema(method)
        if not schema:
            QMessageBox.information(self, 'Model parameters', 'This estimator has no configurable parameters in this route.')
            return
        dialog = QDialog(self)
        dialog.setWindowTitle(self.analysis_method.currentText() + ' parameters')
        layout = QFormLayout(dialog)
        widgets = {}
        existing = self.model_parameter_values.get(method, {})
        for name, spec in schema.items():
            kind, default, *bounds = spec
            value = existing.get(name, default)
            if kind == 'bool':
                widget = QCheckBox(dialog); widget.setChecked(bool(value))
            elif kind == 'int':
                widget = QSpinBox(dialog); widget.setRange(*bounds); widget.setValue(int(value))
            else:
                widget = QDoubleSpinBox(dialog); widget.setDecimals(9); widget.setRange(*bounds); widget.setValue(float(value))
            widget.setObjectName('modelParameter_' + name)
            widgets[name] = widget
            layout.addRow(name, widget)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, parent=dialog)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)
        from app.utils.responsive import fit_window_to_screen
        fit_window_to_screen(dialog, 520, 360, min_width=300, min_height=180)
        if dialog.exec_() == QDialog.Accepted:
            self.model_parameter_values[method] = {name: widget.isChecked() if isinstance(widget, QCheckBox) else widget.value()
                                                  for name, widget in widgets.items()}
        return dialog

    def _mark_optional_analysis_methods(self):
        import importlib.util
        for key, module in (('XGBoost', 'xgboost'), ('LightGBM', 'lightgbm')):
            index = self.analysis_method.findData(key)
            if index >= 0 and importlib.util.find_spec(module) is None:
                item = self.analysis_method.model().item(index)
                item.setEnabled(False)
                item.setToolTip(f'{key} is not installed in this Python environment.')

    def _require_verified_model_split(self, data_model, action, *, report_error=False,
                                      require_split=False):
        """Block modeling consumers from using an unverified legacy split.

        This guard is shared by the Analyze preparation path and modeling PCA,
        so callers cannot bypass the row-alignment check through a different UI
        entry point. Exploratory, unsplit data keeps its existing behavior.
        """
        has_split_attempt = getattr(data_model, 'has_split_attempt', None)
        split_attempt = (
            bool(has_split_attempt()) if callable(has_split_attempt)
            else getattr(data_model, 'partitioned_data', None) is not None
            or any(getattr(data_model, name, None) is not None
                   for name in ('X_train', 'y_train', 'X_test', 'y_test'))
        )
        if not split_attempt and not require_split:
            return True

        has_partitioned_data = getattr(data_model, 'has_partitioned_data', None)
        has_partition_record = (
            bool(has_partitioned_data()) if callable(has_partitioned_data)
            else getattr(data_model, 'partitioned_data', None) is not None
        )
        has_verified_split = getattr(data_model, 'has_verified_split', None)
        verified_split = (
            bool(has_verified_split()) if callable(has_verified_split)
            else has_partition_record
            and getattr(data_model, 'row_alignment_verified', False)
            and all(getattr(data_model, name, None) is not None
                    for name in ('X_train', 'y_train', 'X_test', 'y_test'))
        )
        if split_attempt and verified_split:
            return True

        if not split_attempt:
            message = f"A train/test split is required. Create the split before {action}."
        else:
            message = (
                "The current train/test split has no verified internal row alignment. "
                f"Recreate the split before {action}."
            )
        if report_error:
            self.display_error(message)
            return False
        raise ValueError(message)

    def _prepare_modeling_data(self, analysis_type):
        """
        Consolidated entry point for modeling data preparation.

        Returns a definitive task_type ('classification' or 'regression') and the
        prepared X_train, X_test, y_train, y_test. The task_type is driven by the
        user's analysis-type selection; mismatches between the selection and the
        data are surfaced as clear errors instead of silently corrected.
        """
        if not hasattr(self, 'controller') or not hasattr(self.controller, 'data_controller'):
            raise ValueError("Data controller not initialized")
        data_model = self.controller.data_controller.data_model
        # Check before selecting feature caches or writing train/test arrays to
        # ModelingModel; start_analysis() will surface this actionable error.
        self._require_verified_model_split(data_model, "model analysis", require_split=True)

        # Select the appropriate feature source.
        X_train, X_test = None, None
        if (self.current_feature_source == 'selected_features' and
                self.feature_data_options.get('selected_features') is not None):
            selected_data = self.feature_data_options['selected_features']
            X_train = selected_data['X_train']
            X_test = selected_data['X_test']
        elif (hasattr(self.controller, 'feature_selection_controller') and
              hasattr(self.controller.feature_selection_controller, 'feature_selection_model') and
              hasattr(self.controller.feature_selection_controller.feature_selection_model, 'selected_features')):
            self.progress_dialog.update_progress(10, _("main_window.using_selected_features"))
            if hasattr(data_model, 'X_train_selected') and data_model.X_train_selected is not None:
                X_train = data_model.X_train_selected
                X_test = data_model.X_test_selected
            else:
                X_train = data_model.X_train
                X_test = data_model.X_test
        else:
            X_train = data_model.X_train
            X_test = data_model.X_test

        y_train = data_model.y_train
        y_test = data_model.y_test

        # The representation is recorded alongside the partition matrices.
        # The UI selector can be stale after split-safe preprocessing, so it
        # cannot label the active matrices as raw based on selection state.
        matrix_representation = getattr(
            data_model, 'partitioned_input_representation', 'fitted_feature_matrix'
        )
        if self.current_feature_source in ('original', 'preprocessed'):
            input_representation = matrix_representation
            if input_representation == 'raw_spectrum':
                self.current_feature_source = 'original'
            elif input_representation.startswith('prepared:'):
                self.current_feature_source = 'preprocessed'
        else:
            input_representation = f'prepared:{self.current_feature_source}'

        # Cache raw train/test data on the modeling model for downstream workflows.
        if hasattr(self.controller, 'modeling_controller') and hasattr(self.controller.modeling_controller, 'modeling_model'):
            modeling_model = self.controller.modeling_controller.modeling_model
            modeling_model.X_train = X_train
            modeling_model.X_test = X_test
            modeling_model.y_train = y_train
            modeling_model.y_test = y_test
            cv_unsafe_reason = _cv_unavailable_transform_reason(
                self.current_feature_source, self.feature_data_options, data_model
            )
            modeling_model.cv_scope_safe = cv_unsafe_reason is None
            modeling_model.cv_scope_reason = cv_unsafe_reason
            modeling_model.cv_train_sample_ids = (
                list(data_model.X_train.index)
                if isinstance(getattr(data_model, 'X_train', None), pd.DataFrame)
                else list(range(len(X_train))) if X_train is not None else None
            )
            modeling_model.cv_test_sample_ids = (
                list(data_model.X_test.index)
                if isinstance(getattr(data_model, 'X_test', None), pd.DataFrame)
                else []
            )
            partition = data_model.get_partitioned_data() or {}
            train_index = data_model.X_train.index if isinstance(data_model.X_train, pd.DataFrame) else None
            test_index = data_model.X_test.index if isinstance(data_model.X_test, pd.DataFrame) else None
            modeling_model.cv_train_physical_sample_ids = (
                partition['sample_id_train'].loc[train_index].tolist()
                if partition.get('sample_id_train') is not None and train_index is not None else None
            )
            modeling_model.cv_test_physical_sample_ids = (
                partition['sample_id_test'].loc[test_index].tolist()
                if partition.get('sample_id_test') is not None and test_index is not None else None
            )
            modeling_model.cv_train_group_ids = (
                partition['group_id_train'].loc[train_index].tolist()
                if partition.get('group_id_train') is not None and train_index is not None else None
            )
            modeling_model.cv_test_group_ids = (
                partition['group_id_test'].loc[test_index].tolist()
                if partition.get('group_id_test') is not None and test_index is not None else None
            )
            modeling_model.cv_group_validation = bool(partition.get('group_validation', False))
            modeling_model.cv_feature_names = (
                list(X_train.columns) if isinstance(X_train, pd.DataFrame) else None
            )
            modeling_model.cv_input_representation = input_representation

        # Definitive task type comes from the user's selection.
        if analysis_type.startswith("Quantitative"):
            task_type = 'regression'
        else:
            task_type = 'classification'

        if y_train is None:
            raise ValueError("Missing training labels (y_train).")

        from app.utils.label_processor import EnhancedLabelProcessor
        label_processor = EnhancedLabelProcessor()
        detected_task_type = label_processor.detect_task_type(y_train)

        # Surface mismatches as clear errors; offer to switch instead of silently
        # overriding the user.
        if task_type == 'regression' and detected_task_type == 'classification':
            sample = sorted(list(set(str(label) for label in y_train[:10])))
            reply = QMessageBox.question(
                self,
                _("main_window.analysis_type_mismatch_title"),
                _("main_window.quantitative_to_qualitative_prompt").format(labels=sample),
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if reply == QMessageBox.Yes:
                task_type = 'classification'
                idx = self.analysis_type.findData("Qualitative")
                if idx >= 0:
                    self.analysis_type.setCurrentIndex(idx)
            else:
                raise ValueError(
                    f"Quantitative analysis requires numeric targets, but the labels look categorical "
                    f"(sample labels: {sample}). Please select Qualitative analysis for classification tasks."
                )
        if task_type == 'classification' and detected_task_type == 'regression':
            reply = QMessageBox.question(
                self,
                _("main_window.analysis_type_mismatch_title"),
                _("main_window.qualitative_to_quantitative_prompt"),
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if reply == QMessageBox.Yes:
                task_type = 'regression'
                idx = self.analysis_type.findData("Quantitative")
                if idx >= 0:
                    self.analysis_type.setCurrentIndex(idx)
            else:
                raise ValueError(
                    "Qualitative analysis requires categorical labels, but the labels look continuous. "
                    "Please select Quantitative analysis for regression tasks."
                )

        # Process labels according to the definitive task type.
        if task_type == 'classification':
            # Decode numeric labels via the data-model mapping when available.
            if hasattr(data_model, 'label_mapping') and data_model.label_mapping:
                index_to_label = data_model.label_mapping.get('index_to_label', {})
                if index_to_label:
                    safe_mapping = {k: str(v) for k, v in index_to_label.items()}

                    def _decode_with_mapping(label):
                        try:
                            return str(safe_mapping.get(int(label), str(label)))
                        except (ValueError, TypeError):
                            return str(label)

                    # Only attempt mapping when labels look numeric; string labels are kept as-is.
                    if len(y_train) > 0:
                        try:
                            int(y_train[0])
                            y_train = np.array([_decode_with_mapping(label) for label in y_train], dtype=str)
                        except (ValueError, TypeError):
                            pass
                    if y_test is not None and len(y_test) > 0:
                        try:
                            int(y_test.iloc[0] if isinstance(y_test, pd.Series) else y_test[0])
                            if isinstance(y_test, pd.Series):
                                y_test = y_test.map(_decode_with_mapping)
                                y_test = np.array(y_test, dtype=str)
                            else:
                                y_test = np.array([_decode_with_mapping(label) for label in y_test], dtype=str)
                        except (ValueError, TypeError):
                            pass

            # Ensure string arrays.
            if y_train is not None:
                if not isinstance(y_train, np.ndarray) or y_train.dtype.kind not in 'SU':
                    y_train = np.array([str(label) for label in y_train], dtype=str)
            if y_test is not None:
                if not isinstance(y_test, np.ndarray) or y_test.dtype.kind not in 'SU':
                    y_test = np.array([str(label) for label in y_test], dtype=str)
        else:
            # Regression: coerce to numeric and reject non-numeric labels.
            if isinstance(y_train, pd.Series):
                y_train_numeric = pd.to_numeric(y_train, errors='coerce')
            else:
                y_train_numeric = pd.to_numeric(pd.Series(y_train), errors='coerce')
            if y_train_numeric.isna().any():
                failed = y_train[y_train_numeric.isna()][:3].tolist()
                raise ValueError(
                    f"Quantitative analysis requires numeric labels, but non-numeric values were found: {failed}. "
                    "Please select Qualitative analysis for classification tasks."
                )
            y_train = y_train_numeric.values

            if y_test is not None:
                if isinstance(y_test, pd.Series):
                    y_test_numeric = pd.to_numeric(y_test, errors='coerce')
                else:
                    y_test_numeric = pd.to_numeric(pd.Series(y_test), errors='coerce')
                if y_test_numeric.isna().any():
                    failed = y_test[y_test_numeric.isna()][:3].tolist()
                    raise ValueError(
                        f"Quantitative analysis requires numeric test labels, but non-numeric values were found: {failed}. "
                        "Please select Qualitative analysis for classification tasks."
                    )
                y_test = y_test_numeric.values

        # Final array conversion.
        X_train = np.array(X_train)
        X_test = np.array(X_test)
        y_train = np.array(y_train)
        if y_test is not None:
            y_test = np.array(y_test)

        return X_train, X_test, y_train, y_test, task_type

    def _predict_and_evaluate(self, analyzer, X_test, y_test, task_type,
                              row_ids=None, physical_sample_ids=None,
                              group_ids=None):
        """Use one fitted prediction result for scoring and UI output."""
        prediction_result = analyzer.predict_result(
            X_test,
            row_ids=row_ids,
            physical_sample_ids=physical_sample_ids,
            group_ids=group_ids,
        )
        from app.services.evaluation_service import EvaluationService
        metrics = EvaluationService().evaluate_prediction_result(
            y_test, prediction_result,
            metrics=(['rmse', 'mae', 'r2'] if task_type == 'regression'
                     else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
            task_type=task_type,
            row_ids=row_ids,
            physical_sample_ids=physical_sample_ids,
            group_ids=group_ids,
        )
        return prediction_result, metrics

    def start_analysis(self):
        """Start the spectral analysis process"""
        global pd
        if self.current_spectra is None:    
            QMessageBox.warning(self, _("main_window.message_2"), _("main_window.load_spectral_data_first"))    
            return
          
        if not self.reference_method.currentData():
            QMessageBox.warning(self, _("main_window.message_2"), _("main_window.select_reference_method"))
            return
        analysis_type = self.analysis_type.currentData()    
        method = self.analysis_method.currentData()    
          
        method_mapping = {
            "Neural Network": "nn", 
            "XGBoost": "xgboost",
            "LightGBM": "lightgbm",
            "Random Forest": "rf"
        }
          
        if method in method_mapping:
            method = method_mapping[method]
        else:
              
            method = method.lower()
        try:
              
            self.progress_dialog = ProgressDialog(_("main_window.analysis_progress_title"), self)    
            self.progress_dialog.show()    
              
            self.progress_dialog.update_progress(10, _("main_window.preparing_data"))
            X_train, X_test, y_train, y_test, task_type = self._prepare_modeling_data(analysis_type)
            data_model = self.controller.data_controller.data_model
            cv_unsafe_reason = _cv_unavailable_transform_reason(
                self.current_feature_source, self.feature_data_options, data_model
            )
            cv_sample_ids = (
                list(data_model.X_train.index)
                if isinstance(getattr(data_model, 'X_train', None), pd.DataFrame)
                else list(range(len(X_train))) if X_train is not None else None
            )
            cv_outer_test_ids = (
                list(data_model.X_test.index)
                if isinstance(getattr(data_model, 'X_test', None), pd.DataFrame)
                else []
            )
            modeling_model = self.controller.modeling_controller.modeling_model
            cv_physical_ids = getattr(modeling_model, 'cv_train_physical_sample_ids', None)
            cv_outer_physical_ids = getattr(modeling_model, 'cv_test_physical_sample_ids', None)
            cv_group_ids = getattr(modeling_model, 'cv_train_group_ids', None)
            cv_outer_group_ids = getattr(modeling_model, 'cv_test_group_ids', None)
            cv_group_validation = bool(getattr(modeling_model, 'cv_group_validation', False))
            predictor_fit_scope = {
                'row_ids': cv_sample_ids,
                'physical_sample_ids': cv_physical_ids,
                'group_ids': cv_group_ids,
                'group_validation': cv_group_validation,
                'input_representation': getattr(
                    modeling_model, 'cv_input_representation', 'fitted_feature_matrix'
                ),
                'feature_names': getattr(modeling_model, 'cv_feature_names', None),
            }
            prediction_result = None
            y_pred = None

            if X_train is None or y_train is None:
                x_status = "missing" if X_train is None else "available"
                y_status = "missing" if y_train is None else "available"
                error_msg = _(
                    "main_window.data_missing_error_body"
                ).format(x_status=x_status, y_status=y_status)
                self.display_error(error_msg, _("main_window.data_missing_error_title"))
                self.progress_dialog.hide()
                return

            print("=== Data Quality Check ===")
            print(f"Training samples: {X_train.shape[0]}")
            print(f"Features: {X_train.shape[1]}")
            print(f"Unique labels: {len(np.unique(y_train))}")
            # Check training sample count
            if X_train.shape[0] < 20:
                error_msg = _("main_window.insufficient_training_data_samples").format(samples=X_train.shape[0])
                self.display_error(error_msg.strip(), _("main_window.insufficient_training_data_title"))
                self.progress_dialog.hide()
                return
            # Check feature count - lower minimum to accommodate feature selection
            if X_train.shape[1] < 2:
                error_msg = _("main_window.insufficient_features_count").format(features=X_train.shape[1])
                self.display_error(error_msg.strip(), _("main_window.insufficient_features_title"))
                self.progress_dialog.hide()
                return
            elif X_train.shape[1] < 5:
                print(f"Warning: Only {X_train.shape[1]} features available. Results may be limited with very few features.")
            elif X_train.shape[1] < 10:
                print(f"Notice: {X_train.shape[1]} features available. This is acceptable for modeling, especially after feature selection.")
            # Check label quality for classification
            if task_type == 'classification':
                unique_labels = len(np.unique(y_train))
                if unique_labels < 2:
                    self.display_error(_("main_window.insufficient_label_classes"), _("main_window.insufficient_label_classes_title"))
                    self.progress_dialog.hide()
                    return
                # Only warn if classes exceed 95% of samples (extremely unrealistic)
                elif unique_labels > X_train.shape[0] * 0.95:
                    print(f"Warning: High number of classes ({unique_labels} classes for {X_train.shape[0]} samples). This might indicate a regression problem disguised as classification.")
                    # Don't return - allow the analysis to continue
              
            hyperopt_params = {
                'method': self.optimization_method.currentData(),    
                'metric': self.evaluation_metric.currentData(),    
                'cv_folds': self.cv_folds.value(),    
                'max_iterations': self.max_iterations.value()    
            }
              
              
            if task_type == 'regression':  # Quantitative analysis
                self.progress_dialog.update_progress(25, _("main_window.performing_quantitative_analysis"))  # Update progress to 25%
                # Set analysis type to quantitative
                if hasattr(self.controller, 'modeling_controller') and hasattr(self.controller.modeling_controller, 'modeling_model'):
                    self.controller.modeling_controller.modeling_model.set_analysis_type('quantitative')
                    print("Explicitly setting analysis type to quantitative")
                analyzer = QuantitativeAnalyzer(  # Create quantitative analyzer
                    method=method.lower()  # Set analysis method
                )
                # Train model
                self.progress_dialog.update_progress(40, _("main_window.training_quantitative_model"))
                # Prepare parameters, ensure task type is correct
                model_params = {**self.model_parameter_values.get(method, {}), 'task_type': 'regression', **predictor_fit_scope}
                try:
                    # Labels were already validated and converted to numeric by
                    # _prepare_modeling_data(); use them directly.
                    y_train_safe = y_train
                    run_heavy(lambda: analyzer.fit(X_train, y_train_safe, **model_params), progress_dialog=self.progress_dialog)  # Fit model with explicit regression task type
                    if self.progress_dialog.was_cancelled:
                        self.progress_dialog.close()
                        return
                except ImportError as e:
                    # Handle import errors - if required libraries are not installed
                    error_msg = _("main_window.required_library_not_installed").format(error=str(e))
                    self.display_error(error_msg)
                    self.progress_dialog.hide()
                    return
                except Exception as e:
                    # Handle other training errors
                    error_msg = _("main_window.error_training_model").format(error=str(e))
                    self.display_error(error_msg)
                    self.progress_dialog.hide()
                    return
                # Update progress bar to avoid getting stuck at 40%
                self.progress_dialog.update_progress(50, _("main_window.model_training_completed"))
                # Cross-validation
                self.progress_dialog.update_progress(60, _("main_window.performing_cv"))
                # Use the converted y_train_safe for cross-validation to maintain consistency
                results = run_heavy(
                    lambda: _execute_fold_safe_cv(
                        analyzer, X_train, y_train_safe, task_type,
                        hyperopt_params['cv_folds'], cv_sample_ids,
                        cv_outer_test_ids, cv_unsafe_reason,
                        cv_physical_ids, cv_outer_physical_ids,
                        cv_group_ids, cv_outer_group_ids, cv_group_validation,
                    ),
                    progress_dialog=self.progress_dialog,
                )
                if results is None:
                    self.progress_dialog.close()
                    return
                # Make predictions
                if X_test is not None and y_test is not None:
                    self.progress_dialog.update_progress(70, _("main_window.making_predictions"))
                    prediction_result, metric_values = run_heavy(
                        lambda: self._predict_and_evaluate(
                            analyzer, X_test, y_test, 'regression',
                            row_ids=cv_outer_test_ids,
                            physical_sample_ids=cv_outer_physical_ids,
                            group_ids=cv_outer_group_ids,
                        ),
                        progress_dialog=self.progress_dialog,
                    )
                    if prediction_result is None:
                        self.progress_dialog.close()
                        return
                    y_pred = prediction_result.predictions
                    results.update({
                        'test_rmse': metric_values.get('rmse'),
                        'test_r2': metric_values.get('r2'),
                        'test_mae': metric_values.get('mae'),
                        'task_type': 'regression'
                    })
                  
                if hasattr(self.controller, 'modeling_controller') and hasattr(self.controller.modeling_controller, 'modeling_model'):
                    modeling_model = self.controller.modeling_controller.modeling_model
                    modeling_model.set_model(analyzer.model)
                    modeling_model.trained_model = analyzer.model
                    modeling_model.fitted_predictor = analyzer.fitted_predictor
                    modeling_model.prediction_result = prediction_result
                    modeling_model.analyzer = analyzer
                    modeling_model.diagnostics = None
                    modeling_model.diagnostic_inputs = {'X_train': X_train.copy(), 'X_test': X_test.copy() if X_test is not None else None,
                        'y_train': y_train.copy(), 'y_test': y_test.copy() if y_test is not None else None, 'task_type': task_type}
                    modeling_model.set_model_data(None)
                    self._update_optimizer_button()
                    self.controller.modeling_controller.modeling_model.set_method(method)
                    self.controller.modeling_controller.modeling_model.set_evaluation_results(results)
            else:  # classification / qualitative analysis
                self.progress_dialog.update_progress(25, _("main_window.performing_qualitative_analysis"))  # Update progress to 25%
                # Set analysis type to qualitative
                if hasattr(self.controller, 'modeling_controller') and hasattr(self.controller.modeling_controller, 'modeling_model'):
                    self.controller.modeling_controller.modeling_model.set_analysis_type('qualitative')
                analyzer = QualitativeAnalyzer(  # Create qualitative analyzer
                    method=method  # Set analysis method
                )
                # Train model
                self.progress_dialog.update_progress(40, _("main_window.training_qualitative_model"))
                try:
                    # Labels were already validated and converted to strings by
                    # _prepare_modeling_data(); ensure a uniform string array.
                    y_train_safe = y_train
                    sample_types = set(type(v).__name__ for v in y_train_safe[:20])
                    if len(sample_types) > 1:
                        y_train_safe = np.array([str(v) for v in y_train_safe])
                    run_heavy(
                        lambda: analyzer.fit(X_train, y_train_safe, **self.model_parameter_values.get(method, {}), **predictor_fit_scope),
                        progress_dialog=self.progress_dialog,
                    )
                    if self.progress_dialog.was_cancelled:
                        self.progress_dialog.close()
                        return
                except ImportError as e:
                    # Handle import errors - if required libraries are not installed
                    error_msg = _("main_window.required_library_not_installed").format(error=str(e))
                    self.display_error(error_msg)
                    self.progress_dialog.hide()
                    return
                except Exception as e:
                    # Handle other training errors
                    error_msg = _("main_window.error_training_model").format(error=str(e))
                    self.display_error(error_msg)
                    self.progress_dialog.hide()
                    return
                # Update progress bar to avoid getting stuck at 40%
                self.progress_dialog.update_progress(50, _("main_window.model_training_completed"))
                # Cross-validation
                self.progress_dialog.update_progress(60, _("main_window.performing_cv"))
                # Use the same standardized labels for cross-validation
                print("=== MAIN WINDOW: Cross-validation using pre-processed labels ===")
                print(f"Cross-validation labels: {y_train_safe.dtype}, samples: {y_train_safe[:5]}")
                results = run_heavy(
                    lambda: _execute_fold_safe_cv(
                        analyzer, X_train, y_train_safe, task_type,
                        hyperopt_params['cv_folds'], cv_sample_ids,
                        cv_outer_test_ids, cv_unsafe_reason,
                        cv_physical_ids, cv_outer_physical_ids,
                        cv_group_ids, cv_outer_group_ids, cv_group_validation,
                    ),
                    progress_dialog=self.progress_dialog,
                )
                if results is None:
                    self.progress_dialog.close()
                    return
                # Make predictions
                if X_test is not None and y_test is not None:
                    self.progress_dialog.update_progress(70, _("main_window.making_predictions"))
                    # Labels were already standardized to strings by _prepare_modeling_data().
                    y_test_eval = y_test

                    prediction_result, metrics_results = run_heavy(
                        lambda: self._predict_and_evaluate(
                            analyzer, X_test, y_test_eval, 'classification',
                            row_ids=cv_outer_test_ids,
                            physical_sample_ids=cv_outer_physical_ids,
                            group_ids=cv_outer_group_ids,
                        ),
                        progress_dialog=self.progress_dialog,
                    )
                    if prediction_result is None:
                        self.progress_dialog.close()
                        return
                    y_pred = prediction_result.predictions
                    results.update({
                        'test_accuracy': metrics_results.get('accuracy', 0.0),
                        'test_precision': metrics_results.get('precision', 0.0),
                        'test_recall': metrics_results.get('recall', 0.0),
                        'test_f1': metrics_results.get('f1', 0.0),
                        'task_type': 'classification'
                    })
                  
                if hasattr(self.controller, 'modeling_controller') and hasattr(self.controller.modeling_controller, 'modeling_model'):
                    modeling_model = self.controller.modeling_controller.modeling_model
                    modeling_model.set_model(analyzer.model)
                    modeling_model.trained_model = analyzer.model
                    modeling_model.fitted_predictor = analyzer.fitted_predictor
                    modeling_model.prediction_result = prediction_result
                    modeling_model.analyzer = analyzer
                    modeling_model.diagnostics = None
                    modeling_model.diagnostic_inputs = {'X_train': X_train.copy(), 'X_test': X_test.copy() if X_test is not None else None,
                        'y_train': y_train.copy(), 'y_test': y_test.copy() if y_test is not None else None, 'task_type': task_type}
                    modeling_model.set_model_data(None)
                    self._update_optimizer_button()
                    self.controller.modeling_controller.modeling_model.set_method(method)
                    self.controller.modeling_controller.modeling_model.set_evaluation_results(results)
                    
                    # **New: Auto-save ONNX model**
                    self.auto_save_estimator_from_analysis(analyzer.model, X_train, method, results)

                    # **New: Generate reproducibility info**
                    try:
                        from app.services.evaluation_service import EvaluationService
                        eval_service = EvaluationService()
                        preprocessing_params = self._collect_preprocessing_params()
                        feature_selection_params = self._collect_feature_selection_params()
                        cv_results = {
                            'method': f"{cv_folds}-fold CV" if 'cv_folds' in locals() else 'cross-validation',
                            'folds': cv_folds if 'cv_folds' in locals() else 5,
                            'mean_score': results.get('r2') or results.get('r2_score') or results.get('accuracy') or None,
                            'std_score': results.get('std_score', 0.0),
                        }
                        global_rs = getattr(
                            self.controller.modeling_controller.modeling_service,
                            'global_random_state', 42
                        )
                        repro_info = eval_service.generate_reproducibility_info(
                            model=analyzer.model,
                            preprocessing_params=preprocessing_params,
                            feature_selection_params=feature_selection_params,
                            cv_results=cv_results,
                            global_random_state=global_rs,
                        )
                        self.controller.modeling_controller.modeling_model.reproducibility_info = repro_info
                    except Exception as repro_error:
                        logging.warning(f"Reproducibility info generation failed: {repro_error}")
            # Display results
            self.progress_dialog.update_progress(75, _("main_window.generating_analysis_results"))  # Update progress to 75%
            msg = "Analysis Results:\n"  # Initialize result text
            for metric, value in results.items():  # Iterate through results
                if isinstance(value, float):
                    msg += f"{metric}: {value:.4f}\n"  # Add result information
                else:
                    msg += f"{metric}: {value}\n"  # Add result information
              
            self.progress_dialog.update_progress(90, _("main_window.updating_visualization"))
            # Update visualization components - add code based on specific implementation
            if hasattr(self, 'visualization_widget'):
                if analysis_type.startswith("Quantitative") and X_test is not None and y_test is not None:
                    # Display prediction result scatter plot
                    self.visualization_widget.clear()
                    self.visualization_widget.plot_scatter(y_test, y_pred, 
                                                         title=_("main_window.actual_vs_predicted_title"), 
                                                         xlabel="Actual Values", 
                                                         ylabel="Predicted Values")
                elif X_test is not None and y_test is not None:
                    # Display confusion matrix
                    from sklearn.metrics import confusion_matrix

                    print("Preparing confusion matrix visualization...")

                    # Build a consistent label mapping from the union of true and predicted
                    # labels. Unknown labels are included explicitly rather than silently
                    # mapped to class 0.
                    data_model = self.controller.data_controller.data_model
                    original_label_mapping = None
                    if hasattr(data_model, 'label_mapping') and data_model.label_mapping:
                        original_label_mapping = data_model.label_mapping

                    y_test_is_string = hasattr(y_test, 'dtype') and y_test.dtype.kind in ['U', 'S', 'O']
                    y_pred_is_numeric = hasattr(y_pred, 'dtype') and y_pred.dtype.kind in ['i', 'f']

                    if y_test_is_string and y_pred_is_numeric:
                        # Predictions are indices into alphabetically sorted test labels.
                        sorted_labels = sorted(np.unique(y_test))
                        class_names = list(sorted_labels) + ['Unknown']
                        label_to_index = {label: idx for idx, label in enumerate(class_names)}

                        y_test_indices = np.array([label_to_index[str(label)] for label in y_test])
                        max_valid_index = len(sorted_labels) - 1
                        y_pred_indices = np.array([
                            int(pred) if 0 <= int(pred) <= max_valid_index else label_to_index['Unknown']
                            for pred in y_pred
                        ])
                    else:
                        all_labels = set()
                        for label in y_test:
                            all_labels.add(str(label).strip())
                        for label in y_pred:
                            all_labels.add(str(label).strip())
                        if original_label_mapping is not None:
                            for label in original_label_mapping.get('label_to_index', {}):
                                all_labels.add(str(label).strip())

                        sorted_labels = sorted(all_labels)
                        class_names = list(sorted_labels) + ['Unknown']
                        label_to_index = {label: idx for idx, label in enumerate(class_names)}

                        y_test_indices = np.array([label_to_index.get(str(label).strip(), label_to_index['Unknown']) for label in y_test])
                        y_pred_indices = np.array([label_to_index.get(str(label).strip(), label_to_index['Unknown']) for label in y_pred])

                    cm = confusion_matrix(y_test_indices, y_pred_indices)

                    # Display confusion matrix
                    self.visualization_widget.clear()
                    self.visualization_widget.plot_confusion_matrix(cm,
                                                                 class_names=class_names,
                                                                 title=_("main_window.confusion_matrix_title"))
              
            self.progress_dialog.update_progress(95, _("main_window.finalizing_results"))
              
            if hasattr(self.controller, 'modeling_controller') and hasattr(self.controller.modeling_controller, 'modeling_model'):
                if hasattr(self.controller.modeling_controller.modeling_model, 'evaluation_results'):
                      
                    final_results = self.controller.modeling_controller.modeling_model.evaluation_results
                    if final_results:
                        results = final_results
              
            self.result_table.setRowCount(0)
              
            if self.result_table.columnCount() < 5:
                  
                self.result_table.setColumnCount(5)
                self.result_table.setHorizontalHeaderLabels([_("main_window.method_header"), _("main_window.r2accuracy_header"), _("main_window.rmsef1_header"), _("main_window.maeprecision_header"), _("main_window.recall_item")])
              
            row_position = self.result_table.rowCount()
            self.result_table.insertRow(row_position)
              
            method_item = QTableWidgetItem(method)
            self.result_table.setItem(row_position, 0, method_item)
              
            is_quantitative = analysis_type.startswith("Quantitative")
            task_type = results.get('task_type', 'unknown')
            print(f"Displaying results - Analysis type: {analysis_type}, Task type: {task_type}")
              
            if is_quantitative or task_type == 'regression':
                  
                r2_value = results.get('r2_mean', results.get('test_r2', 0.0))
                r2_item = QTableWidgetItem(f"{r2_value:.4f}")
                self.result_table.setItem(row_position, 1, r2_item)
                rmse_value = results.get('rmse_mean', results.get('test_rmse', 0.0)) 
                rmse_item = QTableWidgetItem(f"{rmse_value:.4f}")
                self.result_table.setItem(row_position, 2, rmse_item)
                  
                mae_value = results.get('mae_mean', results.get('test_mae', 0.0))
                mae_item = QTableWidgetItem(f"{mae_value:.4f}")
                self.result_table.setItem(row_position, 3, mae_item)
                  
                self.result_table.setItem(row_position, 4, QTableWidgetItem("-"))
            else:
                  
                acc_value = results.get('accuracy', results.get('test_accuracy', 0.0))
                acc_item = QTableWidgetItem(f"{acc_value:.4f}")
                self.result_table.setItem(row_position, 1, acc_item)
                f1_value = results.get('f1_score', results.get('test_f1', 0.0))
                f1_item = QTableWidgetItem(f"{f1_value:.4f}")
                self.result_table.setItem(row_position, 2, f1_item)
                precision_value = results.get('precision', results.get('test_precision', 0.0))
                precision_item = QTableWidgetItem(f"{precision_value:.4f}")
                self.result_table.setItem(row_position, 3, precision_item)
                recall_value = results.get('recall', results.get('test_recall', 0.0)) 
                recall_item = QTableWidgetItem(f"{recall_value:.4f}")
                self.result_table.setItem(row_position, 4, recall_item)
              
            self.result_table.resizeColumnsToContents()
              
            self.progress_dialog.update_progress(100, _("main_window.analysis_complete"))    
            self.progress_dialog.close()    
            QMessageBox.information(self, _("main_window.message_9"), msg)
        except Exception as e:
            if hasattr(self, 'progress_dialog') and self.progress_dialog:
                self.progress_dialog.close()
            QMessageBox.critical(self, _("main_window.message"), _("main_window.analysis_failed").format(error=str(e)))
    def generate_report(self):
        """Generate analysis report"""
        if self.current_spectra is None:
            QMessageBox.warning(self, _("main_window.message_2"), _("main_window.load_data_first"))
            return
        try:
            # Show progress dialog
            self.progress_dialog = ProgressDialog(_("main_window.generating_report_progress_title"), self)
            self.progress_dialog.show()
            # Prepare report data
            self.progress_dialog.update_progress(10, _("main_window.preparing_report_data"))
            spectra_data = {
                'shape': self.current_spectra.shape,
                'wavelength_range': f"{self.wavelengths[0]:.2f} - {self.wavelengths[-1]:.2f}",
                'n_samples': self.current_spectra.shape[0],
                'n_features': self.current_spectra.shape[1]
            }
            # Get actual preprocessing methods applied
            preprocessing_results = {}
            if hasattr(self, 'controller') and hasattr(self.controller, 'preprocessing_controller'):
                  
                if hasattr(self.controller.preprocessing_controller, 'preprocessing_model'):
                      
                    print(f"Looking for preprocessing methods: found preprocessing_model")
                    if hasattr(self.controller.preprocessing_controller.preprocessing_model, 'applied_methods'):
                          
                        print(f"Found applied_methods, containing {len(self.controller.preprocessing_controller.preprocessing_model.applied_methods)} methods")
                        for method, params in self.controller.preprocessing_controller.preprocessing_model.applied_methods.items():
                            preprocessing_results[method] = params
                    else:
                        print("preprocessing_model exists but has no applied_methods attribute")
                        preprocessing_results = {
                            'No preprocessing': _('main_window.no_preprocessing_methods_applied')
                        }
                else:
                    print("Cannot find preprocessing_model attribute")
                    preprocessing_results = {
                        'No preprocessing': _('main_window.no_preprocessing_methods_applied')
                    }
            else:
                print("Cannot find preprocessing_controller")
                preprocessing_results = {
                    'No preprocessing': _('main_window.no_preprocessing_methods_applied')
                }
            committed_params = self._collect_preprocessing_params()
            if committed_params:
                preprocessing_results = {name: str(params) for name, params in committed_params.items()}
            # Get actual feature selection methods applied
            feature_extraction_results = {}
            if hasattr(self, 'controller') and hasattr(self.controller, 'feature_selection_controller') and hasattr(self.controller.feature_selection_controller, 'feature_selection_model'):
                if hasattr(self.controller.feature_selection_controller.feature_selection_model, 'selected_method'):
                    method = self.controller.feature_selection_controller.feature_selection_model.selected_method
                    num_features = len(self.controller.feature_selection_controller.feature_selection_model.selected_features) if hasattr(self.controller.feature_selection_controller.feature_selection_model, 'selected_features') else 0
                    feature_extraction_results[method] = f"Selected {num_features} features"
                else:
                    feature_extraction_results = {
                        'No feature selection': _('main_window.no_feature_selection_methods_applied')
                    }
            else:
                feature_extraction_results = {
                    'No feature selection': _('main_window.no_feature_selection_methods_applied')
                }
            # Get actual analysis/modeling results
            analysis_results = {}
            if hasattr(self, 'controller') and hasattr(self.controller, 'modeling_controller') and hasattr(self.controller.modeling_controller, 'modeling_model'):
                if hasattr(self.controller.modeling_controller.modeling_model, 'evaluation_results'):
                    analysis_results = self.controller.modeling_controller.modeling_model.evaluation_results
                elif hasattr(self.controller.modeling_controller.modeling_model, 'trained_model'):
                    analysis_results = {
                        'Model': str(type(self.controller.modeling_controller.modeling_model.trained_model).__name__),
                        'Training status': _('main_window.training_status_trained')
                    }
                else:
                    analysis_results = {
                        'No analysis': _('main_window.no_modeling_or_analysis')
                    }
            else:
                analysis_results = {
                    'No analysis': _('main_window.no_modeling_or_analysis')
                }
            # Generate report in a worker thread (keeps the UI responsive)
            self.progress_dialog.update_progress(75, _("main_window.generating_pdf_report"))
            self._compute_model_diagnostics(progress_dialog=self.progress_dialog)
            if self.progress_dialog.was_cancelled:
                self.progress_dialog.update_progress(100);self.progress_dialog.close()
                return
            self._report_worker = _ReportWorker(
                spectra_data,
                preprocessing_results,
                feature_extraction_results,
                analysis_results,
                title=_("main_window.spectral_analysis_report_title"),
                parent=self,
                reproducibility_info=getattr(self.controller.modeling_controller.modeling_model, 'reproducibility_info', None),
                diagnostics=getattr(self.controller.modeling_controller.modeling_model, 'diagnostics', None),
            )
            self._report_worker.progress.connect(self.progress_dialog.update_progress)
            self.progress_dialog.cancelled.connect(self._report_worker.cancel)
            self._report_worker.result_ready.connect(self._on_report_generated)
            self._report_worker.error_occurred.connect(self._on_report_error)
            self._report_worker.finished.connect(self._on_report_worker_finished)
            self._report_worker.start()
        except Exception as e:
            if hasattr(self, 'progress_dialog') and self.progress_dialog:
                self.progress_dialog.close()
            QMessageBox.critical(self, _("main_window.message"), _("main_window.report_failed").format(error=str(e)))

    def _on_report_generated(self, report_path):
        """Report worker finished: close the progress dialog and report the result."""
        if hasattr(self, 'progress_dialog') and self.progress_dialog:
            self.progress_dialog.update_progress(100, _("main_window.report_generation_complete"))
            self.progress_dialog.close()
        if not report_path:
            return  # Cancelled before completion
        self.statusBar().showMessage(f"Report generated: {report_path}")
        QMessageBox.information(self, _("main_window.message_7"), _("main_window.report_success"))

    def _on_report_error(self, error):
        """Report worker failed: close the progress dialog and show the error."""
        if hasattr(self, 'progress_dialog') and self.progress_dialog:
            self.progress_dialog.update_progress(100)
            self.progress_dialog.close()
        QMessageBox.critical(self, _("main_window.message"), _("main_window.report_failed").format(error=str(error)))

    def _on_report_worker_finished(self):
        """Worker thread finished: close the dialog if the user cancelled it."""
        if (hasattr(self, '_report_worker') and self._report_worker and
                self._report_worker.is_cancelled() and
                hasattr(self, 'progress_dialog') and self.progress_dialog and
                self.progress_dialog.isVisible()):
            self.progress_dialog.close()

    def preview_preprocessing(self):
        """Preview the preprocessing effects on the main visualization widget."""
        if not self.controller.check_data_ready():
            QMessageBox.warning(self, _("main_window.message_2"), _("main_window.load_data_first"))
            return

        try:
            preview_mode = self.preview_mode.currentData()
            
            methods_applied = []
            if hasattr(self.controller.preprocessing_controller, 'preprocessing_model') and \
               hasattr(self.controller.preprocessing_controller.preprocessing_model, 'applied_methods'):
                methods_applied = list(self.controller.preprocessing_controller.preprocessing_model.applied_methods.keys())

            # The visualization widget now handles all preview logic based on the mode.
            self.visualization_widget.update_preprocessing_preview(
                data_model=self.controller.data_controller.data_model,
                wavelengths=self.wavelengths,
                preview_mode=preview_mode,
                methods_applied=methods_applied
            )

        except Exception as e:
            QMessageBox.critical(self, _("main_window.message"), _("main_window.preview_failed").format(error=str(e)))
            import traceback
            traceback.print_exc()
    
    def reset_preprocessing_params(self):
        """Reset preprocessing parameters to default values"""
        
        # Reset despiking parameters
        self.despiking_check.setChecked(False)
        self.despiking_method.setCurrentIndex(0)  # MAD
        self.despiking_window.setValue(7)  # More conservative default
        self.despiking_threshold.setValue(3.0)  # More conservative threshold
          
        self.baseline_check.setChecked(False)
        self.baseline_method.setCurrentIndex(0)  # Polynomial
        self.scatter_check.setChecked(False)    
        self.smooth_check.setChecked(False)    
        self.derivative_check.setChecked(False)    
        self.standardize_check.setChecked(False)    
        self.norm_check.setChecked(False)    
        self.outlier_check.setChecked(False)    
        self.denoise_check.setChecked(False)    
        self.alignment_check.setChecked(False)
        
        # Reset Raman specific parameters
        self.wavelength_calib_check.setChecked(False)
        self.intensity_calib_check.setChecked(False)    
          
        self.poly_order.setValue(2)  # Better default for most spectra    
        self.scatter_method.setCurrentIndex(0)    
        self.smooth_method.setCurrentIndex(0)    
        self.window_size.setValue(11)  # Better odd number for smoothing    
        self.derivative_order.setValue(1)    
        self.standardize_method.setCurrentIndex(0)    
        self.norm_method.setCurrentIndex(0)    
        self.outlier_threshold.setValue(3.0)    
        self.denoise_strength.setValue(0.5)    
        self.alignment_method.setCurrentIndex(0)    
        self.reference_method.setCurrentIndex(0)    
          
        self.preview_mode.setCurrentIndex(0)    
          
        if hasattr(self, 'original_spectra') and self.original_spectra is not None:    
            self.current_spectra = self.original_spectra.copy()    
            self.visualization_widget.plot_spectra(self.wavelengths, self.original_spectra, labels=self.sample_labels)    
        elif self.spectra_data is not None:    
            self.visualization_widget.plot_spectra(self.wavelengths, self.spectra_data, labels=self.sample_labels)    

    def show_preprocessing_help(self):
        """Show comprehensive preprocessing algorithms help"""
        from PyQt5.QtWidgets import QDialog, QVBoxLayout, QTabWidget, QWidget, QTextEdit, QPushButton
        
        help_dialog = QDialog(self)
        help_dialog.setWindowTitle(_("main_window.help_title"))
        from app.utils.responsive import fit_window_to_screen
        fit_window_to_screen(help_dialog, 900, 700, min_width=520, min_height=420)
        
        layout = QVBoxLayout()
        
        # Create tab widget for different algorithm categories
        tabs = QTabWidget()
        
        # Spike Removal Tab
        spike_tab = QWidget()
        spike_layout = QVBoxLayout()
        spike_text = QTextEdit()
        spike_text.setReadOnly(True)
        spike_content = """
<h1><b>Spike Removal (Despiking)</b></h1>

<p>Spike removal is primarily used to eliminate cosmic ray spikes and instrumental artifacts from Raman spectra. These spikes typically appear as abnormally high intensity values at single or few data points, which can severely affect subsequent spectral analysis.</p>

<h2><b>MAD (Median Absolute Deviation)</b></h2>
<p>The MAD method identifies spikes by calculating the deviation of data points from the median within a local window. For each data point, the algorithm takes a window around it, calculates the median and median absolute deviation within that window, and if the current point's deviation exceeds the threshold, it is considered a spike and replaced with the median value. This method is particularly effective for detecting sharp cosmic ray spikes in Raman spectroscopy because it uses robust statistics that are less affected by the spikes themselves.</p>

<p>Window size is typically set between 7-15 points, with smaller windows (7-9 points) being suitable for detecting sharp cosmic ray spikes, while larger windows provide more stability for noisy spectra. The threshold parameter controls detection sensitivity, with values of 3-4 being conservative and suitable for most situations. Setting the threshold too low may remove normal data points, while too high may miss genuine spikes. After processing, check the spike statistics in reports to evaluate effectiveness.</p>

<h2><b>Local Z-score</b></h2>
<p>The Local Z-score method detects anomalous points using local mean and standard deviation. The algorithm calculates local statistics around each data point, normalizes the difference between the current point and local mean by the local standard deviation to obtain a standardized score, and points exceeding the threshold are considered spikes. This method is more sensitive to broader anomalous features and suitable for handling cases beyond simple single-point spikes, particularly when baseline fluctuations are significant.</p>

<p>Recommended window size is 9-11 points, with thresholds typically set at 4-5, which is higher than MAD due to different Z-score distribution characteristics. In practice, start with the MAD method using conservative parameters (window=7, threshold=3) for testing and observe results. Increase threshold if too many normal data points are removed, or increase window size if spectra are noisy.</p>
        """
        spike_text.setHtml(spike_content)
        spike_layout.addWidget(spike_text)
        spike_tab.setLayout(spike_layout)
        tabs.addTab(spike_tab, _("main_window.despiking_group"))
        
        # Baseline Correction Tab
        baseline_tab = QWidget()
        baseline_layout = QVBoxLayout()
        baseline_text = QTextEdit()
        baseline_text.setReadOnly(True)
        baseline_content = """
<h1><b>Baseline Correction</b></h1>

<p>Baseline correction removes baseline drift and background fluorescence interference from spectra. Baseline issues are common in various spectroscopic techniques, manifesting as slow changes in overall intensity or background signal overlay, affecting accurate peak intensity determination and quantitative spectral analysis.</p>

<h2><b>Polynomial</b></h2>
<p>Polynomial baseline correction estimates the baseline by fitting a polynomial function and then subtracts it from the original spectrum. This is the most straightforward method, suitable for smooth, gradually varying baselines. The polynomial order is the key parameter, with orders 1-5 being selectable.</p>

<p>Low-order polynomials (1-2) are suitable for simple linear or quadratic baseline drift, while high-order polynomials (3-5) can handle more complex baseline shapes but may overfit and affect genuine spectral features. Orders 2-3 are appropriate choices for most cases. Too low order may not completely remove baseline, while too high may weaken or distort genuine peak signals.</p>

<h2><b>ALS (Asymmetric Least Squares)</b></h2>
<p>The ALS method uses an iterative algorithm that assigns greater weight to points below the baseline and lower weight to peak regions, enabling better distinction between baseline and peak signals. This method is particularly suitable for spectra with obvious peak signals above the baseline, as it can automatically identify and protect peak regions from baseline fitting interference. Compared to polynomial methods, ALS better maintains peak shapes and intensities, especially for peak-dense spectra. The algorithm automatically adjusts weight distribution without requiring manual setting of complex parameters, but computation time is relatively longer.</p>

<h2><b>airPLS (Adaptive Iteratively Reweighted Penalized Least Squares)</b></h2>
<p>airPLS is an improved version of the ALS method that employs adaptive weight adjustment strategies. The algorithm can automatically identify baseline and peak regions, dynamically adjusting the weight of each data point, providing stronger adaptability to complex and variable baselines. This method performs excellently when processing multi-component baselines, irregular backgrounds, or spectra with significant baseline shape variations. The advantage of airPLS lies in its strong robustness, providing good results for different types of spectra, though with the highest computational complexity.</p>

<p>When selecting baseline correction methods, start with 2nd-order polynomial. If the baseline is complex or has obvious peak signals, use ALS. For particularly difficult baselines, try airPLS. After processing, always visually inspect results to ensure peak shapes are not destroyed and baselines are effectively removed.</p>
        """
        baseline_text.setHtml(baseline_content)
        baseline_layout.addWidget(baseline_text)
        baseline_tab.setLayout(baseline_layout)
        tabs.addTab(baseline_tab, _("main_window.baseline_group"))
        
        # Scatter Correction Tab
        scatter_tab = QWidget()
        scatter_layout = QVBoxLayout()
        scatter_text = QTextEdit()
        scatter_text.setReadOnly(True)
        scatter_content = """
<h1><b>Scatter Correction</b></h1>

<p>Scatter correction is primarily used in near-infrared and mid-infrared spectroscopy to eliminate multiplicative scattering effects caused by physical properties of samples such as particle size, density, and surface roughness. These effects cause samples with identical chemical composition to produce different spectral intensities, affecting quantitative analysis accuracy.</p>

<h2><b>SNV (Standard Normal Variate)</b></h2>
<p>SNV performs centering and standardization on each spectrum individually, using the formula (X-mean)/standard deviation. This method assumes that scattering effects have the same influence across the entire spectral range, correcting scattering by eliminating intensity differences between spectra. SNV processing is simple and fast, with good results for most near-infrared transmission spectra, particularly suitable when scattering differences between samples are small. However, this method may amplify noise and should be used cautiously for spectra with low signal-to-noise ratios.</p>

<h2><b>MSC (Multiplicative Scatter Correction)</b></h2>
<p>MSC uses the average spectrum of all samples as a reference, correcting scattering by aligning each spectrum with the reference spectrum through linear regression. This method maintains relative intensity relationships between spectra and is suitable for reflectance spectra processing. MSC assumes scattering is systematic and works well for sample sets with regular scattering variation patterns. Compared to SNV, MSC better preserves original spectral shape features, but requires representative reference spectra and is more sensitive to abnormal samples.</p>

<h2><b>EMSC (Extended Multiplicative Scatter Correction)</b></h2>
<p>EMSC adds polynomial baseline correction to MSC, enabling simultaneous handling of multiplicative scattering and additive baseline effects. This method is particularly suitable for complex spectra with both scattering problems and baseline drift. EMSC simultaneously estimates scattering coefficients and baseline polynomial coefficients through multivariate linear regression, providing more comprehensive spectral correction. Processing effects are usually superior to using MSC or baseline correction alone, but computational complexity is higher and parameter settings require more experience.</p>

<h2><b>RNV (Robust Normal Variate)</b></h2>
<p>RNV is an improved version of SNV that uses median and median absolute deviation instead of mean and standard deviation for standardization, providing stronger resistance to outliers and noise. When outliers or significant noise exist in the data, RNV is more stable and reliable than SNV. This method maintains the simplicity of SNV while improving robustness, making it suitable for processing spectral data of varying quality.</p>

<h2><b>OSC (Orthogonal Signal Correction)</b></h2>
<p>OSC is specifically designed for supervised learning scenarios, using principal component analysis to identify and remove variation components orthogonal (unrelated) to target variables. This method requires known target variable information and can selectively remove scattering and other interferences unrelated to analysis objectives. OSC is valuable in chemometric modeling but is only applicable when there are clear analysis targets and cannot be used for exploratory data analysis.</p>

<p>When selecting scatter correction methods, SNV is preferred for near-infrared transmission spectra, MSC is better for reflectance spectra, EMSC is used when both scattering and baseline issues exist, RNV is considered for poor data quality, and OSC is only used for supervised learning requirements.</p>
        """
        scatter_text.setHtml(scatter_content)
        scatter_layout.addWidget(scatter_text)
        scatter_tab.setLayout(scatter_layout)
        tabs.addTab(scatter_tab, _("main_window.scatter_group"))
        
        # Smoothing Tab
        smooth_tab = QWidget()
        smooth_layout = QVBoxLayout()
        smooth_text = QTextEdit()
        smooth_text.setReadOnly(True)
        smooth_content = """
<h1><b>Smoothing</b></h1>

<p>The purpose of smoothing is to reduce spectral noise while preserving genuine spectral features as much as possible. Noise typically manifests as high-frequency random fluctuations, while genuine spectral signals are relatively smooth. Appropriate smoothing can improve signal-to-noise ratio, but excessive smoothing leads to peak broadening, intensity reduction, or even feature loss.</p>

<h2><b>Savitzky-Golay Filter</b></h2>
<p>The Savitzky-Golay method fits polynomials within local windows and replaces the center point with the fitted value, enabling both noise smoothing and good preservation of peak shapes. Window size must be odd, typically ranging from 5-21 points. Smaller windows (9-11 points) preserve more details but have limited smoothing effects, while larger windows provide stronger smoothing but may be excessive. Polynomial order controls fitting complexity, with orders 2-3 suitable for most spectra. Too low order may result in insufficient fitting, while too high may introduce false peaks. This method's advantage is its ability to maintain peak positions and relative intensities well, making it the preferred method for spectral smoothing.</p>

<h2><b>Moving Average</b></h2>
<p>Moving average is the simplest smoothing method, directly averaging data points within a window. This method has strong suppression effects on high-frequency noise and fast computation speed, but significantly broadens peak shapes and reduces peak heights. Moving average is suitable for situations with very high noise and low requirements for peak shape. Larger windows provide stronger smoothing effects but more severe peak broadening. It is generally used only in special situations with extremely low signal-to-noise ratios or when strong smoothing is needed.</p>

<h2><b>Gaussian Smoothing</b></h2>
<p>Gaussian smoothing uses Gaussian functions as weights for weighted averaging of data, with maximum weight at the center point and decreasing weights with distance. This method produces natural smoothing effects and better peak shape preservation than moving average. The standard deviation parameter controls smoothing strength, with larger values providing stronger smoothing effects. Gaussian smoothing effectively reduces noise while maintaining overall spectral shape, suitable for applications with certain requirements for peak shape.</p>

<h2><b>Median Filter</b></h2>
<p>Median filtering replaces the center point with the median of data within the window. This method is particularly effective for impulse noise and spikes, capable of smoothing while maintaining edges and sharp features. Median filtering does not blur peak boundaries like other methods, making it useful for situations requiring both denoising and peak sharpness preservation. This method is often combined with other smoothing methods, first using median filtering to remove spikes, then using other methods for further smoothing.</p>

<p>In practical applications, Savitzky-Golay filtering is recommended as the first choice, starting with small windows (9-11 points) and low orders (2-3). For spectra with particularly high noise, try Gaussian smoothing. For situations requiring spike removal, consider median filtering. After smoothing, always check whether peaks are excessively broadened and whether signals are distorted.</p>
        """
        smooth_text.setHtml(smooth_content)
        smooth_layout.addWidget(smooth_text)
        smooth_tab.setLayout(smooth_layout)
        tabs.addTab(smooth_tab, _("main_window.smooth_group"))
        
        # Advanced Methods Tab
        advanced_tab = QWidget()
        advanced_layout = QVBoxLayout()
        advanced_text = QTextEdit()
        advanced_text.setReadOnly(True)
        advanced_content = """
<h1><b>Advanced Preprocessing Methods</b></h1>

<h2><b>Normalization</b></h2>
<p>Normalization scales spectral data to specific ranges, eliminating intensity differences between different samples. Min-Max normalization scales data to the [0,1] interval, suitable for maintaining relative data distribution. Unit vector normalization standardizes each spectrum's vector length to 1, emphasizing spectral shape rather than intensity. Peak normalization scales based on the highest peak intensity, suitable for emphasizing relative peak intensity relationships. Method selection depends on analysis objectives: use Min-Max for absolute intensity focus, unit vector for spectral shape focus, and peak normalization for relative peak intensity focus.</p>

<h2><b>Standardization</b></h2>
<p>Standardization converts data to a distribution with mean 0 and standard deviation 1. Z-Score standardization uses arithmetic mean and standard deviation, suitable for data distributions close to normal. Robust standardization uses median and median absolute deviation, providing stronger resistance to outliers. Standardization is mainly used for data preprocessing before multivariate analysis, ensuring different variables have similar scales and preventing certain variables from dominating analysis results due to large numerical ranges.</p>

<h2><b>Derivative</b></h2>
<p>Derivative transformation enhances peak resolution and eliminates baseline interference by calculating first or second derivatives of spectra. First derivative converts original peaks to positive-negative peak pairs, effectively eliminating constant baselines and linear drift while improving resolution of overlapping peaks. Second derivative further enhances resolution, converting original peaks to negative peaks, particularly effective for severely overlapping peaks. Derivative transformation amplifies noise, so smoothing processing is usually required first. This method is valuable in qualitative analysis but changes peak shapes and intensity relationships.</p>

<h2><b>Outlier Detection</b></h2>
<p>Outlier detection is used to identify and process abnormal spectra in datasets. Statistical methods judge outliers based on distance from mean, simple and intuitive but with requirements for data distribution. Isolation forest uses random forest concepts, identifying easily isolated abnormal points by constructing decision trees. Local outlier factor is based on local density concepts, comparing each point's density with its neighbors to identify outliers. Outliers may be measurement errors, sample contamination, or truly special samples, requiring manual judgment after detection on whether to remove them.</p>

<h2><b>Denoising</b></h2>
<p>Denoising methods are more complex than simple smoothing and can better distinguish between signals and noise. Wavelet denoising separates different frequency components through multi-resolution analysis, maintaining signal details while denoising. Total variation denoising is based on signal gradient characteristics, maintaining edges while smoothing regions. Non-local means utilizes repetitive patterns in images for denoising, effective for structured noise. These methods are computationally complex but superior to traditional smoothing, suitable for applications with high signal quality requirements.</p>

<h2><b>Peak Alignment</b></h2>
<p>Peak alignment corrects peak shifts between different spectra, which may be caused by temperature changes, instrument drift, and other factors. Cross-correlation alignment finds optimal alignment positions by maximizing correlations between spectra, suitable for overall shifts. Dynamic time warping allows non-linear alignment, handling situations with different degrees of shift in different regions. The Icoshift method divides spectra into multiple intervals for separate alignment, balancing efficiency and flexibility. Peak alignment is important for multivariate analysis but may change relative position relationships of peaks.</p>
        """
        advanced_text.setHtml(advanced_content)
        advanced_layout.addWidget(advanced_text)
        advanced_tab.setLayout(advanced_layout)
        tabs.addTab(advanced_tab, _("main_window.advanced_tab_tab"))
        
        # Best Practices Tab (shortened for space)
        practices_tab = QWidget()
        practices_layout = QVBoxLayout()
        practices_text = QTextEdit()
        practices_text.setReadOnly(True)
        practices_content = """
<h1><b>Best Practices & Workflow</b></h1>

<h2><b>Preprocessing Order Recommendations</b></h2>
<p>The order of spectral preprocessing is important, as incorrect order may lead to poor processing effects or even introduce new problems. The recommended processing order is: first perform despiking (Raman spectra only), as spikes affect all subsequent processing steps; then perform baseline correction to remove baseline drift and background interference; next perform scatter correction (mainly for near-infrared and mid-infrared) to eliminate physical scattering effects; finally perform smoothing, as smoothing affects other correction methods and should be placed last.</p>

<h2><b>Processing Strategies for Different Spectral Techniques</b></h2>
<p><b>Raman Spectra</b> typically require despiking, recommended using MAD method to remove cosmic ray spikes, then 2-3 order polynomial for baseline correction. Raman spectra generally do not require scatter correction. Smoothing should be cautious, recommended using small window (7-9 points) Savitzky-Golay filtering to avoid excessive smoothing causing peak broadening.</p>

<p><b>Near-Infrared Spectra</b> do not require despiking. Scatter correction is a key step, with SNV preferred for transmission spectra and MSC for reflectance spectra. Baseline correction is selected as needed, typically 1-2 order polynomials suffice. Smoothing can be moderate, with 9-15 point window Savitzky-Golay filtering being suitable.</p>

<p><b>Mid-Infrared/FTIR Spectra</b> also do not require despiking. Baseline correction is important, with polynomial or ALS methods available. For complex samples, consider EMSC method to simultaneously handle scattering and baseline issues. Smoothing should be moderate, recommended 9-11 point window Savitzky-Golay filtering.</p>

<h2><b>Common Errors and Considerations</b></h2>
<p>Over-processing is the most common problem, with many users tending to use all available preprocessing methods, but appropriate processing is often minimal processing. Incorrect processing order is also common, such as smoothing before baseline correction, which affects baseline detection accuracy. Excessive smoothing leading to spectral resolution loss is another common issue, especially when using overly large smoothing windows. Ignoring visual inspection is dangerous; automated processing results must be checked for reasonableness. Finally, different samples may require different processing parameters and cannot be generalized.</p>

<h2><b>Quality Control Recommendations</b></h2>
<p>After each processing step, use preview functions to check effects and compare spectral changes before and after processing. Pay special attention to whether peak shapes, positions, and intensities undergo unreasonable changes. Processing parameters should be recorded in reports to ensure reproducibility. For important analysis projects, validate processing effects using known standard samples. Establish standard operating procedures, use consistent processing parameters for similar samples, but maintain flexibility to adjust according to specific situations.</p>
        """
        practices_text.setHtml(practices_content)
        practices_layout.addWidget(practices_text)
        practices_tab.setLayout(practices_layout)
        tabs.addTab(practices_tab, _("main_window.practices_tab_tab"))
        
        layout.addWidget(tabs)
        
        # Close button
        close_btn = QPushButton(_("main_window.close_btn"))
        close_btn.clicked.connect(help_dialog.close)
        layout.addWidget(close_btn)
        
        help_dialog.setLayout(layout)
        help_dialog.exec_()

    def display_error(self, message, title="Error"):
        """Display an error message to the user"""
        QMessageBox.critical(self, _("main_window.error_title"), message)

    def _on_feature_btn_clicked(self):
        """
        Handles the 'Apply' button click in the 'Feature' group.
        It intelligently delegates to the correct workflow (exploratory PCA, modeling PCA, or other feature selection).
        """
        method = self.feature_method.currentData()
        params = {'n_components': self.feature_param_spin.value()}
        
        print(f"Feature engineering requested for method: {method} with params: {params}")

        if "PCA" in method:
            # Use the main-window handler which correctly chooses exploratory vs modeling PCA.
            self.apply_feature_engineering()
        else:
            # For other methods, use the existing supervised feature selection logic.
            print(f"Redirecting to supervised feature selection for method: {method}")
            self.apply_feature_selection()

    def apply_feature_engineering(self):
        """Unified feature engineering handler - selects the processing path by algorithm type."""
        try:
            method = self.feature_method.currentData()
            param = self.feature_param_spin.value()
            data_model = self.controller.data_controller.data_model

            if not self._require_verified_model_split(
                    data_model, "feature engineering", report_error=True):
                return

            print(f"Applying feature engineering: {method} with parameter: {param}")

            # Smart pipeline: choose different processing paths based on algorithm type
            if "PCA" in method:
                # Check whether data has been partitioned
                data_model = self.controller.data_controller.data_model
                is_partitioned = (
                    data_model.has_partitioned_data()
                    and getattr(data_model, 'row_alignment_verified', False)
                )

                if not is_partitioned:
                    # Exploratory analysis path
                    print("Data is not partitioned. Running PCA in exploratory mode.")
                    self._run_exploratory_pca(param)
                else:
                    # Modeling workflow path
                    print("Data is partitioned. Running PCA in modeling mode (fit on train, transform all).")
                    self._run_modeling_pca(param)

            elif method in ["SelectKBest", "Recursive Feature Elimination (RFE)", "LASSO", "Feature Importance", "Mutual Information"]:
                # Supervised feature selection path - requires partitioned data
                self._apply_supervised_feature_selection(method, param)
            elif method in ["PLSR", "Wavelet", "Peak Detection"]:
                # Specialized algorithm path - handled per algorithm
                self._apply_specialized_feature_method(method, param)
            else:
                QMessageBox.warning(self, _("main_window.message_2"), _("main_window.unknown_method").format(method=method))

        except Exception as e:
            error_msg = _("main_window.feature_engineering_failed").format(error=str(e))
            print(f"ERROR: {error_msg}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, _("main_window.message_11"), error_msg)

    def _run_exploratory_pca(self, n_components):
        """Run exploratory PCA on unsplit data and show a dedicated dialog."""
        data_controller = getattr(getattr(self, 'controller', None), 'data_controller', None)
        data_model = getattr(data_controller, 'data_model', None)
        if data_model is not None and not self._require_verified_model_split(
                data_model, "exploratory PCA", report_error=True):
            return

        try:
            print(f"Calling PCA service in exploratory mode with n_components={n_components}")
            self.feature_extraction_service.run_feature_extraction(
                "PCA", {'n_components': n_components}
            )
        except Exception as e:
            error_msg = _("main_window.exploratory_pca_failed").format(error=str(e))
            print(f"ERROR: {error_msg}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, _("main_window.message_12"), error_msg)

    def _run_modeling_pca(self, n_components):
        """Run PCA on partitioned data to prevent data leakage and provide visualization."""
        data_model = self.controller.data_controller.data_model
        if not self._require_verified_model_split(
                data_model, "modeling PCA", report_error=True, require_split=True):
            return
        if not (hasattr(data_model, 'X_train') and data_model.X_train is not None):
            QMessageBox.critical(self, _("main_window.message"), _("main_window.pca_not_partitioned"))
            return

        try:
            from sklearn.decomposition import PCA
            import pandas as pd

            X_train = data_model.X_train
            X_test = data_model.X_test

            print(f"Fitting PCA on training data (shape: {X_train.shape}) with n_components={n_components}")

            # Check whether requested components exceed the maximum possible
            max_components = min(X_train.shape)
            if n_components > max_components:
                print(f"WARNING: Requested components ({n_components}) is greater than max possible ({max_components}). Adjusting to {max_components}.")
                n_components = max_components
                self.feature_param_spin.setValue(n_components)


            pca = PCA(n_components=n_components)

            # Fit on training data ONLY
            pca.fit(X_train)

            # Transform both train and test data
            X_train_pca = pca.transform(X_train)
            X_test_pca = pca.transform(X_test) if X_test is not None else None

            print(f"   Transformed X_train shape: {X_train_pca.shape}")
            if X_test_pca is not None:
                print(f"   Transformed X_test shape: {X_test_pca.shape}")

            # Update data model for subsequent steps
            data_model.X_train_selected = X_train_pca
            data_model.X_test_selected = X_test_pca

            # Update feature management system
            self.feature_data_options['selected_features'] = {
                'X_train': X_train_pca,
                'X_test': X_test_pca,
                'selected_features': [f'PC_{i+1}' for i in range(X_train_pca.shape[1])]
            }
            self.current_feature_source = 'selected_features'

            # Notify user
            explained_variance = sum(pca.explained_variance_ratio_)
            self.statusBar().showMessage(f"PCA for modeling complete. Now using {pca.n_components_} PCA features.", 5000)

            # Show results with PCAExplorerDialog
            dialog = PCAExplorerDialog(parent=self)
            dialog.set_data(
                pca_instance=pca,
                loadings=pca.components_,
                explained_variance_ratio=pca.explained_variance_ratio_,
                cumulative_variance=np.cumsum(pca.explained_variance_ratio_),
                X_scores=X_train_pca,
                wavelengths=self.wavelengths,
                y=data_model.y_train, # Pass labels for coloring score plot
                is_modeling_mode=True
            )
            dialog.show()
            self._track_toplevel_widget(self.pca_dialogs, dialog, max_count=5)

        except Exception as e:
            error_msg = _("main_window.modeling_pca_failed").format(error=str(e))
            print(f"ERROR: {error_msg}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, _("main_window.message_13"), error_msg)
    
    def _apply_unsupervised_feature_extraction(self, method, param):
        """Unsupervised feature extraction (e.g. PCA) - no labels or split required."""
        print(f"Applying unsupervised feature extraction: {method}")

        data_controller = getattr(getattr(self, 'controller', None), 'data_controller', None)
        data_model = getattr(data_controller, 'data_model', None)
        if data_model is not None and not self._require_verified_model_split(
                data_model, "feature extraction", report_error=True):
            return

        if self.current_spectra is None:
            QMessageBox.warning(self, _("main_window.message_2"), _("main_window.load_spectral_data_first"))
            return

        # Use current spectral data for unsupervised feature extraction
        from app.services.feature_extraction_service import feature_extraction_service

        # Convert numpy array to DataFrame for processing
        import pandas as pd
        if isinstance(self.current_spectra, np.ndarray):
            X = pd.DataFrame(self.current_spectra)
        else:
            X = self.current_spectra

        if "PCA" in method:  # "Principal Component Analysis (PCA)"
            results = feature_extraction_service.extract_pca_features(
                X, n_components=param, cev_threshold=0.95
            )

            # Store PCA results
            self.feature_data_options['pca_features'] = results['transformed_data'].values

            # Ask whether to use PCA features
            reply = QMessageBox.question(
                self, _("main_window.message_14"),
                f"PCA completed! Extracted {results['n_components']} components.\n"
                f"Explained variance: {results['cumulative_explained_variance'][-1]:.1%}\n\n"
                f"Would you like to use these PCA features for subsequent modeling?\n\n"
                f"- Yes: Use {results['n_components']} PCA components for modeling\n"
                f"- No: Keep original data for modeling",
                QMessageBox.Yes | QMessageBox.No
            )

            if reply == QMessageBox.Yes:
                self.current_feature_source = 'pca_features'
                QMessageBox.information(
                    self, _("main_window.message_15"),
                    f"Now using {results['n_components']} PCA components for modeling.\n"
                    f"You can proceed with data partitioning and modeling."
                )
            else:
                QMessageBox.information(
                    self, _("main_window.message_16"),
                    f"PCA features are available but original data will be used for modeling.\n"
                    f"You can switch to PCA features later if needed."
                )
    
    def _apply_supervised_feature_selection(self, method, param):
        """Supervised feature selection - requires labels and a train/test split."""
        print(f"Applying supervised feature selection: {method}")

        # Special handling: if PCA is chosen, use the correct modeling PCA path
        if "PCA" in method:
            print("PCA detected in supervised path, redirecting to correct modeling PCA path...")
            self._run_modeling_pca(param)
            return

        # Check whether data has been partitioned
        if not hasattr(self.controller, 'data_controller') or not hasattr(self.controller.data_controller, 'data_model'):
            QMessageBox.warning(self, _("main_window.message_2"), _("main_window.partition_first"))
            return

        data_model = self.controller.data_controller.data_model
        if not self._require_verified_model_split(
                data_model, "feature selection", report_error=True, require_split=True):
            return
        if not hasattr(data_model, 'X_train') or data_model.X_train is None:
            QMessageBox.warning(self, _("main_window.message_2"), _("main_window.partition_first"))
            return

        # Fall back to the existing feature selection logic
        self.apply_feature_selection()

    def _apply_specialized_feature_method(self, method, param):
        """Specialized feature engineering methods now delegate to the unified handler."""
        print(f"Applying specialized feature method: {method}")
        self.apply_feature_selection()
    
    def apply_feature_selection(self):
        """Apply feature selection with intelligent recommendations"""
        try:
            # Get current parameters
            method = self.feature_method.currentData()
            param = self.feature_param_spin.value()

            data_controller = getattr(getattr(self, 'controller', None), 'data_controller', None)
            data_model = getattr(data_controller, 'data_model', None)
            if data_model is not None:
                is_exploratory_pca = "PCA" in method
                if not self._require_verified_model_split(
                        data_model, "feature selection", report_error=True,
                        require_split=not is_exploratory_pca):
                    return
            elif "PCA" not in method:
                self.display_error("A train/test split is required before feature selection.")
                return

            # Special handling: if the user calls this method with PCA, redirect to unsupervised path
            if "PCA" in method:  # "Principal Component Analysis (PCA)"
                print("PCA detected, redirecting to unsupervised extraction...")
                self._apply_unsupervised_feature_extraction(method, param)
                return

            recommendation_msg = "" # Initialize empty message
            # Intelligent feature count recommendation
            if hasattr(self.controller, 'data_controller') and hasattr(self.controller.data_controller, 'data_model'):
                data_model = self.controller.data_controller.data_model
                if hasattr(data_model, 'y_train') and data_model.y_train is not None:
                    y_train = data_model.y_train
                    from app.utils.label_processor import EnhancedLabelProcessor
                    lp = EnhancedLabelProcessor()
                    task_type = lp.detect_task_type(y_train)
                    n_samples = len(y_train)
                    if task_type == 'classification':
                        n_classes = len(np.unique(y_train))
                        min_features_needed = max(n_classes * 3, 30)
                        if param < min_features_needed:
                            recommendation_msg = (f"<b>Warning:</b> The current setting is <b>{param}</b> features, "
                                                  f"but for <b>{n_classes}</b> classes, at least <b>{min_features_needed}</b> are recommended for better accuracy. "
                                                  f"The analysis was run with {param} features.")
                    else:
                        # Regression: avoid using unique y values; use sample-size heuristic.
                        min_features_needed = max(n_samples // 10, 5)
                        if param < min_features_needed:
                            recommendation_msg = (f"<b>Warning:</b> The current setting is <b>{param}</b> features, "
                                                  f"but for regression with <b>{n_samples}</b> samples, at least <b>{min_features_needed}</b> are recommended for better accuracy. "
                                                  f"The analysis was run with {param} features.")
                    if recommendation_msg:
                        print(f"Feature selection recommendation: {recommendation_msg}")
            # Continue with existing feature selection logic
            # Get method mapping and parameters
            method_mapping = {
                "PCA": "Principal Component Analysis (PCA)",
                "PLSR": "PLSR",
                "Peak Detection": "Peak Detection",
                "Wavelet": "Wavelet"
            }
            service_method = method_mapping.get(method, method)
            params = {'k': param}
            # Get training data
            data_model = self.controller.data_controller.data_model
            # Partitioned preprocessing is stored as keyed train/test frames.
            # Never reconstruct the split by slicing a full-data preview.
            X_train = data_model.X_train
            X_test = data_model.X_test

            y_train = data_model.y_train
            # Apply feature selection using the controller's apply_method
            result = self.controller.feature_selection_controller.apply_method(
                X_train, y_train, X_test, service_method, params
            )
            # Update data model with results
            data_model.X_train_selected = result['X_train_selected']
            if X_test is not None:
                data_model.X_test_selected = result['X_test_selected']

            # After feature selection, automatically switch to selected features
            self.feature_data_options['selected_features'] = {
                'X_train': result['X_train_selected'],
                'X_test': result['X_test_selected'] if X_test is not None else None,
                'selected_features': result['selected_features']
            }
            self.current_feature_source = 'selected_features'

            self.statusBar().showMessage(f"Feature selection complete: {len(result['selected_features'])} features selected. System will now use these for modeling.")

            print(f"Feature selection completed and activated:")
            print(f"   Selected {len(result['selected_features'])} features from {X_train.shape[1]} original features")
            print(f"   System switched to using selected features for modeling")
            # Auto-popup feature importance visualization window
            if 'feature_importance' in result and result['feature_importance'] is not None:
                from app.utils.visualization_window import VisualizationWindow
                vis_window = VisualizationWindow(title=_("main_window.feature_selection_result_title"))
                vis_window.set_message(recommendation_msg)
                vis_window.plot_feature_importance(
                    result['feature_importance'],
                    result['selected_features']
                )
                vis_window.show()
                self._track_toplevel_widget(self.feature_vis_windows, vis_window, max_count=5)
        except Exception as e:
            self.display_error(_("main_window.feature_selection_failed").format(error=str(e)))

    def invalidate_dataset_feature_state(self, clear_history=True):
        """Clear UI-side matrices/windows after a dataset or split change."""
        if clear_history and hasattr(self, 'operation_history'):
            self.operation_history.clear()
            self._pending_preprocessing_snapshot = None
        if hasattr(self, 'optimize_btn'):
            self.optimize_btn.setEnabled(False)
        if hasattr(self, 'feature_data_options'):
            for key in ('original', 'preprocessed', 'pca_features', 'selected_features'):
                self.feature_data_options[key] = None
        self.current_feature_source = 'original'
        if hasattr(self, 'result_table'):
            self.result_table.setRowCount(0)
        self.processed_spectra = None
        self.current_spectra = None
        main_controller = getattr(self, 'controller', None)
        modeling_controller = getattr(main_controller, 'modeling_controller', None)
        modeling_model = getattr(modeling_controller, 'modeling_model', None)
        if modeling_model is not None:
            if hasattr(modeling_model, 'clear_prediction_state'):
                modeling_model.clear_prediction_state()
            modeling_model.evaluation_results = {}
            modeling_model.reproducibility_info = None
            modeling_model.diagnostics = None
            modeling_model.diagnostic_inputs = None
            modeling_model.cv_scope_safe = False
            modeling_model.cv_scope_reason = (
                "The dataset, target, or split changed after this model was trained. "
                "Run analysis again to create a fold-scope contract for the current rows."
            )
            modeling_model.cv_train_sample_ids = None
            modeling_model.cv_test_sample_ids = None
            modeling_model.cv_train_physical_sample_ids = None
            modeling_model.cv_test_physical_sample_ids = None
            modeling_model.cv_train_group_ids = None
            modeling_model.cv_test_group_ids = None
            modeling_model.cv_group_validation = False
            modeling_model.cv_feature_names = None
            modeling_model.cv_input_representation = 'fitted_feature_matrix'
        preprocessing_controller = getattr(main_controller, 'preprocessing_controller', None)
        preprocessing_model = getattr(preprocessing_controller, 'preprocessing_model', None)
        if preprocessing_model is not None:
            preprocessing_model.applied_methods = {}
            preprocessing_model.applied_steps = []
        selection_controller = getattr(main_controller, 'feature_selection_controller', None)
        selection_model = getattr(selection_controller, 'feature_selection_model', None)
        if selection_model is not None:
            selection_model.set_selected_method(None)
            selection_model.set_selected_features([])
            selection_model.set_feature_importance(None)
        for collection_name in ('pca_dialogs', 'feature_vis_windows'):
            collection = getattr(self, collection_name, None)
            if collection is None:
                continue
            for window in list(collection.values()):
                try:
                    window.close()
                except Exception:
                    pass
            collection.clear()

    def _update_optimizer_button(self):
        """Enable the mounted search action only for a trained, fold-safe model."""
        button = getattr(self, 'optimize_btn', None)
        if button is None:
            return
        controller = getattr(self, 'controller', None)
        modeling_controller = getattr(controller, 'modeling_controller', None)
        model = getattr(modeling_controller, 'modeling_model', None)
        eligible = bool(
            model is not None
            and getattr(model, 'trained_model', None) is not None
            and getattr(model, 'X_train', None) is not None
            and getattr(model, 'y_train', None) is not None
            and getattr(model, 'cv_scope_safe', False)
        )
        button.setEnabled(eligible)

    def optimize_current_model(self):
        """Dispatch the visible optimizer controls through the grouped search controller."""
        if not self.controller.check_model_trained():
            return None
        self.optimize_btn.setEnabled(False)
        try:
            result = self.controller.hyperopt_controller.apply_main_window_selection(
                self.optimization_method.currentData(),
                self.cv_folds.value(),
                self.evaluation_metric.currentData(),
                self.max_iterations.value(),
            )
            if result is not None:
                best_params, _best_model, _cv_results = result
                modeling_model = self.controller.modeling_controller.modeling_model
                from app.services.prediction_contract import FittedSpectrumPredictor
                modeling_model.diagnostics = None
                task_type = (
                    'classification' if modeling_model.analysis_type == 'qualitative'
                    else 'regression'
                )
                model_matrix = np.asarray(modeling_model.X_train)
                modeling_model.fitted_predictor = FittedSpectrumPredictor(
                    estimator=_best_model,
                    task_type=task_type,
                    feature_names=getattr(modeling_model, 'cv_feature_names', None),
                    n_features=model_matrix.shape[1],
                    fit_row_ids=getattr(modeling_model, 'cv_train_sample_ids', None),
                    fit_physical_sample_ids=getattr(
                        modeling_model, 'cv_train_physical_sample_ids', None
                    ),
                    fit_group_ids=getattr(modeling_model, 'cv_train_group_ids', None),
                    group_validation=bool(getattr(modeling_model, 'cv_group_validation', False)),
                    input_representation=getattr(
                        modeling_model, 'cv_input_representation', 'fitted_feature_matrix'
                    ),
                )
                modeling_model.prediction_result = None
                modeling_model.set_model_data(None)
                self.display_message(
                    f"Hyperparameter search completed. Best parameters: {best_params}",
                    "Hyperparameter Search",
                )
            return result
        except Exception as exc:
            self.display_error(f"Hyperparameter search failed: {exc}")
            return None
        finally:
            self._update_optimizer_button()

    def on_column_mapping_changed(self, mapping):
        if self.controller.data_controller.apply_column_mapping(mapping):
            self.data_partitioning_view.set_column_mapping(mapping)
            self.update_data_view(self.controller.data_controller.data_model.data)

    def on_label_column_changed(self, index):
        """Atomically update response, wavelength, and identity roles."""
        if not hasattr(self, 'controller') or not hasattr(self.controller, 'data_controller'):
            return
        data_controller = self.controller.data_controller
        data_model = data_controller.data_model
        mapping_view = getattr(self, 'data_partitioning_view', None)
        if mapping_view is None or data_model.data is None:
            data_model.set_label_column_index(index)
            self.invalidate_dataset_feature_state()
            return

        previous_label = data_model.label_column_index
        previous_wavelengths = data_model.wavelength_column_positions
        mapping = mapping_view.get_column_mapping()
        mapping['label_column'] = int(index)
        if data_controller.apply_column_mapping(mapping):
            self.update_data_view(data_model.data)
            return

        # Reject impossible role combinations without leaving the UI selector
        # out of sync with the still-committed DataModel mapping.
        mapping_view.label_column_combo.blockSignals(True)
        mapping_view.label_column_combo.setCurrentIndex(previous_label)
        mapping_view.label_column_combo.blockSignals(False)
        if previous_wavelengths is None:
            mapping_view.clear_column_mapping()
        else:
            mapping_view.set_column_mapping({
                'label_column': previous_label,
                'wavelength_columns': previous_wavelengths,
            })

    def partition_data_with_params(self):
        """Apply data partitioning with parameters from the data partitioning view"""
          
        if not self.controller.check_data_ready():
            self.display_message(_("main_window.load_data_first"), _("main_window.message_2"))
            return
        try:
              
            method = self.data_partitioning_view.get_selected_method()
            params = self.data_partitioning_view.get_parameters()
            # **CRITICAL FIX: Force classification mode for qualitative analysis**
            current_analysis_type = self.analysis_type.currentData() if hasattr(self, 'analysis_type') else "Qualitative"
            if current_analysis_type == "Qualitative":
                params['force_classification'] = True
                print(f"Forcing classification mode for qualitative analysis")
            print(f"Data partitioning - method: {method}")
            print(f"Data partitioning - parameters: {params}")
              
            self.controller.data_controller.apply_data_partitioning(method, params)
        except Exception as e:
            self.display_error(_("main_window.partition_failed").format(error=str(e)))
            import traceback
            traceback.print_exc()

    def apply_data_partitioning(self):
        """Apply data partitioning - keep backward compatibility"""
          
        self.partition_data_with_params()

    def feature_selection(self):
        # This method is now empty as the feature selection logic has been moved to the controller
        pass

    def on_analysis_type_change(self, analysis_type):
        """Handle analysis type change event"""
        print(f"Analysis type changed to: {analysis_type}")
        # Update interface prompts
        if analysis_type.startswith("Quantitative"):
            self.analysis_desc.setText(_("main_window.analysis_desc_analysis_desc_text"))
            # Check if the data is suitable for quantitative analysis
            if hasattr(self, 'controller') and hasattr(self.controller, 'data_controller'):
                data_model = self.controller.data_controller.data_model
                if hasattr(data_model, 'y_train') and data_model.y_train is not None:
                    y_train = data_model.y_train
                    # Check if it's a classification label (classification features usually have fewer unique values)
                    if hasattr(y_train, 'nunique'):
                        unique_count = y_train.nunique()
                        if unique_count <= 10:  # If unique values are less than 10
                            self.display_message(_("main_window.suggest_qualitative").format(unique_count), _("main_window.analysis_type_suggestion_title"))
                    elif hasattr(y_train, 'shape'):
                        unique_count = len(np.unique(y_train))
                        if unique_count <= 10:
                            self.display_message("Warning: The current target variable has few unique values ({}), which may be more suitable for qualitative analysis.".format(unique_count),
                                              "Analysis Type Suggestion")
        else:
            self.analysis_desc.setText(_("main_window.analysis_desc_analysis_desc_text_2"))
            # Check if the data is suitable for qualitative analysis
            if hasattr(self, 'controller') and hasattr(self.controller, 'data_controller'):
                data_model = self.controller.data_controller.data_model
                if hasattr(data_model, 'y_train') and data_model.y_train is not None:
                    y_train = data_model.y_train
                    # Check if it's continuous value (continuous values usually have more unique values)
                    if hasattr(y_train, 'nunique'):
                        unique_count = y_train.nunique()
                        if unique_count > 10 and unique_count / len(y_train) > 0.1:  # Many unique values with high ratio
                            self.display_message(_("main_window.suggest_quantitative").format(unique_count), _("main_window.analysis_type_suggestion_title"))
                    elif hasattr(y_train, 'shape'):
                        unique_count = len(np.unique(y_train))
                        if unique_count > 10 and unique_count / len(y_train) > 0.1:
                            self.display_message("Warning: The current target variable has many unique values ({}), which may be more suitable for quantitative analysis.".format(unique_count),
                                              "Analysis Type Suggestion")

    def create_analysis_controls(self):
        """Create analysis control area"""
        analysis_group = QGroupBox(_("main_window.analysis_group"))
        layout = QVBoxLayout()
        # Add task type selector
        task_type_layout = QHBoxLayout()
        self.task_type_label = QLabel(_("main_window.task_type_label"))
        self.task_type_combo = QComboBox()
        for _text, _key in [(_("main_window.classification_task_item"), "Classification Task"),
            (_("main_window.regression_task_item"), "Regression Task")]:
            self.task_type_combo.addItem(_text, _key)
        self.task_type_combo.currentIndexChanged.connect(self.on_task_type_changed)
        task_type_layout.addWidget(self.task_type_label)
        task_type_layout.addWidget(self.task_type_combo)
        layout.addLayout(task_type_layout)
        # Analysis type selection
        analysis_layout = QHBoxLayout()
        self.analysis_type_label = QLabel(_("main_window.analysis_type_label"))
        self.analysis_type = QComboBox()
        for _text, _key in [(_("main_window.qualitative_item"), "Qualitative"),
            (_("main_window.quantitative_item"), "Quantitative")]:
            self.analysis_type.addItem(_text, _key)
        self.analysis_type.currentTextChanged.connect(lambda _text: self.on_analysis_type_changed(self.analysis_type.currentData()))
        analysis_layout.addWidget(self.analysis_type_label)
        analysis_layout.addWidget(self.analysis_type)
        layout.addLayout(analysis_layout)
        # Analysis method selection
        method_layout = QHBoxLayout()
        self.analysis_method_label = QLabel(_("main_window.analysis_method_label"))
        self.analysis_method = QComboBox()
        method_layout.addWidget(self.analysis_method_label)
        method_layout.addWidget(self.analysis_method)
        layout.addLayout(method_layout)

        # Evaluation metric selection
        eval_layout = QHBoxLayout()
        self.evaluation_metric_label = QLabel(_("main_window.evaluation_metric_label"))
        self.evaluation_metric = QComboBox()
        eval_layout.addWidget(self.evaluation_metric_label)
        eval_layout.addWidget(self.evaluation_metric)
        layout.addLayout(eval_layout)
        # Auto update analysis methods and evaluation metrics
        self.update_analysis_methods(self.analysis_type.currentData())
        # Analysis button
        analysis_button_layout = QHBoxLayout()
        self.analyze_button = QPushButton(_("main_window.analyze_btn"))
        self.analyze_button.clicked.connect(self.start_analysis)
        analysis_button_layout.addWidget(self.analyze_button)
        layout.addLayout(analysis_button_layout)
        # Analysis description
        self.analysis_desc = QLabel(_("main_window.analysis_desc"))
        self.analysis_desc.setStyleSheet(f"font-style: italic; color: {tok.COLOR_TEXT_SECONDARY};")
        layout.addWidget(self.analysis_desc)
        # Results table
        self.result_table = QTableWidget(0, 5)
        self.result_table.setHorizontalHeaderLabels([_("main_window.method_header"), _("main_window.r2_item"), _("main_window.rmse_item"), _("main_window.mae_item"), _("main_window.f1auc_header")])
        self.result_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.result_table)
        analysis_group.setLayout(layout)
        return analysis_group
    def on_task_type_changed(self, index):
        """Handle task type change"""
        task_type = "classification" if index == 0 else "regression"
        # Synchronize task type and analysis type
        if task_type == "classification" and self.analysis_type.currentData() != "Qualitative":
            self.analysis_type.setCurrentIndex(self.analysis_type.findData("Qualitative"))
        elif task_type == "regression" and self.analysis_type.currentData() != "Quantitative":
            self.analysis_type.setCurrentIndex(self.analysis_type.findData("Quantitative"))
        # Set task_type in controller
        if hasattr(self, 'controller'):
            self.controller.task_type = task_type
            print(f"Task type updated to: {task_type}")
            # If data model exists, update its task_type
            if hasattr(self.controller, 'data_controller') and hasattr(self.controller.data_controller, 'data_model'):
                self.controller.data_controller.data_model.task_type = task_type
                print(f"Data model task type set to: {task_type}")
    def on_analysis_type_changed(self, analysis_type):
        """Handle analysis type change"""
        # Update analysis methods and evaluation metrics options
        self.update_analysis_methods(analysis_type)
        # Synchronize task type selector
        if analysis_type == "Qualitative" and self.task_type_combo.currentData() != "Classification Task":
            self.task_type_combo.setCurrentIndex(self.task_type_combo.findData("Classification Task"))
        elif analysis_type == "Quantitative" and self.task_type_combo.currentData() != "Regression Task":
            self.task_type_combo.setCurrentIndex(self.task_type_combo.findData("Regression Task"))
        # Update analysis description
        if analysis_type == "Qualitative":
            self.analysis_desc.setText(_("main_window.analysis_desc_analysis_desc_text_3"))
            self.controller.analysis_type = "Qualitative"
            # Check if data is suitable for qualitative analysis
            if hasattr(self, 'controller') and hasattr(self.controller, 'data_controller'):
                data_model = self.controller.data_controller.data_model
                if hasattr(data_model, 'y_train') and data_model.y_train is not None:
                    y_train = data_model.y_train
                    # Check if continuous values (continuous values usually have more unique values)
                    if hasattr(y_train, 'nunique'):
                        unique_count = y_train.nunique()
                        if unique_count > 10 and unique_count / len(y_train) > 0.1:  # Many unique values with high ratio
                            self.display_message(_("main_window.suggest_quantitative").format(unique_count), _("main_window.analysis_type_suggestion_title"))
                    elif hasattr(y_train, 'shape'):
                        unique_count = len(np.unique(y_train))
                        if unique_count > 10 and unique_count / len(y_train) > 0.1:
                            self.display_message("Warning: Current target variable has many unique values ({}), may be more suitable for quantitative analysis.".format(unique_count),
                                              "Analysis Type Suggestion")

    def on_scatter_method_changed(self, method):
        """Handle scatter correction method change"""
        # Enable settings button for all methods that have parameter dialogs
        if method in ["MSC", "SNV", "EMSC", "RNV", "OSC"]:
            self.settings_btn.setEnabled(True)
        else:
            self.settings_btn.setEnabled(False)
    def open_scatter_parameters(self):
        """
        A refactored method to open a clean, well-laid-out dialog 
        displaying all available parameters for the selected scatter correction method.
        """
        method = self.scatter_method.currentData()
        # Create a mapping from UI display names to actual plugin names
        method_mapping = {
            "MSC": "Multiplicative Scatter Correction (MSC)",
            "SNV": "Standard Normal Variate (SNV)",
            "EMSC": "Extended Multiplicative Scatter Correction (EMSC)",
            "RNV": "Robust Normal Variate (RNV)",
            "OSC": "Orthogonal Signal Correction (OSC)"
        }
        try:
            # BUG FIX V4: Use the method map to get the correct plugin name
            preprocessing_service = self.controller.preprocessing_controller.preprocessing_service
            plugin_name = method_mapping.get(method, method)
            param_info = None
            # First, check for a plugin
            if plugin_name in preprocessing_service.plugins:
                plugin = preprocessing_service.plugins[plugin_name]
                param_info = plugin.get_parameter_info()
            else:
                # If no plugin, provide parameters for built-in methods
                param_info = self.get_builtin_method_params(method)
            # If no configurable parameters, show an informational message
            if not param_info:
                algorithm_info = {
                    "MSC": _("main_window.scatter_info_msc"),
                    "EMSC": _("main_window.scatter_info_emsc"),
                    "RNV": _("main_window.scatter_info_rnv"),
                    "OSC": "The Orthogonal Signal Correction algorithm uses fixed default parameters:\n- Number of Components: 1\n- Orthogonal components are calculated automatically.\n- No manual adjustment is required."
                }
                info_text = algorithm_info.get(method, _("main_window.algorithm_info_default").format(method=method))
                QMessageBox.information(self, _("main_window.algorithm_info_title").format(method=method), info_text)
                return

            dialog = QDialog(self)
            # Add detailed descriptions for each algorithm
            algorithm_descriptions = {
                "SNV": _("main_window.scatter_desc_snv"),
                "MSC": _("main_window.scatter_desc_msc"),
                "EMSC": _("main_window.scatter_desc_emsc"),
                "RNV": _("main_window.scatter_desc_rnv"),
                "OSC": _("main_window.scatter_desc_osc")
            }
            dialog.setWindowTitle(_("main_window.parameter_settings_title").format(method=method))
            form_layout = QFormLayout(dialog)
            form_layout.setSpacing(ui.scaled_px(tok.SPACE_LG))
            form_layout.setContentsMargins(ui.scaled_px(20), ui.scaled_px(20), ui.scaled_px(20), ui.scaled_px(20))
            # Add algorithm description label
            if method in algorithm_descriptions:
                desc_label = QLabel(algorithm_descriptions[method])
                desc_label.setStyleSheet(f"""
                    QLabel {{
                        color: {tok.COLOR_TEXT_HEADING};
                        font-weight: bold;
                        font-size: {ui.scaled_pt(tok.BASE_FONT_PT_MD)}pt;
                        padding: {ui.scaled_px(tok.SPACE_XS)}px;
                        background-color: {tok.COLOR_BG_ALT};
                        border-radius: {ui.scaled_px(tok.RADIUS_SM)}px;
                        margin-bottom: {ui.scaled_px(10)}px;
                    }}
                """)
                form_layout.addRow(desc_label)
            widgets = {}
            # Dynamically load and display all parameters
            for param_name, info in param_info.items():
                # Use the English parameter name for the label
                label_text = info.get('name', param_name)
                widget = self.data_partitioning_view.create_widget(info)
                # Set appropriate widths and styles for different control types
                if isinstance(widget, (QSpinBox, QDoubleSpinBox)):
                    ui.set_min_width(widget, tok.CONTROL_MIN_WIDTH)
                    widget.setStyleSheet(f"QSpinBox, QDoubleSpinBox {{ font-size: {ui.scaled_pt(tok.BASE_FONT_PT_MD)}pt; }}")
                elif isinstance(widget, QComboBox):
                    ui.set_min_width(widget, tok.COMBOBOX_MIN_WIDTH_MD)
                    widget.setStyleSheet(f"QComboBox {{ font-size: {ui.scaled_pt(tok.BASE_FONT_PT_MD)}pt; }}")
                elif isinstance(widget, QCheckBox):
                    # For checkboxes, use the English label
                    widget.setText(label_text)
                    widget.setStyleSheet(f"QCheckBox {{ font-size: {ui.scaled_pt(tok.BASE_FONT_PT_MD)}pt; }}")
                    form_layout.addRow(widget)
                    widgets[param_name] = widget
                    continue # Skip the standard addRow
                else:
                    ui.set_min_width(widget, tok.COMBOBOX_MIN_WIDTH_MD)
                # Add parameter description as a tooltip
                if 'description' in info:
                    widget.setToolTip(info['description'])
                form_layout.addRow(f"{label_text}:", widget)
                widgets[param_name] = widget

            # Add a separator line
            line = QFrame()
            line.setFrameShape(QFrame.HLine)
            line.setFrameShadow(QFrame.Sunken)
            line.setStyleSheet(f"QFrame {{ color: {tok.COLOR_BORDER}; margin: {ui.scaled_px(10)}px 0; }}")
            form_layout.addRow(line)
            # Create buttons
            button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
            button_box.button(QDialogButtonBox.Ok).setText(_("main_window.ok_btn"))
            button_box.button(QDialogButtonBox.Cancel).setText(_("main_window.cancel_btn"))
            button_box.button(QDialogButtonBox.Ok).setStyleSheet(f"""
                QPushButton {{
                    background-color: {tok.COLOR_PRIMARY};
                    color: white;
                    border: none;
                    padding: {ui.scaled_px(8)}px {ui.scaled_px(16)}px;
                    border-radius: {ui.scaled_px(tok.RADIUS_SM)}px;
                    font-size: {ui.scaled_pt(tok.BASE_FONT_PT_MD)}pt;
                }}
                QPushButton:hover {{
                    background-color: {tok.COLOR_PRIMARY_PRESSED};
                }}
            """)
            button_box.button(QDialogButtonBox.Cancel).setStyleSheet(f"""
                QPushButton {{
                    background-color: {tok.COLOR_TEXT_SECONDARY};
                    color: white;
                    border: none;
                    padding: {ui.scaled_px(8)}px {ui.scaled_px(16)}px;
                    border-radius: {ui.scaled_px(tok.RADIUS_SM)}px;
                    font-size: {ui.scaled_pt(tok.BASE_FONT_PT_MD)}pt;
                }}
                QPushButton:hover {{
                    background-color: {tok.COLOR_DISABLED_TEXT};
                }}
            """)
            button_box.accepted.connect(dialog.accept)
            button_box.rejected.connect(dialog.reject)
            form_layout.addRow(button_box)
            from app.utils.responsive import fit_window_to_screen
            fit_window_to_screen(
                dialog,
                preferred_width=520,
                preferred_height=dialog.sizeHint().height(),
                min_width=450,
                min_height=320,
            )

            if dialog.exec_():
                new_params = {}
                for name, widget in widgets.items():
                    if isinstance(widget, QCheckBox):
                        new_params[name] = widget.isChecked()
                    elif isinstance(widget, QComboBox):
                        new_params[name] = widget.currentData() if widget.currentData() is not None else widget.currentText()
                    elif isinstance(widget, QLineEdit):
                        new_params[name] = widget.text()
                    else:
                        new_params[name] = widget.value()

                # If it's a plugin, use its set_parameters method
                if plugin_name in preprocessing_service.plugins:
                    plugin = preprocessing_service.plugins[plugin_name]
                    plugin.set_parameters(**new_params)
                else:
                    # If it's a built-in method, store parameters in an instance variable
                    if not hasattr(self, 'builtin_method_params'):
                        self.builtin_method_params = {}
                    self.builtin_method_params[method] = new_params
                self.display_message(_("main_window.params_updated").format(method=method), _("main_window.message_7"))

        except Exception as e:
            self.display_error(_("main_window.open_params_failed").format(method=method, error=str(e)))

    def _toggle_poly_order_visibility(self, method):
        """Show or hide the Poly Order row based on the selected method"""
        is_sgolay = (method == "S-Golay")
        self.poly_order_label.setVisible(is_sgolay)
        self.smooth_poly_order.setVisible(is_sgolay)
    def get_builtin_method_params(self, method):
        """Define parameter configurations for built-in methods from a technical perspective."""
        if method == "SNV":
            # SNV: Standard Normal Variate, corrects for multiplicative scatter effects.
            # Key parameters: centering, scaling, and min_std threshold.
            return {
                'center': {
                    'name': 'Center Data',
                    'type': 'bool',
                    'default': True,
                    'description': 'Subtract the mean of each spectrum (recommended).'
                },
                'scale': {
                    'name': 'Scale Data',
                    'type': 'bool',
                    'default': True,
                    'description': 'Divide by the standard deviation of each spectrum (recommended).'
                },
                'min_std': {
                    'name': 'Min Std Threshold',
                    'type': 'float',
                    'default': 1e-6,
                    'min': 1e-10,
                    'max': 1e-2,
                    'description': 'Safety threshold to avoid division by zero.'
                }
            }
        elif method == "MSC":
            # MSC: Multiplicative Scatter Correction, uses a reference spectrum.
            # Key parameter: reference spectrum calculation method.
            return {
                'reference_spectrum': {
                    'name': 'Reference Spectrum',
                    'type': 'str',
                    'default': 'mean',
                    'options': ['mean', 'median', 'first_sample'],
                    'description': 'Method to calculate the reference spectrum: mean (recommended), median, or first sample.'
                }
            }
        elif method == "EMSC":
            # EMSC: Extended MSC, includes polynomial baseline correction.
            # Key parameters: reference method and polynomial degree.
            return {
                'reference_spectrum': {
                    'name': 'Reference Spectrum',
                    'type': 'str',
                    'default': 'mean',
                    'options': ['mean', 'median', 'first_sample'],
                    'description': 'Method to calculate the reference spectrum.'
                },
                'polynomial_degree': {
                    'name': 'Polynomial Degree',
                    'type': 'int',
                    'default': 2,
                    'min': 0,
                    'max': 4,
                    'description': 'Degree of the polynomial for baseline correction (2 is often sufficient).'
                }
            }
        elif method == "RNV":
            # RNV: Robust Normal Variate, a robust version of SNV.
            # Key parameter: robust statistic method.
            return {
                'robust_statistic': {
                    'name': 'Robust Statistic',
                    'type': 'str',
                    'default': 'median',
                    'options': ['median', 'trimmed_mean_10', 'trimmed_mean_20'],
                    'description': 'Robust statistic to use: median (recommended), 10% trimmed mean, or 20% trimmed mean.'
                }
            }
        elif method == "OSC":
            # OSC: Orthogonal Signal Correction, removes orthogonal variation.
            # Key parameter: number of components to remove.
            return {
                'num_components': {
                    'name': 'Number of Components',
                    'type': 'int',
                    'default': 1,
                    'min': 1,
                    'max': 5,
                    'description': 'Number of orthogonal components to remove (1-2 is common; more may cause overfitting).'
                }
            }
        else:
            return None

    def auto_save_estimator_from_analysis(self, model, X_sample, method, evaluation_results):
        """
        Auto-save a fitted estimator pickle from analysis process.
        
        Args:
            model: trained model
            X_sample: sample data for inferring input shape
            method: training method name
            evaluation_results: evaluation results
        """
        try:
            if model is None:
                return

            # This legacy automatic path stores only the estimator pickle.
            # Complete fitted-analyzer ONNX export is a separate explicit action.
            print("Saving fitted estimator as pickle; use Export Fitted Model to ONNX for ONNX output.")

            onnx_path = self.onnx_service.auto_save_model(
                model=model,
                X_sample=X_sample,
                model_name=type(model).__name__,
                method=method,
                evaluation_results=evaluation_results
            )

            if onnx_path:
                # Display save success message
                print(f"Analysis estimator saved ({os.path.splitext(onnx_path)[1]}): {onnx_path}")
            else:
                print("INFO: No estimator artifact was saved.")

        except Exception as e:
            print(f"Error in auto_save_estimator_from_analysis: {e}")
            # Do not interrupt main flow

    def _collect_preprocessing_params(self):
        """Return committed canonical operations in their actual insertion order."""
        import ast
        model = getattr(self.controller.preprocessing_controller, 'preprocessing_model', None)
        applied = getattr(model, 'applied_methods', {})
        steps = getattr(model, 'applied_steps', []) or [
            {'method': name, 'params': stored} for name, stored in applied.items()
        ]
        result = {}
        for number, step in enumerate(steps, start=1):
            name, stored = step['method'], step['params']
            try:
                parameters = ast.literal_eval(stored) if isinstance(stored, str) else dict(stored)
            except (ValueError, SyntaxError, TypeError):
                parameters = {'recorded_parameters': str(stored)}
            parameters['enabled'] = True
            parameters['canonical_method'] = name
            if 'source_key' in step:
                parameters['source_key'] = step['source_key']
            key = name if name not in result else f'{number}: {name}'
            result[key] = parameters
        return result

    def _collect_feature_selection_params(self):
        """Collect feature-selection parameters for reproducibility reporting."""
        fs_model = getattr(
            self.controller.feature_selection_controller,
            'feature_selection_model', None
        )
        if fs_model and getattr(fs_model, 'selected_method', None):
            return {
                'method': fs_model.selected_method,
                'n_features': len(fs_model.selected_features) if fs_model.selected_features else 'All',
                'criteria': 'N/A',
            }
        return None
