# -*- coding: utf-8 -*-
"""
NaN/Inf Data Handling Dialog
Addresses Reviewer 1 Comment 1 about data loading errors with invalid values
"""

from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QRadioButton, QButtonGroup, QTextEdit, QGroupBox, QMessageBox,
    QProgressBar, QApplication, QScrollArea, QWidget
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont, QIcon
import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any
import logging
from app.utils.responsive import fit_window_to_screen
from app.utils.translator import translator, _

class DataCleaningWorker(QThread):
    """Worker thread for data cleaning operations"""
    progress = pyqtSignal(int)
    status = pyqtSignal(str)
    finished = pyqtSignal(object, dict)  # cleaned_data, statistics
    
    def __init__(self, data, action, interpolation_method='linear'):
        super().__init__()
        self.data = data
        self.action = action
        self.interpolation_method = interpolation_method
    
    def run(self):
        try:
            self.status.emit("Analyzing data quality...")
            self.progress.emit(10)
            
            # Analyze data issues
            stats = self._analyze_data_issues(self.data)
            self.progress.emit(30)
            
            if self.action == "drop":
                self.status.emit("Removing rows with invalid values...")
                cleaned_data = self._drop_invalid_rows(self.data, stats)
            elif self.action == "interpolate":
                self.status.emit(f"Interpolating using {self.interpolation_method} method...")
                cleaned_data = self._interpolate_values(self.data, stats)
            else:  # keep
                self.status.emit("Keeping data unchanged...")
                cleaned_data = self.data.copy()
            
            self.progress.emit(90)
            
            # Final validation
            self.status.emit("Validating cleaned data...")
            final_stats = self._analyze_data_issues(cleaned_data)
            self.progress.emit(100)
            
            self.finished.emit(cleaned_data, {
                'original_stats': stats,
                'final_stats': final_stats,
                'action_taken': self.action
            })
            
        except Exception as e:
            self.status.emit(f"Error during data cleaning: {str(e)}")
            self.finished.emit(None, {'error': str(e)})
    
    def _analyze_data_issues(self, data):
        """Analyze data for NaN, Inf, and other issues"""
        stats = {
            'total_rows': len(data),
            'total_columns': len(data.columns),
            'nan_count': 0,
            'inf_count': 0,
            'problematic_rows': set(),
            'problematic_columns': {},
            'zero_variance_columns': []
        }
        
        for col in data.columns:
            col_data = data[col]
            
            # Count NaN values
            nan_count = col_data.isna().sum()
            if nan_count > 0:
                stats['nan_count'] += nan_count
                stats['problematic_columns'][col] = stats['problematic_columns'].get(col, {})
                stats['problematic_columns'][col]['nan_count'] = nan_count
                stats['problematic_rows'].update(col_data[col_data.isna()].index.tolist())
            
            # Count Inf values (for numeric columns)
            if pd.api.types.is_numeric_dtype(col_data):
                inf_count = np.isinf(col_data).sum()
                if inf_count > 0:
                    stats['inf_count'] += inf_count
                    stats['problematic_columns'][col] = stats['problematic_columns'].get(col, {})
                    stats['problematic_columns'][col]['inf_count'] = inf_count
                    stats['problematic_rows'].update(col_data[np.isinf(col_data)].index.tolist())
                
                # Check for zero variance
                if col_data.var() == 0:
                    stats['zero_variance_columns'].append(col)
        
        stats['problematic_rows'] = list(stats['problematic_rows'])
        return stats
    
    def _drop_invalid_rows(self, data, stats):
        """Drop rows containing NaN or Inf values"""
        if not stats['problematic_rows']:
            return data.copy()
        
        cleaned_data = data.drop(index=stats['problematic_rows']).reset_index(drop=True)
        return cleaned_data
    
    def _interpolate_values(self, data, stats):
        """Interpolate NaN and Inf values"""
        cleaned_data = data.copy()
        
        for col in data.columns:
            if col in stats['problematic_columns']:
                col_data = cleaned_data[col]
                
                # Replace Inf with NaN first
                col_data = col_data.replace([np.inf, -np.inf], np.nan)
                
                # Interpolate NaN values
                if pd.api.types.is_numeric_dtype(col_data):
                    if self.interpolation_method == 'linear':
                        col_data = col_data.interpolate(method='linear')
                    elif self.interpolation_method == 'median':
                        col_data = col_data.fillna(col_data.median())
                    elif self.interpolation_method == 'mean':
                        col_data = col_data.fillna(col_data.mean())
                    
                    # Fill any remaining NaN with forward/backward fill
                    col_data = col_data.bfill().ffill()
                
                cleaned_data[col] = col_data
        
        return cleaned_data

class NaNInfHandlingDialog(QDialog):
    """Dialog for handling NaN and Inf values in spectral data"""
    
    def __init__(self, data, parent=None):
        super().__init__(parent)
        self.data = data
        self.cleaned_data = None
        self.statistics = None
        self.init_ui()
        self.analyze_data()
    
    def init_ui(self):
        """Initialize the dialog UI"""
        self.setWindowTitle(_("nan_inf_handling_dialog.title"))
        self.setModal(True)
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_LG[0]), ui.scaled_px(tok.DIALOG_SIZE_LG[1]), min_width=ui.scaled_px(440), min_height=ui.scaled_px(360))
        
        # Set font
        font = ui.get_scaled_font("Segoe UI", 9)
        self.setFont(font)
        
        layout = QVBoxLayout(self)
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        
        # Header
        header = QLabel(_("nan_inf_handling_dialog.header"))
        header.setObjectName("pageTitle")
        header.setAlignment(Qt.AlignCenter)
        content_layout.addWidget(header)
        
        # Problem description
        self.problem_text = QTextEdit()
        ui.set_max_height(self.problem_text, tok.TEXT_EDIT_MAX_HEIGHT_MD)
        self.problem_text.setReadOnly(True)
        content_layout.addWidget(self.problem_text)
        
        # Action selection group
        action_group = QGroupBox(_("nan_inf_handling_dialog.action_group"))
        action_layout = QVBoxLayout()
        
        self.action_group = QButtonGroup()
        
        # Option 1: Drop affected rows
        self.drop_radio = QRadioButton(_("nan_inf_handling_dialog.drop_radio"))
        self.drop_radio.setToolTip(_("nan_inf_handling_dialog.drop_radio_drop_radio_tooltip"))
        action_layout.addWidget(self.drop_radio)
        self.action_group.addButton(self.drop_radio, 1)
        
        # Option 2: Interpolate values
        self.interpolate_radio = QRadioButton(_("nan_inf_handling_dialog.interpolate_radio"))
        self.interpolate_radio.setToolTip(_("nan_inf_handling_dialog.interpolate_radio_interpolate_radio_tooltip"))
        self.interpolate_radio.setChecked(True)  # Default choice
        action_layout.addWidget(self.interpolate_radio)
        self.action_group.addButton(self.interpolate_radio, 2)
        
        # Option 3: Keep unchanged
        self.keep_radio = QRadioButton(_("nan_inf_handling_dialog.keep_radio"))
        self.keep_radio.setToolTip(_("nan_inf_handling_dialog.keep_radio_keep_radio_tooltip"))
        action_layout.addWidget(self.keep_radio)
        self.action_group.addButton(self.keep_radio, 3)
        
        action_group.setLayout(action_layout)
        content_layout.addWidget(action_group)
        
        # Interpolation method selection (initially hidden)
        self.interpolation_group = QGroupBox(_("nan_inf_handling_dialog.interpolation_group"))
        interp_layout = QVBoxLayout()
        
        self.interp_method_group = QButtonGroup()
        
        self.linear_radio = QRadioButton(_("nan_inf_handling_dialog.linear_radio"))
        self.linear_radio.setChecked(True)
        interp_layout.addWidget(self.linear_radio)
        self.interp_method_group.addButton(self.linear_radio, 1)
        
        self.median_radio = QRadioButton(_("nan_inf_handling_dialog.median_radio"))
        interp_layout.addWidget(self.median_radio)
        self.interp_method_group.addButton(self.median_radio, 2)
        
        self.mean_radio = QRadioButton(_("nan_inf_handling_dialog.mean_radio"))
        interp_layout.addWidget(self.mean_radio)
        self.interp_method_group.addButton(self.mean_radio, 3)
        
        self.interpolation_group.setLayout(interp_layout)
        content_layout.addWidget(self.interpolation_group)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        content_layout.addWidget(self.progress_bar)
        
        # Status label
        self.status_label = QLabel("")
        self.status_label.setVisible(False)
        content_layout.addWidget(self.status_label)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(content_widget)
        layout.addWidget(scroll_area)
        
        # Buttons
        button_layout = QHBoxLayout()

        self.preview_btn = QPushButton(_("nan_inf_handling_dialog.preview_btn"))
        self.preview_btn.setProperty("role", "secondary")
        self.preview_btn.clicked.connect(self.preview_changes)
        button_layout.addWidget(self.preview_btn)

        self.apply_btn = QPushButton(_("nan_inf_handling_dialog.apply_btn"))
        self.apply_btn.setProperty("role", "success")
        self.apply_btn.clicked.connect(self.apply_changes)
        button_layout.addWidget(self.apply_btn)

        self.cancel_btn = QPushButton(_("nan_inf_handling_dialog.cancel_btn"))
        self.cancel_btn.setProperty("role", "quiet")
        self.cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_btn)

        layout.addLayout(button_layout)
        
        # Connect signals
        self.interpolate_radio.toggled.connect(self.on_action_changed)
        self.on_action_changed()  # Initialize visibility
    
    def analyze_data(self):
        """Analyze the data for issues"""
        nan_count = self.data.isna().sum().sum()
        inf_count = 0
        
        # Count Inf values in numeric columns
        for col in self.data.select_dtypes(include=[np.number]).columns:
            inf_count += np.isinf(self.data[col]).sum()
        
        # Identify problematic rows
        problematic_rows = set()
        for col in self.data.columns:
            col_data = self.data[col]
            problematic_rows.update(col_data[col_data.isna()].index.tolist())
            if pd.api.types.is_numeric_dtype(col_data):
                problematic_rows.update(col_data[np.isinf(col_data)].index.tolist())
        
        # Update problem description
        problem_text = _("nan_inf_handling_dialog.problem_text").format(
            rows=len(self.data),
            columns=len(self.data.columns),
            nan_count=nan_count,
            inf_count=inf_count,
            affected_rows=len(problematic_rows),
            percentage=len(problematic_rows)/len(self.data)*100
        )

        self.problem_text.setPlainText(problem_text.strip())

    def on_action_changed(self):
        """Handle action selection changes"""
        interpolate_selected = self.interpolate_radio.isChecked()
        self.interpolation_group.setVisible(interpolate_selected)
    
    def preview_changes(self):
        """Preview the changes that would be made"""
        action = self.get_selected_action()
        interp_method = self.get_interpolation_method()
        
        # Create worker for preview
        self.worker = DataCleaningWorker(self.data, action, interp_method)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.status.connect(self.status_label.setText)
        self.worker.finished.connect(self.on_preview_finished)
        
        # Show progress
        self.progress_bar.setVisible(True)
        self.status_label.setVisible(True)
        self.preview_btn.setEnabled(False)
        self.apply_btn.setEnabled(False)
        
        self.worker.start()
    
    def on_preview_finished(self, cleaned_data, stats):
        """Handle preview completion"""
        self.progress_bar.setVisible(False)
        self.status_label.setVisible(False)
        self.preview_btn.setEnabled(True)
        self.apply_btn.setEnabled(True)
        
        if cleaned_data is None:
            QMessageBox.critical(self, _("nan_inf_handling_dialog.message"), _("nan_inf_handling_dialog.preview_failed").format(error=stats.get('error', 'Unknown error')))
            return
        
        # Show preview results
        original_stats = stats['original_stats']
        final_stats = stats['final_stats']
        action = stats['action_taken']

        suitable = _("nan_inf_handling_dialog.suitable_yes") if final_stats['nan_count'] == 0 and final_stats['inf_count'] == 0 else _("nan_inf_handling_dialog.suitable_no")

        preview_text = _("nan_inf_handling_dialog.preview_results").format(
            action=action.upper(),
            before_rows=original_stats['total_rows'],
            before_nan=original_stats['nan_count'],
            before_inf=original_stats['inf_count'],
            before_problematic=len(original_stats['problematic_rows']),
            after_rows=final_stats['total_rows'],
            after_nan=final_stats['nan_count'],
            after_inf=final_stats['inf_count'],
            after_problematic=len(final_stats['problematic_rows']),
            suitable=suitable
        )

        QMessageBox.information(self, _("nan_inf_handling_dialog.message_2"), preview_text.strip())

    def apply_changes(self):
        """Apply the selected changes"""
        action = self.get_selected_action()
        interp_method = self.get_interpolation_method()
        
        # Create worker for actual processing
        self.worker = DataCleaningWorker(self.data, action, interp_method)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.status.connect(self.status_label.setText)
        self.worker.finished.connect(self.on_apply_finished)
        
        # Show progress
        self.progress_bar.setVisible(True)
        self.status_label.setVisible(True)
        self.preview_btn.setEnabled(False)
        self.apply_btn.setEnabled(False)
        self.cancel_btn.setEnabled(False)
        
        self.worker.start()
    
    def on_apply_finished(self, cleaned_data, stats):
        """Handle apply completion"""
        if cleaned_data is None:
            QMessageBox.critical(self, _("nan_inf_handling_dialog.message"), _("nan_inf_handling_dialog.cleaning_failed").format(error=stats.get('error', 'Unknown error')))
            self.progress_bar.setVisible(False)
            self.status_label.setVisible(False)
            self.preview_btn.setEnabled(True)
            self.apply_btn.setEnabled(True)
            self.cancel_btn.setEnabled(True)
            return
        
        self.cleaned_data = cleaned_data
        self.statistics = stats
        
        # Show success message
        final_stats = stats['final_stats']
        success_msg = _("nan_inf_handling_dialog.success_message").format(
            rows=final_stats['total_rows'],
            columns=final_stats['total_columns'],
            nan_count=final_stats['nan_count'],
            inf_count=final_stats['inf_count']
        )

        QMessageBox.information(self, _("nan_inf_handling_dialog.message_3"), success_msg.strip())
        self.accept()

    def get_selected_action(self):
        """Get the selected action"""
        if self.drop_radio.isChecked():
            return "drop"
        elif self.interpolate_radio.isChecked():
            return "interpolate"
        else:
            return "keep"
    
    def get_interpolation_method(self):
        """Get the selected interpolation method"""
        if self.linear_radio.isChecked():
            return "linear"
        elif self.median_radio.isChecked():
            return "median"
        else:
            return "mean"
    
    def get_cleaned_data(self):
        """Get the cleaned data"""
        return self.cleaned_data
    
    def get_statistics(self):
        """Get cleaning statistics"""
        return self.statistics

def detect_and_handle_data_issues(data, parent=None):
    """
    Detect and handle data quality issues
    
    Args:
        data: DataFrame to check
        parent: Parent widget for dialog
        
    Returns:
        Tuple[DataFrame, bool]: (cleaned_data, user_cancelled)
    """
    # Quick check for issues
    has_nan = data.isna().any().any()
    has_inf = False
    
    for col in data.select_dtypes(include=[np.number]).columns:
        if np.isinf(data[col]).any():
            has_inf = True
            break
    
    if not has_nan and not has_inf:
        return data, False  # No issues found
    
    # Show dialog for handling issues
    dialog = NaNInfHandlingDialog(data, parent)
    if dialog.exec_() == QDialog.Accepted:
        cleaned_data = dialog.get_cleaned_data()
        return cleaned_data if cleaned_data is not None else data, False
    else:
        return data, True  # User cancelled

if __name__ == "__main__":
    # Test the dialog
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    app = QApplication([])
    
    # Create test data with issues
    test_data = pd.DataFrame({
        'wavelength_1': [1, 2, np.nan, 4, 5],
        'wavelength_2': [1.1, np.inf, 3.3, 4.4, 5.5],
        'wavelength_3': [2.1, 2.2, 2.3, np.nan, 2.5]
    })
    
    cleaned_data, cancelled = detect_and_handle_data_issues(test_data)
    
    if not cancelled:
        logging.info("Cleaned data:")
        logging.info(cleaned_data)
    else:
        logging.info("User cancelled")
    
    app.exec_()
