"""Compact editor for verification-driven R-to-Python spectral operators."""

from __future__ import annotations

import json
import re

import numpy as np
import requests
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QCheckBox,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLayout,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSizePolicy,
    QScrollArea,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.services.algorithm_onboarding_service import (
    AlgorithmOnboardingError,
    OnboardingCandidate,
)
from app.ui import design_tokens as tok
from app.utils import ui_scaling as ui
from app.utils.responsive import fit_window_to_screen
from app.utils.worker import Worker


def _json_text(value) -> str:
    try:
        return json.dumps(np.asarray(value).tolist(), ensure_ascii=False, indent=2)
    except Exception:
        return "[]"


class _RConversionWorker(Worker):
    """Keep the existing LLMService request off the Qt UI thread."""

    def __init__(self, llm_service, r_source: str, parent=None):
        super().__init__(parent)
        self._service = llm_service
        self._r_source = r_source
        self._session = requests.Session()

    def run_task(self):
        prompt = (
            "Convert the supplied standalone R spectral preprocessing function to Python. "
            "Return only source code defining exactly one module-level function "
            "transform(X, params), with X numeric and shaped (samples, channels). "
            "The operation must be stateless and independent for each sample row; "
            "preserve channel count/order and do not fit cohort-level state. "
            "Use only numpy, scipy, math, or statistics imports. Do not read or write files, "
            "perform network/process actions, or invent reference outputs. Preserve the R "
            "algorithm semantics and make parameter access explicit through params."
        )
        return self._service.chat(message=prompt, code=self._r_source, session=self._session)

    def cancel(self):
        super().cancel()
        try:
            self._session.close()
        except Exception:
            pass


class AlgorithmOnboardingDialog(QDialog):
    """Collect source/schema/fixtures, verify the exact editor text, then accept."""

    def __init__(
        self,
        onboarding_service,
        llm_service=None,
        *,
        initial_X=None,
        axis=None,
        axis_unit="nm",
        parent=None,
    ):
        super().__init__(parent)
        self.onboarding_service = onboarding_service
        self.llm_service = llm_service
        self._report = None
        self.candidate_id = None
        self._conversion_worker = None
        self._build_ui(initial_X=initial_X, axis=axis, axis_unit=axis_unit)

    def _build_ui(self, *, initial_X, axis, axis_unit):
        self.setWindowTitle("Algorithm onboarding — stateless spectral preprocessing")
        fit_window_to_screen(
            self,
            ui.scaled_px(920),
            ui.scaled_px(790),
            min_width=ui.scaled_px(660),
            min_height=ui.scaled_px(470),
        )
        self.setObjectName("algorithmOnboardingDialog")

        root = QVBoxLayout(self)
        root.setContentsMargins(
            ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM),
            ui.scaled_px(tok.SPACE_SM), ui.scaled_px(tok.SPACE_SM),
        )
        root.setSpacing(ui.scaled_px(tok.SPACE_XS))

        self.scope_label = QLabel(
            "Stateless per-spectrum preprocessing only. Samples are rows; spectral channels are columns. "
            "Fitted/stateful methods, feature selection, and models are disabled."
        )
        self.scope_label.setWordWrap(True)
        root.addWidget(self.scope_label)

        conversion_row = QHBoxLayout()
        self.convert_button = QPushButton("Convert R source with configured LLM")
        self.convert_button.setObjectName("onboardingConvertButton")
        self.convert_button.clicked.connect(self.convert_r_source)
        self.llm_status_label = QLabel()
        self.llm_status_label.setWordWrap(True)
        self._llm_configured = bool(
            self.llm_service and str(getattr(self.llm_service, "api_key", "")).strip()
        )
        self.convert_button.setEnabled(self._llm_configured)
        if self._llm_configured:
            self.llm_status_label.setText("LLM conversion is configured; generated code still requires verification.")
        else:
            self.llm_status_label.setText(
                "LLM conversion requires an API key in LLM settings. Manual Python entry and verification remain available."
            )
        conversion_row.addWidget(self.convert_button)
        conversion_row.addWidget(self.llm_status_label, stretch=1)
        root.addLayout(conversion_row)

        self.tabs = QTabWidget()
        self.tabs.setObjectName("onboardingTabs")
        self.content_scroll = QScrollArea()
        self.content_scroll.setObjectName("onboardingContentScrollArea")
        self.content_scroll.setWidgetResizable(True)
        self.content_widget = QWidget()
        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_layout.setSizeConstraint(QLayout.SetMinimumSize)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.addWidget(self.tabs)
        self.content_scroll.setWidget(self.content_widget)
        root.addWidget(self.content_scroll, stretch=1)

        source_tab = QWidget()
        source_form = QFormLayout(source_tab)
        source_form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
        source_form.setSpacing(ui.scaled_px(tok.SPACE_XS))

        self.name_edit = QLineEdit()
        self.name_edit.setObjectName("algorithmNameField")
        self.name_edit.setPlaceholderText("Algorithm name")
        source_form.addRow("Name", self.name_edit)

        self.r_source_edit = self._editor("rSourceEditor", 92, "Paste the original standalone R function.")
        source_form.addRow("Original R source", self.r_source_edit)

        self.python_source_edit = self._editor(
            "pythonSourceEditor", 150,
            "Editable Python source with exactly: def transform(X, params): ...",
        )
        source_form.addRow("Generated / edited Python", self.python_source_edit)

        self.parameter_schema_edit = self._editor(
            "parameterSchemaEditor", 92,
            '{"scale": {"type": "number", "default": 1.0}}',
        )
        self.parameter_schema_edit.setPlainText("{}")
        source_form.addRow("Typed parameter schema (JSON)", self.parameter_schema_edit)

        self.parameter_values_edit = self._editor("parameterValuesEditor", 66, '{"scale": 1.0}')
        self.parameter_values_edit.setPlainText("{}")
        source_form.addRow("Verification values (JSON)", self.parameter_values_edit)

        self.parameter_preview_label = QLabel("No typed parameters parsed yet.")
        self.parameter_preview_label.setObjectName("parameterPreviewLabel")
        self.parameter_preview_label.setWordWrap(True)
        source_form.addRow("Parameter preview", self.parameter_preview_label)
        self.tabs.addTab(source_tab, "Source & parameters")

        data_tab = QWidget()
        data_form = QFormLayout(data_tab)
        data_form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
        data_form.setSpacing(ui.scaled_px(tok.SPACE_XS))

        self.axis_unit_edit = QLineEdit(str(axis_unit or "nm"))
        self.axis_unit_edit.setObjectName("spectralAxisUnitField")
        data_form.addRow("Axis unit", self.axis_unit_edit)
        self.axis_edit = self._editor("spectralAxisEditor", 72, "Numeric wavelength/wavenumber coordinates in source channel order.")
        self.axis_edit.setPlainText(_json_text(axis) if axis is not None else "[]")
        data_form.addRow("Spectral axis (JSON)", self.axis_edit)
        self.input_matrix_edit = self._editor("spectralInputEditor", 112, "Numeric matrix: samples by spectral channels.")
        self.input_matrix_edit.setPlainText(_json_text(initial_X) if initial_X is not None else "[]")
        data_form.addRow("Verification matrix X (JSON)", self.input_matrix_edit)
        self.reference_examples_edit = self._editor(
            "referenceExamplesEditor", 136,
            '[{"input": [[...]], "expected": [[...]], "parameters": {}}]',
        )
        self.reference_examples_edit.setPlainText("[]")
        data_form.addRow("Trusted R input/output fixtures (JSON)", self.reference_examples_edit)
        self.tabs.addTab(data_tab, "Axis & trusted examples")

        self.verification_output = QPlainTextEdit()
        self.verification_output.setObjectName("verificationOutcomes")
        self.verification_output.setReadOnly(True)
        # Preserve a readable result area. Unbounded source editors otherwise
        # consumed the entire content height and reduced this to one line.
        self.verification_output.setMinimumHeight(ui.scaled_px(160))
        self.verification_output.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.verification_output.setPlaceholderText("Run verification to see check outcomes.")
        self.verification_output.setMaximumBlockCount(100)
        self.content_layout.addWidget(self.verification_output)

        consent_row = QHBoxLayout()
        self.acceptance_checkbox = QCheckBox(
            "I reviewed this verified candidate and want to register it in preprocessing."
        )
        self.acceptance_checkbox.setObjectName("explicitAcceptanceCheckbox")
        self.acceptance_checkbox.setEnabled(False)
        self.acceptance_checkbox.toggled.connect(self._update_register_enabled)
        consent_row.addWidget(self.acceptance_checkbox, stretch=1)
        root.addLayout(consent_row)

        button_row = QHBoxLayout()
        self.verify_button = QPushButton("Verify candidate")
        self.verify_button.setObjectName("verifyCandidateButton")
        self.verify_button.clicked.connect(self.verify_candidate)
        self.register_button = QPushButton("Accept and register")
        self.register_button.setObjectName("acceptCandidateButton")
        self.register_button.setEnabled(False)
        self.register_button.clicked.connect(self.accept_candidate)
        self.cancel_button = QPushButton("Close")
        self.cancel_button.clicked.connect(self.reject)
        button_row.addWidget(self.verify_button)
        button_row.addWidget(self.register_button)
        button_row.addWidget(self.cancel_button)
        root.addLayout(button_row)

        self._editable_widgets = [
            self.name_edit, self.r_source_edit, self.python_source_edit,
            self.parameter_schema_edit, self.parameter_values_edit,
            self.axis_unit_edit, self.axis_edit, self.input_matrix_edit,
            self.reference_examples_edit,
        ]
        for widget in self._editable_widgets:
            signal = getattr(widget, "textChanged", None)
            if signal is not None:
                signal.connect(self._invalidate_verification)
        self.parameter_schema_edit.textChanged.connect(self._update_parameter_preview)
        self.parameter_values_edit.textChanged.connect(self._update_parameter_preview)
        self._update_parameter_preview()

    @staticmethod
    def _editor(object_name, height, placeholder):
        editor = QPlainTextEdit()
        editor.setObjectName(object_name)
        editor.setPlaceholderText(placeholder)
        # Each editor keeps its designed multiline height; longer code/JSON
        # scrolls inside the editor and the complete form scrolls on laptops.
        editor.setFixedHeight(ui.scaled_px(height))
        editor.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        editor.setLineWrapMode(QPlainTextEdit.NoWrap)
        editor.setTabStopDistance(ui.scaled_px(4) * 4)
        editor.setStyleSheet(
            f"font-family: {', '.join(tok.FONT_FAMILY_CODE)}; "
            f"font-size: {ui.scaled_pt(tok.BASE_FONT_PT_SM)}pt;"
        )
        return editor

    def _invalidate_verification(self, *_args):
        if self._report is None:
            return
        self._report = None
        self.acceptance_checkbox.setChecked(False)
        self.acceptance_checkbox.setEnabled(False)
        self.register_button.setEnabled(False)
        self.verification_output.setPlainText(
            "Candidate fields changed. Verify the exact edited source and inputs again before acceptance."
        )

    def _update_parameter_preview(self, *_args):
        try:
            schema = json.loads(self.parameter_schema_edit.toPlainText() or "{}")
            values = json.loads(self.parameter_values_edit.toPlainText() or "{}")
            if not isinstance(schema, dict) or not isinstance(values, dict):
                raise ValueError("schema and values must be JSON objects")
            if not schema:
                text = "No parameters declared."
            else:
                lines = []
                for name, spec in schema.items():
                    if not isinstance(spec, dict):
                        lines.append(f"{name}: invalid schema entry")
                        continue
                    value = values.get(name, spec.get("default", "<required>"))
                    lines.append(f"{name}: {spec.get('type', '?')} = {value!r}")
                text = "\n".join(lines)
            self.parameter_preview_label.setText(text)
        except Exception as exc:
            self.parameter_preview_label.setText(f"Schema/value preview unavailable: {exc}")

    def _candidate_from_editor(self):
        schema = json.loads(self.parameter_schema_edit.toPlainText() or "{}")
        parameters = json.loads(self.parameter_values_edit.toPlainText() or "{}")
        X = json.loads(self.input_matrix_edit.toPlainText() or "[]")
        axis = json.loads(self.axis_edit.toPlainText() or "[]")
        reference_examples = json.loads(self.reference_examples_edit.toPlainText() or "[]")
        return OnboardingCandidate(
            name=self.name_edit.text().strip(),
            python_source=self.python_source_edit.toPlainText(),
            original_r_source=self.r_source_edit.toPlainText(),
            algorithm_category="stateless_preprocessing",
            parameter_schema=schema,
            parameters=parameters,
            X=X,
            axis=axis,
            axis_unit=self.axis_unit_edit.text().strip(),
            reference_examples=reference_examples,
        )

    def verify_candidate(self):
        self._report = None
        self.acceptance_checkbox.setChecked(False)
        self.acceptance_checkbox.setEnabled(False)
        self.register_button.setEnabled(False)
        try:
            candidate = self._candidate_from_editor()
            self._report = self.onboarding_service.verify_candidate(candidate)
            lines = [
                f"Candidate source SHA-256: {self._report.source_sha256}",
                "Verification outcomes:",
            ]
            lines.extend(
                f"[{item.status.upper()}] {item.name}: {item.details}"
                for item in self._report.checks
            )
            lines.append(
                "Overall: all implemented checks passed. Review and explicitly accept to register."
                if self._report.passed
                else "Overall: not accepted. Fix failed checks and supply trusted fixtures for any not_verified check."
            )
            self.verification_output.setPlainText("\n".join(lines))
            self.acceptance_checkbox.setEnabled(self._report.passed)
            self.acceptance_checkbox.setChecked(False)
            self._update_register_enabled()
            return self._report
        except Exception as exc:
            self.verification_output.setPlainText(f"Candidate input could not be parsed: {exc}")
            return None

    def _update_register_enabled(self, *_args):
        self.register_button.setEnabled(
            bool(self._report and self._report.passed and self.acceptance_checkbox.isChecked())
        )

    def accept_candidate(self):
        if not self._report or not self._report.passed or not self.acceptance_checkbox.isChecked():
            return False
        try:
            self.candidate_id = self.onboarding_service.accept_candidate(
                self._report,
                edited_python_source=self.python_source_edit.toPlainText(),
                user_confirmed=True,
            )
            self.verification_output.setPlainText(
                f"Registered verified stateless plugin: {self.candidate_id}"
            )
            self.accept()
            return True
        except (AlgorithmOnboardingError, OSError, ValueError) as exc:
            self.verification_output.setPlainText(f"Registration was not completed: {exc}")
            return False

    def convert_r_source(self):
        if not self._llm_configured or self._conversion_worker is not None:
            return False
        r_source = self.r_source_edit.toPlainText().strip()
        if not r_source:
            self.llm_status_label.setText("Enter the original R function before requesting conversion.")
            return False
        self.convert_button.setEnabled(False)
        self.llm_status_label.setText("Converting in the background; review and verify the generated source before acceptance.")
        worker = _RConversionWorker(self.llm_service, r_source, parent=None)
        self._conversion_worker = worker
        worker.result_ready.connect(self._on_conversion_result)
        worker.error_occurred.connect(self._on_conversion_error)
        worker.finished.connect(self._on_conversion_finished)
        worker.start()
        return True

    @staticmethod
    def _extract_python_source(response):
        text = str(response or "").strip()
        match = re.search(r"```(?:python|py)?\s*(.*?)```", text, flags=re.IGNORECASE | re.DOTALL)
        return match.group(1).strip() if match else text

    def _on_conversion_result(self, response):
        code = self._extract_python_source(response)
        if code:
            self.python_source_edit.setPlainText(code)
            self.llm_status_label.setText("Generated source loaded for review. Run verification before acceptance.")
        else:
            self.llm_status_label.setText("The LLM returned no Python source.")

    def _on_conversion_error(self, error):
        self.llm_status_label.setText(f"LLM conversion failed: {error}")

    def _on_conversion_finished(self):
        self._conversion_worker = None
        self.convert_button.setEnabled(self._llm_configured)

    def closeEvent(self, event):
        worker = self._conversion_worker
        if worker is not None and worker.isRunning():
            worker.cancel()
            worker.wait(500)
        self._conversion_worker = None
        super().closeEvent(event)
