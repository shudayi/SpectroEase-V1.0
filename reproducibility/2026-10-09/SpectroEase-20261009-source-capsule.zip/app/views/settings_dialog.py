# app/views/settings_dialog.py
"""Application settings dialog.

Lets the user view and edit the fields in ``config/settings.py::Settings``.
The dialog is intentionally light-weight: a single ``QDialog`` with a
``QTabWidget`` for organization. All edits are persisted via
``Settings.save_settings`` when the user clicks OK.
"""

from __future__ import annotations

import json
from typing import Optional

from PyQt5.QtWidgets import (
    QDialog, QDialogButtonBox, QVBoxLayout, QHBoxLayout, QFormLayout,
    QTabWidget, QWidget, QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox,
    QLabel, QGroupBox, QListWidget, QListWidgetItem, QHBoxLayout, QPushButton,
    QMessageBox, QSizePolicy, QScrollArea, QLayout,
)
from PyQt5.QtCore import Qt

from config.settings import Settings
from app.ui import design_tokens as tok
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _
from app.utils.spectral_units import ALL_UNITS, axis_label
from app.utils.responsive import fit_window_to_screen


_UNITS = ['nm', 'cm-1', 'um', 'THz', 'eV', 'Å']
_INTENSITY_UNITS = ['absorbance', 'reflectance', 'transmittance', 'counts']

# Default metric lists (kept in sync with config/settings.py).
DEFAULT_CLASSIFICATION_METRICS = [
    'accuracy', 'precision', 'recall', 'f1_macro', 'f1_weighted',
    'roc_auc', 'confusion_matrix',
]
DEFAULT_REGRESSION_METRICS = [
    'rmse', 'mae', 'r2', 'mape', 'rpd',
]


class _IntegerField(QSpinBox):
    def __init__(self, value: int, minimum: int = 0, maximum: int = 1000000, parent=None):
        super().__init__(parent)
        self.setRange(minimum, maximum)
        self.setValue(value)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)


class _FloatField(QDoubleSpinBox):
    def __init__(self, value: float, minimum: float = 0.0, maximum: float = 1e9,
                 decimals: int = 4, step: float = 0.1, parent=None):
        super().__init__(parent)
        self.setRange(minimum, maximum)
        self.setDecimals(decimals)
        self.setSingleStep(step)
        self.setValue(value)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)


class SettingsDialog(QDialog):
    """Edit ``Settings`` fields and persist on OK."""

    def __init__(self, settings: Optional[Settings] = None, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._settings = settings or Settings()
        self.setWindowTitle(_('settings_dialog.title'))
        self.setModal(True)
        fit_window_to_screen(self, ui.scaled_px(580), ui.scaled_px(620), min_width=ui.scaled_px(480), min_height=ui.scaled_px(520))

        root = QVBoxLayout(self)
        root.setContentsMargins(
            ui.scaled_px(tok.SPACE_LG), ui.scaled_px(tok.SPACE_LG),
            ui.scaled_px(tok.SPACE_LG), ui.scaled_px(tok.SPACE_LG),
        )
        root.setSpacing(ui.scaled_px(tok.SPACE_MD))

        intro = QLabel(_('settings_dialog.intro'))
        intro.setObjectName("secondaryText")
        intro.setWordWrap(True)
        root.addWidget(intro)

        tabs = QTabWidget()

        # ----- General -----
        general_tab = QWidget()
        general_layout = QVBoxLayout(general_tab)
        general_layout.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
        )
        general_layout.setSpacing(ui.scaled_px(tok.SPACE_MD))

        appearance_group = QGroupBox(_('settings_dialog.appearance_group'))
        appearance_form = QFormLayout(appearance_group)
        appearance_form.setSpacing(ui.scaled_px(tok.SPACE_SM))
        appearance_form.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
        )

        self.theme_combo = QComboBox()
        for theme_key in ['light', 'dark']:
            self.theme_combo.addItem(
                translator.lget(f'settings_dialog.theme_{theme_key}', theme_key.capitalize()),
                theme_key,
            )
        self.theme_combo.setCurrentIndex(
            max(0, self.theme_combo.findData(self._settings.theme))
        )
        appearance_form.addRow(_('settings_dialog.theme'), self.theme_combo)

        self.language_combo = QComboBox()
        for lang in ['en', 'zh']:
            self.language_combo.addItem(
                translator.lget(f'settings_dialog.language_{lang}', lang.upper()),
                lang,
            )
        self.language_combo.setCurrentIndex(
            max(0, self.language_combo.findData(self._settings.language))
        )
        appearance_form.addRow(_('settings_dialog.language'), self.language_combo)

        general_layout.addWidget(appearance_group)

        units_group = QGroupBox(_('settings_dialog.units_group'))
        units_form = QFormLayout(units_group)
        units_form.setSpacing(ui.scaled_px(tok.SPACE_SM))
        units_form.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
        )

        self.preferred_x_unit_combo = QComboBox()
        for unit in _UNITS:
            self.preferred_x_unit_combo.addItem(
                axis_label(unit), unit,
            )
        self.preferred_x_unit_combo.setCurrentIndex(
            max(0, self.preferred_x_unit_combo.findData(self._settings.preferred_x_unit))
        )
        units_form.addRow(_('settings_dialog.preferred_x_unit'), self.preferred_x_unit_combo)

        self.preferred_y_unit_combo = QComboBox()
        for unit in _INTENSITY_UNITS:
            self.preferred_y_unit_combo.addItem(unit.capitalize(), unit)
        self.preferred_y_unit_combo.setCurrentIndex(
            max(0, self.preferred_y_unit_combo.findData(self._settings.preferred_y_unit))
        )
        units_form.addRow(_('settings_dialog.preferred_y_unit'), self.preferred_y_unit_combo)

        general_layout.addWidget(units_group)
        general_layout.addStretch(1)
        tabs.addTab(general_tab, _('settings_dialog.general_tab'))

        # ----- Detection -----
        detection_tab = QWidget()
        detection_layout = QVBoxLayout(detection_tab)
        detection_layout.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
        )
        detection_layout.setSpacing(ui.scaled_px(tok.SPACE_MD))

        task_group = QGroupBox(_('settings_dialog.task_detection_group'))
        task_form = QFormLayout(task_group)
        task_form.setSpacing(ui.scaled_px(tok.SPACE_SM))
        task_form.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
        )

        self.categorical_count_spin = _IntegerField(
            int(self._settings.categorical_unique_count_max),
            minimum=2, maximum=10000,
        )
        task_form.addRow(
            _('settings_dialog.categorical_unique_count_max'),
            self.categorical_count_spin,
        )

        self.categorical_ratio_spin = _FloatField(
            float(self._settings.categorical_unique_ratio_max),
            minimum=0.0, maximum=1.0, decimals=3, step=0.05,
        )
        task_form.addRow(
            _('settings_dialog.categorical_unique_ratio_max'),
            self.categorical_ratio_spin,
        )

        self.isolation_forest_spin = _FloatField(
            float(self._settings.isolationforest_contamination),
            minimum=0.0, maximum=1.0, decimals=3, step=0.01,
        )
        task_form.addRow(
            _('settings_dialog.isolationforest_contamination'),
            self.isolation_forest_spin,
        )

        detection_layout.addWidget(task_group)

        data_group = QGroupBox(_('settings_dialog.data_quality_group'))
        data_form = QFormLayout(data_group)
        data_form.setSpacing(ui.scaled_px(tok.SPACE_SM))
        data_form.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
        )

        self.numeric_conv_spin = _FloatField(
            float(self._settings.numeric_conversion_threshold),
            minimum=0.0, maximum=1.0, decimals=3, step=0.05,
        )
        data_form.addRow(
            _('settings_dialog.numeric_conversion_threshold'),
            self.numeric_conv_spin,
        )

        self.missing_rate_spin = _FloatField(
            float(self._settings.missing_rate_warning_threshold),
            minimum=0.0, maximum=1.0, decimals=3, step=0.05,
        )
        data_form.addRow(
            _('settings_dialog.missing_rate_warning_threshold'),
            self.missing_rate_spin,
        )

        self.zscore_spin = _FloatField(
            float(self._settings.zscore_threshold),
            minimum=0.1, maximum=10.0, decimals=2, step=0.1,
        )
        data_form.addRow(
            _('settings_dialog.zscore_threshold'),
            self.zscore_spin,
        )

        self.iqr_spin = _FloatField(
            float(self._settings.iqr_coefficient),
            minimum=0.1, maximum=10.0, decimals=2, step=0.1,
        )
        data_form.addRow(
            _('settings_dialog.iqr_coefficient'),
            self.iqr_spin,
        )

        detection_layout.addWidget(data_group)
        detection_layout.addStretch(1)
        tabs.addTab(detection_tab, _('settings_dialog.detection_tab'))

        # ----- Metrics -----
        metrics_tab = QWidget()
        metrics_layout = QVBoxLayout(metrics_tab)
        metrics_layout.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
        )
        metrics_layout.setSpacing(ui.scaled_px(tok.SPACE_MD))

        cls_group = QGroupBox(_('settings_dialog.classification_metrics'))
        cls_layout = QVBoxLayout(cls_group)
        cls_layout.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
        )

        self.cls_metrics_list = QListWidget()
        self.cls_metrics_list.setSelectionMode(QListWidget.MultiSelection)
        self.cls_metrics_list.addItems(DEFAULT_CLASSIFICATION_METRICS)
        cls_current = set(self._settings.default_classification_metrics or [])
        for i in range(self.cls_metrics_list.count()):
            item = self.cls_metrics_list.item(i)
            if item.text() in cls_current:
                item.setSelected(True)
        cls_layout.addWidget(self.cls_metrics_list)
        metrics_layout.addWidget(cls_group)

        reg_group = QGroupBox(_('settings_dialog.regression_metrics'))
        reg_layout = QVBoxLayout(reg_group)
        reg_layout.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
        )

        self.reg_metrics_list = QListWidget()
        self.reg_metrics_list.setSelectionMode(QListWidget.MultiSelection)
        self.reg_metrics_list.addItems(DEFAULT_REGRESSION_METRICS)
        reg_current = set(self._settings.default_regression_metrics or [])
        for i in range(self.reg_metrics_list.count()):
            item = self.reg_metrics_list.item(i)
            if item.text() in reg_current:
                item.setSelected(True)
        reg_layout.addWidget(self.reg_metrics_list)
        metrics_layout.addWidget(reg_group)

        random_seed_group = QGroupBox(_('settings_dialog.random_seed_group'))
        seed_layout = QFormLayout(random_seed_group)
        seed_layout.setSpacing(ui.scaled_px(tok.SPACE_SM))
        seed_layout.setContentsMargins(
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
            ui.scaled_px(tok.SPACE_MD), ui.scaled_px(tok.SPACE_MD),
        )

        self.random_state_spin = _IntegerField(
            int(self._settings.random_state),
            minimum=0, maximum=1000000,
        )
        seed_layout.addRow(
            _('settings_dialog.random_state'),
            self.random_state_spin,
        )
        metrics_layout.addWidget(random_seed_group)
        metrics_layout.addStretch(1)
        tabs.addTab(metrics_tab, _('settings_dialog.metrics_tab'))

        # Keep form rows at their natural height on small logical work areas
        # (for example a 1366x768 display at 150% Windows scaling). Compressing
        # the entire page makes adjacent spin boxes overlap. Scroll each page
        # while leaving Save/Cancel outside the scrolling content.
        pages = [(tabs.widget(i), tabs.tabText(i)) for i in range(tabs.count())]
        while tabs.count():
            tabs.removeTab(0)
        for page, title in pages:
            page.layout().setSizeConstraint(QLayout.SetMinimumSize)
            for form in page.findChildren(QFormLayout):
                form.setSizeConstraint(QLayout.SetMinimumSize)
                form.setVerticalSpacing(ui.scaled_px(tok.SPACE_SM))
            scroll = QScrollArea(tabs)
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QScrollArea.NoFrame)
            scroll.setWidget(page)
            tabs.addTab(scroll, title)
        self.cls_metrics_list.setMinimumHeight(ui.scaled_px(110))
        self.reg_metrics_list.setMinimumHeight(ui.scaled_px(100))
        root.addWidget(tabs)

        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self._on_accept)
        button_box.rejected.connect(self.reject)
        ok_btn = button_box.button(QDialogButtonBox.Ok)
        if ok_btn is not None:
            ok_btn.setText(_('settings_dialog.save'))
            ok_btn.setProperty("role", "primary")
        cancel_btn = button_box.button(QDialogButtonBox.Cancel)
        if cancel_btn is not None:
            cancel_btn.setText(_('settings_dialog.cancel'))
            cancel_btn.setProperty("role", "secondary")
        root.addWidget(button_box)

    # ------------------------------------------------------------------ handlers

    def _on_accept(self):
        new_settings = {
            'theme': self.theme_combo.currentData(),
            'language': self.language_combo.currentData(),
            'preferred_x_unit': self.preferred_x_unit_combo.currentData(),
            'preferred_y_unit': self.preferred_y_unit_combo.currentData(),
            'categorical_unique_count_max': int(self.categorical_count_spin.value()),
            'categorical_unique_ratio_max': float(self.categorical_ratio_spin.value()),
            'isolationforest_contamination': float(self.isolation_forest_spin.value()),
            'numeric_conversion_threshold': float(self.numeric_conv_spin.value()),
            'missing_rate_warning_threshold': float(self.missing_rate_spin.value()),
            'zscore_threshold': float(self.zscore_spin.value()),
            'iqr_coefficient': float(self.iqr_spin.value()),
            'random_state': int(self.random_state_spin.value()),
            'default_classification_metrics': [
                self.cls_metrics_list.item(i).text()
                for i in range(self.cls_metrics_list.count())
                if self.cls_metrics_list.item(i).isSelected()
            ],
            'default_regression_metrics': [
                self.reg_metrics_list.item(i).text()
                for i in range(self.reg_metrics_list.count())
                if self.reg_metrics_list.item(i).isSelected()
            ],
        }

        try:
            for key, value in new_settings.items():
                setattr(self._settings, key, value)
            self._settings.save_settings()
        except Exception as exc:
            QMessageBox.critical(
                self,
                _('settings_dialog.save_error_title'),
                _('settings_dialog.save_error_message').format(error=str(exc)),
            )
            return

        self.accept()
