# app/views/spectral_type_pre_selection_dialog.py
"""
Spectral Type Pre-selection Dialog
Select spectral type before importing data
"""

from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui

from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                           QPushButton, QComboBox, QGroupBox, QTextEdit,
                           QFormLayout, QFrame, QScrollArea, QWidget)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QPixmap
from app.utils.responsive import fit_window_to_screen
from app.utils.translator import translator, _

class SpectralTypePreSelectionDialog(QDialog):
    """Spectral Type Pre-selection Dialog"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.selected_type = None
        self.init_ui()
    
    def init_ui(self):
        """Initialize interface"""
        self.setWindowTitle(_("spectral_type_pre_selection_dialog.title"))
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_PARAM_MD[0]), ui.scaled_px(tok.DIALOG_SIZE_PARAM_MD[1]), min_width=ui.scaled_px(380), min_height=ui.scaled_px(320))
        
        layout = QVBoxLayout(self)
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        
        # Title
        title_label = QLabel(_("spectral_type_pre_selection_dialog.title_label"))
        title_font = ui.get_scaled_font("Segoe UI", 14)
        title_font.setBold(True)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)

        content_layout.addWidget(title_label)

        # Description text
        info_label = QLabel(_("spectral_type_pre_selection_dialog.info_label"))
        info_label.setAlignment(Qt.AlignCenter)
        info_label.setWordWrap(True)

        content_layout.addWidget(info_label)
        
        # Spectral type selection group
        type_group = QGroupBox(_("spectral_type_pre_selection_dialog.type_group"))
        type_layout = QFormLayout()
        
        self.type_combo = QComboBox()
        self.type_combo.addItem(_("spectral_type_pre_selection_dialog.nir_near_infrared_800_2500_nm_item"), "nir")
        self.type_combo.addItem(_("spectral_type_pre_selection_dialog.raman_200_4000_cm-1_item"), "raman")
        self.type_combo.addItem(_("spectral_type_pre_selection_dialog.mirftir_mid_infrared_2500_25000_nm_item"), "mir")
        self.type_combo.addItem(_("spectral_type_pre_selection_dialog.vis_nir_visible_nir_400_1100_nm_item"), "vis_nir")
        self.type_combo.addItem(_("spectral_type_pre_selection_dialog.uv_vis_ultraviolet_visible_200_800_nm_item"), "uv_vis")
        self.type_combo.addItem(_("spectral_type_pre_selection_dialog.auto_detect_from_data_item"), "auto")
        
        self.type_combo.setCurrentIndex(0)  # Default select NIR
        self.type_combo.currentTextChanged.connect(self.on_type_changed)
        
        type_layout.addRow(_("spectral_type_pre_selection_dialog.spectral_type_label"), self.type_combo)
        ui.configure_form_row(type_layout.labelForField(self.type_combo), self.type_combo)
        type_group.setLayout(type_layout)
        
        content_layout.addWidget(type_group)
        
        # Description area
        self.description_text = QTextEdit()
        ui.set_max_height(self.description_text, tok.TEXT_EDIT_MAX_HEIGHT_MD)
        self.description_text.setReadOnly(True)

        content_layout.addWidget(QLabel(_("spectral_type_pre_selection_dialog.description")))
        content_layout.addWidget(self.description_text)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(content_widget)
        layout.addWidget(scroll_area)
        
        # Button area
        button_layout = QHBoxLayout()
        
        self.cancel_btn = QPushButton(_("spectral_type_pre_selection_dialog.cancel_btn"))
        self.cancel_btn.clicked.connect(self.reject)
        
        self.continue_btn = QPushButton(_("spectral_type_pre_selection_dialog.continue_btn"))
        self.continue_btn.clicked.connect(self.accept)
        self.continue_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {tok.COLOR_PRIMARY};
                color: white;
                border: none;
                border-radius: {ui.scaled_px(tok.RADIUS_SM)}px;
                padding: {ui.scaled_px(tok.SPACE_SM)}px {ui.scaled_px(tok.SPACE_LG)}px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {tok.COLOR_PRIMARY_HOVER};
            }}
            QPushButton:pressed {{
                background-color: {tok.COLOR_PRIMARY_PRESSED};
            }}
        """)
        
        button_layout.addStretch()
        button_layout.addWidget(self.cancel_btn)
        button_layout.addWidget(self.continue_btn)
        
        layout.addLayout(button_layout)
        
        # Initialize description
        self.on_type_changed()
    
    def on_type_changed(self):
        """Spectral type change event"""
        current_data = self.type_combo.currentData()
        descriptions = {
            "nir": _("spectral_type_pre_selection_dialog.description_nir"),
            "raman": _("spectral_type_pre_selection_dialog.description_raman"),
            "mir": _("spectral_type_pre_selection_dialog.description_mir"),
            "vis_nir": _("spectral_type_pre_selection_dialog.description_vis_nir"),
            "uv_vis": _("spectral_type_pre_selection_dialog.description_uv_vis"),
            "auto": _("spectral_type_pre_selection_dialog.description_auto")
        }
        
        description = descriptions.get(current_data, "")
        self.description_text.setHtml(description)
    
    def get_selected_type(self):
        """Get selected spectral type"""
        return self.type_combo.currentData()
    
    def get_type_name(self):
        """Get spectral type name"""
        return self.type_combo.currentText().split(" - ")[0]
