# -*- coding: utf-8 -*-
"""
Dialog for PCA Exploratory Analysis Visualization.
"""
from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui
from app.utils.translator import translator, _

import numpy as np
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QGroupBox, QScrollArea, QWidget, QDialogButtonBox, QSizePolicy
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from app.utils.responsive import fit_window_to_screen

class PCAExplorerDialog(QDialog):
    """
    A comprehensive dialog to display PCA exploratory analysis results,
    including scree, cumulative variance, scores, and loadings plots.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(_("pca_explorer_dialog.title"))
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_PCA[0]), ui.scaled_px(tok.DIALOG_SIZE_PCA[1]), min_width=ui.scaled_px(720), min_height=ui.scaled_px(560))

        # --- Data Storage ---
        self.pca = None
        self.loadings = None
        self.explained_variance_ratio = None
        self.cumulative_variance = None
        self.X_scores = None
        self.wavelengths = None
        self.y = None
        self.is_modeling_mode = False

        # --- UI Setup ---
        # Main layout with Scroll Area
        scroll_area = QScrollArea(self)
        scroll_area.setWidgetResizable(True)

        container_widget = QWidget()
        self.main_layout = QVBoxLayout(container_widget)

        scroll_area.setWidget(container_widget)

        dialog_layout = QVBoxLayout(self)
        dialog_layout.addWidget(scroll_area)

        # OK Button
        button_box = QDialogButtonBox(QDialogButtonBox.Ok)
        button_box.accepted.connect(self.accept)
        dialog_layout.addWidget(button_box)

        self.setLayout(dialog_layout)

    def set_data(self, pca_instance, loadings, explained_variance_ratio, cumulative_variance, X_scores, wavelengths, y=None, is_modeling_mode=False):
        """Set the data to be plotted and render the plots."""
        self.pca = pca_instance
        self.loadings = loadings
        self.explained_variance_ratio = explained_variance_ratio
        self.cumulative_variance = cumulative_variance
        self.X_scores = X_scores
        self.wavelengths = wavelengths
        self.y = y
        self.is_modeling_mode = is_modeling_mode
        self.plot()

    def plot(self):
        """Renders all PCA plots."""
        # Clear previous plots if any
        for i in reversed(range(self.main_layout.count())):
            widgetToRemove = self.main_layout.itemAt(i).widget()
            self.main_layout.removeWidget(widgetToRemove)
            widgetToRemove.setParent(None)

        self._plot_scree()
        self._plot_scores()
        self._plot_loadings()

    def _plot_scree(self):
        """Plots the scree and cumulative variance."""
        if self.explained_variance_ratio is None: return

        scree_fig = create_figure(tok.MPL_FIGSIZE_MD, tok.MPL_BASE_DPI)

        scree_fig.set_constrained_layout(True)
        ax1 = scree_fig.add_subplot(111)

        components = np.arange(1, len(self.explained_variance_ratio) + 1)

        ax1.bar(components, self.explained_variance_ratio * 100, alpha=0.7, color='g', label=_('pca_explorer_dialog.individual_explained_variance_label'))
        ax1.set_xlabel(_('pca_explorer_dialog.pc_xlabel'), fontsize=12)
        ax1.set_ylabel(_('pca_explorer_dialog.explained_variance_pct_ylabel'), color='g', fontsize=12)
        ax1.tick_params(axis='y', labelcolor='g')
        ax1.set_xticks(components)
        ax1.set_xlim(0.5, len(components) + 0.5)

        ax2 = ax1.twinx()
        ax2.plot(components, self.cumulative_variance * 100, 'b-', marker='o', label=_('pca_explorer_dialog.cumulative_explained_variance_label'))
        ax2.set_ylabel(_('pca_explorer_dialog.cumulative_variance_pct_ylabel'), color='b', fontsize=12)
        ax2.tick_params(axis='y', labelcolor='b')
        ax2.set_ylim(0, 105)

        scree_fig.suptitle(_('pca_explorer_dialog.scree_title'), fontsize=16)
        lines, labels = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax2.legend(lines + lines2, labels + labels2, loc='center right')

        from app.ui.mpl_layout import layout_figure
        layout_figure(scree_fig, legend_fontsize=9)

        canvas = FigureCanvas(scree_fig)
        canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        canvas.setMinimumHeight(280)
        groupbox = QGroupBox(_("pca_explorer_dialog.groupbox"))
        layout = QVBoxLayout()
        layout.addWidget(canvas)
        groupbox.setLayout(layout)
        self.main_layout.addWidget(groupbox)

    def _plot_scores(self):
        """Plots the scores of PC1 vs PC2."""
        if self.X_scores is None or self.X_scores.shape[1] < 2: return

        scores_fig = create_figure(tok.MPL_FIGSIZE_MD, tok.MPL_BASE_DPI)

        scores_fig.set_constrained_layout(True)
        ax = scores_fig.add_subplot(111)

        title = _("pca_explorer_dialog.scores_title")
        if self.is_modeling_mode:
            title += _("pca_explorer_dialog.training_set_suffix")

        scatter = ax.scatter(self.X_scores[:, 0], self.X_scores[:, 1], c=self.y, cmap='viridis', alpha=0.7, edgecolors='k')

        ax.set_xlabel(_("pca_explorer_dialog.pc1_xlabel").format(var=self.explained_variance_ratio[0]), fontsize=12)
        ax.set_ylabel(_("pca_explorer_dialog.pc2_ylabel").format(var=self.explained_variance_ratio[1]), fontsize=12)
        ax.set_title(title, fontsize=16)
        ax.grid(True, linestyle='--', alpha=0.6)
        ax.axhline(0, color='black', linewidth=0.5)
        ax.axvline(0, color='black', linewidth=0.5)

        if self.y is not None and len(np.unique(self.y)) > 1:
            try:
                legend = ax.legend(*scatter.legend_elements(), title=_("pca_explorer_dialog.classes_legend_title"))
                ax.add_artist(legend)
            except ValueError:
                # Handle cases with non-numeric y for legend
                pass

        from app.ui.mpl_layout import layout_figure
        layout_figure(scores_fig, legend_fontsize=9)
        canvas = FigureCanvas(scores_fig)
        canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        canvas.setMinimumHeight(280)
        groupbox = QGroupBox(_("pca_explorer_dialog.groupbox_2"))
        layout = QVBoxLayout()
        layout.addWidget(canvas)
        groupbox.setLayout(layout)
        self.main_layout.addWidget(groupbox)

    def _plot_loadings(self):
        """Plots the PCA loadings for the first few components."""
        if self.loadings is None or self.wavelengths is None: return

        loadings_fig = create_figure(tok.MPL_FIGSIZE_MD, tok.MPL_BASE_DPI)

        loadings_fig.set_constrained_layout(True)
        ax = loadings_fig.add_subplot(111)

        num_pcs_to_plot = min(self.loadings.shape[0], 3)
        for i in range(num_pcs_to_plot):
            ax.plot(self.wavelengths, self.loadings[i, :], label=f'PC-{i+1}')

        ax.set_title(_('pca_explorer_dialog.loadings_title'), fontsize=16)
        ax.set_xlabel(_('pca_explorer_dialog.loadings_xlabel'), fontsize=12)
        ax.set_ylabel(_('pca_explorer_dialog.loadings_ylabel'), fontsize=12)
        ax.legend()
        ax.grid(True, linestyle='--', alpha=0.6)

        from app.ui.mpl_layout import layout_figure
        layout_figure(loadings_fig, legend_fontsize=9)
        canvas = FigureCanvas(loadings_fig)
        canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        canvas.setMinimumHeight(280)

        groupbox = QGroupBox(_("pca_explorer_dialog.groupbox_3"))
        layout = QVBoxLayout()
        layout.addWidget(canvas)
        groupbox.setLayout(layout)
        self.main_layout.addWidget(groupbox)
