# app/views/spectral_type_selection_dialog.py
"""
Spectral Type Selection Dialog
Advanced spectral type configuration dialog
"""

from app.ui import design_tokens as tok
from app.ui.mpl_theme import create_figure
from app.utils import ui_scaling as ui

from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                           QPushButton, QComboBox, QGroupBox, QTextEdit,
                           QFormLayout, QFrame, QSpinBox, QDoubleSpinBox,
                           QCheckBox, QTabWidget, QWidget, QScrollArea)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QPixmap
import numpy as np
from app.utils.responsive import fit_window_to_screen
from app.utils.translator import translator, _

class SpectralTypeSelectionDialog(QDialog):
    """Advanced Spectral Type Selection Dialog"""
    
    def __init__(self, data, wavelengths, parent=None):
        super().__init__(parent)
        self.data = data
        self.wavelengths = wavelengths
        self.selected_config = None
        self.init_ui()
    
    def init_ui(self):
        """Initialize interface"""
        self.setWindowTitle(_("spectral_type_selection_dialog.title"))
        fit_window_to_screen(self, ui.scaled_px(tok.DIALOG_SIZE_XL[0]), ui.scaled_px(tok.DIALOG_SIZE_XL[1]), min_width=ui.scaled_px(520), min_height=ui.scaled_px(420))
        
        layout = QVBoxLayout(self)
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        
        # Title
        title_label = QLabel(_("spectral_type_selection_dialog.title"))
        title_label.setObjectName("pageTitle")
        title_label.setAlignment(Qt.AlignCenter)

        content_layout.addWidget(title_label)

        # Auto-detection results and explanation
        auto_detection_group = QGroupBox(_("spectral_type_selection_dialog.auto_detection_group"))
        auto_layout = QVBoxLayout()

        # Auto-detection explanation
        explanation_text = QLabel(_("spectral_type_selection_dialog.explanation_text"))
        explanation_text.setObjectName("secondaryText")
        explanation_text.setWordWrap(True)
        auto_layout.addWidget(explanation_text)

        # Auto-detected type display
        self.auto_detected_label = QLabel()
        self.auto_detected_label.setObjectName("statusChip")
        self.auto_detected_label.setProperty("status", "success")
        auto_layout.addWidget(self.auto_detected_label)
        
        auto_detection_group.setLayout(auto_layout)
        content_layout.addWidget(auto_detection_group)
        
        # Manual selection
        selection_group = QGroupBox(_("spectral_type_selection_dialog.selection_group"))
        selection_layout = QVBoxLayout()
        
        # Spectral type combo
        type_layout = QFormLayout()
        self.type_combo = QComboBox()
        self.type_combo.addItem(_("spectral_type_selection_dialog.nir_near_infrared_800_2500_nm_item"), "nir")
        self.type_combo.addItem(_("spectral_type_selection_dialog.raman_200_4000_cm-1_item"), "raman") 
        self.type_combo.addItem(_("spectral_type_selection_dialog.mirftir_mid_infrared_2500_25000_nm_item"), "mir")
        self.type_combo.addItem(_("spectral_type_selection_dialog.vis_nir_visible_near_infrared_400_1100_nm_item"), "vis_nir")
        self.type_combo.addItem(_("spectral_type_selection_dialog.uv_vis_ultraviolet_visible_200_800_nm_item"), "uv_vis")
        self.type_combo.addItem(_("spectral_type_selection_dialog.custom_range_item"), "custom")
        
        self.type_combo.currentTextChanged.connect(self.update_preprocessing_recommendations)
        type_layout.addRow(_("spectral_type_selection_dialog.spectral_type_label"), self.type_combo)
        ui.configure_form_row(type_layout.labelForField(self.type_combo), self.type_combo)
        selection_layout.addLayout(type_layout)
        
        # Expert preprocessing recommendations
        self.recommendations_text = QTextEdit()
        ui.set_max_height(self.recommendations_text, tok.TEXT_EDIT_MAX_HEIGHT_XL)
        self.recommendations_text.setReadOnly(True)

        selection_layout.addWidget(QLabel(_("spectral_type_selection_dialog.expert_preprocessing_recommendations")))
        selection_layout.addWidget(self.recommendations_text)
        
        selection_group.setLayout(selection_layout)
        content_layout.addWidget(selection_group)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(content_widget)
        layout.addWidget(scroll_area)
        
        # Buttons
        button_layout = QHBoxLayout()

        self.ok_button = QPushButton(_("spectral_type_selection_dialog.ok_button"))
        self.ok_button.setProperty("role", "primary")
        self.ok_button.clicked.connect(self.accept)

        self.cancel_button = QPushButton(_("spectral_type_selection_dialog.cancel_button"))
        self.cancel_button.setProperty("role", "quiet")
        self.cancel_button.clicked.connect(self.reject)

        button_layout.addStretch()
        button_layout.addWidget(self.cancel_button)
        button_layout.addWidget(self.ok_button)
        
        layout.addLayout(button_layout)
        
        # Perform auto-detection and set initial recommendations
        self.perform_auto_detection()
        self.update_preprocessing_recommendations()
    
    def create_basic_tab(self):
        """Create basic configuration tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        
        # Spectral type selection
        type_group = QGroupBox(_("spectral_type_selection_dialog.type_group"))
        type_layout = QFormLayout()
        
        self.type_combo = QComboBox()
        self.type_combo.addItem(_("spectral_type_selection_dialog.nir_near_infrared_item"), "nir")
        self.type_combo.addItem(_("spectral_type_selection_dialog.raman_spectroscopy_item"), "raman")
        self.type_combo.addItem(_("spectral_type_selection_dialog.mir_mid_infrared_item"), "mir")
        self.type_combo.addItem(_("spectral_type_selection_dialog.vis_nir_visible_near_infrared_item"), "vis_nir")
        self.type_combo.addItem(_("spectral_type_selection_dialog.uv_vis_ultraviolet_visible_item"), "uv_vis")
        self.type_combo.addItem(_("spectral_type_selection_dialog.custom_item"), "custom")
        
        type_layout.addRow(_("spectral_type_selection_dialog.spectral_type_label"), self.type_combo)
        type_group.setLayout(type_layout)
        
        # Adaptation level
        adapt_group = QGroupBox(_("spectral_type_selection_dialog.adapt_group"))
        adapt_layout = QFormLayout()
        
        self.adapt_combo = QComboBox()
        self.adapt_combo.addItem(_("spectral_type_selection_dialog.basic_standard_parameters_item"), "basic")
        self.adapt_combo.addItem(_("spectral_type_selection_dialog.advanced_optimized_parameters_item"), "advanced")
        self.adapt_combo.addItem(_("spectral_type_selection_dialog.expert_custom_parameters_item"), "expert")
        
        adapt_layout.addRow(_("spectral_type_selection_dialog.adaptation_level_label"), self.adapt_combo)
        adapt_group.setLayout(adapt_layout)
        
        layout.addWidget(type_group)
        layout.addWidget(adapt_group)
        layout.addStretch()
        
        widget.setLayout(layout)
        return widget
    
    def create_advanced_tab(self):
        """Create advanced configuration tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        
        # Preprocessing options
        preproc_group = QGroupBox(_("spectral_type_selection_dialog.preproc_group"))
        preproc_layout = QVBoxLayout()
        
        self.snv_check = QCheckBox(_("spectral_type_selection_dialog.snv_check"))
        self.msc_check = QCheckBox(_("spectral_type_selection_dialog.msc_check"))
        self.baseline_check = QCheckBox(_("spectral_type_selection_dialog.baseline_check"))
        self.smooth_check = QCheckBox(_("spectral_type_selection_dialog.smooth_check"))
        self.derivative_check = QCheckBox(_("spectral_type_selection_dialog.derivative_check"))
        
        preproc_layout.addWidget(self.snv_check)
        preproc_layout.addWidget(self.msc_check)
        preproc_layout.addWidget(self.baseline_check)
        preproc_layout.addWidget(self.smooth_check)
        preproc_layout.addWidget(self.derivative_check)
        
        preproc_group.setLayout(preproc_layout)
        
        # Parameter settings
        param_group = QGroupBox(_("spectral_type_selection_dialog.param_group"))
        param_layout = QFormLayout()
        
        self.window_spin = QSpinBox()
        self.window_spin.setRange(3, 51)
        self.window_spin.setValue(15)
        self.window_spin.setSingleStep(2)
        
        self.poly_spin = QSpinBox()
        self.poly_spin.setRange(1, 5)
        self.poly_spin.setValue(2)
        
        param_layout.addRow(_("spectral_type_selection_dialog.smoothing_window_label"), self.window_spin)
        param_layout.addRow(_("spectral_type_selection_dialog.polynomial_order_label"), self.poly_spin)
        
        param_group.setLayout(param_layout)
        
        layout.addWidget(preproc_group)
        layout.addWidget(param_group)
        layout.addStretch()
        
        widget.setLayout(layout)
        return widget
    
    def get_selected_config(self):
        """Get the selected configuration"""
        if self.selected_config is None:
            self.selected_config = self.build_config()
        return self.selected_config
    
    def build_config(self):
        """Build configuration from UI selections"""
        spectral_type = self.type_combo.currentData()
        spectral_name = self.type_combo.currentText()
        
        config = {
            "spectral_type": spectral_type,
            "spectral_name": spectral_name,
            "wavelength_range": [np.min(self.wavelengths), np.max(self.wavelengths)] if self.wavelengths is not None else None,
            "auto_detected": hasattr(self, 'auto_detected_label') and 'Auto-detected' in self.auto_detected_label.text(),
            "preprocessing_config": {
                "scatter_correction": {
                    "enabled": True,
                    "method": "snv"
                },
                "baseline_correction": {
                    "enabled": True,
                    "method": "als"
                },
                "smoothing": {
                    "enabled": True,
                    "method": "savgol",
                    "window_length": 11,
                    "polyorder": 2
                },
                "derivative": {
                    "enabled": False,
                    "order": 1
                }
            },
            "parameter_adaptations": {}
        }
        
        return config
    
    def accept(self):
        """Handle accept button"""
        self.selected_config = self.build_config()
        super().accept()
    
    def perform_auto_detection(self):
        """Perform automatic spectral type detection based on wavelength analysis"""
        if self.wavelengths is None or len(self.wavelengths) == 0:
            self.auto_detected_label.setText(_("spectral_type_selection_dialog.auto_detected_label_auto_detected_label_text"))
            return
        
        wl_min, wl_max = np.min(self.wavelengths), np.max(self.wavelengths)
        wl_range = wl_max - wl_min
        
        # Expert spectral type detection logic
        detected_type = "unknown"
        confidence = "Low"
        reasons = []
        
        # Raman Detection (200-4000 cm⁻¹ or similar ranges)
        # Raman can be in wavenumbers (200-4000 cm⁻¹) or wavelength shifts
        if (200 <= wl_min <= 400 and 2000 <= wl_max <= 4000) or (wl_min < 500 and wl_max > 2000):
            detected_type = "raman"
            confidence = "High"
            reasons.append(f"Range {wl_min:.0f}-{wl_max:.0f} matches Raman spectroscopy (wavenumber or shift range)")
            
        # NIR Detection (800-2500 nm) - but not if it looks like Raman
        elif 700 <= wl_min <= 1000 and 2000 <= wl_max <= 3000 and not (wl_min < 500):
            detected_type = "nir"
            confidence = "High"
            reasons.append(f"Wavelength range {wl_min:.0f}-{wl_max:.0f} nm matches NIR spectroscopy")
            
        # MIR/FTIR Detection (2500-25000 nm or 4000-400 cm⁻¹)
        elif wl_min >= 2000 and wl_max >= 10000:
            detected_type = "mir"
            confidence = "High"
            reasons.append(f"Long wavelength range {wl_min:.0f}-{wl_max:.0f} nm indicates MIR/FTIR")
            
        # VIS-NIR Detection (400-1100 nm)
        elif 300 <= wl_min <= 500 and 900 <= wl_max <= 1200:
            detected_type = "vis_nir"
            confidence = "Medium"
            reasons.append(f"Range {wl_min:.0f}-{wl_max:.0f} nm spans visible to near-infrared")
            
        # UV-VIS Detection (200-800 nm)
        elif wl_min <= 300 and 600 <= wl_max <= 900:
            detected_type = "uv_vis"
            confidence = "Medium"
            reasons.append(f"Range {wl_min:.0f}-{wl_max:.0f} nm covers UV-visible spectrum")
            
        # Ambiguous cases
        else:
            confidence = "Low"
            reasons.append(f"Wavelength range {wl_min:.0f}-{wl_max:.0f} nm does not clearly match standard spectral types")
            reasons.append("Manual selection recommended for optimal preprocessing")
        
        # Update display
        if detected_type != "unknown":
            # Set the combo box to the detected type
            for i in range(self.type_combo.count()):
                if self.type_combo.itemData(i) == detected_type:
                    self.type_combo.setCurrentIndex(i)
                    break

            self.auto_detected_label.setText(
                _("spectral_type_selection_dialog.auto_detected_success").format(
                    spectral_type=self.type_combo.currentText(),
                    confidence=confidence,
                    reasons='; '.join(reasons)
                )
            )
        else:
            self.auto_detected_label.setText(
                _("spectral_type_selection_dialog.auto_detected_uncertain").format(
                    confidence=confidence,
                    reasons='; '.join(reasons)
                )
            )

    def update_preprocessing_recommendations(self):
        """Update expert preprocessing recommendations based on selected spectral type"""
        current_type = self.type_combo.currentData()
        
        # Expert recommendations from chemometrics perspective - 基于系统实际功能
        recommendations = {
            "nir": _("spectral_type_selection_dialog.recommendations_nir"),
            "raman": _("spectral_type_selection_dialog.recommendations_raman"),
            "mir": _("spectral_type_selection_dialog.recommendations_mir"),
            "vis_nir": _("spectral_type_selection_dialog.recommendations_vis_nir"),
            "uv_vis": _("spectral_type_selection_dialog.recommendations_uv_vis"),
            "custom": _("spectral_type_selection_dialog.recommendations_custom")
        }

        recommendation_text = recommendations.get(current_type, recommendations["custom"])
        self.recommendations_text.setHtml(recommendation_text)
