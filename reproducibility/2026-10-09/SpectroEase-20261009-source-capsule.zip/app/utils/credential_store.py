# app/utils/credential_store.py
"""Small helper to protect sensitive strings using the OS credential store.

On Windows this uses DPAPI (Data Protection API) via ctypes, which encrypts
data to the current user account. If OS encryption is unavailable, saving a
new credential fails instead of falling back to plain-text storage.
"""

import base64
import logging
import sys

logger = logging.getLogger(__name__)


def _is_encrypted_value(value: str) -> bool:
    """Heuristic: encrypted values are base64-encoded bytes prefixed with 'dpapi:'."""
    return isinstance(value, str) and value.startswith("dpapi:")


def protect(plaintext: str) -> str:
    """Return an opaque string that can later be passed to :func:`unprotect`.

    On Windows the result is DPAPI-encrypted. If encryption is unavailable,
    raise an error rather than writing the credential in plain text.
    """
    if not plaintext:
        return plaintext

    if sys.platform == "win32":
        try:
            return "dpapi:" + base64.b64encode(_dpapi_protect(plaintext.encode("utf-8"))).decode("ascii")
        except Exception as e:
            logger.error("Failed to encrypt credential with DPAPI: %s", e)
            raise RuntimeError("Could not encrypt the API key with Windows DPAPI; the key was not saved.") from e
    raise RuntimeError("Secure API-key storage is unavailable on this platform; the key was not saved.")


def unprotect(ciphertext: str) -> str:
    """Reverse :func:`protect`.

    Handles legacy plain-text values transparently.
    """
    if not ciphertext:
        return ciphertext

    if _is_encrypted_value(ciphertext):
        if sys.platform != "win32":
            logger.warning("Cannot decrypt DPAPI credential on non-Windows platform.")
            return ""
        try:
            blob = base64.b64decode(ciphertext[len("dpapi:"):])
            return _dpapi_unprotect(blob).decode("utf-8")
        except Exception as e:
            logger.error("Failed to decrypt credential: %s", e)
            return ""

    # Legacy plain-text value
    return ciphertext


def _dpapi_protect(data: bytes) -> bytes:
    """Encrypt bytes with Windows DPAPI for the current user."""
    import ctypes
    from ctypes import wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [
            ("cbData", wintypes.DWORD),
            ("pbData", wintypes.LPBYTE),
        ]

    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    CryptProtectData = crypt32.CryptProtectData
    CryptProtectData.argtypes = [
        ctypes.POINTER(DATA_BLOB),
        wintypes.LPCWSTR,
        ctypes.POINTER(DATA_BLOB),
        wintypes.LPVOID,
        wintypes.LPVOID,
        wintypes.DWORD,
        ctypes.POINTER(DATA_BLOB),
    ]
    CryptProtectData.restype = wintypes.BOOL

    blob_in = DATA_BLOB()
    blob_in.cbData = len(data)
    blob_in.pbData = ctypes.cast(ctypes.create_string_buffer(data), wintypes.LPBYTE)

    blob_out = DATA_BLOB()

    if not CryptProtectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
        raise ctypes.WinError(ctypes.get_last_error())

    encrypted = bytes(ctypes.string_at(blob_out.pbData, blob_out.cbData))
    ctypes.windll.kernel32.LocalFree(blob_out.pbData)
    return encrypted


def _dpapi_unprotect(data: bytes) -> bytes:
    """Decrypt bytes encrypted with Windows DPAPI for the current user."""
    import ctypes
    from ctypes import wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [
            ("cbData", wintypes.DWORD),
            ("pbData", wintypes.LPBYTE),
        ]

    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    CryptUnprotectData = crypt32.CryptUnprotectData
    CryptUnprotectData.argtypes = [
        ctypes.POINTER(DATA_BLOB),
        wintypes.LPWSTR,
        ctypes.POINTER(DATA_BLOB),
        wintypes.LPVOID,
        wintypes.LPVOID,
        wintypes.DWORD,
        ctypes.POINTER(DATA_BLOB),
    ]
    CryptUnprotectData.restype = wintypes.BOOL

    blob_in = DATA_BLOB()
    blob_in.cbData = len(data)
    blob_in.pbData = ctypes.cast(ctypes.create_string_buffer(data), wintypes.LPBYTE)

    blob_out = DATA_BLOB()

    if not CryptUnprotectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
        raise ctypes.WinError(ctypes.get_last_error())

    decrypted = bytes(ctypes.string_at(blob_out.pbData, blob_out.cbData))
    ctypes.windll.kernel32.LocalFree(blob_out.pbData)
    return decrypted
