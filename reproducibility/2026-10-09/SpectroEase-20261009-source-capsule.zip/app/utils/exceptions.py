# utils/exceptions.py

class DataServiceError(Exception):
    """Exception raised for errors in the data service."""
    def __init__(self, message="An error occurred in the Data Service."):
        self.message = message
        super().__init__(self.message)


class DataQualityError(DataServiceError):
    """Exception raised when data quality issues require user interaction.

    Carries the quality analysis and the original data so a controller/view
    can present an interactive dialog and apply the chosen handling.
    """
    def __init__(self, message="Data quality issues detected.", analysis=None, data=None):
        super().__init__(message)
        self.analysis = analysis or {}
        self.data = data


class PreprocessingError(Exception):
    """Exception raised for errors during preprocessing."""
    def __init__(self, message="An error occurred during preprocessing."):
        self.message = message
        super().__init__(self.message)


class FeatureSelectionError(Exception):
    """Exception raised for errors during feature selection."""
    def __init__(self, message="An error occurred during feature selection."):
        self.message = message
        super().__init__(self.message)


class FeatureExtractionError(Exception):
    """Exception raised for errors during feature extraction."""
    def __init__(self, message="An error occurred during feature extraction."):
        self.message = message
        super().__init__(self.message)


class ModelingError(Exception):
    """Exception raised for errors during modeling."""
    def __init__(self, message="An error occurred during modeling."):
        self.message = message
        super().__init__(self.message)


class HyperparameterOptimizationError(Exception):
    """Exception raised for errors during hyperparameter optimization."""
    def __init__(self, message="An error occurred during hyperparameter optimization."):
        self.message = message
        super().__init__(self.message)


class EvaluationError(Exception):
    """Exception raised for errors during evaluation."""
    def __init__(self, message="An error occurred during evaluation."):
        self.message = message
        super().__init__(self.message)


class LLMServiceError(Exception):
    """Exception raised for errors in the LLM service."""
    def __init__(self, message="An error occurred while calling the LLM service."):
        self.message = message
        super().__init__(self.message)


def user_facing_error(exc, fallback="Operation failed. See log for details."):
    """Map an exception to a safe, user-facing message.

    Never expose file paths, exception class names, or tracebacks to end users;
    log the full detail at the except site instead. ``ValueError`` and
    ``SyntaxError`` messages pass through on purpose: this project raises
    ValueError with carefully written user-facing text, and SyntaxError
    describes the user's own converted code.
    """
    if isinstance(exc, (SyntaxError, ValueError)):
        return str(exc)
    if isinstance(exc, LLMServiceError):
        return exc.message
    if isinstance(exc, PermissionError):
        return "Permission denied. Check file/folder write permissions."
    if isinstance(exc, FileNotFoundError):
        return "File not found. Check the file path."
    if isinstance(exc, IsADirectoryError):
        return "Expected a file but found a directory."
    if isinstance(exc, TimeoutError):
        return "The operation timed out. Please try again."
    if isinstance(exc, (OSError, IOError)):
        return "File or network I/O error. See log for details."
    return fallback
