# app/utils/translator.py

import json
import os
import logging

from PyQt5.QtCore import QObject, pyqtSignal

logger = logging.getLogger("SpectroEase1.1")


class Translator(QObject):
    """Simple JSON-based translator with optional language-changed signal."""

    language_changed = pyqtSignal(str)

    def __init__(self, language='en', parent=None):
        super().__init__(parent)
        self.language = language
        self.translations = {}
        self.load_translations()

    def load_translations(self):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        translation_file = os.path.join(base_dir, '..', '..', 'translations', f'{self.language}.json')
        translation_file = os.path.normpath(translation_file)
        if os.path.exists(translation_file):
            try:
                with open(translation_file, 'r', encoding='utf-8') as f:
                    self.translations = json.load(f)
            except json.JSONDecodeError:
                self.translations = {}
                logger.error("Error decoding JSON in translation file for language '%s'.", self.language)
        else:
            self.translations = {}
            logger.warning("Translation file for language '%s' not found at %s.", self.language, translation_file)

    def set_language(self, language):
        if language == self.language:
            return
        self.language = language
        self.load_translations()
        self.language_changed.emit(language)

    def translate(self, key):
        return self.translations.get(key, key)

    def lget(self, key, default=None):
        """Lookup with explicit default; falls back to ``default`` or key."""
        if default is None:
            default = key
        return self.translations.get(key, default)

    def __call__(self, key):
        return self.translate(key)


# Global translator instance and convenience alias.
translator = Translator(language='en')
_ = translator.translate
