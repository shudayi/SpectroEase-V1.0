#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Label Processing Utilities

Single source of truth for classification vs regression detection and label
encoding/decoding. All log output uses plain ASCII to avoid encoding crashes on
Windows consoles configured for GBK/cp1252.
"""

import numpy as np
import pandas as pd
from typing import Tuple, Any, Optional, Dict, Union, List
import logging

logger = logging.getLogger(__name__)

# String literals that represent missing / infinite numeric values.
_MISSING_LITERALS = {"", "nan", "inf", "-inf", "+inf", "none", "null", "na"}


def safe_isna(value: Any) -> bool:
    """
    Safe check for missing/null/invalid values that works with any data type.

    Treats literal strings such as "NaN", "inf", and "-inf" as missing values,
    not as valid class names or regression targets.
    """
    if value is None:
        return True

    # Handle string literals that denote missing / infinite values.
    if isinstance(value, str):
        if value.strip().lower() in _MISSING_LITERALS:
            return True

    # Handle numeric NaN/inf.
    try:
        if isinstance(value, (int, float, np.integer, np.floating)):
            if np.isnan(value) or np.isinf(value):
                return True
    except (ValueError, TypeError, OverflowError):
        pass

    try:
        if pd.isna(value):
            return True
    except (ValueError, TypeError):
        pass

    return False


def _to_numpy_array(labels: Union[np.ndarray, pd.Series, list]) -> np.ndarray:
    """Convert labels to a numpy array with a stable dtype."""
    if isinstance(labels, pd.Series):
        return labels.values
    if isinstance(labels, list):
        return np.array(labels, dtype=object)
    if isinstance(labels, np.ndarray):
        return labels
    return np.array(labels, dtype=object)


def _numeric_unique_count(values: List[float]) -> int:
    """
    Return a tolerance-aware unique count for numeric values.

    Values that differ only by floating-point noise are counted as one unique
    value. NaN and inf are ignored.
    """
    clean = []
    for v in values:
        if safe_isna(v):
            continue
        try:
            fv = float(v)
            if np.isfinite(fv):
                clean.append(fv)
        except (ValueError, TypeError):
            continue
    if not clean:
        return 0
    rounded = np.round(np.array(clean, dtype=float), decimals=10)
    return len(np.unique(rounded))


class EnhancedLabelProcessor:
    """Single source of truth for label processing and task-type detection."""

    def __init__(self, settings=None):
        self.label_encoder = None
        self.label_mapping = None
        self.is_string_labels = False
        self.task_type = None
        self.original_labels = None
        self.auto_detected_type = None
        # Optional Settings instance; if provided, task-type detection thresholds
        # are read from it so users can adjust them in the Settings dialog.
        self.settings = settings

    def _reset_state(self):
        """Reset all mutable state so stale mappings cannot leak across datasets."""
        self.label_encoder = None
        self.label_mapping = None
        self.is_string_labels = False
        self.task_type = None
        self.original_labels = None
        self.auto_detected_type = None

    def detect_task_type(self, labels: Union[np.ndarray, pd.Series, list]) -> str:
        """
        Detect whether labels describe a classification or regression task.

        Rules (applied in order):
          1. String / non-numeric labels -> classification.
          2. Numeric labels with <= 20 unique values -> classification.
          3. Numeric labels where unique count / sample count < 0.1 -> classification.
          4. Numeric labels that are all integers, with <= 50 unique values,
             and unique count / sample count < 0.5 -> classification.
          5. Otherwise -> regression.

        Returns:
            str: 'classification' or 'regression'.
        """
        self.auto_detected_type = None

        if labels is None or len(labels) == 0:
            logger.warning("Empty labels provided; defaulting to classification")
            self.auto_detected_type = 'classification'
            return 'classification'

        labels_array = _to_numpy_array(labels)

        has_string = False
        numeric_values = []

        for label in labels_array:
            if safe_isna(label):
                continue

            str_label = str(label).strip()

            # Any value containing alphabetic characters is treated as a string label.
            if any(c.isalpha() for c in str_label):
                has_string = True
                break

            try:
                numeric_values.append(float(label))
            except (ValueError, TypeError):
                has_string = True
                break

        if has_string:
            logger.info("CLASSIFICATION detected: string labels found")
            self.auto_detected_type = 'classification'
            return 'classification'

        if not numeric_values:
            logger.info("CLASSIFICATION detected: no valid numeric values")
            self.auto_detected_type = 'classification'
            return 'classification'

        total_count = len(numeric_values)
        unique_count = _numeric_unique_count(numeric_values)
        unique_ratio = unique_count / total_count if total_count > 0 else 0.0

        # Threshold pulled from Settings if injected, otherwise defaults.
        unique_count_max = 20
        unique_ratio_max = 0.1
        integer_max = 50
        integer_ratio_max = 0.5
        if self.settings is not None:
            try:
                unique_count_max = int(
                    getattr(self.settings, 'categorical_unique_count_max', unique_count_max)
                )
                unique_ratio_max = float(
                    getattr(self.settings, 'categorical_unique_ratio_max', unique_ratio_max)
                )
            except (TypeError, ValueError):
                pass

        if unique_count <= unique_count_max:
            logger.info(
                "CLASSIFICATION detected: few unique values (%d/%d)",
                unique_count, total_count,
            )
            self.auto_detected_type = 'classification'
            return 'classification'

        if unique_ratio < unique_ratio_max:
            logger.info(
                "CLASSIFICATION detected: low unique ratio (%.3f)",
                unique_ratio,
            )
            self.auto_detected_type = 'classification'
            return 'classification'

        all_integers = all(float(v).is_integer() for v in numeric_values)
        if all_integers and unique_count <= integer_max and unique_ratio < integer_ratio_max:
            logger.info(
                "CLASSIFICATION detected: integer labels with %d classes",
                unique_count,
            )
            self.auto_detected_type = 'classification'
            return 'classification'

        logger.info("REGRESSION detected: continuous values")
        logger.info("  Total samples: %d", total_count)
        logger.info("  Unique values: %d", unique_count)
        logger.info(
            "  Value range: [%.3f, %.3f]",
            min(numeric_values), max(numeric_values),
        )
        self.auto_detected_type = 'regression'
        return 'regression'

    def process_labels_smart(
        self,
        labels: Union[pd.Series, np.ndarray, list],
        force_task_type: Optional[str] = None,
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """
        Process labels into a model-ready format.

        Args:
            labels: Raw label data.
            force_task_type: Optional override ('classification' or 'regression').

        Returns:
            Tuple of (processed_labels, metadata).
        """
        # Reset mutable state at the start of every public call.
        self._reset_state()

        try:
            labels_array = _to_numpy_array(labels)

            # Strip whitespace from string labels and normalize missing literals.
            cleaned_labels = []
            for label in labels_array:
                if isinstance(label, str):
                    cleaned_labels.append(label.strip())
                else:
                    cleaned_labels.append(label)
            labels_array = np.array(cleaned_labels, dtype=object)

            # Store originals for reference and inverse mapping.
            self.original_labels = labels_array.copy()

            # Determine task type.
            self.auto_detected_type = self.detect_task_type(labels_array)
            if force_task_type in ('classification', 'regression'):
                self.task_type = force_task_type
            else:
                self.task_type = self.auto_detected_type

            logger.info("Task type: %s (auto-detected: %s)", self.task_type, self.auto_detected_type)

            if self.task_type == 'classification':
                return self._process_classification(labels_array)
            else:
                return self._process_regression(labels_array)

        except Exception as exc:
            logger.error("Label processing failed: %s", exc)
            # Consistent emergency fallback: build a minimal mapping from strings.
            fallback_labels = np.array(
                [str(label).strip() if label is not None else "None" for label in labels]
            )
            self.task_type = 'classification'
            self.original_labels = fallback_labels.copy()
            unique_labels = sorted(set(fallback_labels), key=str)
            self.label_mapping = {
                'label_to_index': {str(label): idx for idx, label in enumerate(unique_labels)},
                'index_to_label': {idx: str(label) for idx, label in enumerate(unique_labels)},
                'unique_labels': unique_labels,
            }
            processed = np.array(
                [self.label_mapping['label_to_index'][str(label)] for label in fallback_labels]
            )
            logger.warning("Fallback label mapping used with %d classes", len(unique_labels))
            return processed, self.label_mapping

    def _process_classification(
        self, labels_array: np.ndarray
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Process classification labels and build a consistent mapping."""
        # Exclude missing values when building the class list.
        valid_mask = np.array([not safe_isna(label) for label in labels_array])
        valid_labels = labels_array[valid_mask] if valid_mask.any() else labels_array

        # Canonical form for keys is string; original representative is the first
        # occurrence of each string key.
        seen: List[str] = []
        representative: Dict[str, str] = {}
        for label in valid_labels:
            key = str(label).strip()
            if key not in seen:
                seen.append(key)
                representative[key] = key

        unique_labels = seen

        label_to_index = {label: idx for idx, label in enumerate(unique_labels)}
        index_to_label = {idx: label for idx, label in enumerate(unique_labels)}

        processed_labels = []
        for label in labels_array:
            if safe_isna(label):
                processed_labels.append(-1)
            else:
                key = str(label).strip()
                processed_labels.append(label_to_index.get(key, -1))

        processed_labels = np.array(processed_labels, dtype=int)

        self.label_mapping = {
            'label_to_index': label_to_index,
            'index_to_label': index_to_label,
            'unique_labels': unique_labels,
            'classes': unique_labels,
        }

        metadata: Dict[str, Any] = {
            'task_type': 'classification',
            'num_classes': len(unique_labels),
            'class_names': unique_labels,
            'auto_detected': self.auto_detected_type,
            'label_mapping': self.label_mapping,
        }

        logger.info("Classification labels processed: %d classes", len(unique_labels))
        if len(unique_labels) <= 20:
            logger.info("  Classes: %s", unique_labels)

        return processed_labels, metadata

    def _process_regression(
        self, labels_array: np.ndarray
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Process regression labels into numeric targets."""
        processed_labels = []
        conversion_failures = 0

        for label in labels_array:
            if safe_isna(label):
                processed_labels.append(np.nan)
                continue

            str_label = str(label).strip()

            # Reject values that contain letters; they are not valid regression targets.
            if any(c.isalpha() for c in str_label):
                conversion_failures += 1
                processed_labels.append(np.nan)
                continue

            try:
                processed_labels.append(float(label))
            except (ValueError, TypeError):
                conversion_failures += 1
                processed_labels.append(np.nan)

        processed_labels = np.array(processed_labels, dtype=float)
        valid_mask = ~np.isnan(processed_labels)
        valid_values = processed_labels[valid_mask]

        if conversion_failures > len(labels_array) * 0.1:
            logger.warning(
                "High regression conversion failure rate (%d/%d); consider classification",
                conversion_failures, len(labels_array),
            )

        metadata: Dict[str, Any] = {
            'task_type': 'regression',
            'min_value': float(np.min(valid_values)) if len(valid_values) else np.nan,
            'max_value': float(np.max(valid_values)) if len(valid_values) else np.nan,
            'mean_value': float(np.mean(valid_values)) if len(valid_values) else np.nan,
            'std_value': float(np.std(valid_values)) if len(valid_values) else np.nan,
            'valid_samples': int(len(valid_values)),
            'missing_samples': int(len(processed_labels) - len(valid_values)),
            'auto_detected': self.auto_detected_type,
        }

        logger.info("Regression labels processed: %d samples", len(processed_labels))
        if len(valid_values):
            logger.info("  Range: [%.3f, %.3f]", metadata['min_value'], metadata['max_value'])
            logger.info(
                "  Mean: %.3f +/- %.3f",
                metadata['mean_value'], metadata['std_value'],
            )
        logger.info(
            "  Valid samples: %d/%d",
            metadata['valid_samples'], len(processed_labels),
        )

        return processed_labels, metadata

    def convert_predictions_back(self, predictions: np.ndarray) -> np.ndarray:
        """
        Convert model predictions back to the original label format.

        Note: -1 is treated as a missing-value sentinel for classification.
        """
        if self.task_type == 'classification' and self.label_mapping is not None:
            index_to_label = self.label_mapping['index_to_label']
            original_predictions = []
            for pred in predictions:
                if pred == -1 or safe_isna(pred):
                    original_predictions.append(None)
                else:
                    pred_int = int(round(float(pred))) if not safe_isna(pred) else -1
                    original_predictions.append(
                        index_to_label.get(pred_int, f"Unknown_Class_{pred_int}")
                    )
            return np.array(original_predictions, dtype=object)
        else:
            return predictions

    def get_task_info(self) -> Dict[str, Any]:
        """Return comprehensive task information."""
        return {
            'task_type': self.task_type,
            'auto_detected_type': self.auto_detected_type,
            'label_mapping': self.label_mapping,
            'original_labels_sample': (
                list(self.original_labels[:10]) if self.original_labels is not None else None
            ),
            'num_classes': (
                len(self.label_mapping['unique_labels']) if self.label_mapping else None
            ),
        }


# Backward compatibility wrapper.
class LabelProcessor(EnhancedLabelProcessor):
    """Backward-compatible alias for EnhancedLabelProcessor."""

    def process_labels(self, labels, task_type=None):
        """Legacy method for backward compatibility."""
        return self.process_labels_smart(labels, task_type)

    def detect_task_type(self, labels):
        """Legacy method."""
        return super().detect_task_type(labels)
