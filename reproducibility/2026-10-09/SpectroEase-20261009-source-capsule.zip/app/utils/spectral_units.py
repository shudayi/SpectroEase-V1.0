# app/utils/spectral_units.py
"""Spectral unit conversion utilities.

Supports conversion among the six most common spectral units used in
spectroscopy:

==========  ============  ===================  ===============
Unit        Symbol        Family                Reference
==========  ============  ===================  ===============
nm          nm            wavelength            1 nm
cm-1        wavenumber    frequency / c        1 cm-1 = 1e7 / lambda_nm
um          micrometer    wavelength            1 um = 1e3 nm
THz         frequency     frequency             1 THz = 1e12 Hz
eV          energy        energy                1 eV = h * 1e12 Hz
Å           Angstrom      wavelength            1 Å = 0.1 nm
==========  ============  ===================  ===============

All conversions go through nm as the canonical intermediate. Precision is
driven by SI constants; the resulting values are always ``float64``.
"""

from __future__ import annotations

from typing import Iterable, Union

import numpy as np


# Canonical unit aliases (also used in Settings.preferred_x_unit).
NM = 'nm'
CM_1 = 'cm-1'
UM = 'um'
THZ = 'THz'
EV = 'eV'
ANGSTROM = 'Å'

ALL_UNITS = (NM, CM_1, UM, THZ, EV, ANGSTROM)

# SI constants
_SPEED_OF_LIGHT_M_PER_S = 299_792_458.0
_PLANCK_J_S = 6.62607015e-34
_ELEC_CHARGE_J = 1.602176634e-19

# 1 cm-1 corresponds to 1e7 / lambda_nm (because lambda(cm) = 1e7 / nu(cm-1))
_CM_1_TO_NM = 1e7
# 1 um = 1e3 nm
_UM_TO_NM = 1e3
# 1 Å = 0.1 nm
_ANGSTROM_TO_NM = 0.1
# 1 THz = 1e12 Hz; nu (Hz) = c / lambda (m), so lambda (m) = c / nu, lambda (nm) = c / nu * 1e9
# => lambda_nm = c / (nu_THz * 1e12) * 1e9 = c / 1000 / nu_THz
_THZ_TO_NM = _SPEED_OF_LIGHT_M_PER_S / 1e3
# 1 eV = h * freq; freq = E / h; lambda_nm = c / (E / h) * 1e9 = c * h / E * 1e9
# For E in eV: lambda_nm = c * h / (E * e) * 1e9
_EV_TO_NM = _SPEED_OF_LIGHT_M_PER_S * _PLANCK_J_S / _ELEC_CHARGE_J * 1e9


def _to_canonical_factor(from_unit: str) -> float:
    """Return the multiplicative factor to convert *from_unit* values to nm."""
    unit = from_unit.strip()
    if unit == NM:
        return 1.0
    if unit == CM_1:
        # Convert wavenumber (cm-1) to wavelength (nm): lambda_nm = 1e7 / nu_cm-1
        # Caller handles inversion; we return a sentinel via lambda function.
        raise ValueError("Use to_nm directly for cm-1 (reciprocal conversion).")
    if unit == UM:
        return _UM_TO_NM
    if unit == THZ:
        return _THZ_TO_NM
    if unit == EV:
        return _EV_TO_NM
    if unit == ANGSTROM:
        return _ANGSTROM_TO_NM
    raise ValueError(f"Unknown spectral unit: {from_unit!r}")


def to_nm(value: Union[float, np.ndarray], from_unit: str) -> Union[float, np.ndarray]:
    """Convert ``value`` from ``from_unit`` to nanometers.

    cm-1 is a reciprocal unit; numpy / Python both support division.
    """
    unit = from_unit.strip()
    if unit == NM:
        return np.asarray(value, dtype=np.float64)
    if unit == CM_1:
        # Guard against zero wavenumber; return inf for symmetry.
        with np.errstate(divide='ignore', invalid='ignore'):
            return np.where(
                np.asarray(value) == 0,
                np.inf,
                _CM_1_TO_NM / np.asarray(value, dtype=np.float64),
            )
    if unit == UM:
        return np.asarray(value, dtype=np.float64) * _UM_TO_NM
    if unit == THZ:
        return _THZ_TO_NM / np.asarray(value, dtype=np.float64)
    if unit == EV:
        return _EV_TO_NM / np.asarray(value, dtype=np.float64)
    if unit == ANGSTROM:
        return np.asarray(value, dtype=np.float64) * _ANGSTROM_TO_NM
    raise ValueError(f"Unknown spectral unit: {from_unit!r}")


def from_nm(value_nm: Union[float, np.ndarray], to_unit: str) -> Union[float, np.ndarray]:
    """Convert ``value_nm`` (nm) to ``to_unit``."""
    unit = to_unit.strip()
    if unit == NM:
        return np.asarray(value_nm, dtype=np.float64)
    if unit == CM_1:
        with np.errstate(divide='ignore', invalid='ignore'):
            return np.where(
                np.asarray(value_nm) == 0,
                np.inf,
                _CM_1_TO_NM / np.asarray(value_nm, dtype=np.float64),
            )
    if unit == UM:
        return np.asarray(value_nm, dtype=np.float64) / _UM_TO_NM
    if unit == THZ:
        with np.errstate(divide='ignore', invalid='ignore'):
            return _THZ_TO_NM / np.asarray(value_nm, dtype=np.float64)
    if unit == EV:
        with np.errstate(divide='ignore', invalid='ignore'):
            return _EV_TO_NM / np.asarray(value_nm, dtype=np.float64)
    if unit == ANGSTROM:
        return np.asarray(value_nm, dtype=np.float64) / _ANGSTROM_TO_NM
    raise ValueError(f"Unknown spectral unit: {to_unit!r}")


def convert_array(
    values: Iterable[float],
    from_unit: str,
    to_unit: str,
) -> np.ndarray:
    """Convert an array of wavelengths/wavenumbers between two units."""
    src = np.asarray(list(values), dtype=np.float64)
    if from_unit.strip() == to_unit.strip():
        return src
    return from_nm(to_nm(src, from_unit), to_unit)


def axis_label(unit: str) -> str:
    """Return a human-readable x-axis label for the given unit."""
    unit = unit.strip()
    if unit == NM:
        return 'Wavelength (nm)'
    if unit == CM_1:
        return 'Wavenumber (cm⁻¹)'
    if unit == UM:
        return 'Wavelength (µm)'
    if unit == THZ:
        return 'Frequency (THz)'
    if unit == EV:
        return 'Energy (eV)'
    if unit == ANGSTROM:
        return 'Wavelength (Å)'
    return f'Wavelength ({unit})'


def normalize_unit(value: str) -> str:
    """Return a canonical unit string from common user spellings."""
    if value is None:
        return NM
    raw = value.strip()
    lowered = raw.lower()
    # Strip whitespace, dashes, parens-like wrappers.
    for candidate in ALL_UNITS:
        if lowered == candidate.lower():
            return candidate
    aliases = {
        'cm^-1': CM_1, 'cm−1': CM_1, 'cm_1': CM_1, 'cm': CM_1,
        'um': UM, 'micrometer': UM, 'micron': UM, 'μm': UM,
        'thz': THZ, 'frequency': THZ,
        'ev': EV, 'electronvolt': EV, 'electron_volt': EV,
        'a': ANGSTROM, 'angstrom': ANGSTROM, 'angstroem': ANGSTROM,
        'nm': NM, 'nanometer': NM, 'nanometre': NM,
    }
    if lowered in aliases:
        return aliases[lowered]
    return raw


def is_valid_unit(value: str) -> bool:
    """Return True if ``value`` is a known spectral unit."""
    try:
        normalize_unit(value)
        return normalize_unit(value) in ALL_UNITS
    except Exception:
        return False
