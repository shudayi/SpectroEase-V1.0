# -*- coding: utf-8 -*-
"""
UI Scaling and DPI Awareness Utility
Addresses Editor Comment 2: UI scaling issues on different resolutions
"""

from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QSize
from PyQt5.QtGui import QFont
import logging
import re

logger = logging.getLogger("SpectroEase1.1")

class UIScalingManager:
    """Manages UI scaling and DPI awareness across different screen resolutions"""
    
    def __init__(self):
        self.refresh()

    def refresh(self):
        """Refresh cached screen information for a screen or the primary screen.

        Qt 5 high-DPI scaling exposes screen and widget geometry in
        device-independent (logical) pixels.  Those values are the coordinate
        authority for this module; the device-pixel ratio is retained for
        diagnostics only and must not be applied to QWidget dimensions again.
        """
        self.screen_info = self._get_screen_info()
        self.scale_factor = self._calculate_scale_factor()
        self.font_scale = self._calculate_font_scale()
        return self

    def refresh_for_screen(self, screen):
        """Refresh the shared cache for a particular Qt screen."""
        self.screen_info = self._get_screen_info(screen)
        self.scale_factor = self._calculate_scale_factor()
        self.font_scale = self._calculate_font_scale()
        return self

    def _get_screen_info(self, screen=None):
        """Get current screen information"""
        app = QApplication.instance()
        if screen is None and app is not None:
            screen = app.primaryScreen()
        if screen is None:
            return {
                "width": 1920,
                "height": 1080,
                "dpi": 96,
                "device_pixel_ratio": 1.0,
                "available_geometry": None,
            }

        screen_rect = screen.geometry()
        available_geometry = screen.availableGeometry()
        dpi = screen.logicalDotsPerInch()

        return {
            "width": screen_rect.width(),
            "height": screen_rect.height(),
            "dpi": dpi,
            "device_pixel_ratio": getattr(screen, "devicePixelRatio", lambda: 1.0)(),
            "available_geometry": available_geometry,
        }
    
    def _calculate_scale_factor(self):
        """Compatibility value for legacy callers; Qt owns DPI scaling.

        QWidget geometry is already expressed in Qt logical pixels.  Scaling
        those values by a resolution-derived factor makes layouts diverge
        between monitors and can shrink controls on high-DPI screens.  Keep
        this attribute at 1.0 for older callers such as the Matplotlib theme.
        """
        return 1.0
    
    def _calculate_font_scale(self):
        """Compatibility value; Qt converts point-sized fonts using screen DPI."""
        return 1.0
    
    def get_scaled_window_size(self, base_width=2000, base_height=1200):
        """Get a window size bounded to the current logical work area."""
        available = self.screen_info.get("available_geometry")
        if available is None:
            return min(base_width, 1200), min(base_height, 800)
        
        # For logical work areas up to 1080 px tall, use most of the available
        # screen. Dense scientific controls should not start overly short.
        if self.screen_info["height"] <= 1080:
            target_width = int(available.width() * 0.9)
            target_height = int(available.height() * 0.94)
        else:
            # For larger screens, use base size with scaling
            target_width = int(base_width * self.scale_factor)
            target_height = int(base_height * self.scale_factor)
        
        # Keep a useful floor where possible, then cap to the actual logical
        # work area.  Never return a size larger than a small display.
        usable_width = max(1, available.width() - 40)
        usable_height = max(1, available.height() - 40)
        target_width = min(max(target_width, min(1200, usable_width)), usable_width)
        target_height = min(max(target_height, min(800, usable_height)), usable_height)
        
        return target_width, target_height
    
    def get_scaled_font(self, base_font_name="Segoe UI", base_size=9):
        """Create a point-sized font; Qt converts points for the active screen."""
        point_size = max(8, min(int(base_size), 14))
        return QFont(base_font_name, point_size)

    def get_scaled_value(self, base_value):
        """Return a Qt logical-pixel design value (legacy API)."""
        return int(base_value * self.scale_factor)

    def get_workflow_width_budget(self, window_width=None):
        """Return min/preferred/max widths for the left workflow panel."""
        available = self.screen_info.get("available_geometry")
        screen_width = available.width() if available is not None else self.screen_info.get("width", 1920)

        if screen_width <= 1400:
            budget = {"min": 420, "preferred": 460, "max": 500}
        elif screen_width <= 1700:
            budget = {"min": 440, "preferred": 480, "max": 520}
        elif screen_width <= 2100:
            budget = {"min": 460, "preferred": 500, "max": 560}
        else:
            budget = {"min": 480, "preferred": 540, "max": 600}

        if window_width:
            max_by_window = max(budget["min"], int(window_width * 0.34))
            budget["max"] = min(budget["max"], max_by_window)
            budget["preferred"] = min(budget["preferred"], budget["max"])

        return budget
    
    def apply_dpi_awareness(self):
        """Legacy no-op retained for callers from older releases.

        Qt 5.15's Windows platform plugin provides per-monitor awareness and
        high-DPI scaling.  Mixing a late Win32 process-awareness call with Qt's
        own logical-pixel model makes behavior depend on startup order.
        Configure Qt attributes before QApplication instead (see main.py).
        """
        logger.debug("DPI awareness is managed by the Qt platform plugin")
    
    def get_scaling_info(self):
        """Get detailed scaling information for debugging"""
        return {
            "screen_resolution": f"{self.screen_info['width']}x{self.screen_info['height']}",
            "screen_dpi": self.screen_info["dpi"],
            "ui_scale_factor": self.scale_factor,
            "font_scale_factor": self.font_scale,
            "recommended_window_size": self.get_scaled_window_size()
        }

    # ------------------------------------------------------------------ tiers
    # Screen tiers are derived from Qt's available logical width.
    # Supported bounds (Qt device-independent logical pixels):
    #   compact    : width <= 1400  (e.g. 1366x768 laptops)
    #   standard   : width <= 1700  (e.g. 1440x900, 1600x900)
    #   wide       : width <= 2100  (e.g. 1920x1080)
    #   ultrawide  : width  > 2100  (e.g. 2560x1440, 3840x2160)
    # Tests override the available width through monkey-patching of
    # QApplication.primaryScreen to exercise each tier.
    def tier(self):
        """Return the current screen tier as a string."""
        width = self.screen_info.get("width", 1920)
        if not width:
            try:
                from PyQt5.QtWidgets import QApplication
                screen = QApplication.instance().primaryScreen() if QApplication.instance() else None
                if screen is not None:
                    width = screen.geometry().width()
            except Exception:
                width = 1920
        if width <= 1400:
            return "compact"
        if width <= 1700:
            return "standard"
        if width <= 2100:
            return "wide"
        return "ultrawide"

    def is_compact(self):
        """True if the primary screen is in the compact tier."""
        return self.tier() == "compact"

    def is_ultrawide(self):
        """True if the primary screen is in the ultrawide tier."""
        return self.tier() == "ultrawide"

    def get_main_window_size(self, base_width=2000, base_height=1200):
        """Return a tier-aware startup size in Qt logical pixels.

        Compact work areas use nearly the full available rectangle.  Larger
        work areas retain the established 2/3 startup size.  A modest floor
        applies where possible, while the available work rectangle is always
        the hard ceiling.
        """
        available = self.screen_info.get("available_geometry")
        if available is None:
            try:
                from PyQt5.QtWidgets import QApplication
                screen = QApplication.instance().primaryScreen() if QApplication.instance() else None
                if screen is not None:
                    available = screen.availableGeometry()
            except Exception:
                available = None
        if available is None:
            available_w, available_h = base_width, base_height
        else:
            available_w, available_h = available.width(), available.height()

        # Compact logical work areas need nearly the full screen so the
        # workflow and results remain usable.  Larger areas retain the
        # existing 2/3 startup size.  All measurements here are Qt logical px.
        margin = 8
        usable_w = max(1, available_w - margin)
        usable_h = max(1, available_h - margin)
        if usable_w <= 1400 or usable_h <= 760:
            target_w = int(usable_w * 0.90)
            target_h = int(usable_h * 0.94)
        else:
            target_w = int(usable_w * 2 / 3)
            target_h = int(usable_h * 2 / 3)
        target_w = min(max(640, target_w), usable_w)
        target_h = min(max(480, target_h), usable_h)
        return target_w, target_h

    def get_table_height_for_height(self, available_height=None):
        """Tier-aware result table height for the right panel."""
        if available_height is None:
            available_height = self.screen_info["height"]
        from app.ui import design_tokens as tok
        if available_height <= 800:
            return scaled_px(tok.RESULT_TABLE_HEIGHT_SM)
        if available_height <= 950:
            return scaled_px(tok.RESULT_TABLE_HEIGHT_MD)
        if available_height <= 1200:
            return scaled_px(tok.RESULT_TABLE_HEIGHT_LG)
        return scaled_px(tok.RESULT_TABLE_HEIGHT_XL)

    def get_dialog_min_size(self, base_min_w=None, base_min_h=None):
        """Return dialog minimums as Qt logical pixels."""
        from app.ui import design_tokens as tok
        if base_min_w is None:
            base_min_w = tok.DIALOG_MIN_WIDTH
        if base_min_h is None:
            base_min_h = tok.DIALOG_MIN_HEIGHT
        return scaled_px(base_min_w), scaled_px(base_min_h)

# Global UI scaling manager instance
ui_scaling_manager = UIScalingManager()

def apply_responsive_sizing(window, base_width=2000, base_height=1200):
    """Apply responsive sizing to a window"""
    ui_scaling_manager.refresh()
    width, height = ui_scaling_manager.get_scaled_window_size(base_width, base_height)
    window.resize(width, height)
    
    # Center the window on screen
    screen_geometry = ui_scaling_manager.screen_info.get("available_geometry")
    if screen_geometry is None:
        logger.debug("No Qt screen available; skipped window centering")
        return
    x = screen_geometry.x() + (screen_geometry.width() - width) // 2
    y = screen_geometry.y() + (screen_geometry.height() - height) // 2
    window.move(x, y)

    logger.debug("Applied responsive sizing: %sx%s (scale: %.2f)", width, height, ui_scaling_manager.scale_factor)

def scaled_px(base_value):
    """Compatibility helper: return a design-token Qt logical pixel value.

    Qt owns device-pixel conversion.  Keep this API for existing call sites,
    but do not rescale QWidget/QSS geometry from screen resolution or DPR.
    """
    return ui_scaling_manager.get_scaled_value(base_value)

def scaled_pt(base_pt):
    """Return a point size for QFont/QSS; Qt applies screen DPI conversion."""
    return max(8, min(int(base_pt), 14))

def scaled_qsize(base_w, base_h):
    """Return a scaled QSize."""
    return QSize(scaled_px(base_w), scaled_px(base_h))

def set_min_size(widget, base_w, base_h):
    """Set widget minimum size from base design-token values."""
    widget.setMinimumSize(scaled_px(base_w), scaled_px(base_h))

def set_min_width(widget, base_w):
    """Set widget minimum width from a base design-token value."""
    widget.setMinimumWidth(scaled_px(base_w))

def set_min_height(widget, base_h):
    """Set widget minimum height from a base design-token value."""
    widget.setMinimumHeight(scaled_px(base_h))

def set_max_width(widget, base_w):
    """Set widget maximum width from a base design-token value."""
    widget.setMaximumWidth(scaled_px(base_w))

def set_max_height(widget, base_h):
    """Set widget maximum height from a base design-token value."""
    widget.setMaximumHeight(scaled_px(base_h))

def set_fixed_size(widget, base_w, base_h):
    """Set widget fixed size from base design-token values."""
    widget.setFixedSize(scaled_px(base_w), scaled_px(base_h))

def set_icon_size(widget, base_w, base_h):
    """Set widget icon size from base design-token values."""
    widget.setIconSize(scaled_qsize(base_w, base_h))

def configure_form_row(label, control, label_base_w=None,
                       control_base_w=None,
                       row_base_h=None):
    """Configure a typical label+control form row with scaled dimensions."""
    from app.ui import design_tokens as tok
    if label_base_w is None:
        label_base_w = tok.LABEL_MIN_WIDTH
    if control_base_w is None:
        control_base_w = tok.CONTROL_MIN_WIDTH
    if row_base_h is None:
        row_base_h = tok.ROW_HEIGHT_BASE
    set_min_width(label, label_base_w)
    set_min_height(label, row_base_h)
    set_min_width(control, control_base_w)
    set_min_height(control, row_base_h)

def get_scaled_font(base_name="Segoe UI", base_size=9):
    """Get scaled QFont."""
    return ui_scaling_manager.get_scaled_font(base_name, base_size)

def get_responsive_font(base_name="Segoe UI", base_size=9):
    """Get responsive font (alias for compatibility)."""
    return get_scaled_font(base_name, base_size)


def scale_stylesheet(css: str) -> str:
    """Scale px/pt size values in a QSS stylesheet using the current UI scale.

    Only padding, margin (and margin-*), width, height, border-radius and
    font-size are adjusted; other declarations are left untouched.
    """
    # px dimensions
    def dim_repl(m):
        prop = m.group(1)
        vals = m.group(2).strip().split()
        scaled = []
        for v in vals:
            num = v.replace("px", "")
            try:
                scaled.append(str(scaled_px(int(num))) + "px")
            except ValueError:
                scaled.append(v)
        return f"{prop}: {' '.join(scaled)};"

    css = re.sub(
        r"(?i)(padding|margin(?:-[a-z]+)?|width|height|border-radius)\s*:\s*((?:\d+px\s*)+);",
        dim_repl,
        css,
    )

    # font-size in px
    def fs_px_repl(m):
        size = int(m.group(1))
        return f"font-size: {scaled_px(size)}px;"

    css = re.sub(r"(?i)font-size\s*:\s*(\d+)px\s*;", fs_px_repl, css)

    # font-size in pt
    def fs_pt_repl(m):
        size = int(m.group(1))
        return f"font-size: {scaled_pt(size)}pt;"

    css = re.sub(r"(?i)font-size\s*:\s*(\d+)pt\s*;", fs_pt_repl, css)
    return css
