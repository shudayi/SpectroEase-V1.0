"""Validate source-column roles without reordering the chosen spectral axis."""

import math
from numbers import Integral


def spectral_column_positions(data, target_column, identity_columns=(), selected=None):
    """Resolve explicit positions, or infer numeric axis headers for legacy input.

    If no headers are numeric wavelengths, retain the legacy feature convention.
    An explicit empty selection is an error, not a request to use all columns.
    """
    count = data.shape[1]
    if isinstance(target_column, bool) or not isinstance(target_column, Integral) or not 0 <= target_column < count:
        raise ValueError('The response must identify a valid source column.')
    target_column = int(target_column)
    identity_positions = [int(i) for i in identity_columns if i is not None]
    identities = set(identity_positions)
    if target_column in identities:
        raise ValueError('The response column cannot also be a sample/group ID column.')
    if len(identity_positions) != len(identities):
        raise ValueError('Sample ID and group ID must use separate source columns.')
    excluded = {target_column} | identities
    if selected is None:
        candidates = [i for i in range(count) if i not in excluded]
        axis = []
        for i in candidates:
            try:
                value = float(str(data.columns[i]).strip())
            except (TypeError, ValueError):
                continue
            if math.isfinite(value) and value > 0:
                axis.append(i)
        positions = axis or candidates
    else:
        if not isinstance(selected, (list, tuple)):
            raise ValueError('Spectral columns must be an ordered list of source positions.')
        positions = []
        for position in selected:
            if isinstance(position, bool) or not isinstance(position, Integral) or not 0 <= position < count:
                raise ValueError('A selected spectral column is outside the current source data.')
            position = int(position)
            if position in excluded:
                raise ValueError('Response and sample/group ID columns cannot be spectral features.')
            if position in positions:
                raise ValueError('A spectral column was selected more than once.')
            positions.append(position)
    if not positions:
        raise ValueError('Select at least one spectral column.')
    names = [data.columns[i] for i in positions]
    if len(set(names)) != len(names):
        raise ValueError('Selected spectral columns have ambiguous duplicate names.')
    return positions
