# -*- coding: utf-8 -*-
"""
后台任务 Worker 基类

将耗时操作从 UI 线程移到 QThread，避免界面冻结。
子类只需实现 run_task() 并在完成后通过 result_ready 信号返回结果。
"""

from PyQt5.QtCore import QThread, pyqtSignal, QEventLoop, QCoreApplication


class Worker(QThread):
    """Base worker thread for long-running tasks."""

    result_ready = pyqtSignal(object)
    error_occurred = pyqtSignal(str)
    progress_updated = pyqtSignal(int, str)  # progress (0-100), message

    def __init__(self, parent=None):
        super().__init__(parent)
        self._is_cancelled = False

    def cancel(self):
        """Request cancellation. Subclasses should check is_cancelled()."""
        self._is_cancelled = True

    def is_cancelled(self):
        return self._is_cancelled

    def run(self):
        """Override run_task in subclasses instead of this method."""
        try:
            result = self.run_task()
            if not self._is_cancelled:
                self.result_ready.emit(result)
        except Exception as e:
            if not self._is_cancelled:
                self.error_occurred.emit(str(e))

    def run_task(self):
        """Subclasses override this to perform actual work."""
        raise NotImplementedError("Subclasses must implement run_task()")

    def report_progress(self, progress: int, message: str = ""):
        """Convenience helper to emit progress from subclasses."""
        self.progress_updated.emit(progress, message)


class FuncWorker(Worker):
    """Run an arbitrary callable in a thread, preserving the original exception object.

    Unlike the base ``Worker.run`` (which stringifies exceptions into
    ``error_occurred``), this keeps ``_result`` / ``_error`` as attributes so
    callers can re-raise the *original* exception type in the UI thread.
    """

    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self._fn = fn
        self._result = None
        self._error = None

    def run(self):
        try:
            self._result = self._fn()
        except Exception as e:  # keep the original exception object
            self._error = e
        # ``finished`` is emitted automatically by QThread when run() returns.


def run_heavy(fn, progress_dialog=None):
    """Run ``fn`` off the UI thread while a nested event loop keeps the UI responsive.

    The calling code keeps its synchronous shape (no restructuring needed), but
    the UI no longer freezes: events are processed while ``fn`` runs. Safety
    relies on a **modal** ``progress_dialog`` (or another modal guard) blocking
    re-entry while the nested loop spins.

    Returns ``fn``'s result, or ``None`` if the user cancelled before
    completion. Re-raises ``fn``'s *original* exception in the UI thread.
    ``fn`` itself cannot be interrupted mid-flight; cancellation only
    suppresses the result.
    """
    app = QCoreApplication.instance()
    if app is None:
        raise RuntimeError("run_heavy requires a running QCoreApplication")

    # Guard against starting a nested event loop when the application is
    # already shutting down, which can leave the loop (and the caller)
    # dangling.
    if app.closingDown():
        return None

    loop = QEventLoop()
    worker = FuncWorker(fn)
    worker.finished.connect(loop.quit)
    if progress_dialog is not None:
        progress_dialog.cancelled.connect(worker.cancel)
    worker.start()
    loop.exec()  # nested event loop: UI stays responsive while fn runs
    if worker.is_cancelled():
        return None
    if worker._error is not None:
        raise worker._error
    return worker._result
