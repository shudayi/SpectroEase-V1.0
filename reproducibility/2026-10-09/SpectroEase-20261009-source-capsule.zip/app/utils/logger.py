# utils/logger.py

import logging
import os
import sys
from logging.handlers import RotatingFileHandler


# Track logger names that have already been configured so repeated calls do
# not attach additional handlers to the same logger.
_CONFIGURED_LOGGERS = set()


def _ensure_utf8_stdout():
    """Reconfigure sys.stdout/stderr to UTF-8 to avoid GBK-console crashes."""
    for stream_name in ('stdout', 'stderr'):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, 'reconfigure', None)
        if callable(reconfigure) and not getattr(stream, 'closed', False):
            try:
                # Keep the existing object: other loggers may retain it.
                # Rewrapping its buffer can close that buffer when the old
                # wrapper is collected, breaking pytest and Optuna logging.
                reconfigure(encoding='utf-8', errors='replace')
            except Exception:
                # If the stream has already been replaced or is incompatible,
                # leave it as-is.
                pass


class _CurrentConsoleHandler(logging.StreamHandler):
    """Follow current output without owning or closing a captured stream."""

    def emit(self, record):
        stream = getattr(sys, 'stdout', None)
        if stream is None or getattr(stream, 'closed', False):
            return  # pythonw may have no attached console.
        self.stream = stream
        super().emit(record)

    def flush(self):
        stream = getattr(sys, 'stdout', None)
        if stream is not None and not getattr(stream, 'closed', False):
            try:
                stream.flush()
            except (OSError, ValueError):
                pass


def setup_logger(name='SpectroEase1.1', log_file='app.log', level=logging.INFO):
    """Setup logger configuration.

    Idempotent: calling this multiple times with the same ``name`` returns the
    existing logger without adding duplicate handlers.
    """
    logger = logging.getLogger(name)

    if name in _CONFIGURED_LOGGERS:
        logger.setLevel(level)
        return logger

    _ensure_utf8_stdout()

    formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s')

    # Ensure the log directory exists.
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)

    handler = RotatingFileHandler(
        log_file,
        encoding='utf-8',
        errors='replace',
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
    )
    handler.setFormatter(formatter)

    console_handler = _CurrentConsoleHandler()
    console_handler.setFormatter(formatter)

    logger.setLevel(level)
    logger.addHandler(handler)
    logger.addHandler(console_handler)

    _CONFIGURED_LOGGERS.add(name)
    return logger
