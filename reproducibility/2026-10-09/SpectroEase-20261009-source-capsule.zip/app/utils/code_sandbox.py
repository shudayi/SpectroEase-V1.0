# app/utils/code_sandbox.py
"""Light-weight sandbox for executing user-provided / LLM-generated plugin code.

This is **not** a full isolation sandbox: the code still runs in the same
process. It provides two layers of defense:

1. AST whitelist validation (imports and dangerous calls/attributes).
2. Execution with a restricted `__builtins__` dictionary.

For stronger isolation, run generated code in a separate subprocess or use
RestrictedPython. The goal here is to eliminate the trivial bypasses of the
previous blacklist approach while keeping the existing plugin-integration flow
intact.
"""

import ast
import types
from typing import List


# Module roots that converted plugins are allowed to import.
ALLOWED_IMPORT_ROOTS = frozenset({
    # Plugin interfaces and app helpers
    'interfaces',
    'app',
    # Standard library
    'abc',
    'collections',
    'copy',
    'inspect',
    'itertools',
    'json',
    'math',
    'numbers',
    'operator',
    're',
    'statistics',
    'typing',
    'warnings',
    # Scientific / ML stack
    'numpy',
    'pandas',
    'scipy',
    'sklearn',
    'xgboost',
    'lightgbm',
})

# Callables that are never allowed in generated code.
DANGEROUS_CALLS = frozenset({
    'eval', 'exec', 'compile', '__import__', 'input', 'open',
})

# Attribute calls that are never allowed in generated code.
DANGEROUS_ATTRIBUTES = frozenset({
    'system', 'popen', 'remove', 'rmtree', 'unlink',
})

# Safe builtin subset for plugin execution.
# Keep the normal Python builtins that plugin code needs for class/function
# definitions and numeric/scientific work; remove anything that can load code
# or access the filesystem directly.
_SAFE_BUILTINS = {
    # Constants
    'True', 'False', 'None', 'NotImplemented', 'Ellipsis',
    # Types
    'bool', 'bytearray', 'bytes', 'complex', 'dict', 'enumerate', 'filter',
    'float', 'frozenset', 'int', 'list', 'map', 'memoryview', 'object',
    'property', 'range', 'reversed', 'set', 'slice', 'str', 'tuple', 'type',
    'zip',
    # Functions
    'abs', 'all', 'any', 'ascii', 'bin', 'chr', 'divmod', 'format', 'hasattr',
    'hash', 'hex', 'id', 'isinstance', 'issubclass', 'iter', 'len', 'max',
    'min', 'next', 'oct', 'ord', 'pow', 'repr', 'round', 'sorted', 'sum',
    'vars',
    # Class helpers
    'classmethod', 'staticmethod', 'super',
    # Exceptions
    'ArithmeticError', 'AssertionError', 'AttributeError', 'BaseException',
    'BlockingIOError', 'BrokenPipeError', 'BufferError', 'BytesWarning',
    'ChildProcessError', 'ConnectionAbortedError', 'ConnectionError',
    'ConnectionRefusedError', 'ConnectionResetError', 'DeprecationWarning',
    'EOFError', 'EnvironmentError', 'Exception', 'FileExistsError',
    'FileNotFoundError', 'FloatingPointError', 'FutureWarning', 'GeneratorExit',
    'IOError', 'ImportError', 'ImportWarning', 'IndentationError', 'IndexError',
    'InterruptedError', 'IsADirectoryError', 'KeyError', 'KeyboardInterrupt',
    'LookupError', 'MemoryError', 'ModuleNotFoundError', 'NameError',
    'NotADirectoryError', 'NotImplementedError', 'OSError', 'OverflowError',
    'PendingDeprecationWarning', 'PermissionError', 'ProcessLookupError',
    'RecursionError', 'ReferenceError', 'ResourceWarning', 'RuntimeError',
    'RuntimeWarning', 'StopAsyncIteration', 'StopIteration', 'SyntaxError',
    'SyntaxWarning', 'SystemError', 'TabError', 'TimeoutError', 'TypeError',
    'UnboundLocalError', 'UnicodeDecodeError', 'UnicodeEncodeError',
    'UnicodeError', 'UnicodeTranslationError', 'UnicodeWarning', 'UserWarning',
    'ValueError', 'Warning', 'ZeroDivisionError',
}


def validate_code(code: str) -> List[str]:
    """Return a list of violations for code that does not pass the whitelist.

    An empty list means the code is allowed.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return [f'Syntax error: {exc}']

    violations = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split('.')[0]
                if root not in ALLOWED_IMPORT_ROOTS:
                    violations.append(f'Import of {alias.name} is not allowed')
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ''
            root = module.split('.')[0]
            if root not in ALLOWED_IMPORT_ROOTS:
                violations.append(f'Import from {module} is not allowed')
        elif isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Name) and func.id in DANGEROUS_CALLS:
                violations.append(f'Call to {func.id}() is not allowed')
            elif isinstance(func, ast.Attribute) and func.attr in DANGEROUS_ATTRIBUTES:
                violations.append(f'Call to .{func.attr}() is not allowed')

    return sorted(set(violations))


def execute_plugin_code(code: str, module_name: str = 'custom_plugin') -> types.ModuleType:
    """Validate and execute plugin code in a module with restricted builtins.

    Args:
        code: Python source code for the plugin.
        module_name: Name for the synthetic module.

    Returns:
        The populated module.

    Raises:
        CodeSandboxError: If validation fails or execution fails.
    """
    violations = validate_code(code)
    if violations:
        raise CodeSandboxError(
            'Generated code failed validation:\n' + '\n'.join(f'- {v}' for v in violations)
        )

    mod = types.ModuleType(module_name)
    mod.__dict__['__builtins__'] = _safe_builtins.copy()

    try:
        exec(code, mod.__dict__)  # noqa: S102
    except Exception as exc:
        raise CodeSandboxError(f'Error executing generated code: {exc}') from exc

    return mod


class CodeSandboxError(Exception):
    """Raised when generated code fails validation or execution."""
    pass


# Required methods for each supported plugin target type.
_REQUIRED_METHODS = {
    'Preprocessing': {'get_name', 'get_parameter_info', 'apply'},
    'Feature Selection': {'get_name', 'get_parameter_info', 'select_features'},
    'Modeling': {'get_name', 'get_parameter_info', 'train', 'predict'},
    'Data Splitting': {'get_name', 'get_parameter_info', 'split_data'},
}


def validate_interface_conformance(code: str, target_type: str) -> List[str]:
    """Check that generated code defines a class with the required interface methods.

    Args:
        code: Generated Python source code.
        target_type: One of 'Preprocessing', 'Feature Selection', 'Modeling',
            'Data Splitting'.

    Returns:
        List of conformance issues. Empty list means conformance passed.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return [f'Syntax error: {exc}']

    required = _REQUIRED_METHODS.get(target_type)
    if required is None:
        return [f'Unknown target type: {target_type}']

    classes = [node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]
    if not classes:
        return ['No class definition found in generated code']

    issues = []
    for cls in classes:
        methods = {node.name for node in cls.body if isinstance(node, ast.FunctionDef)}
        missing = required - methods
        if missing:
            issues.append(
                f'Class "{cls.name}" is missing required methods: {", ".join(sorted(missing))}'
            )

    if not issues:
        return []

    # Only report the first class that partially matches, or all if none match
    return issues[:1] if len(classes) == 1 else [issues[0]]
