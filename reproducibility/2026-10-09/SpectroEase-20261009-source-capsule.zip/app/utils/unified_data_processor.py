"""
Unified Data Processor - Delegates label handling to EnhancedLabelProcessor.

This module remains a thin convenience wrapper for views that need string-only
labels for visualization. All task-type decisions are made by
app.utils.label_processor.EnhancedLabelProcessor.
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Union
import logging

from app.utils.label_processor import EnhancedLabelProcessor

logger = logging.getLogger(__name__)


class UnifiedDataProcessor:
    """
    Unified Data Processor - a view-facing wrapper around EnhancedLabelProcessor.

    Core principles:
      1. Labels always maintain their original string format for display.
      2. Unified numeric indices are used for internal processing.
      3. Provide a unified conversion interface.
    """

    def __init__(self):
        self.original_labels = None
        self.label_to_index = {}
        self.index_to_label = {}
        self.task_type = None
        self.is_initialized = False
        self._processor = EnhancedLabelProcessor()

    def initialize_from_data(self, labels: Union[pd.Series, np.ndarray, list]) -> Dict[str, Any]:
        """
        Initialize the processor from raw label data.

        Returns:
            Dict with task_type, num_classes, num_samples, unique_labels, and
            label_mapping.
        """
        try:
            if isinstance(labels, pd.Series):
                labels_array = labels.values
            elif isinstance(labels, list):
                labels_array = np.array(labels)
            else:
                labels_array = np.array(labels)

            self.original_labels = np.array(
                [str(label).strip() for label in labels_array], dtype='<U50'
            )

            self.task_type = self._processor.detect_task_type(labels_array)

            unique_labels = np.unique(self.original_labels)
            self.label_to_index = {label: idx for idx, label in enumerate(unique_labels)}
            self.index_to_label = {idx: label for idx, label in enumerate(unique_labels)}

            self.is_initialized = True

            logger.info("Unified data processor initialized:")
            logger.info("  Task type: %s", self.task_type)
            logger.info("  Number of labels: %d", len(unique_labels))
            logger.info("  Number of samples: %d", len(self.original_labels))

            return {
                'task_type': self.task_type,
                'num_classes': len(unique_labels),
                'num_samples': len(self.original_labels),
                'unique_labels': unique_labels.tolist(),
                'label_mapping': {
                    'label_to_index': self.label_to_index,
                    'index_to_label': self.index_to_label
                }
            }

        except Exception as exc:
            logger.error("Unified data processor initialization failed: %s", exc)
            raise

    def get_display_labels(self) -> np.ndarray:
        """Return labels in their original string form for display."""
        if not self.is_initialized:
            raise ValueError("Processor not initialized")
        return self.original_labels.copy()

    def get_numeric_labels(self) -> np.ndarray:
        """Return labels as numeric values suitable for machine learning."""
        if not self.is_initialized:
            raise ValueError("Processor not initialized")

        if self.task_type == 'classification':
            return np.array([self.label_to_index[label] for label in self.original_labels])
        else:
            try:
                return np.array([float(label) for label in self.original_labels])
            except ValueError as exc:
                logger.error("Regression label conversion failed: %s", exc)
                raise ValueError(f"Regression labels cannot be converted to numbers: {exc}")

    def convert_predictions_to_display(self, predictions: np.ndarray) -> np.ndarray:
        """Convert model predictions back to display labels."""
        if not self.is_initialized:
            raise ValueError("Processor not initialized")

        if self.task_type == 'classification':
            return np.array(
                [self.index_to_label.get(int(pred), f"Unknown_{pred}")
                 for pred in predictions], dtype='<U50'
            )
        else:
            return predictions

    def get_safe_labels_for_visualization(self) -> np.ndarray:
        """
        Return labels that are safe for visualization.

        For classification, numeric-looking labels are prefixed so they are not
        misinterpreted as continuous values. For regression, original numeric
        labels are returned.
        """
        if not self.is_initialized:
            raise ValueError("Processor not initialized")

        if self.task_type == 'regression':
            return self.original_labels.copy()

        safe_labels = []
        for label in self.original_labels:
            if self._looks_like_number(label):
                safe_labels.append(f"Class_{label}")
            else:
                safe_labels.append(str(label))

        return np.array(safe_labels, dtype='<U50')

    def _looks_like_number(self, label: str) -> bool:
        """Return True if label can be parsed as a number."""
        try:
            float(label)
            return True
        except (ValueError, TypeError):
            return False

    def get_info(self) -> Dict[str, Any]:
        """Return processor state information."""
        if not self.is_initialized:
            return {'initialized': False}

        return {
            'initialized': True,
            'task_type': self.task_type,
            'num_classes': len(self.index_to_label),
            'num_samples': len(self.original_labels),
            'unique_labels': list(self.index_to_label.values()),
            'sample_labels': self.original_labels[:5].tolist()
        }


# Global instance for backward compatibility.
unified_processor = UnifiedDataProcessor()
