import numpy as np
import pandas as pd
import logging

from app.utils.label_processor import EnhancedLabelProcessor

logger = logging.getLogger(__name__)


class DataTypeFixer:
    """Utility class for fixing data type inconsistencies, especially mixed type errors."""

    @staticmethod
    def fix_mixed_types(y, force_type=None):
        """
        Fix mixed type data so it can be properly evaluated.

        Args:
            y: Label data to fix.
            force_type: Force conversion type ('float', 'int', 'auto').

        Returns:
            Tuple: (fixed_labels, detected_conversion_type)
        """
        if isinstance(y, pd.Series):
            y_array = y.values
        elif isinstance(y, list):
            y_array = np.array(y)
        else:
            y_array = np.asarray(y)

        if len(y_array) == 0:
            return y_array, "none"

        dtypes = set([type(item) for item in y_array])

        has_int = any(issubclass(t, (int, np.integer)) for t in dtypes)
        has_float = any(issubclass(t, (float, np.floating)) for t in dtypes)
        has_str = any(issubclass(t, str) for t in dtypes)
        has_bool = any(issubclass(t, (bool, np.bool_)) for t in dtypes)

        if force_type == 'float':
            conversion = 'float'
        elif force_type == 'int':
            conversion = 'int'
        elif force_type == 'auto':
            if has_str:
                conversion = 'str'
            elif has_float and not has_int and not has_bool:
                conversion = 'float'
            elif has_int and not has_float and not has_bool:
                conversion = 'int'
            elif has_bool and not has_int and not has_float:
                conversion = 'bool'
            elif has_float:
                conversion = 'float'
            elif has_int or has_bool:
                conversion = 'int'
            else:
                conversion = 'str'
        else:
            if has_float and has_int:
                conversion = 'float'
            elif (has_int or has_bool) and not has_float and not has_str:
                conversion = 'int'
            elif has_float:
                conversion = 'float'
            elif has_str:
                conversion = 'str'
            else:
                conversion = 'int'

        logger.info("Selected conversion type: %s", conversion)

        try:
            if conversion == 'float':
                def safe_float_convert(val):
                    try:
                        str_val = str(val).strip()
                        if str_val and not str_val.replace('.', '').replace('-', '').replace('e', '').replace('E', '').replace('+', '').isdigit():
                            raise ValueError(f"String label detected: {str_val}")
                        return float(val)
                    except (ValueError, TypeError):
                        raise ValueError(f"Cannot convert to float: {val}")

                result = np.array([safe_float_convert(item) for item in y_array])
                logger.info("Successfully converted to float")
            elif conversion == 'int':
                if has_float:
                    def safe_round_float(val):
                        try:
                            str_val = str(val).strip()
                            if str_val and not str_val.replace('.', '').replace('-', '').replace('e', '').replace('E', '').replace('+', '').isdigit():
                                raise ValueError(f"String label detected: {str_val}")
                            return round(float(val))
                        except (ValueError, TypeError):
                            raise ValueError(f"Cannot convert to float: {val}")

                    y_array = np.array([safe_round_float(item) for item in y_array])
                result = np.array([int(item) for item in y_array])
                logger.info("Successfully converted to integer")
            elif conversion == 'bool':
                result = np.array([bool(item) for item in y_array])
            elif conversion == 'str':
                result = np.array([str(item) for item in y_array])
                logger.info("Successfully converted to string")
            else:
                logger.warning("Unknown conversion type: %s, returning original data", conversion)
                result = y_array

            return result, conversion
        except Exception as exc:
            logger.error("Error converting data type: %s", exc)
            return y_array, "error"

    @staticmethod
    def fix_for_classification(y):
        """Fix data types specifically for classification tasks."""
        y_fixed, conversion = DataTypeFixer.fix_mixed_types(y, 'auto')

        if conversion == 'float':
            y_fixed = np.round(y_fixed).astype(int)

        if conversion == 'str':
            from app.utils.label_processor import EnhancedLabelProcessor
            processor = EnhancedLabelProcessor()
            y_fixed, _ = processor.process_labels_smart(y_fixed, 'classification')
            logger.info("Encoded string labels via EnhancedLabelProcessor")

        return y_fixed

    @staticmethod
    def fix_for_regression(y):
        """Fix data types specifically for regression tasks."""
        y_fixed, _ = DataTypeFixer.fix_mixed_types(y, 'float')
        return y_fixed

    @staticmethod
    def check_and_fix_evaluation_data(model, X, y, task_type=None):
        """
        Comprehensive check and fix for evaluation data.

        Task-type detection is delegated to EnhancedLabelProcessor so all label
        decisions live in one place.

        Returns:
            Tuple of (X, y_fixed, task_type).
        """
        if task_type is None:
            model_class = model.__class__.__name__
            if any(clf in model_class for clf in ['Classifier', 'SVC', 'LogisticRegression']):
                task_type = "classification"
            elif any(reg in model_class for reg in ['Regressor', 'SVR', 'LinearRegression']):
                task_type = "regression"
            else:
                processor = EnhancedLabelProcessor()
                task_type = processor.detect_task_type(y)

        if task_type == "classification":
            y_fixed = DataTypeFixer.fix_for_classification(y)
        else:
            y_fixed = DataTypeFixer.fix_for_regression(y)

        return X, y_fixed, task_type
