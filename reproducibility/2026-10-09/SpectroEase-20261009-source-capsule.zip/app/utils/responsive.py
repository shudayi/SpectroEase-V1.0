"""Screen-aware sizing helpers for top-level Qt widgets.

All dimensions and screen rectangles in this module use Qt 5.15's logical
(device-independent) pixel coordinate system.  The helper does not apply the
device-pixel ratio to widget geometry a second time.
"""

from PyQt5.QtWidgets import QApplication


def _widget_screen(widget, explicit_screen=None):
    """Return the screen of an explicit target, the owner, or the widget."""
    if explicit_screen is not None:
        return explicit_screen

    # A child dialog belongs with its owner when the owner's native window
    # handle already exists.  This is important when the main window is on a
    # secondary monitor with a different logical work area.
    parent_getter = getattr(widget, "parentWidget", None)
    parent = parent_getter() if callable(parent_getter) else None
    if parent is not None:
        owner = parent.window() if callable(getattr(parent, "window", None)) else parent
        handle_getter = getattr(owner, "windowHandle", None)
        handle = handle_getter() if callable(handle_getter) else None
        if handle is not None:
            screen = handle.screen()
            if screen is not None:
                return screen
        screen_getter = getattr(owner, "screen", None)
        if callable(screen_getter):
            screen = screen_getter()
            if screen is not None:
                return screen

    handle_getter = getattr(widget, "windowHandle", None)
    handle = handle_getter() if callable(handle_getter) else None
    if handle is not None:
        screen = handle.screen()
        if screen is not None:
            return screen

    screen_getter = getattr(widget, "screen", None)
    if callable(screen_getter):
        screen = screen_getter()
        if screen is not None:
            return screen

    app = QApplication.instance()
    return app.primaryScreen() if app is not None else None


def fit_window_to_screen(
    widget,
    preferred_width,
    preferred_height,
    min_width=None,
    min_height=None,
    margin=None,
    screen=None,
    center=True,
):
    """Size a top-level widget to its owner's/current screen work area.

    Preferred and minimum dimensions are logical pixels.  If the requested
    minimum cannot fit on a small screen, it is bounded to the usable work
    area so the title bar and close controls remain reachable.  Child dialogs
    are centered over their owner, clamped to the selected screen, and use the
    screen's global (possibly non-zero or negative) origin.
    """
    from app.ui import design_tokens as tok
    from app.utils.ui_scaling import scaled_px

    if min_width is None:
        min_width = scaled_px(tok.DIALOG_MIN_WIDTH)
    if min_height is None:
        min_height = scaled_px(tok.DIALOG_MIN_HEIGHT)
    if margin is None:
        margin = scaled_px(tok.DIALOG_SCREEN_MARGIN)

    target_screen = _widget_screen(widget, screen)
    if target_screen is None:
        bounded_min_width = max(1, int(min_width))
        bounded_min_height = max(1, int(min_height))
        widget.setMinimumSize(bounded_min_width, bounded_min_height)
        widget.resize(
            max(bounded_min_width, int(preferred_width)),
            max(bounded_min_height, int(preferred_height)),
        )
        return

    available = target_screen.availableGeometry()
    margin = max(0, int(margin))
    usable_width = max(1, available.width() - margin)
    usable_height = max(1, available.height() - margin)
    bounded_min_width = min(max(1, int(min_width)), usable_width)
    bounded_min_height = min(max(1, int(min_height)), usable_height)
    width = min(max(bounded_min_width, int(preferred_width)), usable_width)
    height = min(max(bounded_min_height, int(preferred_height)), usable_height)
    widget.setMinimumSize(bounded_min_width, bounded_min_height)
    widget.resize(width, height)

    if not center:
        return

    parent_getter = getattr(widget, "parentWidget", None)
    parent = parent_getter() if callable(parent_getter) else None
    if parent is not None:
        owner = parent.window() if callable(getattr(parent, "window", None)) else parent
        frame = owner.frameGeometry()
        x = frame.center().x() - width // 2
        y = frame.center().y() - height // 2
    else:
        x = available.x() + (available.width() - width) // 2
        y = available.y() + (available.height() - height) // 2

    # QRect coordinates are in the virtual-desktop logical coordinate system;
    # preserve the screen origin instead of assuming that the primary monitor
    # starts at (0, 0).
    min_x = available.x()
    min_y = available.y()
    max_x = available.x() + max(0, available.width() - width - margin)
    max_y = available.y() + max(0, available.height() - height - margin)
    widget.move(min(max(x, min_x), max_x), min(max(y, min_y), max_y))
