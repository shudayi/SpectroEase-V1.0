"""
Data Compatibility Utils

This module provides compatibility helpers for labels and evaluation data.
Task-type detection and label encoding are delegated to
app.utils.label_processor.EnhancedLabelProcessor so the label processor remains
the single source of truth.
"""

import numpy as np
import pandas as pd
import re
from typing import Tuple, Union, List, Dict, Any
import logging
from collections import Counter
from app.utils.label_processor import EnhancedLabelProcessor

logger = logging.getLogger(__name__)


def safe_float_convert(val):
    """Safely convert value to float, return NaN if conversion fails."""
    try:
        return float(val)
    except (ValueError, TypeError):
        return np.nan


def normalize_label(val):
    """
    Standardize a label value to a consistent string representation.

    Processing rules:
      1. None values become the string "None".
      2. Strings are stripped of leading/trailing whitespace.
      3. Integer-like floats (1.0) become integer strings ("1").
      4. Other decimals are rounded to two decimal places.
      5. All other types become strings.
    """
    if val is None:
        return "None"

    if isinstance(val, str):
        val = val.strip()

    try:
        num = float(val)
        if num.is_integer():
            return str(int(num))
        else:
            return f"{num:.2f}"
    except (ValueError, TypeError):
        return str(val).strip()


def standardize_classification_labels(
    y_true: Union[np.ndarray, pd.Series, List],
    y_pred: Union[np.ndarray, pd.Series, List]
) -> Tuple[np.ndarray, np.ndarray, Dict[str, int]]:
    """
    Standardize true labels and predictions for classification tasks.

    Both arrays are normalized to a shared string vocabulary and then encoded as
    contiguous integer indices. No automatic K-means merging is performed.

    Returns:
        Tuple of (y_true_encoded, y_pred_encoded, label_map).
    """
    # Convert pandas to numpy if needed.
    if isinstance(y_true, pd.Series):
        y_true = y_true.values
    if isinstance(y_pred, pd.Series):
        y_pred = y_pred.values

    logger.info("Starting classification label standardization")

    if not isinstance(y_true, np.ndarray):
        y_true = np.array(y_true)
    if not isinstance(y_pred, np.ndarray):
        y_pred = np.array(y_pred)

    # Convert both arrays to normalized strings.
    y_true_str = np.array([normalize_label(label) for label in y_true])
    y_pred_str = np.array([normalize_label(label) for label in y_pred])

    if len(y_true_str) > 0:
        before_after = [
            f"'{y_true[i]}' -> '{y_true_str[i]}'"
            for i in range(min(5, len(y_true)))
        ]
        logger.debug("Label standardization examples: %s", ", ".join(before_after))

    logger.debug("Label examples - True: %s", y_true_str[:5])
    logger.debug("Label examples - Predicted: %s", y_pred_str[:5])

    all_labels = np.unique(np.concatenate([y_true_str, y_pred_str]))
    label_count = len(all_labels)
    logger.info("Detected %d unique labels", label_count)

    if label_count <= 20:
        logger.debug("All unique labels: %s", list(all_labels))
    else:
        logger.debug("First 20 unique labels: %s ...", list(all_labels[:20]))

    if label_count > 100:
        logger.warning(
            "Detected %d unique labels (>100). Check for float precision issues or data errors.",
            label_count,
        )

    label_map = {label: idx for idx, label in enumerate(all_labels)}
    logger.debug("Label mapping: %s", label_map)

    y_true_idx = np.array([label_map[label] for label in y_true_str])
    y_pred_idx = np.array([label_map[label] for label in y_pred_str])

    logger.info("Label standardization completed")
    return y_true_idx, y_pred_idx, label_map


def standardize_regression_values(
    y_true: Union[np.ndarray, pd.Series, List],
    y_pred: Union[np.ndarray, pd.Series, List] = None
) -> Union[Tuple[np.ndarray, np.ndarray, np.ndarray], Tuple[np.ndarray, np.ndarray]]:
    """
    Standardize true values and predictions for regression tasks.

    Converts both arrays to float and returns a boolean mask of valid entries.
    """
    if isinstance(y_true, pd.Series):
        y_true = y_true.values
    if y_pred is not None and isinstance(y_pred, pd.Series):
        y_pred = y_pred.values

    y_true_float = np.array([extract_number(val) for val in y_true])

    if y_pred is None:
        mask = ~np.isnan(y_true_float)
        return y_true_float, mask

    if isinstance(y_pred, pd.Series):
        y_pred = y_pred.values
    elif not isinstance(y_pred, np.ndarray):
        y_pred = np.array(y_pred)

    y_pred_float = np.array([extract_number(val) for val in y_pred])
    mask = ~np.isnan(y_true_float) & ~np.isnan(y_pred_float)

    return y_true_float, y_pred_float, mask


def extract_number(val: Any) -> float:
    """
    Extract a number from any value.

    Returns NaN if extraction fails.
    """
    if val is None:
        return np.nan

    try:
        if isinstance(val, (int, float)):
            return float(val)
        return float(val)
    except (ValueError, TypeError):
        try:
            match = re.search(r"[-+]?[0-9]*\.?[0-9]+", str(val))
            return float(match.group()) if match else np.nan
        except Exception:
            return np.nan


def is_classification_task(y: Union[np.ndarray, pd.Series, List]) -> bool:
    """
    Determine whether a task is classification.

    Delegates to EnhancedLabelProcessor so detection rules live in one place.
    """
    processor = EnhancedLabelProcessor()
    return processor.detect_task_type(y) == 'classification'


def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean a DataFrame by handling missing values and converting types.

    Skips columns whose names suggest they are labels or categories.
    """
    if df is None or df.empty:
        return df

    df_clean = df.copy()

    for col in df_clean.columns:
        if not pd.api.types.is_numeric_dtype(df_clean[col]):
            continue

        if df_clean[col].isna().any():
            median_val = df_clean[col].median()
            df_clean[col] = df_clean[col].fillna(median_val)

    for col in df_clean.columns:
        if pd.api.types.is_string_dtype(df_clean[col]):
            try:
                col_name_lower = str(col).lower()
                if any(
                    keyword in col_name_lower
                    for keyword in ['label', 'class', 'category', 'target', 'variety', 'type', 'group']
                ):
                    logger.debug("Skipping label column in clean_dataframe: %s", col)
                    continue

                numeric_values = df_clean[col].apply(lambda x: extract_number(x))
                if numeric_values.isna().mean() < 0.5:
                    df_clean[col] = numeric_values
            except Exception as exc:
                logger.debug("Skipping column %s conversion in clean_dataframe: %s", col, exc)

    return df_clean


def prepare_data_for_training(
    X: pd.DataFrame,
    y: Union[pd.Series, np.ndarray]
) -> Tuple[pd.DataFrame, Union[pd.Series, np.ndarray]]:
    """
    Prepare data for model training.

    Cleans features and normalizes the target variable according to task type.
    """
    if not isinstance(X, pd.DataFrame):
        try:
            X = pd.DataFrame(X, columns=[f'feature_{i}' for i in range(X.shape[1])])
        except Exception as exc:
            logger.error("Error converting features to DataFrame: %s", exc)
            raise

    X_clean = clean_dataframe(X)

    if is_classification_task(y):
        if isinstance(y, pd.Series):
            if pd.api.types.is_categorical_dtype(y):
                y = y.cat.codes
        elif isinstance(y, np.ndarray):
            if y.dtype.kind not in 'iuf':
                y = np.array([str(val) if val is not None else "None" for val in y])
    else:
        if isinstance(y, pd.Series):
            sample_values = y.head(5).tolist()
            string_count = sum(
                1 for val in sample_values
                if isinstance(val, str)
                and not str(val).replace('.', '').replace('-', '').isdigit()
            )
            if string_count == 0:
                y = y.apply(lambda x: extract_number(x))
            else:
                logger.warning(
                    "Detected string labels in regression task, keeping as strings: %s",
                    sample_values,
                )
        elif isinstance(y, np.ndarray):
            sample_values = y[:5].tolist()
            string_count = sum(
                1 for val in sample_values
                if isinstance(val, str)
                and not str(val).replace('.', '').replace('-', '').isdigit()
            )
            if string_count == 0:
                y = np.array([extract_number(val) for val in y])
            else:
                logger.warning(
                    "Detected string labels in regression task, keeping as strings: %s",
                    sample_values,
                )

    return X_clean, y


def prepare_labels_safely(
    y: Union[np.ndarray, pd.Series, List],
    task_type: str = None
) -> Tuple[np.ndarray, str]:
    """
    Process labels safely, standardizing regardless of input type.

    Delegates to EnhancedLabelProcessor; the returned task type is the actual
    task type used.
    """
    processor = EnhancedLabelProcessor()
    processed, metadata = processor.process_labels_smart(y, force_task_type=task_type)
    actual_task_type = metadata.get('task_type', task_type or 'classification')
    return processed, actual_task_type


def encode_classification_labels(
    labels: Union[np.ndarray, pd.Series, List],
    return_mapping: bool = True
) -> Union[np.ndarray, Tuple[np.ndarray, Dict, Dict]]:
    """
    Encode classification labels as integers (0 to N-1).

    Returns the encoded labels plus forward and inverse mappings when
    return_mapping is True.
    """
    logger.info("Encoding classification labels to integers")

    if isinstance(labels, pd.Series):
        labels = labels.values
    elif not isinstance(labels, np.ndarray):
        labels = np.array(labels)

    original_labels = labels.copy()

    # If numeric and all integers, encode directly.
    if np.issubdtype(labels.dtype, np.number):
        try:
            if np.all(np.equal(np.mod(labels, 1), 0)):
                if labels.dtype.kind in ['U', 'S', 'O']:
                    raise ValueError("Contains string labels, cannot convert to int")
                labels_int = labels.astype(int)
                unique_labels = np.unique(labels_int)
                forward_map = {int(label): idx for idx, label in enumerate(unique_labels)}
                inverse_map = {idx: int(label) for idx, label in enumerate(unique_labels)}
                labels_encoded = np.array([forward_map[int(label)] for label in labels_int])

                logger.info("Direct integer encoding used - %d unique integer labels", len(unique_labels))

                if return_mapping:
                    return labels_encoded, forward_map, inverse_map
                else:
                    return labels_encoded
        except Exception as exc:
            logger.debug("Integer direct encoding failed, falling back to string conversion: %s", exc)

    labels_str = np.array([normalize_label(label) for label in labels])

    if len(labels) > 0:
        logger.debug("Label conversion examples:")
        for i in range(min(5, len(labels))):
            logger.debug(
                "  Original: '%s' (%s) -> Normalized: '%s' (%s)",
                original_labels[i], type(original_labels[i]).__name__,
                labels_str[i], type(labels_str[i]).__name__,
            )

    unique_labels = np.unique(labels_str)
    logger.info("Encoding classification labels - Detected %d unique classification labels", len(unique_labels))

    if len(unique_labels) <= 20:
        logger.debug("All unique labels: %s", list(unique_labels))
    else:
        logger.debug("First 20 unique labels: %s ...", list(unique_labels[:20]))

    forward_map = {label: idx for idx, label in enumerate(unique_labels)}
    inverse_map = {idx: label for idx, label in enumerate(unique_labels)}

    labels_encoded = np.array([forward_map[label] for label in labels_str])

    if len(labels) > 0:
        logger.debug("Label encoding examples:")
        for i in range(min(5, len(labels))):
            logger.debug(
                "  Normalized: '%s' -> Encoded: %d (Mapping back: '%s')",
                labels_str[i], labels_encoded[i], inverse_map[labels_encoded[i]],
            )

    label_counts = Counter(labels_encoded)
    sorted_counts = sorted(label_counts.items(), key=lambda x: x[1], reverse=True)
    logger.debug("Label encoding counts (top 10): %s", sorted_counts[:10])

    if return_mapping:
        return labels_encoded, forward_map, inverse_map
    else:
        return labels_encoded


def predict_with_encoded_labels(
    model,
    X: np.ndarray,
    inverse_map: Dict
) -> np.ndarray:
    """
    Use a pre-built label mapping to convert predictions back to original labels.
    """
    predictions = model.predict(X)

    if hasattr(predictions, 'dtype') and np.issubdtype(predictions.dtype, np.floating):
        try:
            if predictions.dtype.kind not in ['U', 'S', 'O']:
                predictions = np.round(predictions).astype(int)
        except (ValueError, TypeError):
            pass

    def safe_int_convert_for_mapping(val):
        try:
            str_val = str(val).strip()
            if str_val and not str_val.replace('.', '').replace('-', '').replace('e', '').replace('E', '').replace('+', '').isdigit():
                return None
            return int(float(val))
        except (ValueError, TypeError):
            return None

    original_predictions = []
    for p in predictions:
        int_p = safe_int_convert_for_mapping(p)
        if int_p is not None:
            original_predictions.append(inverse_map.get(int_p, "Unknown"))
        else:
            original_predictions.append(str(p))

    return np.array(original_predictions)


def evaluate_classification(
    y_true: np.ndarray,
    y_pred: np.ndarray
) -> Dict[str, float]:
    """
    Evaluate classification model performance, safely handling mixed types.
    """
    from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
    import sklearn

    logger.info(
        "Evaluating classification performance - y_true type: %s, dtype: %s",
        type(y_true), getattr(y_true, 'dtype', 'N/A')
    )
    logger.info(
        "Evaluating classification performance - y_pred type: %s, dtype: %s",
        type(y_pred), getattr(y_pred, 'dtype', 'N/A')
    )

    try:
        if hasattr(y_true, 'dtype') and hasattr(y_pred, 'dtype') and y_true.dtype != y_pred.dtype:
            logger.warning("Label types inconsistent: y_true=%s, y_pred=%s", y_true.dtype, y_pred.dtype)

            if y_true.dtype.kind in 'iuf' and y_pred.dtype.kind == 'U':
                logger.info("Attempting to convert string predictions to numbers...")
                try:
                    def safe_convert_to_int(val):
                        try:
                            str_val = str(val).strip()
                            if str_val and not str_val.replace('.', '').replace('-', '').replace('e', '').replace('E', '').replace('+', '').isdigit():
                                return None
                            return int(safe_float_convert(val))
                        except (ValueError, TypeError):
                            return None

                    converted_pred = [safe_convert_to_int(x) for x in y_pred]
                    if None in converted_pred:
                        raise ValueError("Contains string labels that cannot be converted to numbers")

                    y_pred = np.array(converted_pred)
                    logger.info("Successfully converted predictions to numbers: %s", y_pred.dtype)
                except Exception as exc:
                    logger.warning("Cannot convert predictions to numbers: %s", exc)
                    y_true = np.array([str(x) for x in y_true])
                    logger.info("Converting true labels to strings instead: %s", y_true.dtype)

            elif y_pred.dtype.kind in 'iuf' and y_true.dtype.kind == 'U':
                logger.info("Attempting to convert numeric predictions to strings...")
                try:
                    y_pred = np.array([str(x) for x in y_pred])
                    logger.info("Successfully converted predictions to strings: %s", y_pred.dtype)
                except Exception as exc:
                    logger.warning("Cannot convert predictions to strings: %s", exc)
                    try:
                        def safe_convert_to_int(val):
                            try:
                                str_val = str(val).strip()
                                if str_val and not str_val.replace('.', '').replace('-', '').replace('e', '').replace('E', '').replace('+', '').isdigit():
                                    return None
                                return int(safe_float_convert(val))
                            except (ValueError, TypeError):
                                return None

                        converted_true = [safe_convert_to_int(x) for x in y_true]
                        if None in converted_true:
                            raise ValueError("Contains string labels that cannot be converted to numbers")

                        y_true = np.array(converted_true)
                        logger.info("Converting true labels to numbers instead: %s", y_true.dtype)
                    except Exception as exc2:
                        logger.error("Both conversions failed, cannot resolve type inconsistency: %s", exc2)
    except Exception as exc:
        logger.warning("Error while resolving type inconsistency: %s", exc)

    try:
        if np.issubdtype(y_true.dtype, np.integer) and np.issubdtype(y_pred.dtype, np.integer):
            logger.debug("Both arrays are integer type, using direct calculation")

            unique_classes = np.unique(np.concatenate([y_true, y_pred]))
            num_classes = len(unique_classes)

            metrics = {}
            metrics["accuracy"] = float(accuracy_score(y_true, y_pred))

            if num_classes > 1:
                metrics["f1"] = float(f1_score(y_true, y_pred, average='weighted', zero_division=0))
                metrics["precision"] = float(precision_score(y_true, y_pred, average='weighted', zero_division=0))
                metrics["recall"] = float(recall_score(y_true, y_pred, average='weighted', zero_division=0))
            else:
                metrics["f1"] = 1.0 if metrics["accuracy"] == 1.0 else 0.0
                metrics["precision"] = 1.0 if metrics["accuracy"] == 1.0 else 0.0
                metrics["recall"] = 1.0 if metrics["accuracy"] == 1.0 else 0.0

            return metrics
    except Exception as exc:
        logger.debug("Direct metric calculation failed, falling back to standardization: %s", exc)

    logger.debug("Converting labels to normalized format for evaluation")

    if not np.issubdtype(y_true.dtype, np.number):
        y_true_str = np.array([str(label) if label is not None else "None" for label in y_true])
    else:
        y_true_str = y_true

    if not np.issubdtype(y_pred.dtype, np.number):
        y_pred_str = np.array([str(label) if label is not None else "None" for label in y_pred])
    else:
        y_pred_str = y_pred

    y_true_idx, y_pred_idx, _ = standardize_classification_labels(y_true_str, y_pred_str)

    logger.debug("Label types after standardization - True: %s, Pred: %s", y_true_idx.dtype, y_pred_idx.dtype)

    unique_classes = np.unique(np.concatenate([y_true_idx, y_pred_idx]))
    num_classes = len(unique_classes)

    metrics = {}
    metrics["accuracy"] = float(accuracy_score(y_true_idx, y_pred_idx))

    if num_classes > 1:
        metrics["f1"] = float(f1_score(y_true_idx, y_pred_idx, average='weighted', zero_division=0))
        metrics["precision"] = float(precision_score(y_true_idx, y_pred_idx, average='weighted', zero_division=0))
        metrics["recall"] = float(recall_score(y_true_idx, y_pred_idx, average='weighted', zero_division=0))
    else:
        metrics["f1"] = 1.0 if metrics["accuracy"] == 1.0 else 0.0
        metrics["precision"] = 1.0 if metrics["accuracy"] == 1.0 else 0.0
        metrics["recall"] = 1.0 if metrics["accuracy"] == 1.0 else 0.0

    return metrics
