# -*- coding: utf-8 -*-
"""
全局主题管理器

统一 App 样式表（QSS）与 Matplotlib 主题入口。
"""

from app.ui import mpl_theme
from app.ui.style_sheet_builder import build_app_stylesheet
from config.settings import Settings

LIGHT = "light"
DARK = "dark"


class Theme:
    LIGHT = LIGHT
    DARK = DARK


_settings_instance = None


def _get_settings():
    """延迟初始化并缓存 Settings 实例。"""
    global _settings_instance
    if _settings_instance is None:
        _settings_instance = Settings()
    return _settings_instance


def get_current_theme():
    """从 config.settings.Settings 读取当前主题，默认 light。"""
    try:
        settings = _get_settings()
        theme = getattr(settings, "theme", LIGHT)
    except Exception:
        theme = LIGHT
    return theme if theme in (LIGHT, DARK) else LIGHT


def get_app_stylesheet(theme=None):
    """包装 style_sheet_builder.build_app_stylesheet，返回主题对应的 QSS。"""
    if theme is None:
        theme = get_current_theme()
    if theme not in (LIGHT, DARK):
        theme = LIGHT
    return build_app_stylesheet(theme)


def apply_theme_to_app(app, theme=None):
    """将主题应用到 QApplication：设置 QSS 并同步 Matplotlib 主题。"""
    if theme is None:
        theme = get_current_theme()
    if theme not in (LIGHT, DARK):
        theme = LIGHT

    if app is not None:
        app.setStyleSheet(get_app_stylesheet(theme))

    if theme == DARK:
        mpl_theme.apply_dark_theme()
    else:
        mpl_theme.apply_light_theme()
