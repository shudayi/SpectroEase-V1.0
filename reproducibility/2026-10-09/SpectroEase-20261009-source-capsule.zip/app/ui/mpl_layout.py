"""Shared chart layout rules for screen charts and physical-size exports."""
import textwrap


def layout_figure(figure, *, legend_fontsize=None):
    """Keep legends outside data, wrap complete labels, and own the layout.

    Label text is wrapped rather than shortened. The original legend text is
    retained on each text artist so resizing does not introduce nested wraps.
    """
    width = figure.get_size_inches()[0] * figure.dpi
    height = figure.get_size_inches()[1] * figure.dpi
    from matplotlib.text import Text
    from app.ui.mpl_theme import chart_font_family
    family = chart_font_family()
    for artist in figure.findobj(match=Text):
        artist.set_fontfamily(['DejaVu Sans', family])
    wrap_width = 22 if width < 750 else 30
    legend_axes = []
    for axis in figure.axes:
        legend = axis.get_legend()
        if legend is None:
            continue
        # Do not place an arbitrarily tall class list outside a small canvas.
        # Keep complete labels on the axes for export metadata; the on-screen
        # key identifies the visible subset explicitly.
        full = getattr(axis, '_spectroease_full_legend', None)
        handles, labels = axis.get_legend_handles_labels()
        if full is None or len(labels) > len(full[1]):
            full = (handles, labels)
            axis._spectroease_full_legend = full
        if len(full[1]) > 8:
            count = max(2, min(8, int(height / 85)))
            legend.remove()
            legend = axis.legend(full[0][:count], full[1][:count],
                                 title=f'Key: {count} of {len(full[1])} series',
                                 frameon=False)
        legend_axes.append((axis, legend))
        # Let this helper allocate the legend gutter explicitly. If the
        # legend participates in tight_layout as well, Matplotlib reserves its
        # width a second time and leaves the axes unnecessarily narrow.
        legend.set_in_layout(False)
        for artist in legend.get_texts():
            artist.set_fontfamily(['DejaVu Sans', family])
            label = getattr(artist, '_spectroease_full_label', artist.get_text())
            artist._spectroease_full_label = label
            artist.set_text('\n'.join(textwrap.wrap(label, width=wrap_width)) or label)
            if legend_fontsize is not None:
                artist.set_fontsize(legend_fontsize)

    has_legend = bool(legend_axes)
    # In a wide, single-axis canvas, a compact legend below the plot uses the
    # available horizontal space better than a tall right-hand legend. Keep a
    # side legend on small screens and on multi-axis figures.
    labels_in_legend = len(legend_axes[0][1].get_texts()) if len(legend_axes) == 1 else 0
    bottom_legend = (
        len(legend_axes) == 1 and width >= 850 and height >= 320
        and labels_in_legend <= 4
    )
    figure._spectroease_legend_layout = (
        "bottom" if bottom_legend else "side" if has_legend else "none"
    )
    if bottom_legend:
        _, legend = legend_axes[0]
        legend.set_loc('lower center')
        legend.set_bbox_to_anchor((0.5, 0.04), transform=figure.transFigure)
    else:
        for axis, legend in legend_axes:
            legend.set_loc('center left')
            legend.set_bbox_to_anchor((1.02, 0.5), transform=axis.transAxes)
    # Start with a wider plotting area, then measure the rendered external
    # legends and reclaim only as much right-hand space as they need. This
    # keeps short legends from leaving a large blank strip while retaining a
    # real gutter for long/wrapped class labels.
    right = 0.84 if has_legend and not bottom_legend else 0.98
    bottom = 0.36 if bottom_legend else 0.03
    rect = (0.02, bottom, right, 0.98)
    figure.tight_layout(pad=1.1, rect=rect)
    if not has_legend or bottom_legend:
        return

    canvas = getattr(figure, "canvas", None)
    if canvas is None or not hasattr(canvas, "get_renderer"):
        return
    legends = [axis.get_legend() for axis in figure.axes if axis.get_legend() is not None]
    for _ in range(4):
        try:
            canvas.draw()
            renderer = canvas.get_renderer()
            figure_box = figure.get_window_extent(renderer)
            if figure_box.width <= 0:
                break
            overflow = max(
                (legend.get_window_extent(renderer).x1 for legend in legends),
                default=figure_box.x1,
            ) - (figure_box.x1 - 2)
            if overflow <= 1:
                break
            right = max(0.56, right - (overflow / figure_box.width) * 1.08)
            rect = (0.02, bottom, right, 0.98)
            figure.tight_layout(pad=1.1, rect=rect)
        except (AttributeError, RuntimeError, ValueError):
            # Preserve a conservative margin if a backend cannot measure
            # artists before the final draw.
            right = min(right, 0.68)
            figure.tight_layout(pad=1.1, rect=(0.02, bottom, right, 0.98))
            break
