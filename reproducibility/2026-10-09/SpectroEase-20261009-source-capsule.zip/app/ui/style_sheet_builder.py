# -*- coding: utf-8 -*-
"""Global QSS generated from the SpectroEase design tokens."""

from app.ui import design_tokens as tok
from app.utils.ui_scaling import scaled_px, scaled_pt


def px(value):
    return f"{scaled_px(value)}px"


def pt(value):
    return f"{scaled_pt(value)}pt"


def build_app_stylesheet(theme="light"):
    """Build the application stylesheet from semantic light/dark tokens."""
    colors = _dark_colors() if theme == "dark" else _light_colors()
    font_family = ", ".join(f'"{name}"' if " " in name else name for name in tok.FONT_FAMILY_UI)
    return f"""
QMainWindow, QWidget {{
    background-color: {colors['bg']};
    color: {colors['text']};
    font-family: {font_family};
    font-size: {pt(tok.BASE_FONT_PT)};
}}

QFrame#surfaceCard, QGroupBox {{
    background-color: {colors['surface']};
    border: 1px solid {colors['border']};
    border-radius: {px(tok.RADIUS_MD)};
}}

QFrame#statusCard {{
    background-color: {colors['surface']};
    border: 1px solid {colors['border_light']};
    border-left: 3px solid {colors['primary']};
    border-radius: {px(tok.RADIUS_SM)};
}}
QFrame#statusCard[status="success"] {{ border-left-color: {tok.COLOR_SUCCESS}; }}
QFrame#statusCard[status="warning"] {{ border-left-color: #d18c1e; }}
QFrame#statusCard[status="error"] {{ border-left-color: {tok.COLOR_DANGER}; }}

QGroupBox {{
    margin-top: {px(tok.SPACE_LG)};
    padding: {px(tok.SPACE_LG)} {px(tok.SPACE_MD)} {px(tok.SPACE_MD)};
    font-weight: 600;
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    left: {px(tok.SPACE_MD)};
    padding: 0 {px(tok.SPACE_XS)};
    color: {colors['heading']};
}}

QLabel#pageTitle {{
    color: {colors['heading']};
    font-size: {pt(tok.BASE_FONT_PT_LG + 2)};
    font-weight: 700;
}}
QLabel#sectionTitle {{
    color: {colors['heading']};
    font-size: {pt(tok.BASE_FONT_PT_LG)};
    font-weight: 700;
    padding-top: {px(tok.SPACE_SM)};
    padding-bottom: {px(tok.SPACE_XS)};
}}
QLabel#sectionSubtitle, QLabel#secondaryText {{
    color: {colors['secondary']};
}}
QLabel#statusChip {{
    background-color: {colors['info_soft']};
    color: {colors['primary']};
    border-radius: {px(tok.RADIUS_SM)};
    padding: {px(tok.SPACE_XS)} {px(tok.SPACE_SM)};
}}
QLabel#statusChip[status="success"] {{ background-color: {colors['success_soft']}; color: {tok.COLOR_SUCCESS}; }}
QLabel#statusChip[status="warning"] {{ background-color: {colors['warning_soft']}; color: #8a6318; }}
QLabel#statusChip[status="error"] {{ background-color: {colors['danger_soft']}; color: {tok.COLOR_DANGER}; }}

QPushButton {{
    background-color: {colors['primary']};
    color: #ffffff;
    border: 1px solid {colors['primary_pressed']};
    border-radius: {px(tok.RADIUS_SM)};
    padding: {px(tok.SPACE_SM)} {px(tok.SPACE_LG)};
    min-height: {px(tok.BUTTON_MIN_HEIGHT_MD)};
}}
QPushButton:hover {{ background-color: {colors['primary_hover']}; }}
QPushButton:pressed {{ background-color: {colors['primary_pressed']}; }}
QPushButton:disabled {{ background-color: {colors['disabled_bg']}; border-color: {colors['border']}; color: {colors['disabled_text']}; }}
QPushButton[role="secondary"] {{ background-color: {colors['surface']}; color: {colors['primary']}; border-color: {colors['primary']}; }}
QPushButton[role="quiet"] {{ background-color: transparent; color: {colors['secondary']}; border-color: transparent; }}
QPushButton[role="danger"] {{ background-color: {tok.COLOR_DANGER}; border-color: {tok.COLOR_DANGER_HOVER}; }}
QPushButton[role="success"] {{ background-color: {tok.COLOR_SUCCESS}; border-color: {tok.COLOR_SUCCESS_HOVER}; }}

QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit, QTextEdit, QTableWidget, QTableView {{
    background-color: {colors['surface']};
    border: 1px solid {colors['border_light']};
    border-radius: {px(tok.RADIUS_SM)};
    padding: {px(tok.SPACE_XS)};
    min-height: {px(tok.INPUT_MIN_HEIGHT)};
    selection-background-color: {colors['selection']};
    selection-color: {colors['text']};
}}
QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QLineEdit:focus, QTextEdit:focus {{ border-color: {colors['primary']}; }}

QTabWidget::pane {{ border: none; background: transparent; }}
QTabBar::tab {{ background: transparent; border: none; color: {colors['secondary']}; padding: {px(tok.SPACE_SM)} {px(tok.SPACE_LG)}; margin-right: {px(tok.SPACE_XS)}; }}
QTabBar::tab:hover {{ color: {colors['primary']}; background: {colors['info_soft']}; }}
QTabBar::tab:selected {{ color: {colors['primary']}; font-weight: 700; border-bottom: 2px solid {colors['primary']}; }}

QToolBar {{ background: {colors['toolbar']}; border: none; spacing: {px(tok.SPACE_XS)}; padding: {px(tok.SPACE_XS)} {px(tok.SPACE_SM)}; }}
QToolButton {{ background: transparent; border: none; border-radius: {px(tok.RADIUS_SM)}; padding: {px(tok.SPACE_XS)}; }}
QToolButton:hover {{ background: {colors['info_soft']}; }}
QToolButton:checked {{ background: {colors['selection']}; color: {colors['primary']}; }}

QHeaderView::section {{ background: {colors['toolbar']}; color: {colors['heading']}; border: none; border-bottom: 1px solid {colors['border']}; padding: {px(tok.SPACE_SM)}; font-weight: 600; }}
QProgressBar {{ background: {colors['surface_muted']}; border: none; border-radius: {px(tok.RADIUS_SM)}; text-align: center; }}
QProgressBar::chunk {{ background: {colors['primary']}; border-radius: {px(tok.RADIUS_SM)}; }}
QScrollArea {{ border: none; background: transparent; }}
QToolTip {{ background: {colors['surface']}; color: {colors['text']}; border: 1px solid {colors['border']}; padding: {px(tok.SPACE_SM)}; }}
"""


def _light_colors():
    return {
        "primary": tok.COLOR_PRIMARY, "primary_hover": tok.COLOR_PRIMARY_HOVER,
        "primary_pressed": tok.COLOR_PRIMARY_PRESSED, "bg": tok.COLOR_BG,
        "surface": tok.COLOR_SURFACE, "surface_muted": tok.COLOR_SURFACE_MUTED,
        "toolbar": tok.COLOR_TOOLBAR_BG, "text": tok.COLOR_TEXT,
        "secondary": tok.COLOR_TEXT_SECONDARY, "heading": tok.COLOR_TEXT_HEADING,
        "border": tok.COLOR_BORDER, "border_light": tok.COLOR_BORDER_LIGHT,
        "disabled_bg": tok.COLOR_DISABLED_BG, "disabled_text": tok.COLOR_DISABLED_TEXT,
        "selection": tok.COLOR_SELECTION, "info_soft": tok.COLOR_INFO_SOFT,
        "success_soft": tok.COLOR_SUCCESS_SOFT, "warning_soft": tok.COLOR_WARNING_SOFT,
        "danger_soft": tok.COLOR_DANGER_SOFT,
    }


def _dark_colors():
    return {
        "primary": tok.COLOR_PRIMARY_HOVER, "primary_hover": "#4c91c2",
        "primary_pressed": tok.COLOR_PRIMARY_PRESSED, "bg": tok.DARK_COLOR_BG,
        "surface": tok.DARK_COLOR_BG_WHITE, "surface_muted": "#303238",
        "toolbar": "#2b2d31", "text": tok.DARK_COLOR_TEXT,
        "secondary": "#aeb4bc", "heading": "#8fc4e8",
        "border": tok.DARK_COLOR_BORDER, "border_light": "#50535a",
        "disabled_bg": "#3c3c3c", "disabled_text": "#808080",
        "selection": "#25445a", "info_soft": "#203949",
        "success_soft": "#203a2a", "warning_soft": "#4a3a1e",
        "danger_soft": "#4b2525",
    }


def set_role(widget, role):
    """Apply a semantic QSS role without embedding a stylesheet in a view."""
    widget.setProperty("role", role)
    style = widget.style()
    if style is not None:
        style.unpolish(widget)
        style.polish(widget)
    return widget


def set_status(widget, status):
    """Apply a semantic status property to a status label or card."""
    widget.setProperty("status", status)
    style = widget.style()
    if style is not None:
        style.unpolish(widget)
        style.polish(widget)
    return widget


def refresh_style(widget):
    """Reapply the current QSS on a widget after changing dynamic properties."""
    style = widget.style()
    if style is not None:
        style.unpolish(widget)
        style.polish(widget)
    return widget
