# -*- coding: utf-8 -*-
"""
Matplotlib 主题与 Figure 工厂

统一 Matplotlib 的 rcParams、颜色主题与 figure 创建，使所有图表在不同 DPI/分辨率下
保持清晰且风格一致。
"""

import matplotlib.pyplot as plt
from matplotlib.colors import to_hex
from matplotlib.figure import Figure
from matplotlib import font_manager
from pathlib import Path
import os

from app.ui import design_tokens as tok
from app.utils.ui_scaling import ui_scaling_manager

def chart_font_family():
    """Choose an installed CJK-capable font without changing global rcParams."""
    if os.name == 'nt':
        path = Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Fonts' / 'msyh.ttc'
        if path.exists():
            return font_manager.FontProperties(fname=str(path)).get_name()
    return 'DejaVu Sans'


def apply_light_theme():
    """应用浅色主题到 matplotlib rcParams（全部走 design tokens）。"""
    plt.rcParams.update({
        "axes.facecolor": tok.COLOR_CHART_BG,
        "figure.facecolor": tok.COLOR_SURFACE,
        "axes.edgecolor": tok.COLOR_BORDER,
        "axes.labelcolor": tok.COLOR_TEXT,
        "text.color": tok.COLOR_TEXT,
        "xtick.color": tok.COLOR_TEXT_SECONDARY,
        "ytick.color": tok.COLOR_TEXT_SECONDARY,
        "grid.color": tok.COLOR_CHART_GRID,
        "grid.linestyle": "-",
        "grid.alpha": 0.8,
        "axes.grid": True,
        "axes.grid.axis": "both",
        # Matplotlib SVG looks up a named weight; the CSS-style string "600"
        # is not a valid FontProperties weight there and raises KeyError.
        "axes.titleweight": "semibold",
        "axes.labelsize": tok.BASE_FONT_PT,
        "legend.frameon": False,
        "figure.dpi": tok.MPL_BASE_DPI,
        "savefig.dpi": tok.MPL_BASE_DPI,
    })


def apply_dark_theme():
    """预留暗色主题（仍走 token）。"""
    plt.rcParams.update({
        "axes.facecolor": tok.DARK_COLOR_BG,
        "figure.facecolor": tok.DARK_COLOR_BG_WHITE,
        "axes.edgecolor": tok.DARK_COLOR_BORDER,
        "axes.labelcolor": tok.DARK_COLOR_TEXT,
        "text.color": tok.DARK_COLOR_TEXT,
        "xtick.color": tok.DARK_COLOR_TEXT,
        "ytick.color": tok.DARK_COLOR_TEXT,
        "grid.color": tok.DARK_COLOR_BORDER,
        "grid.linestyle": "--",
        "grid.alpha": 0.5,
        "axes.grid": True,
        "axes.grid.axis": "y",
        "figure.dpi": tok.MPL_BASE_DPI,
        "savefig.dpi": tok.MPL_BASE_DPI,
    })


def create_figure(base_inches=tok.MPL_FIGSIZE_MD, base_dpi=tok.MPL_BASE_DPI, theme="light"):
    """
    Create a screen-oriented Matplotlib Figure that follows UI scaling.

    This factory is for interactive canvases. Use
    ``app.services.plot_export_service.export_figure`` for saved output; that
    service clones the figure and applies an explicit physical width so export
    dimensions do not depend on the monitor DPI or display resolution.

    Args:
        base_inches: Base interactive figure size in inches, default (8, 6).
        base_dpi: Base interactive DPI, default 100.
        theme: 'light' or 'dark'.

    Returns:
        matplotlib.figure.Figure
    """
    sf = ui_scaling_manager.scale_factor
    fs = ui_scaling_manager.font_scale

    # figsize 随屏幕缩放，但不过度放大
    scaled_w = base_inches[0] * min(sf, 1.5)
    scaled_h = base_inches[1] * min(sf, 1.5)
    dpi = min(int(base_dpi * fs), tok.MPL_MAX_DPI)

    if theme == "dark":
        facecolor = tok.DARK_COLOR_BG_WHITE
        edgecolor = tok.DARK_COLOR_BORDER
    else:
        facecolor = tok.COLOR_BG_WHITE
        edgecolor = tok.COLOR_BORDER

    fig = Figure(figsize=(scaled_w, scaled_h), dpi=dpi,
                 facecolor=facecolor, edgecolor=edgecolor)
    return fig


def get_color_palette(n=None, palette=None):
    """Return a list of ``n`` colours drawn from ``palette``.

    ``palette`` defaults to ``tok.PALETTE_DEFAULT`` (the centralized token)
    and falls back to the colour-blind safe palette when ``n`` exceeds the
    primary palette length.
    """
    primary = list(palette or tok.PALETTE_DEFAULT)
    if n is None:
        return primary
    if n <= len(primary):
        return primary[:n]
    # Fall back to color-blind palette for the extra slots.
    fallback = list(tok.COLOR_BLIND_PALETTE)
    out = []
    for i in range(n):
        out.append(primary[i] if i < len(primary) else fallback[(i - len(primary)) % len(fallback)])
    return out


def get_series_style(index, point_count=None):
    """Return a color-blind-aware line style for a plotted series.

    The ten Okabe-Ito colors carry the primary distinction. When a chart has
    more series than hues, line style and sparse markers add a second cue.
    ``point_count`` is used only to keep those markers from crowding dense
    spectra; it never samples or changes the data.
    """
    colors = tok.COLOR_BLIND_PALETTE
    line_styles = ("-", "--", "-.", ":")
    markers = ("o", "s", "^", "D", "v", "P", "X")
    index = max(0, int(index))
    group, color_index = divmod(index, len(colors))
    style = {
        "color": colors[color_index],
        "linestyle": line_styles[group % len(line_styles)],
        "marker": "None",
    }
    if group:
        style["marker"] = markers[(group - 1) % len(markers)]
        count = max(1, int(point_count or 1))
        style["markevery"] = max(1, count // 12)
        style["markersize"] = 3.5
    return style


def apply_axes_style(ax, *, grid=True):
    """Apply the shared light chart finish without changing plot semantics."""
    from matplotlib.text import Text
    for artist in ax.findobj(match=Text):
        artist.set_fontfamily(['DejaVu Sans', chart_font_family()])
    ax.set_facecolor(tok.COLOR_CHART_BG)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["bottom"].set_color(tok.COLOR_BORDER)
    ax.spines["left"].set_color(tok.COLOR_BORDER)
    ax.tick_params(colors=tok.COLOR_TEXT_SECONDARY, which="both")
    if grid:
        ax.grid(True, linestyle="-", linewidth=0.6, color=tok.COLOR_CHART_GRID,
                alpha=0.8, zorder=0)
    else:
        ax.grid(False)


def collect_plot_style_metadata(ax, *, category_order=None, colormap=None):
    """Capture rendered series colors and supported categorical/map context.

    This inspects artists after plotting, so the sidecar describes the colors
    that were actually drawn rather than merely the palette that was intended.
    """
    series = []

    for line in ax.lines:
        label = line.get_label()
        if not label or label.startswith("_"):
            continue
        try:
            color = to_hex(line.get_color(), keep_alpha=False)
        except (TypeError, ValueError):
            continue
        series.append({
            "label": str(label),
            "color": color,
            "linestyle": str(line.get_linestyle()),
            "marker": str(line.get_marker()),
        })

    for collection in ax.collections:
        label = collection.get_label()
        if not label or label.startswith("_"):
            continue
        facecolors = collection.get_facecolors()
        if len(facecolors):
            try:
                color = to_hex(facecolors[0], keep_alpha=False)
            except (TypeError, ValueError):
                continue
            series.append({"label": str(label), "color": color, "artist": "collection"})

    patches = list(ax.patches)
    if patches:
        x_labels = [item.get_text() for item in ax.get_xticklabels()]
        y_labels = [item.get_text() for item in ax.get_yticklabels()]
        patch_labels = x_labels if len(x_labels) == len(patches) else y_labels
        if len(patch_labels) == len(patches):
            for label, patch in zip(patch_labels, patches):
                try:
                    color = to_hex(patch.get_facecolor(), keep_alpha=False)
                except (TypeError, ValueError):
                    continue
                if label:
                    series.append({"label": str(label), "color": color, "artist": "patch"})

    actual_cmap = colormap
    if actual_cmap is None:
        mapped = [artist.get_cmap().name for artist in [*ax.images, *ax.collections]
                  if hasattr(artist, "get_cmap") and artist.get_cmap() is not None]
        if mapped:
            actual_cmap = mapped[0]

    palette_hex = {color.lower() for color in tok.COLOR_BLIND_PALETTE}
    palette_name = (
        tok.MPL_PLOT_PALETTE_NAME
        if series and all(item["color"].lower() in palette_hex for item in series)
        else "mixed/custom" if series else None
    )
    metadata = {
        "palette": palette_name,
        "series_colors": series,
        "series_color_map": {item["label"]: item["color"] for item in series},
    }
    if category_order is not None:
        metadata["category_order"] = [str(label) for label in category_order]
    if actual_cmap is not None:
        metadata["colormap"] = str(actual_cmap)
    return metadata
