# -*- coding: utf-8 -*-
"""
Design Token 单点真相

所有 UI 尺寸、间距、颜色、字号的唯一来源。视图层禁止直接硬编码像素值，
应通过 app.utils.ui_scaling 中的 scaled_px / scaled_pt 等函数从 token 派生。
"""

# =============================================================================
# 基准
# =============================================================================
BASE_WIDTH = 1920          # 设计基准屏幕宽度
BASE_HEIGHT = 1080         # 设计基准屏幕高度
BASE_DPI = 96              # 设计基准 DPI

# =============================================================================
# 字体
# =============================================================================
FONT_FAMILY_UI = ("Microsoft YaHei UI", "Segoe UI", "Arial", "sans-serif")
FONT_FAMILY_CODE = ("Consolas", "Monaco", "monospace")
BASE_FONT_PT = 10
BASE_FONT_PT_SM = 8
BASE_FONT_PT_MD = 10
BASE_FONT_PT_LG = 11

# =============================================================================
# 间距（单位 px，作为缩放基数）
# =============================================================================
SPACE_XXS = 2
SPACE_XS = 4
SPACE_SM = 6
SPACE_MD = 8
SPACE_LG = 12
SPACE_XL = 16
SPACE_XXL = 24

# =============================================================================
# 组件尺寸基数
# =============================================================================
ROW_HEIGHT_BASE = 22
ROW_HEIGHT_MD = 24
ROW_HEIGHT_LG = 28
ROW_HEIGHT_XL = 32

LABEL_MIN_WIDTH = 78
LABEL_MIN_WIDTH_MD = 90
LABEL_MIN_WIDTH_SM = 64
CONTROL_MIN_WIDTH_SM = 80
CONTROL_MIN_WIDTH = 120
CONTROL_MIN_WIDTH_MD = 140
CONTROL_MIN_WIDTH_LG = 160
COMBOBOX_MIN_WIDTH = 132
COMBOBOX_MIN_WIDTH_MD = 150
COMBOBOX_MIN_WIDTH_LG = 180
DIALOG_MIN_WIDTH = 400
DIALOG_MIN_HEIGHT = 300

BUTTON_MIN_WIDTH = 70
BUTTON_MIN_WIDTH_MD = 90
BUTTON_MIN_HEIGHT = 22
BUTTON_MIN_HEIGHT_MD = 26

ICON_SIZE_SM = 16
ICON_SIZE_MD = 20
ICON_SIZE_LG = 24

# =============================================================================
# 表单/行尺寸基数（单行原则：标签与控件同行）
# =============================================================================
FORM_ROW_HEIGHT = ROW_HEIGHT_MD
FORM_LABEL_MIN_WIDTH = LABEL_MIN_WIDTH
FORM_CONTROL_MIN_WIDTH = CONTROL_MIN_WIDTH
INPUT_MIN_HEIGHT = ROW_HEIGHT_MD

# =============================================================================
# 布局间距别名基数
# =============================================================================
GROUP_BOX_CONTENT_MARGIN = SPACE_SM
GROUP_BOX_TITLE_MARGIN = SPACE_XS
WORKFLOW_PAGE_MARGIN = SPACE_XS
DIALOG_CONTENT_MARGIN = SPACE_LG
DIALOG_SECTION_SPACING = SPACE_XL
DIALOG_SCREEN_MARGIN = 80
DIALOG_FOOTER_HEIGHT = 48
DIALOG_INDENT = SPACE_XXL

# =============================================================================
# 网格布局列宽基数（数据分区等参数网格）
# =============================================================================
GRID_LABEL_COL_WIDTH_SM = 56
GRID_CONTROL_COL_WIDTH_SM = 88
GRID_SINGLE_LABEL_COL_WIDTH = 72
GRID_SINGLE_CONTROL_COL_WIDTH = 110

# =============================================================================
# 文本域/弹窗排版基数
# =============================================================================
TEXT_EDIT_MAX_HEIGHT_SM = 96
TEXT_EDIT_MAX_HEIGHT_MD = 120
TEXT_EDIT_MAX_HEIGHT_LG = 150
TEXT_EDIT_MAX_HEIGHT_XL = 200
DIALOG_TITLE_FONT_PT = 12
DIALOG_HEADER_FONT_PT = 14

# =============================================================================
# 对话框尺寸基数（宽，高）——所有 fit_window_to_screen 调用统一引用
# =============================================================================
DIALOG_SIZE_PROGRESS = (480, 120)
DIALOG_SIZE_IMPORT = (520, 260)
DIALOG_SIZE_CONFIG = (520, 360)
DIALOG_SIZE_MD = (520, 420)
DIALOG_SIZE_PARAM_MD = (500, 620)
DIALOG_SIZE_PARAM_LG = (520, 650)
DIALOG_SIZE_LG = (620, 520)
DIALOG_SIZE_CODE_PREVIEW = (620, 420)
DIALOG_SIZE_CODE_RESULT = (820, 620)
DIALOG_SIZE_QUALITY = (700, 600)
DIALOG_SIZE_XL = (720, 640)
DIALOG_SIZE_WORKBENCH = (1000, 700)
DIALOG_SIZE_PCA = (1000, 800)

# =============================================================================
# 面板/窗口尺寸基数
# =============================================================================
MAIN_WINDOW_BASE_WIDTH = 2000
MAIN_WINDOW_BASE_HEIGHT = 1200
MAIN_WINDOW_MIN_WIDTH = 1200
MAIN_WINDOW_MIN_HEIGHT = 800

WORKFLOW_PANEL_MIN_WIDTH = 460
WORKFLOW_PANEL_PREFERRED_WIDTH = 600
WORKFLOW_PANEL_MAX_WIDTH = 760

RESULT_TABLE_HEIGHT_SM = 160
RESULT_TABLE_HEIGHT_MD = 180
RESULT_TABLE_HEIGHT_LG = 210
RESULT_TABLE_HEIGHT_XL = 250

PREPROCESSING_TABS_MIN_HEIGHT = 360

# =============================================================================
# Matplotlib 图表基数
# =============================================================================
MPL_FIGSIZE_SM = (5, 5)
MPL_FIGSIZE_MD = (8, 6)
MPL_FIGSIZE_LG = (10, 6)
MPL_FIGSIZE_XL = (12, 8)
MPL_BASE_DPI = 100
MPL_MAX_DPI = 150

# Export widths are reference profiles for journal-oriented figures. Journals
# can differ; exported figures should be checked against the target journal.
MPL_EXPORT_SINGLE_COLUMN_MM = 89.0
MPL_EXPORT_SINGLE_COLUMN_HEIGHT_MM = 59.33
MPL_EXPORT_DOUBLE_COLUMN_MM = 183.0
MPL_EXPORT_DOUBLE_COLUMN_HEIGHT_MM = 122.0
MPL_EXPORT_MIN_WIDTH_MM = 20.0
MPL_EXPORT_MAX_WIDTH_MM = 300.0
MPL_EXPORT_MIN_HEIGHT_MM = 20.0
MPL_EXPORT_MAX_HEIGHT_MM = 300.0
MPL_EXPORT_DEFAULT_DPI = 300

# =============================================================================
# 圆角
# =============================================================================
RADIUS_SM = 4
RADIUS_MD = 6

# =============================================================================
# 颜色（浅色主题）
# =============================================================================
COLOR_PRIMARY = "#2f6f9f"
COLOR_PRIMARY_HOVER = "#357daf"
COLOR_PRIMARY_PRESSED = "#285d82"

COLOR_SUCCESS = "#4CAF50"
COLOR_SUCCESS_HOVER = "#43A047"
COLOR_DANGER = "#f44336"
COLOR_DANGER_HOVER = "#e53935"
COLOR_WARNING = "#ff9800"

COLOR_BG = "#f6f7f9"
COLOR_BG_WHITE = "#ffffff"
COLOR_BG_ALT = "#edf1f5"
COLOR_TEXT = "#20242a"
COLOR_TEXT_SECONDARY = "#6d7680"
COLOR_TEXT_HEADING = "#1f4e79"

COLOR_BORDER = "#d7dce2"
COLOR_BORDER_LIGHT = "#cfd6de"
COLOR_BORDER_DISABLED = "#b7c0c9"

COLOR_DISABLED_BG = "#c8d0d8"
COLOR_DISABLED_TEXT = "#6d7680"

# 暗色主题预留（暂不启用，但 token 已准备）
DARK_COLOR_BG = "#1e1e1e"
DARK_COLOR_BG_WHITE = "#252526"
DARK_COLOR_TEXT = "#d4d4d4"
DARK_COLOR_BORDER = "#3c3c3c"

# Color-blind safe palette (10 distinct hues, Okabe-Ito). Shared by scientific
# chart series and the optional color-blind-safe UI mode.
COLOR_BLIND_PALETTE = (
    "#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442",
    "#0072B2", "#D55E00", "#CC79A7", "#999999", "#882255",
)
MPL_PLOT_PALETTE_NAME = "Okabe-Ito"
MPL_CONFUSION_CMAP = "Blues"

# Sequential colormaps, ordered by perceptual uniformity.
CMAP_SEQUENTIAL = ('viridis', 'magma', 'plasma', 'inferno', 'Blues', 'Greens')
CMAP_DIVERGING = ('RdBu', 'coolwarm', 'BrBG')
CMAP_QUALITATIVE = ('Set1', 'Set2', 'tab10')

# Default palette used by ``mpl_theme.get_color_palette`` when the number of
# distinct series exceeds the length of the explicit palette.
PALETTE_DEFAULT = (
    '#4F46E5',  # indigo
    '#06B6D4',  # cyan
    '#10B981',  # emerald
    '#F59E0B',  # amber
    '#EF4444',  # red
    '#8B5CF6',  # violet
    '#EC4899',  # pink
    '#14B8A6',  # teal
)

# Chart canvas colours used by mpl_theme.apply_light_theme.
PALETTE_FOREGROUND = '#222222'
PALETTE_BACKGROUND = '#FFFFFF'
PALETTE_GRID = '#E0E0E0'
PALETTE_AXIS = '#666666'
PALETTE_SUBTITLE = '#444444'
PALETTE_LEGEND_FRAME = '#F5F5F5'

# =============================================================================
# Semantic UI colors
# =============================================================================
# These aliases keep view-level styles readable and make palette changes local.
COLOR_SURFACE = COLOR_BG_WHITE
COLOR_SURFACE_RAISED = "#ffffff"
COLOR_SURFACE_MUTED = COLOR_BG_ALT
COLOR_FOCUS_RING = "#7bb7e2"
COLOR_SELECTION = "#dcecf8"
COLOR_INFO = COLOR_PRIMARY
COLOR_INFO_SOFT = "#eaf3fa"
COLOR_SUCCESS_SOFT = "#eaf7ef"
COLOR_WARNING_SOFT = "#fff5df"
COLOR_DANGER_SOFT = "#fdeceb"
COLOR_TOOLBAR_BG = "#f0f4f8"
COLOR_CHART_BG = "#fbfdff"
COLOR_CHART_GRID = "#dfe8f0"

DEFAULT_CMAP = 'viridis'
MPL_SPECTRA_HEATMAP_CMAP = DEFAULT_CMAP
COLOR_SHADOW = "rgba(31, 78, 121, 0.10)"

# Semantic button roles.
BUTTON_PRIMARY = "primary"
BUTTON_SECONDARY = "secondary"
BUTTON_QUIET = "quiet"
BUTTON_DANGER = "danger"
BUTTON_SUCCESS = "success"

# Status roles shared by dataset, task, and processing feedback.
STATUS_EMPTY = "empty"
STATUS_LOADING = "loading"
STATUS_READY = "ready"
STATUS_SUCCESS = "success"
STATUS_WARNING = "warning"
STATUS_ERROR = "error"
