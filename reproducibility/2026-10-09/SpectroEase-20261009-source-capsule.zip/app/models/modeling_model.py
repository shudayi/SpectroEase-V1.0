# app/models/modeling_model.py

class ModelingModel:
    def __init__(self):
        self.model = None
        self.trained_model = None
        # Keep the raw estimator for optimizer/export compatibility and the
        # fitted spectral prediction contract for inference/evaluation.
        self.fitted_predictor = None
        self.prediction_result = None
        self.analyzer = None
        self.cv_train_sample_ids = None
        self.cv_test_sample_ids = None
        self.cv_train_physical_sample_ids = None
        self.cv_test_physical_sample_ids = None
        self.cv_train_group_ids = None
        self.cv_test_group_ids = None
        self.cv_group_validation = False
        self.cv_feature_names = None
        self.cv_input_representation = 'fitted_feature_matrix'
        self.parameters = {}
        self.method = ''
        self.X_train = None
        self.y_train = None
        self.evaluation_results = {}
        self.analysis_type = ''

    def set_model(self, model):
        self.model = model

    def set_parameters(self, params: dict):
        self.parameters = params

    def set_method(self, method: str):
        self.method = method

    def set_training_data(self, X_train, y_train):
        self.X_train = X_train
        self.y_train = y_train

    def set_evaluation_results(self, results: dict):
        """Store model evaluation results"""
        self.evaluation_results = results

    def set_analysis_type(self, analysis_type: str):
        """Set the analysis type ('qualitative' or 'quantitative')"""
        self.analysis_type = analysis_type

    def set_model_data(self, model_data):
        """Store bundled modeling result data."""
        self.model_data = model_data

    def clear_prediction_state(self):
        """Drop fitted transforms and predictions when their data scope changes."""
        self.fitted_predictor = None
        self.prediction_result = None
        self.analyzer = None
        self.trained_model = None
        self.model = None
        self.model_data = None

    def get_model_data(self):
        """Retrieve bundled modeling result data."""
        return getattr(self, 'model_data', None)

    def has_model_data(self):
        """Check whether bundled modeling result data exists."""
        return getattr(self, 'model_data', None) is not None
