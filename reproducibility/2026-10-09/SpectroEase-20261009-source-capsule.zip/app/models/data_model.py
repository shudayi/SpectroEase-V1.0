# app/models/data_model.py

import threading
import uuid
from numbers import Integral

import pandas as pd
import numpy as np
from app.utils.label_processor import EnhancedLabelProcessor
from app.utils.column_mapping import spectral_column_positions

class DataModel:
    def __init__(self, logger=None):
        """Initializes the DataModel."""
        # Reentrant lock protecting compound reads/writes of shared state.
        # Keep lock hold times short: do not invoke long computations while
        # holding the lock.
        self._lock = threading.RLock()

        self.data = None
        self.partitioned_data = None
        self.preprocessed_data = None
        self.file_path = None
        self.label_processor = EnhancedLabelProcessor()
        self._x = None
        self._y = None
        self.features = None
        self.X_processed = None

        # Attributes for direct access, compatible with existing code
        self.X_train = None
        self.y_train = None
        self.X_test = None
        self.y_test = None
        self.X_train_selected = None
        self.X_test_selected = None
        self.selected_features = None
        self.label_mapping = None
        self.task_type = None
        # Internal record identity is deliberately kept in the index only. It
        # is not a physical sample/group identifier and is never a feature.
        self._row_keys = None
        self._row_key_data_ref = None
        self._state_revision = 0
        self.row_alignment_verified = False
        # Explicit physical identifiers are metadata, never spectral features.
        self.sample_id_column_index = None
        self.group_id_column_index = None
        self.sample_id_train = None
        self.sample_id_test = None
        self.group_id_train = None
        self.group_id_test = None
        self.group_validation = False
        # Provenance belongs to the partition matrices themselves. A new
        # verified split starts from source spectra; replacing X through
        # preprocessing changes this to a prepared feature boundary.
        self.partitioned_input_representation = 'raw_spectrum'
        self.partitioned_preprocessing_methods = []

        # Index of the column that contains the target/label values.
        # Defaults to 0 to match the legacy convention used by the project.
        self.label_column_index = 0
        self.wavelength_column_positions = None

    def _split_features_label(self):
        """Split ``self.data`` into features (X) and label (y) using
        ``self.label_column_index``.

        Returns:
            Tuple[Optional[pd.DataFrame], Optional[pd.Series]]: (X, y).
            If ``self.data`` has only one column, the single column is
            returned as X and y is ``None``.
        """
        data = self.data
        if data is None:
            return None, None

        n_cols = data.shape[1]
        if n_cols <= 1:
            return data.copy(), None

        idx = self.label_column_index
        if not isinstance(idx, int) or idx < 0 or idx >= n_cols:
            raise ValueError(
                f"label_column_index {idx!r} is out of range for data with {n_cols} columns"
            )

        y = data.iloc[:, idx]
        identity_positions = {
            value for value in (
                self.sample_id_column_index, self.group_id_column_index
            ) if isinstance(value, int)
        }
        feature_positions = spectral_column_positions(
            data, idx, identity_positions, self.wavelength_column_positions
        )
        X = data.iloc[:, feature_positions].copy()
        return X, y

    def _new_row_keys(self, data):
        return pd.Index(
            [f"rk_{uuid.uuid4().hex}" for _ in range(len(data))],
            name="_row_key",
        )

    def _clear_derived_state(self, clear_partition=True):
        """Drop every cache that was derived from a previous dataset/split."""
        self._x = None
        self._y = None
        self.preprocessed_data = None
        self.X_processed = None
        self.features = None
        self.X_train_selected = None
        self.X_test_selected = None
        self.selected_features = None
        if clear_partition:
            self.partitioned_data = None
            self.partitioned_input_representation = 'raw_spectrum'
            self.partitioned_preprocessing_methods = []
            self.X_train = None
            self.y_train = None
            self.X_test = None
            self.y_test = None
            self.label_mapping = None
            self.label_metadata = None
            self.row_alignment_verified = False
            self.sample_id_train = self.sample_id_test = None
            self.group_id_train = self.group_id_test = None
            self.sample_id_column_index = self.group_id_column_index = None
            self.group_validation = False

    def _ensure_row_keys(self):
        """Refresh keys after legacy callers assign ``data`` directly."""
        data = self.data
        if data is None:
            self._row_keys = None
            self._row_key_data_ref = None
            return None
        if data is not self._row_key_data_ref or self._row_keys is None or len(self._row_keys) != len(data):
            self._clear_derived_state(clear_partition=True)
            self.wavelength_column_positions = None
            self._row_keys = self._new_row_keys(data)
            self._row_key_data_ref = data
            self._state_revision += 1
        return self._row_keys

    def get_row_keys(self):
        """Return an immutable copy of the opaque internal row identities."""
        with self._lock:
            keys = self._ensure_row_keys()
            return None if keys is None else keys.copy()

    def get_state_revision(self):
        """Revision used to discard preprocessing results from stale workers."""
        with self._lock:
            self._ensure_row_keys()
            return self._state_revision

    def set_label_column_index(self, index):
        """Set the column index to use as the target/label.

        Resets derived X/y caches so the next call to ``get_X``/``get_y``
        reflects the new index.
        """
        with self._lock:
            if index == self.label_column_index:
                return
            sample_column = self.sample_id_column_index
            group_column = self.group_id_column_index
            wavelength_positions = None
            if (
                self.data is not None
                and isinstance(index, Integral)
                and not isinstance(index, bool)
                and 0 <= int(index) < self.data.shape[1]
            ):
                identity_positions = {sample_column, group_column} - {None}
                selected = self.wavelength_column_positions
                if selected is not None:
                    selected = [
                        position for position in selected
                        if position != int(index) and position not in identity_positions
                    ] or None
                try:
                    wavelength_positions = spectral_column_positions(
                        self.data, int(index), identity_positions, selected
                    )
                except ValueError:
                    # Preserve the legacy setter behavior for an unusable
                    # target; get_X() will reject the invalid mapping.
                    wavelength_positions = None
            self.label_column_index = index
            self._clear_derived_state(clear_partition=True)
            self.sample_id_column_index = sample_column
            self.group_id_column_index = group_column
            self.wavelength_column_positions = wavelength_positions
            self._state_revision += 1
            self.task_type = None
            self.detect_and_set_task_type()

    def set_data(self, data):
        with self._lock:
            self.data = data
            self.wavelength_column_positions = None
            self._clear_derived_state(clear_partition=True)
            self.sample_id_column_index = None
            self.group_id_column_index = None
            self.sample_id_train = self.sample_id_test = None
            self.group_id_train = self.group_id_test = None
            self.group_validation = False
            self._row_keys = self._new_row_keys(data) if data is not None else None
            self._row_key_data_ref = data
            self._state_revision += 1
            self.task_type = None
            self.detect_and_set_task_type()

    def set_column_mapping(self, mapping, sample_column=None, group_column=None):
        """Validate first, then replace roles and invalidate all derived state.

        The original table and opaque row identities survive a mapping change.
        """
        with self._lock:
            self._ensure_row_keys()
            if self.data is None or not isinstance(mapping, dict):
                raise ValueError('Load data before confirming column roles.')
            target = mapping.get('label_column', self.label_column_index)
            positions = spectral_column_positions(
                self.data, target, (sample_column, group_column),
                mapping.get('wavelength_columns'),
            )
            self._clear_derived_state(clear_partition=True)
            self.label_column_index = int(target)
            self.wavelength_column_positions = positions
            self.sample_id_column_index = sample_column
            self.group_id_column_index = group_column
            self._state_revision += 1
            self.task_type = None
            self.detect_and_set_task_type()

    def detect_and_set_task_type(self):
        """Automatically detect the task type from the label column.

        If ``self.task_type`` is already set to a non-empty value the user
        override is preserved; otherwise the detector runs on the configured
        label column and stores the result in ``self.task_type``.
        """
        if self.task_type:
            return
        if self.data is None or len(self.data.columns) == 0:
            return
        try:
            from config.settings import Settings
            settings = Settings()
        except Exception:
            settings = None
        try:
            from app.utils.label_processor import EnhancedLabelProcessor
            processor = EnhancedLabelProcessor(settings=settings)
            label_idx = getattr(self, 'label_column_index', 0)
            if 0 <= label_idx < self.data.shape[1]:
                y_series = self.data.iloc[:, label_idx]
                self.task_type = processor.detect_task_type(y_series)
        except Exception:
            self.task_type = None

    def get_data(self):
        with self._lock:
            return self.data

    def get_X(self):
        """Returns the feature data (X)."""
        with self._lock:
            self._ensure_row_keys()
            if self._x is None and self.data is not None:
                self._x, _ = self._split_features_label()
            return self._x

    def get_y(self):
        """Returns the label data (y)."""
        with self._lock:
            self._ensure_row_keys()
            if self._y is None and self.data is not None:
                _, self._y = self._split_features_label()
            return self._y

    def get_wavelengths(self):
        """Returns the wavelengths, which are the column names of the feature data."""
        with self._lock:
            self._ensure_row_keys()
            X = self._x
            if X is None and self.data is not None:
                X, _ = self._split_features_label()
            if X is not None:
                return X.columns
            return None

    def get_features(self):
        """Return the engineered features snapshot under the model lock."""
        with self._lock:
            return self.features

    def has_data(self):
        with self._lock:
            return self.data is not None

    def set_partitioned_data(self, partitioned_data, task_type=None,
                             label_metadata=None, label_processor=None):
        """
        Sets the partitioned data and updates direct access attributes
        for backward compatibility.
        """
        with self._lock:
            current_keys = self._ensure_row_keys()
            # A new split invalidates preview/preprocessing/selection state,
            # even when it has the same row counts as the previous split.
            self._clear_derived_state(clear_partition=True)
            self._state_revision += 1
            self.partitioned_data = partitioned_data
            if partitioned_data:
                if 'wavelength_column_positions' in partitioned_data:
                    self.wavelength_column_positions = list(partitioned_data['wavelength_column_positions'])
                self.partitioned_input_representation = 'raw_spectrum'
                self.partitioned_preprocessing_methods = []
                self.X_train = partitioned_data.get('X_train')
                self.y_train = partitioned_data.get('y_train')
                self.X_test = partitioned_data.get('X_test')
                self.y_test = partitioned_data.get('y_test')
                self.label_mapping = partitioned_data.get('label_mapping')
                self.sample_id_column_index = partitioned_data.get('sample_id_column_index')
                self.group_id_column_index = partitioned_data.get('group_id_column_index')
                self.sample_id_train = partitioned_data.get('sample_id_train')
                self.sample_id_test = partitioned_data.get('sample_id_test')
                self.group_id_train = partitioned_data.get('group_id_train')
                self.group_id_test = partitioned_data.get('group_id_test')
                self.group_validation = bool(partitioned_data.get('group_validation', False))
                self.partitioned_data['input_representation'] = self.partitioned_input_representation
                self.partitioned_data['preprocessing_methods'] = []
                train_keys = partitioned_data.get('train_row_keys')
                test_keys = partitioned_data.get('test_row_keys')
                self.row_alignment_verified = (
                    current_keys is not None
                    and train_keys is not None
                    and test_keys is not None
                    and isinstance(self.X_train, pd.DataFrame)
                    and isinstance(self.X_test, pd.DataFrame)
                    and isinstance(self.y_train, pd.Series)
                    and isinstance(self.y_test, pd.Series)
                    and len(train_keys) == len(set(train_keys))
                    and len(test_keys) == len(set(test_keys))
                    and not (set(train_keys) & set(test_keys))
                    and set(train_keys) | set(test_keys) == set(current_keys)
                    and self.X_train.index.equals(pd.Index(train_keys, name='_row_key'))
                    and self.X_test.index.equals(pd.Index(test_keys, name='_row_key'))
                    and self.y_train.index.equals(self.X_train.index)
                    and self.y_test.index.equals(self.X_test.index)
                )
            else:
                self.partitioned_input_representation = 'raw_spectrum'
                self.partitioned_preprocessing_methods = []
                self.X_train = None
                self.y_train = None
                self.X_test = None
                self.y_test = None
                self.label_mapping = None
                self.row_alignment_verified = False
                self.sample_id_train = self.sample_id_test = None
                self.group_id_train = self.group_id_test = None
                self.sample_id_column_index = self.group_id_column_index = None
                self.group_validation = False
            if task_type is not None:
                self.task_type = task_type
            if label_metadata is not None:
                self.label_metadata = label_metadata
            if label_processor is not None:
                self.label_processor = label_processor

    def get_partitioned_data(self):
        with self._lock:
            if self.has_split_attempt() and not self.has_verified_split():
                raise ValueError(
                    "The current split has no verified internal row_key alignment; recreate the split before modeling."
                )
            return self.partitioned_data

    def get_partitioned_features(self):
        """Return (X_train, X_test) snapshot under the model lock."""
        with self._lock:
            if self.has_split_attempt() and not self.has_verified_split():
                raise ValueError(
                    "The current split has no verified internal row_key alignment; recreate the split before modeling."
                )
            return self.X_train, self.X_test

    def has_partitioned_data(self):
        with self._lock:
            return self.partitioned_data is not None

    def has_split_attempt(self):
        """Return whether partition state exists, including legacy direct fields.

        Older callers sometimes assign X_train/X_test/y_train/y_test directly
        without setting ``partitioned_data``. Those values must not make a
        preview operation treat the model as wholly unsplit.
        """
        with self._lock:
            return self.partitioned_data is not None or any(
                getattr(self, name, None) is not None
                for name in ('X_train', 'y_train', 'X_test', 'y_test')
            )

    def has_verified_split(self):
        """Return whether a complete split record passed row-key validation."""
        with self._lock:
            return (
                self.partitioned_data is not None
                and self.row_alignment_verified
                and all(getattr(self, name, None) is not None
                        for name in ('X_train', 'y_train', 'X_test', 'y_test'))
            )

    def set_preprocessed_data(self, preprocessed_data):
        with self._lock:
            self.preprocessed_data = preprocessed_data

    def get_preprocessed_data(self):
        with self._lock:
            return self.preprocessed_data

    def has_preprocessed_data(self):
        with self._lock:
            return self.preprocessed_data is not None

    def set_preprocessing_result(self, result):
        """Atomically apply a preprocessing result dict on the UI thread.

        ``result`` is expected to contain the keys returned by
        ``PreprocessingController._apply_preprocessing_async``:
        ``X_train``, ``X_test``, ``X_processed``, ``preprocessed_data``,
        and ``applied_methods_log``.
        """
        with self._lock:
            if self.has_split_attempt() and not self.has_verified_split():
                return False
            expected_revision = result.get('state_revision')
            if expected_revision is not None and expected_revision != self._state_revision:
                return False

            if result.get('is_partitioned'):
                if not self.has_verified_split():
                    return False
                if self.row_alignment_verified:
                    train_keys = self.partitioned_data.get('train_row_keys')
                    test_keys = self.partitioned_data.get('test_row_keys')
                    X_train_result = result.get('X_train')
                    X_test_result = result.get('X_test')
                    if (
                        not isinstance(X_train_result, pd.DataFrame)
                        or not isinstance(X_test_result, pd.DataFrame)
                        or not X_train_result.index.equals(pd.Index(train_keys, name='_row_key'))
                        or not X_test_result.index.equals(pd.Index(test_keys, name='_row_key'))
                    ):
                        return False

            self.X_train = result.get('X_train', self.X_train)
            self.X_test = result.get('X_test', self.X_test)
            self.y_train = result.get('y_train', self.y_train)
            self.y_test = result.get('y_test', self.y_test)
            self.X_processed = result.get('X_processed', self.X_processed)
            self.preprocessed_data = result.get('preprocessed_data', self.preprocessed_data)
            if result.get('is_partitioned'):
                # This API replaces the partition matrices but does not attach
                # a replayable preprocessing pipeline to them. Preserve the
                # method names as provenance and disable raw-input prediction.
                self.partitioned_input_representation = 'prepared:preprocessed'
                applied_methods = result.get('applied_methods_log') or result.get('methods') or []
                for method in applied_methods:
                    method = str(method)
                    if method not in self.partitioned_preprocessing_methods:
                        self.partitioned_preprocessing_methods.append(method)
            if self.X_train is not None:
                self.features = list(self.X_train.columns)
            # Keep the partitioned flag consistent with available train/test data.
            if self.X_test is not None and self.partitioned_data is not None:
                self.partitioned_data = dict(self.partitioned_data)
                self.partitioned_data['X_train'] = self.X_train
                self.partitioned_data['X_test'] = self.X_test
                self.partitioned_data['y_train'] = self.y_train
                self.partitioned_data['y_test'] = self.y_test
                self.partitioned_data['input_representation'] = self.partitioned_input_representation
                self.partitioned_data['preprocessing_methods'] = list(
                    self.partitioned_preprocessing_methods
                )
            return True

    def clear_data(self):
        """Clears all data attributes."""
        with self._lock:
            self.data = None
            self.wavelength_column_positions = None
            self.partitioned_data = None
            self.preprocessed_data = None
            self.file_path = None
            self._x = None
            self._y = None
            self.features = None
            self.X_processed = None
            self.X_train = None
            self.y_train = None
            self.X_test = None
            self.y_test = None
            self.X_train_selected = None
            self.X_test_selected = None
            self.selected_features = None
            self.label_mapping = None
            self.label_metadata = None
            self.task_type = None
            self._row_keys = None
            self._row_key_data_ref = None
            self.row_alignment_verified = False
            self.sample_id_column_index = self.group_id_column_index = None
            self.sample_id_train = self.sample_id_test = None
            self.group_id_train = self.group_id_test = None
            self.partitioned_input_representation = 'raw_spectrum'
            self.partitioned_preprocessing_methods = []
            self.group_validation = False
            self._state_revision += 1
