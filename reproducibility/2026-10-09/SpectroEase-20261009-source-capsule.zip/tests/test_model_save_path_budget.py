"""Windows path-budget regressions for non-destructive estimator saving."""
from pathlib import Path
import pickle
import numpy as np
import pytest
from app.services.onnx_service import ONNXService


def units(value):
    return len(str(value).encode('utf-16-le')) // 2


@pytest.mark.parametrize('labels', [('x'*300, 'y'*300), ('光谱😀'*100, '方法😀'*100)])
def test_long_labels_fit_model_and_sidecar_path_budget(tmp_path, labels):
    directory = tmp_path / ('destination_' + 'd'*30)
    service = ONNXService(str(directory))
    name, method = labels
    path = service.auto_save_model({'marker': 23}, np.zeros((3, 2)), name, method)
    assert path is not None
    artifact = Path(path)
    sidecar = artifact.with_name(artifact.stem + '_info.txt')
    assert units(artifact.resolve()) <= 259
    assert units(sidecar.resolve()) <= 259
    assert sidecar.exists()
    saved = pickle.loads(artifact.read_bytes())
    assert saved['model_name'] == name and saved['method'] == method
    assert saved['model'] == {'marker': 23}


def test_overlong_directory_fails_with_explicit_reason(tmp_path):
    service = ONNXService(str(tmp_path))
    service.save_directory = str(tmp_path / ('d'*230))
    with pytest.raises(ValueError, match='directory is too long'):
        service._model_filename('model', 'method')
