"""Full-feature audit regression checks for actual preprocessing dispatch."""
import numpy as np
import pandas as pd
import pytest
from scipy.signal import savgol_filter
from app.services.preprocessing_service import PreprocessingService
from app.services.preprocessing.alignment import _dtw_alignment,_shift_segment
from app.services.feature_selection_service import FeatureSelectionService
from app.controllers.preprocessing_controller import PreprocessingController
from app.models.data_model import DataModel
from app.utils.exceptions import PreprocessingError,FeatureSelectionError

@pytest.fixture
def spectra():
    axis=np.linspace(0,1,41)
    rng=np.random.default_rng(13)
    arr=np.array([2+i*.1+axis+np.exp(-((axis-.45)/.1)**2)+rng.normal(0,.03,41) for i in range(12)])
    return pd.DataFrame(arr,index=[f'row-{i}' for i in range(12)],columns=950+5*np.arange(41))

@pytest.mark.parametrize('method,params',[
    ('Savitzky-Golay Filter',{}),('Moving Average',{}),('Median Filter',{}),('Median Filter',{'window_size':4}),
    ('Gaussian Smooth',{}),('Wavelet Smooth',{}),('Baseline Correction',{}),('Baseline (ALS)',{}),
    ('Baseline (airPLS)',{}),('Despiking',{}),('Despiking',{'method':'Local Z-score'}),('Denoising',{}),
    ('Standard Normal Variate (SNV)',{}),('Robust Normal Variate (RNV)',{}),('Vector Normalization',{}),
    ('Area Normalization',{}),('Maximum Normalization',{}),('First Derivative',{}),('Second Derivative',{}),
    ('Third Derivative',{}),('Savitzky-Golay Derivative',{}),('Finite Difference',{}),('Gap-Segment Derivative',{})])
def test_samplewise_operations_are_batch_independent(spectra,method,params):
    service=PreprocessingService()
    full=service.apply_method(spectra,method,params)
    solo=service.apply_method(spectra.iloc[[3]],method,params)
    np.testing.assert_allclose(full.iloc[3],solo.iloc[0],atol=1e-10,rtol=1e-10)
    assert full.index.equals(spectra.index) and full.columns.equals(spectra.columns)
    assert np.isfinite(full).all().all()

def test_sg_matches_scipy_wavelength_axis(spectra):
    result=PreprocessingService().apply_method(spectra,'Savitzky-Golay Filter',{})
    np.testing.assert_allclose(result,savgol_filter(spectra.to_numpy(),11,2,axis=1),atol=1e-12)

def test_msc_removes_affine_scatter():
    r=np.array([1.,2.,4.,8.,3.,2.])
    X=pd.DataFrame([r,2*r+1,.5*r-.2])
    expected=np.tile(X.mean(axis=0).values,(len(X),1))
    actual=PreprocessingService().apply_method(X,'Multiplicative Scatter Correction (MSC)',{})
    np.testing.assert_allclose(actual,expected,atol=1e-11)

def test_emsc_affine_plus_polynomial_recovers_mean_reference():
    axis=np.linspace(-1,1,41)
    ref=2+np.exp(-((axis-.2)/.15)**2)
    X=pd.DataFrame([ref,2*ref+.2+.3*axis,.5*ref-.1+.2*axis**2])
    actual=PreprocessingService().apply_method(X,'Extended Multiplicative Scatter Correction (EMSC)',{})
    np.testing.assert_allclose(actual,np.tile(X.mean().values,(len(X),1)),atol=1e-10)

@pytest.mark.parametrize('name', ['ALS','airPLS'])
def test_baseline_submethod_is_not_polynomial_alias(spectra,name):
    service=PreprocessingService()
    assert not np.allclose(service.apply_method(spectra,'Baseline Correction',{'method':name}),
                           service.apply_method(spectra,'Baseline Correction',{'method':'Polynomial'}))

@pytest.mark.parametrize('method,params',[
    ('Gaussian Smooth',{'sigma':0}),('Moving Average',{'window_size':51}),('Finite Difference',{'step':0}),
    ('Gap-Segment Derivative',{'gap':0}),('Min-Max Scale',{'feature_range':[1,0]}),
    ('Savitzky-Golay Filter',{'window_length':51}),('Wavelet Smooth',{'level':20}),
    ('Despiking',{'method':'unknown'}),('Outlier Detection',{'method':'Isolation'}),
    ('Orthogonal Signal Correction (OSC)',{})])
def test_invalid_or_unimplemented_algorithms_fail_clearly(spectra,method,params):
    with pytest.raises(PreprocessingError):
        PreprocessingService().apply_method(spectra,method,params)

def test_outlier_removal_retains_surviving_row_identity(spectra):
    result=PreprocessingService().apply_method(spectra,'Outlier Detection',{'method':'IQR'})
    assert list(result.index)==[key for key in spectra.index if key in result.index]

@pytest.mark.parametrize('method,params,expected',[
    ('smoothing',{'method':'Median'},'Median Filter'),('smoothing',{'method':'Moving Avg'},'Moving Average'),
    ('smoothing',{'method':'Wavelet'},'Wavelet Smooth'),('standardization',{'method':'Robust'},'Robust Scale'),
    ('normalization',{'method':'Vector'},'Vector Normalization'),('normalization',{'method':'Area'},'Area Normalization'),
    ('normalization',{'method':'Maximum'},'Maximum Normalization'),('derivative',{'order':2},'Second Derivative'),
    ('derivative',{'order':3},'Third Derivative'),('baseline_correction',{'method':'ALS'},'Baseline (ALS)'),
    ('baseline_correction',{'method':'airPLS'},'Baseline (airPLS)'),('denoising',{},'Denoising'),
    ('alignment',{'method':'COW'},'COW (Correlation Optimized Warping)')])
def test_controller_resolves_selected_variant(method,params,expected):
    controller=PreprocessingController(None,None,None,{})
    assert controller._resolve_service_method(method,{method:params})==expected

def test_preview_failure_is_atomic(spectra):
    controller=PreprocessingController(None,None,None,{})
    original=spectra.copy(deep=True)
    with pytest.raises(PreprocessingError):
        controller._process_data(spectra,['First Derivative','smoothing'],{'smoothing':{'window_length':51}})
    pd.testing.assert_frame_equal(spectra,original)

def test_array_alignment_reference_and_path_aggregation(spectra):
    reference=spectra.iloc[0].to_numpy()
    output=PreprocessingService().apply_method(spectra,'Peak Alignment',{'reference':reference})
    assert output.shape==spectra.shape
    target=np.array([0.,0.,1.,2.,3.])
    ref=np.array([0.,1.,2.,3.])
    warped,path=_dtw_alignment(ref,target,window=2)
    np.testing.assert_allclose(warped,ref)
    assert {i for i,j in path}==set(range(len(ref)))

def test_alignment_edges_never_wrap():
    np.testing.assert_array_equal(_shift_segment(np.array([1.,2.,3.,4.]),1),[1,1,2,3])
    np.testing.assert_array_equal(_shift_segment(np.array([1.,2.,3.,4.]),-1),[2,3,4,4])

def test_small_continuous_regression_target_is_not_classification():
    assert not FeatureSelectionService()._is_classification_task(pd.Series(np.linspace(.2,1.9,18)))
    assert FeatureSelectionService()._is_classification_task(pd.Series(['A','B']*9))

@pytest.mark.parametrize('method',['PLSR','Peak Detection','Wavelet'])
def test_mounted_feature_selection_preserves_rows_and_exact_test_columns(spectra,method):
    y=pd.Series(np.linspace(.2,1.9,len(spectra)),index=spectra.index)
    params={'k':5}
    result=FeatureSelectionService().apply_method(spectra.iloc[:9],y.iloc[:9],spectra.iloc[9:],method,params)
    assert result['X_train_selected'].index.equals(spectra.iloc[:9].index)
    assert result['X_test_selected'].equals(spectra.iloc[9:][result['selected_features']])
    assert params=={'k':5}
    assert np.isfinite(result['feature_importance']).all()

def test_feature_count_zero_is_not_silent_all_features(spectra):
    with pytest.raises(FeatureSelectionError):
        FeatureSelectionService().apply_method(spectra,np.arange(len(spectra))+.3,method='Wavelet',params={'k':0})

def test_legacy_plugin_dictionary_protocol_gets_declared_defaults(spectra):
    class Plugin:
        def get_params_info(self):return {'amount':{'default':2.}}
        def apply(self,data,params):return data+params['amount']
    service=PreprocessingService({'audit-legacy-dictionary':Plugin()})
    result=service.apply_method(spectra,'audit-legacy-dictionary',{'amount':3.})
    np.testing.assert_allclose(result,spectra+3.)


def test_mutual_information_failure_is_not_uniform_success(spectra,monkeypatch):
    def fail(*args,**kwargs):raise ValueError('audit-estimator-failure')
    monkeypatch.setattr('sklearn.feature_selection.mutual_info_regression',fail)
    with pytest.raises(FeatureSelectionError,match='audit-estimator-failure'):
        FeatureSelectionService()._calculate_mutual_info_importance_enhanced(spectra,np.arange(len(spectra))+.1,'regression')


def test_zero_mutual_information_remains_zero(spectra,monkeypatch):
    monkeypatch.setattr('sklearn.feature_selection.mutual_info_regression',lambda *args,**kwargs:np.zeros(spectra.shape[1]))
    scores=FeatureSelectionService()._calculate_mutual_info_importance_enhanced(spectra,np.arange(len(spectra))+.1,'regression')
    np.testing.assert_array_equal(scores,np.zeros(spectra.shape[1]))


def test_async_record_preserves_dynamic_method_and_parameters():
    controller=PreprocessingController(None,None,None,{})
    assert controller.preprocessing_model.applied_methods=={}
    result={'success':True,'methods':['smoothing','normalization','derivative'],
            'applied_methods_log':['Median Filter','Area Normalization','Second Derivative'],
            'params_dict':{'smoothing':{'method':'Median','window_length':7},
                           'normalization':{'method':'Area'},'derivative':{'order':2}}}
    assert controller.record_applied_methods(result)
    assert 'Median' in controller.preprocessing_model.applied_methods['Median Filter']
    assert "'order': 2" in controller.preprocessing_model.applied_methods['Second Derivative']
    before=controller.preprocessing_model.applied_methods.copy()
    assert not controller.record_applied_methods({'success':False})
    assert controller.preprocessing_model.applied_methods==before
