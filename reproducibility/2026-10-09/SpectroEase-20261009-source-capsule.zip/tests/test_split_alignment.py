"""S26-31 regression checks for internal row identity and split alignment."""

import pandas as pd
import pytest

from app.models.data_model import DataModel
from app.services.data_service import DataService
from app.controllers.data_controller import DataController
from app.controllers.preprocessing_controller import PreprocessingController


def _source_frame():
    # Duplicate, non-monotonic source indices must not be used as identities.
    return pd.DataFrame(
        {
            'label': [0, 1] * 8,
            's0': [float(i) for i in range(16)],
            's1': [float(i * i) for i in range(16)],
        },
        index=[7, 2, 7, 1, 4, 4, 9, 0, 2, 8, 3, 3, 5, 6, 1, 0],
    )


def _split(model, service=None, random_state=19):
    data = model.get_data()
    y = data.iloc[:, 0]
    processor = model.label_processor
    processed, metadata = processor.process_labels_smart(y, 'classification')
    params = {
        'target_column': 0,
        'task_type': 'classification',
        'processed_labels': processed,
        'original_labels': y,
        'label_metadata': metadata,
        'row_keys': list(model.get_row_keys()),
        'test_size': 0.25,
        'random_state': random_state,
        'shuffle': True,
    }
    result = (service or DataService({})).partition_data(data, 'Train-Test Split', params)
    DataController._validate_partition_result(
        DataController.__new__(DataController), result,
        expected_row_keys=params['row_keys'],
        expected_feature_columns=['s0', 's1'],
    )
    return result


def _install_unverified_direct_split_fields(model):
    """Simulate legacy code that assigned split arrays without a partition record."""
    model.X_train = pd.DataFrame({'s0': [1, 2], 's1': [2, 4]})
    model.y_train = pd.Series([0, 1])
    model.X_test = pd.DataFrame({'s0': [3], 's1': [9]})
    model.y_test = pd.Series([0])
    assert model.partitioned_data is None
    assert not model.row_alignment_verified


def test_row_keys_are_opaque_internal_index_and_survive_duplicate_source_index():
    model = DataModel()
    frame = _source_frame()
    model.set_data(frame)

    keys = model.get_row_keys()
    assert len(keys) == len(frame)
    assert keys.is_unique
    assert keys.name == '_row_key'
    assert not set(keys) & set(frame.index)
    assert '_row_key' not in model.get_X().columns
    assert model.get_X().index.equals(frame.index)


def test_legacy_direct_data_assignment_gets_internal_keys_before_split():
    model = DataModel()
    model.data = _source_frame()  # MainController.check_data_ready legacy path
    keys = model.get_row_keys()
    assert len(keys) == len(model.data)
    assert keys.is_unique and keys.name == '_row_key'
    assert model.partitioned_data is None


def test_builtin_split_preserves_exact_x_y_row_key_order_and_full_partition():
    model = DataModel()
    frame = _source_frame()
    model.set_data(frame)
    keys = model.get_row_keys()
    result = _split(model)

    train_keys = result['train_row_keys']
    test_keys = result['test_row_keys']
    assert set(train_keys).isdisjoint(test_keys)
    assert set(train_keys) | set(test_keys) == set(keys)
    assert result['X_train'].index.tolist() == train_keys
    assert result['y_train'].index.tolist() == train_keys
    assert result['X_test'].index.tolist() == test_keys
    assert result['y_test'].index.tolist() == test_keys
    assert result['X_train'].index.name == result['X_test'].index.name == '_row_key'
    assert list(result['X_train'].columns) == ['s0', 's1']
    assert '_row_key' not in result['X_train'].columns

    expected_by_key = dict(zip(keys, frame['s0'].to_list()))
    for row_key, value in result['X_train']['s0'].items():
        assert value == expected_by_key[row_key]
    for row_key, value in result['X_test']['s0'].items():
        assert value == expected_by_key[row_key]


def test_kfold_result_uses_the_same_internal_key_contract():
    model = DataModel()
    model.set_data(_source_frame())
    data = model.get_data()
    y = data.iloc[:, 0]
    processed, metadata = model.label_processor.process_labels_smart(y, 'classification')
    keys = model.get_row_keys()
    result = DataService({}).partition_data(data, 'K-Fold', {
        'target_column': 0,
        'task_type': 'classification',
        'processed_labels': processed,
        'original_labels': y,
        'label_metadata': metadata,
        'row_keys': list(keys),
        'n_splits': 4,
        'shuffle': True,
        'random_state': 23,
    })
    assert set(result['train_row_keys']).isdisjoint(result['test_row_keys'])
    assert set(result['train_row_keys']) | set(result['test_row_keys']) == set(keys)
    assert result['X_train'].index.equals(result['y_train'].index)
    assert result['X_test'].index.equals(result['y_test'].index)


def test_import_and_resplit_invalidate_model_derived_caches():
    model = DataModel()
    first = _source_frame()
    model.set_data(first)
    first_keys = model.get_row_keys()
    split1 = _split(model, random_state=19)
    model.set_partitioned_data(split1)
    assert model.row_alignment_verified

    model.preprocessed_data = pd.DataFrame({'cached': [1]})
    model.X_processed = model.preprocessed_data
    model.X_train_selected = pd.DataFrame({'selected': [1]})
    model.selected_features = ['selected']
    split2 = _split(model, random_state=21)
    model.set_partitioned_data(split2)
    assert model.preprocessed_data is None
    assert model.X_processed is None
    assert model.X_train_selected is None
    assert model.selected_features is None
    assert model.row_alignment_verified

    model.preprocessed_data = pd.DataFrame({'old': [1]})
    model.X_train_selected = pd.DataFrame({'old': [1]})
    second = _source_frame().assign(s1=lambda value: value['s1'] + 1000)
    model.set_data(second)
    assert model.get_row_keys().is_unique
    assert not set(first_keys) & set(model.get_row_keys())
    assert model.partitioned_data is None
    assert model.preprocessed_data is None
    assert model.X_train_selected is None
    assert not model.row_alignment_verified


def test_stale_preprocessing_result_is_discarded_after_new_split():
    model = DataModel()
    model.set_data(_source_frame())
    stale_revision = model.get_state_revision()
    split = _split(model)
    model.set_partitioned_data(split)
    accepted = model.set_preprocessing_result({
        'success': True,
        'is_partitioned': True,
        'state_revision': stale_revision,
        'X_train': split['X_train'],
        'X_test': split['X_test'],
    })
    assert accepted is False
    assert model.preprocessed_data is None


def test_unverified_legacy_partition_cannot_be_cached_or_used_for_modeling():
    from types import SimpleNamespace
    from app.views.main_window import MainWindow

    model = DataModel()
    model.set_data(_source_frame())
    model.set_partitioned_data({
        'X_train': pd.DataFrame({'s0': [1, 2]}),
        'y_train': pd.Series([0, 1]),
        'X_test': pd.DataFrame({'s0': [3]}),
        'y_test': pd.Series([0]),
    })
    assert not model.row_alignment_verified
    assert model.set_preprocessing_result({
        'success': True, 'is_partitioned': True,
        'X_train': pd.DataFrame({'s0': [10, 20]}),
        'X_test': pd.DataFrame({'s0': [30]}),
        'preprocessed_data': pd.DataFrame({'s0': [10, 20, 30]}),
    }) is False
    assert model.preprocessed_data is None
    with pytest.raises(ValueError, match='verified internal row_key'):
        model.get_partitioned_data()

    errors = []
    fake_window = SimpleNamespace(
        controller=SimpleNamespace(
            data_controller=SimpleNamespace(data_model=model),
        ),
        display_error=errors.append,
    )
    assert MainWindow.get_current_feature_data(fake_window) is None
    assert errors and 'Recreate the split' in errors[0]


def test_analyze_entry_blocks_unverified_partition_before_model_cache_write():
    from types import SimpleNamespace
    from app.views.main_window import MainWindow

    model = DataModel()
    model.set_data(_source_frame())
    model.set_partitioned_data({
        'X_train': pd.DataFrame({'s0': [1, 2]}),
        'y_train': pd.Series([0, 1]),
        'X_test': pd.DataFrame({'s0': [3]}),
        'y_test': pd.Series([0]),
    })
    assert model.has_partitioned_data()
    assert not model.row_alignment_verified

    cached = SimpleNamespace(
        X_train='old-X-train', X_test='old-X-test',
        y_train='old-y-train', y_test='old-y-test',
    )
    fake_window = SimpleNamespace(
        controller=SimpleNamespace(
            data_controller=SimpleNamespace(data_model=model),
            modeling_controller=SimpleNamespace(modeling_model=cached),
        ),
    )
    fake_window._require_verified_model_split = (
        lambda data_model, action, **kwargs:
        MainWindow._require_verified_model_split(fake_window, data_model, action, **kwargs)
    )

    with pytest.raises(ValueError, match='verified internal row alignment.*Recreate the split'):
        MainWindow._prepare_modeling_data(fake_window, 'Quantitative')

    assert cached.X_train == 'old-X-train'
    assert cached.X_test == 'old-X-test'
    assert cached.y_train == 'old-y-train'
    assert cached.y_test == 'old-y-test'


def test_modeling_pca_entry_blocks_unverified_partition_before_feature_cache_write():
    from types import SimpleNamespace
    from app.views.main_window import MainWindow

    model = DataModel()
    model.set_data(_source_frame())
    model.set_partitioned_data({
        'X_train': pd.DataFrame({'s0': [1, 2]}),
        'y_train': pd.Series([0, 1]),
        'X_test': pd.DataFrame({'s0': [3]}),
        'y_test': pd.Series([0]),
    })
    model.X_train_selected = 'old-selected-train'
    model.X_test_selected = 'old-selected-test'

    errors = []
    selected = {'sentinel': 'keep'}
    fake_window = SimpleNamespace(
        controller=SimpleNamespace(
            data_controller=SimpleNamespace(data_model=model),
        ),
        display_error=errors.append,
        feature_data_options={'selected_features': selected},
        current_feature_source='original',
    )
    fake_window._require_verified_model_split = (
        lambda data_model, action, **kwargs:
        MainWindow._require_verified_model_split(fake_window, data_model, action, **kwargs)
    )

    MainWindow._run_modeling_pca(fake_window, 2)

    assert errors and 'verified internal row alignment' in errors[0]
    assert 'Recreate the split' in errors[0]
    assert model.X_train_selected == 'old-selected-train'
    assert model.X_test_selected == 'old-selected-test'
    assert fake_window.feature_data_options['selected_features'] is selected
    assert fake_window.current_feature_source == 'original'


def test_direct_legacy_split_fields_are_blocked_at_modeling_and_selection_entries():
    from types import SimpleNamespace
    from app.views.main_window import MainWindow

    model = DataModel()
    model.set_data(_source_frame())
    _install_unverified_direct_split_fields(model)
    model.X_train_selected = 'old-selected-train'
    model.X_test_selected = 'old-selected-test'

    cached = SimpleNamespace(
        X_train='old-X-train', X_test='old-X-test',
        y_train='old-y-train', y_test='old-y-test',
    )
    errors = []
    fit_calls = []
    feature_options = {'selected_features': {'old': 'selection-cache'}}
    fake_window = SimpleNamespace(
        controller=SimpleNamespace(
            data_controller=SimpleNamespace(data_model=model),
            modeling_controller=SimpleNamespace(modeling_model=cached),
            feature_selection_controller=SimpleNamespace(
                apply_method=lambda *args, **kwargs: fit_calls.append((args, kwargs))
            ),
        ),
        display_error=errors.append,
        feature_data_options=feature_options,
        current_feature_source='original',
        feature_method=SimpleNamespace(currentData=lambda: 'PLSR'),
        feature_param_spin=SimpleNamespace(value=lambda: 3),
        apply_feature_selection=lambda: fit_calls.append('delegated'),
    )
    fake_window._require_verified_model_split = (
        lambda data_model, action, **kwargs:
        MainWindow._require_verified_model_split(fake_window, data_model, action, **kwargs)
    )

    with pytest.raises(ValueError, match='verified internal row alignment.*Recreate the split'):
        MainWindow._prepare_modeling_data(fake_window, 'Quantitative')
    MainWindow._run_modeling_pca(fake_window, 2)
    MainWindow._apply_supervised_feature_selection(fake_window, 'PLSR', 3)
    MainWindow.apply_feature_selection(fake_window)

    assert len(errors) == 3
    assert all('Recreate the split' in error for error in errors)
    assert cached.X_train == 'old-X-train'
    assert cached.X_test == 'old-X-test'
    assert cached.y_train == 'old-y-train'
    assert cached.y_test == 'old-y-test'
    assert model.X_train_selected == 'old-selected-train'
    assert model.X_test_selected == 'old-selected-test'
    assert feature_options['selected_features'] == {'old': 'selection-cache'}
    assert fake_window.current_feature_source == 'original'
    assert not fit_calls


def test_feature_selection_without_any_split_shows_create_split_prompt():
    from types import SimpleNamespace
    from app.views.main_window import MainWindow

    model = DataModel()
    model.set_data(_source_frame())
    assert not model.has_partitioned_data()
    assert all(getattr(model, name) is None for name in ('X_train', 'y_train', 'X_test', 'y_test'))
    errors = []
    fit_calls = []
    fake_window = SimpleNamespace(
        controller=SimpleNamespace(
            data_controller=SimpleNamespace(data_model=model),
            feature_selection_controller=SimpleNamespace(
                apply_method=lambda *args, **kwargs: fit_calls.append((args, kwargs))
            ),
        ),
        display_error=errors.append,
        feature_data_options={'selected_features': None},
        current_feature_source='original',
        feature_method=SimpleNamespace(currentData=lambda: 'PLSR'),
        feature_param_spin=SimpleNamespace(value=lambda: 3),
    )
    fake_window._require_verified_model_split = (
        lambda data_model, action, **kwargs:
        MainWindow._require_verified_model_split(fake_window, data_model, action, **kwargs)
    )

    MainWindow.apply_feature_selection(fake_window)

    assert errors and 'Create the split before feature selection' in errors[0]
    assert not fit_calls


def test_public_preprocessing_api_rejects_direct_split_fields_without_mutation():
    model = DataModel()
    model.set_data(_source_frame())
    _install_unverified_direct_split_fields(model)
    model.preprocessed_data = pd.DataFrame({'preview-cache': [99]})
    model.X_processed = pd.DataFrame({'processed-cache': [88]})
    old_train = model.X_train.copy()
    old_test = model.X_test.copy()
    old_y_train = model.y_train.copy()
    old_y_test = model.y_test.copy()
    old_preview = model.preprocessed_data
    old_processed = model.X_processed

    controller = PreprocessingController(None, None, model, {})
    invoked_methods = []
    controller.preprocessing_service.apply_method = (
        lambda *args, **kwargs: invoked_methods.append((args, kwargs))
    )

    assert model.set_preprocessing_result({
        'success': True,
        'is_partitioned': False,
        'state_revision': model.get_state_revision(),
        'preprocessed_data': pd.DataFrame({'would-overwrite': [1]}),
    }) is False
    assert controller.apply_preprocessing(
        ['Standard Normal Variate (SNV)'], {}
    ) is False

    pd.testing.assert_frame_equal(model.X_train, old_train)
    pd.testing.assert_frame_equal(model.X_test, old_test)
    pd.testing.assert_series_equal(model.y_train, old_y_train)
    pd.testing.assert_series_equal(model.y_test, old_y_test)
    assert model.preprocessed_data is old_preview
    assert model.X_processed is old_processed
    assert not invoked_methods


@pytest.mark.parametrize('partial_state', ['only_y_train', 'only_X_train', 'invalid_partition'])
def test_feature_engineering_pca_entries_block_partial_split_before_fit_or_cache(
        partial_state, monkeypatch):
    from types import SimpleNamespace
    import app.views.main_window as main_window_module
    import app.services.feature_extraction_service as extraction_module
    from app.views.main_window import MainWindow

    model = DataModel()
    model.set_data(_source_frame())
    if partial_state == 'only_y_train':
        model.y_train = pd.Series([0, 1])
    elif partial_state == 'only_X_train':
        model.X_train = pd.DataFrame({'s0': [1, 2], 's1': [2, 4]})
    else:
        model.set_partitioned_data({
            'X_train': pd.DataFrame({'s0': [1, 2], 's1': [2, 4]}),
            'y_train': pd.Series([0, 1]),
        })

    model.X_train_selected = 'old-selected-train'
    model.X_test_selected = 'old-selected-test'
    model.selected_features = ['old-feature']
    model.preprocessed_data = pd.DataFrame({'preview-cache': [99]})
    model.X_processed = pd.DataFrame({'processed-cache': [88]})
    old_preview = model.preprocessed_data
    old_processed = model.X_processed

    errors = []
    exploratory_calls = []
    modeling_calls = []
    feature_cache = {
        'pca_features': 'old-pca-cache',
        'selected_features': {'old': 'selection-cache'},
    }
    pca_fit_calls = []

    class FakeProgressDialog:
        def __init__(self, *args, **kwargs):
            pass

        def show(self):
            pass

        def close(self):
            pass

    monkeypatch.setattr(main_window_module, 'ProgressDialog', FakeProgressDialog)
    monkeypatch.setattr(main_window_module, 'run_heavy', lambda function, **kwargs: function())
    fake_extraction_service = SimpleNamespace(
        extract_pca_features=lambda *args, **kwargs: (
            pca_fit_calls.append((args, kwargs)) or None
        ),
    )
    monkeypatch.setattr(
        extraction_module, 'feature_extraction_service',
        fake_extraction_service, raising=False,
    )

    fake_window = SimpleNamespace(
        controller=SimpleNamespace(
            data_controller=SimpleNamespace(data_model=model),
        ),
        display_error=errors.append,
        feature_data_options=feature_cache,
        current_feature_source='original',
        current_spectra=_source_frame().iloc[:, 1:].to_numpy(),
        feature_method=SimpleNamespace(currentData=lambda: 'PCA'),
        feature_param_spin=SimpleNamespace(value=lambda: 2),
        feature_extraction_service=SimpleNamespace(
            run_feature_extraction=lambda *args, **kwargs: exploratory_calls.append((args, kwargs))
        ),
        _run_modeling_pca=lambda *args, **kwargs: modeling_calls.append((args, kwargs)),
        apply_feature_engineering=lambda: MainWindow.apply_feature_engineering(fake_window),
    )
    fake_window._require_verified_model_split = (
        lambda data_model, action, **kwargs:
        MainWindow._require_verified_model_split(fake_window, data_model, action, **kwargs)
    )

    # Exercise the live button route, the exploratory PCA method directly, and
    # the separately mounted feature-extraction signal handler.
    MainWindow._on_feature_btn_clicked(fake_window)
    MainWindow._run_exploratory_pca(fake_window, 2)
    MainWindow.handle_feature_extraction(fake_window, 'pca', {'n_components': 2})

    assert len(errors) == 3
    assert all('Recreate the split' in error for error in errors)
    assert not exploratory_calls
    assert not modeling_calls
    assert not pca_fit_calls
    assert model.X_train_selected == 'old-selected-train'
    assert model.X_test_selected == 'old-selected-test'
    assert model.selected_features == ['old-feature']
    assert model.preprocessed_data is old_preview
    assert model.X_processed is old_processed
    assert feature_cache == {
        'pca_features': 'old-pca-cache',
        'selected_features': {'old': 'selection-cache'},
    }
    assert fake_window.current_feature_source == 'original'


def test_feature_engineering_button_keeps_exploratory_pca_when_split_is_absent():
    from types import SimpleNamespace
    from app.views.main_window import MainWindow

    model = DataModel()
    model.set_data(_source_frame())
    exploratory_calls = []
    fake_window = SimpleNamespace(
        controller=SimpleNamespace(data_controller=SimpleNamespace(data_model=model)),
        feature_method=SimpleNamespace(currentData=lambda: 'PCA'),
        feature_param_spin=SimpleNamespace(value=lambda: 3),
        _run_exploratory_pca=lambda n_components: exploratory_calls.append(n_components),
        display_error=lambda _message: pytest.fail('unsplit exploratory PCA was blocked'),
        apply_feature_engineering=lambda: MainWindow.apply_feature_engineering(fake_window),
    )
    fake_window._require_verified_model_split = (
        lambda data_model, action, **kwargs:
        MainWindow._require_verified_model_split(fake_window, data_model, action, **kwargs)
    )

    MainWindow._on_feature_btn_clicked(fake_window)

    assert exploratory_calls == [3]


def test_feature_selection_controller_pca_api_blocks_unverified_split_fields():
    from types import SimpleNamespace
    from app.controllers.feature_selection_controller import FeatureSelectionController

    model = DataModel()
    model.set_data(_source_frame())
    model.y_train = pd.Series([0, 1])
    model.X_train_selected = 'old-selected-train'
    model.selected_features = ['old-feature']

    errors = []
    plugin_calls = []
    view = SimpleNamespace(
        display_error=errors.append,
        display_message=lambda *_args: pytest.fail('PCA plugin route should have been blocked'),
    )
    controller = FeatureSelectionController(view, None, model, {})
    controller.feature_selection_service.plugins['Unsupervised PCA'] = SimpleNamespace(
        select_features=lambda **kwargs: plugin_calls.append(kwargs)
    )

    result = controller.apply_feature_selection('Unsupervised PCA', {})

    assert result is None
    assert errors and 'Recreate the split' in errors[0]
    assert not plugin_calls
    assert model.X_train_selected == 'old-selected-train'
    assert model.selected_features == ['old-feature']


def test_feature_extraction_service_pca_api_blocks_partial_split_fields(monkeypatch):
    from app.services.feature_extraction_service import FeatureExtractionService
    import app.services.feature_extraction_service as extraction_module

    model = DataModel()
    model.set_data(_source_frame())
    model.X_train = pd.DataFrame({'s0': [1, 2], 's1': [2, 4]})

    errors = []
    plugin_calls = []

    class SpyPlugin:
        def __init__(self):
            plugin_calls.append('constructed')

        def select_features(self, *args, **kwargs):
            plugin_calls.append((args, kwargs))

    monkeypatch.setattr(extraction_module, 'UnsupervisedPCAPlugin', SpyPlugin)
    monkeypatch.setattr(
        extraction_module.QMessageBox, 'critical',
        lambda *args, **kwargs: errors.append(args),
    )
    service = FeatureExtractionService(model, logger=None)

    service.run_feature_extraction('PCA', {'n_components': 2})

    assert not plugin_calls
    assert errors and 'Recreate the split' in errors[0][-1]


class _BadResetIndexPlugin:
    def partition(self, combined, params):
        X = combined.drop(columns=['label'])
        y = combined['label']
        return {
            'X_train': X.iloc[:8].reset_index(drop=True),
            'X_test': X.iloc[8:].reset_index(drop=True),
            'y_train': y.iloc[:8].reset_index(drop=True),
            'y_test': y.iloc[8:].reset_index(drop=True),
        }


def test_plugin_that_resets_split_indexes_is_rejected_for_overlapping_keys():
    model = DataModel()
    model.set_data(_source_frame())
    data = model.get_data()
    y = data.iloc[:, 0]
    processed, metadata = model.label_processor.process_labels_smart(y, 'classification')
    params = {
        'target_column': 0,
        'task_type': 'classification',
        'processed_labels': processed,
        'original_labels': y,
        'label_metadata': metadata,
        'row_keys': list(model.get_row_keys()),
    }
    with pytest.raises(ValueError, match='duplicate or overlapping row keys'):
        DataService({'Reset index': _BadResetIndexPlugin()}).partition_data(
            data, 'Reset index', params
        )


def test_partitioned_preprocessing_allows_samplewise_and_rejects_cohort_fit():
    model = DataModel()
    model.set_data(_source_frame())
    model.set_partitioned_data(_split(model))
    controller = PreprocessingController(None, None, model, {})

    safe = controller._apply_preprocessing_async(
        ['Standard Normal Variate (SNV)'], {}
    )
    assert safe['success']
    assert safe['X_train'].index.equals(model.X_train.index)
    assert safe['X_test'].index.equals(model.X_test.index)
    assert model.set_preprocessing_result(safe)
    assert model.partitioned_input_representation == 'prepared:preprocessed'
    assert model.partitioned_preprocessing_methods == ['Standard Normal Variate (SNV)']
    assert model.partitioned_data['input_representation'] == 'prepared:preprocessed'

    for method, params in (
        ('scatter_correction', {'scatter_correction': {'method': 'MSC'}}),
        ('Extended Multiplicative Scatter Correction (EMSC)', {}),
        ('scatter_correction', {'scatter_correction': {'method': 'OSC'}}),
        ('Standard Scale', {}),
        ('Min-Max Scale', {}),
        ('Peak Alignment', {}),
        ('Outlier Detection', {}),
    ):
        original_train = model.X_train.copy()
        original_preprocessed = model.preprocessed_data.copy()
        result = controller.apply_preprocessing([method], params)
        assert result is False
        pd.testing.assert_frame_equal(model.X_train, original_train)
        pd.testing.assert_frame_equal(model.preprocessed_data, original_preprocessed)

    # Recreating a split replaces the matrices and resets their provenance.
    model.set_partitioned_data(_split(model, random_state=23))
    assert model.partitioned_input_representation == 'raw_spectrum'
    assert model.partitioned_preprocessing_methods == []


def test_unpartitioned_preview_is_cleared_and_cannot_be_applied_after_split():
    model = DataModel()
    model.set_data(_source_frame())
    controller = PreprocessingController(None, None, model, {})
    preview = controller._apply_preprocessing_async(['Standard Normal Variate (SNV)'], {})
    assert preview['success']
    assert model.set_preprocessing_result(preview)
    assert model.preprocessed_data is not None

    model.set_partitioned_data(_split(model))
    assert model.preprocessed_data is None
    assert model.X_processed is None
    assert model.row_alignment_verified


def test_active_data_controller_split_passes_keys_and_invalidates_view_caches(monkeypatch):
    import app.controllers.data_controller as data_controller_module

    class View:
        def __init__(self):
            self.invalidations = 0
            self.messages = []

        def invalidate_dataset_feature_state(self):
            self.invalidations += 1

        def display_message(self, message, title='Information'):
            self.messages.append((message, title))

        def display_error(self, message):
            self.messages.append((message, 'Error'))

    class Dialog:
        def __init__(self, **kwargs):
            self.partitioned_data = kwargs['partitioned_data']

        def exec_(self):
            return 0

    monkeypatch.setattr(data_controller_module, 'DataPartitioningResultsDialog', Dialog)
    view = View()
    controller = DataController(view, None, {})
    controller.data_model.set_data(_source_frame())
    controller.data_model.preprocessed_data = pd.DataFrame({'stale': [1]})
    controller.data_model.X_train_selected = pd.DataFrame({'stale': [1]})

    result = controller.apply_data_partitioning(
        'Train-Test Split',
        {'target_column': 0, 'test_size': 0.25, 'random_state': 12,
         'force_classification': True},
    )
    assert result is not None
    assert controller.data_model.row_alignment_verified
    assert list(result['X_train'].index) == result['train_row_keys']
    assert result['y_train'].index.equals(result['X_train'].index)
    assert view.invalidations == 1
    assert controller.data_model.preprocessed_data is None
    assert controller.data_model.X_train_selected is None

    controller.data_model.preprocessed_data = pd.DataFrame({'stale-again': [1]})
    result2 = controller.apply_data_partitioning(
        'Train-Test Split',
        {'target_column': 0, 'test_size': 0.25, 'random_state': 14,
         'force_classification': True},
    )
    assert result2 is not None
    assert controller.data_model.preprocessed_data is None
    assert view.invalidations == 2


def test_main_window_invalidates_preview_selection_pca_and_controller_state():
    from types import SimpleNamespace
    from app.views.main_window import MainWindow

    class PreprocessingModel:
        applied_methods = {'old': {}}

    class FeatureSelectionModel:
        def __init__(self):
            self.selected_method = 'old'
            self.selected_features = ['old']
            self.feature_importance = [1]

        def set_selected_method(self, value):
            self.selected_method = value

        def set_selected_features(self, value):
            self.selected_features = value

        def set_feature_importance(self, value):
            self.feature_importance = value

    selection_model = FeatureSelectionModel()
    window = SimpleNamespace(
        feature_data_options={
            'original': pd.DataFrame({'old': [1]}),
            'preprocessed': pd.DataFrame({'old': [1]}),
            'pca_features': pd.DataFrame({'old': [1]}),
            'selected_features': {'X_train': pd.DataFrame({'old': [1]})},
        },
        current_feature_source='pca_features',
        processed_spectra=[[1]],
        current_spectra=[[1]],
        controller=SimpleNamespace(
            preprocessing_controller=SimpleNamespace(preprocessing_model=PreprocessingModel()),
            feature_selection_controller=SimpleNamespace(feature_selection_model=selection_model),
        ),
        pca_dialogs={},
        feature_vis_windows={},
    )

    MainWindow.invalidate_dataset_feature_state(window)
    assert window.feature_data_options == {
        'original': None, 'preprocessed': None, 'pca_features': None, 'selected_features': None,
    }
    assert window.current_feature_source == 'original'
    assert window.processed_spectra is None
    assert window.current_spectra is None
    assert window.controller.preprocessing_controller.preprocessing_model.applied_methods == {}
    assert selection_model.selected_method is None
    assert selection_model.selected_features == []
    assert selection_model.feature_importance is None


def test_main_window_model_data_route_prefers_keyed_split_over_full_preview():
    from types import SimpleNamespace
    from app.views.main_window import MainWindow

    model = DataModel()
    model.set_data(_source_frame())
    model.set_partitioned_data(_split(model))
    preview = pd.DataFrame({'wrong': [-999] * len(model.get_data())})
    dummy_window = SimpleNamespace(
        controller=SimpleNamespace(
            data_controller=SimpleNamespace(data_model=model),
        ),
        current_feature_source='preprocessed',
        feature_data_options={'preprocessed': preview},
    )

    selected = MainWindow.get_current_feature_data(dummy_window)
    assert selected['X_train'] is model.X_train
    assert selected['X_test'] is model.X_test
    assert selected['y_train'] is model.y_train
    assert selected['y_test'] is model.y_test


def test_feature_selection_controller_receives_only_the_keyed_train_rows():
    from types import SimpleNamespace
    from app.controllers.feature_selection_controller import FeatureSelectionController

    model = DataModel()
    model.set_data(_source_frame())
    model.set_partitioned_data(_split(model))
    observed = {}
    view = SimpleNamespace(display_error=lambda _message: None, display_message=lambda *_args: None)
    controller = FeatureSelectionController(view, None, model, {})

    def capture(**kwargs):
        observed.update(kwargs)
        return {'selected_features': ['s0'], 'feature_importance': None}

    controller.feature_selection_service = SimpleNamespace(apply_feature_selection=capture)
    controller.apply_feature_selection('capture', {})

    assert observed['X_train'].index.equals(model.X_train.index)
    assert observed['y_train'].index.equals(model.y_train.index)
    assert observed['X_test'].index.equals(model.X_test.index)
    assert observed['y_test'].index.equals(model.y_test.index)
    assert set(observed['X_train'].index).isdisjoint(observed['X_test'].index)


def test_main_controller_legacy_readiness_fallback_uses_setter_and_clears_ui_caches():
    from types import SimpleNamespace
    from app.controllers.main_controller import MainController
    from app.views.main_window import MainWindow

    class PreprocessingModel:
        applied_methods = {'old': {}}

    class FeatureSelectionModel:
        def set_selected_method(self, value):
            self.selected_method = value

        def set_selected_features(self, value):
            self.selected_features = value

        def set_feature_importance(self, value):
            self.feature_importance = value

    model = DataModel()
    model.set_data(_source_frame())
    old_keys = model.get_row_keys()
    model.preprocessed_data = pd.DataFrame({'old': [1]})
    model.X_train_selected = pd.DataFrame({'old': [1]})
    model.partitioned_data = {'stale': True}
    model.row_alignment_verified = True
    model.data = None  # Force MainController.check_data_ready's legacy fallback.

    selection_model = FeatureSelectionModel()
    main_controller = SimpleNamespace(
        data_controller=SimpleNamespace(data_model=model),
        preprocessing_controller=SimpleNamespace(preprocessing_model=PreprocessingModel()),
        feature_selection_controller=SimpleNamespace(feature_selection_model=selection_model),
    )
    view = SimpleNamespace(
        spectra_data=_source_frame().to_numpy(),
        controller=main_controller,
        feature_data_options={
            'original': pd.DataFrame({'stale': [1]}),
            'preprocessed': pd.DataFrame({'stale': [1]}),
            'pca_features': pd.DataFrame({'stale': [1]}),
            'selected_features': {'stale': True},
        },
        current_feature_source='selected_features',
        current_spectra=[[1]],
        processed_spectra=[[1]],
        pca_dialogs={},
        feature_vis_windows={},
    )
    view.invalidate_dataset_feature_state = lambda: MainWindow.invalidate_dataset_feature_state(view)
    main_controller.view = view

    assert MainController.check_data_ready(main_controller)
    assert model.data is not None
    assert not set(old_keys) & set(model.get_row_keys())
    assert model.partitioned_data is None
    assert model.preprocessed_data is None
    assert model.X_train_selected is None
    assert view.feature_data_options['pca_features'] is None
    assert view.feature_data_options['selected_features'] is None
    assert view.current_feature_source == 'original'
    assert main_controller.preprocessing_controller.preprocessing_model.applied_methods == {}
    assert selection_model.selected_features == []
