"""Candidate execution must fail closed without hanging the application."""

import time
import multiprocessing

import numpy as np
import pytest

from app.services import algorithm_onboarding_service as onboarding


def _candidate(source):
    return onboarding.OnboardingCandidate(
        name="boundary candidate", python_source=source, original_r_source="R source",
        algorithm_category="stateless_preprocessing", parameter_schema={}, parameters={},
        X=[[1.0, 2.0], [3.0, 4.0]], axis=[900.0, 1000.0], axis_unit="nm",
        reference_examples=[{"input": [[1.0, 2.0]], "expected": [[1.0, 2.0]]}],
    )


def test_nonterminating_candidate_is_stopped_and_rejected(tmp_path, monkeypatch):
    source = "def transform(X, params):\n    while True:\n        pass\n"
    monkeypatch.setattr(onboarding, "WORKER_TIMEOUT_SECONDS", 0.3)
    service = onboarding.AlgorithmOnboardingService(tmp_path)
    started = time.monotonic()
    report = service.verify_candidate(_candidate(source))
    assert time.monotonic() - started < 8
    assert not report.passed
    assert any("timed out" in check.details for check in report.checks)
    assert not list(tmp_path.glob("*/plugin.json"))


def test_cancel_reaps_candidate_process():
    transform = onboarding._load_transform("def transform(X, params):\n    return X\n")
    process = transform._process
    pid = process.pid
    assert process.is_alive()
    transform.cancel()
    assert pid not in {child.pid for child in multiprocessing.active_children()}
    with pytest.raises(onboarding.AlgorithmOnboardingError):
        transform(np.ones((1, 2)), {})


def test_candidate_exception_is_not_accepted(tmp_path):
    report = onboarding.AlgorithmOnboardingService(tmp_path).verify_candidate(
        _candidate("def transform(X, params):\n    raise ValueError('broken')\n")
    )
    assert not report.passed
    assert any("broken" in check.details for check in report.checks)
