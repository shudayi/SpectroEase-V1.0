"""Offscreen checks for the active, verification-first preprocessing UI."""

import json
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
import pandas as pd
import pytest
from PyQt5.QtWidgets import QApplication

from app.services.algorithm_onboarding_service import AlgorithmOnboardingService, OnboardingCandidate
from app.services.preprocessing_registry import get_entry, register_plugin, unregister_plugin
from app.views.algorithm_onboarding_dialog import AlgorithmOnboardingDialog
from app.services.llm_service import LLMService


SOURCE = '''import numpy as np

def transform(X, params):
    return np.asarray(X, dtype=float) * params["scale"]
'''
R_SOURCE = "scale_spectra <- function(X, scale = 2) { X * scale }"
X = [[1.0, 2.0], [3.0, 4.0]]
AXIS = [900.0, 1000.0]
FIXTURES = [{
    "input": [[0.5, 1.0], [2.0, 3.0]],
    "expected": [[1.0, 2.0], [4.0, 6.0]],
    "parameters": {"scale": 2.0},
}]


@pytest.fixture
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def plugin_dir(tmp_path, monkeypatch):
    root = tmp_path / "accepted-plugins"
    monkeypatch.setenv("SPECTROEASE_PLUGIN_DIR", str(root))
    return root


def _fill_dialog(dialog, *, bad_reference=False):
    dialog.name_edit.setText("Scale each spectrum")
    dialog.r_source_edit.setPlainText(R_SOURCE)
    dialog.python_source_edit.setPlainText(SOURCE)
    dialog.parameter_schema_edit.setPlainText(
        json.dumps({"scale": {"type": "number", "default": 2.0}})
    )
    dialog.parameter_values_edit.setPlainText("{}")
    dialog.axis_unit_edit.setText("nm")
    dialog.axis_edit.setPlainText(json.dumps(AXIS))
    dialog.input_matrix_edit.setPlainText(json.dumps(X))
    fixtures = json.loads(json.dumps(FIXTURES))
    if bad_reference:
        fixtures[0]["expected"] = [[99.0, 99.0], [99.0, 99.0]]
    dialog.reference_examples_edit.setPlainText(json.dumps(fixtures))


def _candidate():
    return OnboardingCandidate(
        name="Scale each spectrum",
        python_source=SOURCE,
        original_r_source=R_SOURCE,
        algorithm_category="stateless_preprocessing",
        parameter_schema={"scale": {"type": "number", "default": 2.0}},
        parameters={},
        X=X,
        axis=AXIS,
        axis_unit="nm",
        reference_examples=FIXTURES,
    )


def test_dialog_no_key_keeps_manual_verification_available(qapp, plugin_dir):
    service = AlgorithmOnboardingService(plugin_dir)
    dialog = AlgorithmOnboardingDialog(service, LLMService(api_key=""), initial_X=X, axis=AXIS)
    _fill_dialog(dialog)

    assert not dialog.convert_button.isEnabled()
    assert "Manual Python entry and verification remain available" in dialog.llm_status_label.text()
    assert dialog.tabs.count() == 2
    assert dialog.content_scroll.widget() is dialog.content_widget
    assert dialog.parameter_preview_label.text().startswith("scale: number")
    available = qapp.primaryScreen().availableGeometry()
    assert dialog.width() <= available.width()
    assert dialog.height() <= available.height()
    assert dialog.register_button.minimumSizeHint().height() > 0
    report = dialog.verify_candidate()
    assert report is not None and report.passed
    assert dialog.acceptance_checkbox.isEnabled()
    assert not dialog.register_button.isEnabled()
    dialog.close()


@pytest.mark.parametrize("size", [(720, 480), (1050, 980)])
def test_verification_results_keep_seven_readable_lines_and_actions(qapp, plugin_dir, size):
    from PyQt5.QtCore import QPoint, QRect
    dialog = AlgorithmOnboardingDialog(AlgorithmOnboardingService(plugin_dir), LLMService(api_key=""))
    _fill_dialog(dialog)
    dialog.resize(*size)
    dialog.show()
    qapp.processEvents()
    assert dialog.verify_candidate().passed
    qapp.processEvents()
    output = dialog.verification_output
    assert output.viewport().height() >= 7 * output.fontMetrics().lineSpacing()
    assert dialog.python_source_edit.height() == 150
    for index in range(dialog.tabs.count()):
        dialog.tabs.setCurrentIndex(index)
        qapp.processEvents()
        dialog.content_scroll.ensureWidgetVisible(output, 2, 2)
        # QTextEdit focus rectangles can make ensureWidgetVisible target the
        # cursor's first line. Exercise the actual outer scrollbar end route.
        bar = dialog.content_scroll.verticalScrollBar()
        bar.setValue(bar.maximum())
        qapp.processEvents()
        position = output.mapTo(dialog.content_scroll.viewport(), QPoint(0, 0))
        assert dialog.content_scroll.viewport().rect().contains(QRect(position, output.size()))
        for action in (dialog.verify_button, dialog.register_button, dialog.cancel_button):
            position = action.mapTo(dialog, QPoint(0, 0))
            assert dialog.rect().contains(QRect(position, action.size()))
    dialog.close()


def test_bad_trusted_reference_fails_verification_and_blocks_acceptance(qapp, plugin_dir):
    dialog = AlgorithmOnboardingDialog(AlgorithmOnboardingService(plugin_dir), LLMService(api_key=""))
    _fill_dialog(dialog, bad_reference=True)

    report = dialog.verify_candidate()

    assert report is not None and not report.passed
    outcomes = {item.name: item.status for item in report.checks}
    assert outcomes["reference_concordance"] == "fail"
    assert not dialog.acceptance_checkbox.isEnabled()
    assert not dialog.register_button.isEnabled()
    dialog.close()


def test_explicit_acceptance_persists_and_fresh_service_reload_revalidates(qapp, plugin_dir):
    service = AlgorithmOnboardingService(plugin_dir)
    dialog = AlgorithmOnboardingDialog(service, LLMService(api_key=""), initial_X=X, axis=AXIS)
    _fill_dialog(dialog)
    report = dialog.verify_candidate()
    assert report is not None and report.passed
    dialog.acceptance_checkbox.setChecked(True)
    assert dialog.register_button.isEnabled()

    assert dialog.accept_candidate()
    candidate_id = dialog.candidate_id
    assert candidate_id
    assert (plugin_dir / candidate_id / "plugin.json").is_file()
    unregister_plugin(candidate_id)

    fresh_service = AlgorithmOnboardingService(plugin_dir)
    loaded = fresh_service.load_accepted_candidate(candidate_id, register=True)
    assert loaded.passed
    assert get_entry(candidate_id).quality == "verified-stateless"
    fresh_service.disable_plugin(candidate_id)
    dialog.close()


def test_main_window_reloads_plugin_lists_it_and_applies_via_controller_data_model(
    qapp, plugin_dir, monkeypatch
):
    service = AlgorithmOnboardingService(plugin_dir)
    report = service.verify_candidate(_candidate())
    candidate_id = service.accept_candidate(
        report, edited_python_source=SOURCE, user_confirmed=True
    )
    service.disable_plugin(candidate_id)

    from app.utils.translator import Translator
    from app.views import main_window as main_window_module
    from app.views.main_window import MainWindow
    from app.utils import logger as logger_module

    # The production logger wraps stdout/stderr buffers for Windows console
    # encoding. Under pytest's capture streams that wrapper outlives the test
    # and closes capture handles during teardown, so leave captured streams
    # untouched in this offscreen UI test.
    monkeypatch.setattr(logger_module, "_ensure_utf8_stdout", lambda: None)

    window = MainWindow(Translator(language="en"), {}, {}, {}, {}, LLMService(api_key=""))
    try:
        assert not window.open_algorithm_onboarding_button.isHidden()
        assert window.open_algorithm_onboarding_button.objectName() == "openAlgorithmOnboardingButton"
        assert window.onboarded_plugin_combo.findData(candidate_id) >= 0
        assert window.onboarded_plugin_reports[candidate_id].passed

        data_model = window.controller.data_controller.data_model
        frame = pd.DataFrame({
            "label": ["a", "b"],
            "900": [2.0, 4.0],
            "1000": [6.0, 8.0],
        }, index=[11, 7])
        data_model.set_data(frame)
        window.onboarded_plugin_combo.setCurrentIndex(window.onboarded_plugin_combo.findData(candidate_id))
        window.onboarded_plugin_params.setText('{"scale": 3.0}')

        class _Signal:
            def connect(self, _slot):
                pass

        class _Progress:
            def __init__(self, *_args, **_kwargs):
                self.cancelled = _Signal()

            def show(self):
                pass

            def close(self):
                pass

            def update_progress(self, *_args):
                pass

        class _WorkerHandle:
            def cancel(self):
                pass

        monkeypatch.setattr(main_window_module, "ProgressDialog", _Progress)
        monkeypatch.setattr(window, "_finish_preprocessing", lambda *_args: None)

        def _run_controller_worker(methods, params, on_result, on_error, on_finished=None):
            result = window.controller.preprocessing_controller._apply_preprocessing_async(methods, params)
            if result and result.get("success"):
                on_result(result)
            else:
                on_error(result.get("error", "failed") if isinstance(result, dict) else "failed")
            return _WorkerHandle()

        monkeypatch.setattr(
            window.controller.preprocessing_controller,
            "start_preprocessing_worker",
            _run_controller_worker,
        )
        assert window.apply_onboarded_plugin()
        processed = data_model.get_preprocessed_data()
        assert processed is not None
        np.testing.assert_allclose(processed.to_numpy(), [[6.0, 18.0], [12.0, 24.0]])
        assert processed.index.equals(frame.index)
        assert list(processed.columns) == ["900", "1000"]
        assert list(data_model.get_y()) == ["a", "b"]
    finally:
        window.close()
        window.deleteLater()
        AlgorithmOnboardingService(plugin_dir).disable_plugin(candidate_id)


def test_partitioned_controller_accepts_only_verified_stateless_plugins(qapp, plugin_dir):
    from app.controllers.preprocessing_controller import PreprocessingController
    from app.models.data_model import DataModel
    from app.services.preprocessing_registry import register_plugin

    service = AlgorithmOnboardingService(plugin_dir)
    report = service.verify_candidate(_candidate())
    candidate_id = service.accept_candidate(report, edited_python_source=SOURCE, user_confirmed=True)
    model = DataModel()
    frame = pd.DataFrame({"label": [0, 1, 0, 1], "900": [1., 2., 3., 4.], "1000": [2., 4., 6., 8.]})
    model.set_data(frame)
    row_keys = model.get_row_keys()
    train_keys, test_keys = row_keys[:2], row_keys[2:]
    X = model.get_X()
    y = model.get_y()
    split = {
        "X_train": X.iloc[:2].set_axis(train_keys),
        "y_train": y.iloc[:2].set_axis(train_keys),
        "X_test": X.iloc[2:].set_axis(test_keys),
        "y_test": y.iloc[2:].set_axis(test_keys),
        "train_row_keys": list(train_keys),
        "test_row_keys": list(test_keys),
    }
    model.set_partitioned_data(split)
    assert model.row_alignment_verified
    controller = PreprocessingController(None, None, model, {})
    try:
        accepted_result = controller._apply_preprocessing_async([candidate_id], {candidate_id: {"scale": 2.0}})
        assert accepted_result["success"]
        assert accepted_result["is_partitioned"]
        assert accepted_result["X_train"].index.equals(pd.Index(train_keys, name="_row_key"))
        assert accepted_result["X_test"].index.equals(pd.Index(test_keys, name="_row_key"))

        unverified_id = "test-unverified-stateless-plugin"
        unregister_plugin(unverified_id)
        register_plugin(unverified_id, display_name="Unverified", category="plugin", quality="plugin")(
            lambda data, **_params: data.copy()
        )
        rejected = controller._apply_preprocessing_async([unverified_id], {unverified_id: {}})
        assert not rejected["success"]
        assert "only verified sample-wise transforms" in rejected["error"]
        unregister_plugin(unverified_id)
    finally:
        service.disable_plugin(candidate_id)
