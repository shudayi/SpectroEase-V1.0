"""Algorithm identity, parameter retention and non-destructive save regressions."""
import importlib.util
import json
import pickle
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
import subprocess
import sys
from app.services.onnx_service import ONNXService
from plugins.modeling.quantitative_analyzer import QuantitativeAnalyzer
from plugins.modeling.qualitative_analyzer import QualitativeAnalyzer

def isolated_onnx_predictions(path, values):
    """Exercise the exported graph without loading native ORT into Qt tests."""
    import tempfile
    with tempfile.TemporaryDirectory() as directory:
        source = Path(directory) / 'input.npy'
        target = Path(directory) / 'output.npy'
        np.save(source, values)
        code = (
            "import sys,numpy as np,onnxruntime as ort;"
            "s=ort.InferenceSession(sys.argv[1],providers=['CPUExecutionProvider']);"
            "v=s.run(None,{s.get_inputs()[0].name:np.load(sys.argv[2])})[0];"
            "np.save(sys.argv[3],v)"
        )
        subprocess.run([sys.executable, '-c', code, str(path), str(source), str(target)], check=True, timeout=60)
        return np.load(target)

@pytest.fixture
def data():
    rng=np.random.default_rng(42)
    X=pd.DataFrame(rng.normal(size=(36,6)),columns=list('abcdef'))
    y=100+20*X.a.to_numpy()
    return X,y,np.array(['alpha','beta','zeta']*12)

@pytest.mark.parametrize('task',['regression','classification'])
def test_selected_neural_network_type_and_params(task,data):
    X,y,classes=data
    a=QuantitativeAnalyzer('nn') if task=='regression' else QualitativeAnalyzer('nn')
    a.fit(X,y if task=='regression' else classes,hidden_layer_sizes=(8,),max_iter=20,early_stopping=False)
    assert type(a.model).__name__==('MLPRegressor' if task=='regression' else 'MLPClassifier')
    assert a.model.hidden_layer_sizes==(8,)
    assert a.model.max_iter==20
    assert len(a.predict(X.iloc[:3]))==3

@pytest.mark.parametrize('task',['regression','classification'])
@pytest.mark.parametrize('method',['xgboost','lightgbm'])
def test_optional_algorithm_never_silently_replaced(task,method,data):
    X,y,classes=data
    a=QuantitativeAnalyzer(method) if task=='regression' else QualitativeAnalyzer(method)
    if importlib.util.find_spec(method) is None:
        with pytest.raises(ImportError,match='not installed'):
            a.fit(X,y if task=='regression' else classes)
    else:
        a.fit(X,y if task=='regression' else classes,n_estimators=2,n_jobs=1)
        assert type(a.model).__name__.startswith('XGB' if method=='xgboost' else 'LGBM')

@pytest.mark.parametrize('method',['xgboost','lightgbm'])
def test_optional_binary_classifier_fit_and_cv(method,data):
    if importlib.util.find_spec(method) is None:
        pytest.skip(f'{method} not installed in this runtime')
    X,_,_=data
    binary=np.array(['alpha','beta']*18)
    a=QualitativeAnalyzer(method)
    a.fit(X,binary,n_estimators=3,n_jobs=1)
    assert set(a.predict(X)).issubset({'alpha','beta'})
    cv=a.cross_validate(X,binary,cv=3)
    assert len(cv['cv_predictions'])==36
    assert set(cv['cv_predictions']).issubset({'alpha','beta'})

def test_unknown_regression_method_rejected(data):
    X,y,_=data
    with pytest.raises(ValueError,match='Unsupported regression'):
        QuantitativeAnalyzer('made-up-method').fit(X,y)

@pytest.mark.parametrize('task',['regression','classification'])
def test_svm_params_preserved_in_fold_estimators(task,data):
    X,y,classes=data
    a=QuantitativeAnalyzer('svr') if task=='regression' else QualitativeAnalyzer('svm')
    a.fit(X,y if task=='regression' else classes,C=.123,kernel='linear')
    assert a.model.C==.123
    assert a.model.kernel=='linear'
    # The CV factory must reconstruct the same configured estimator.
    model=a._create_model(**a.model_params) if task=='regression' else a._create_model(np.arange(3))
    assert model.C==.123
    assert model.kernel=='linear'
    cv=a.cross_validate(X,y,n_splits=3) if task=='regression' else a.cross_validate(X,classes,cv=3)
    assert len(cv['cv_predictions'])==36

def test_pickle_auto_save_has_separate_sidecar_and_prediction_parity(tmp_path,data):
    X,y,_=data
    a=QuantitativeAnalyzer('plsr'); a.fit(X,y)
    service=ONNXService(str(tmp_path))
    path=service.auto_save_model(a.model,X.to_numpy(),model_name='audit',method='plsr')
    assert path and path.endswith('.pkl')
    saved=pickle.loads(Path(path).read_bytes())
    assert (Path(path).with_name(Path(path).stem+'_info.txt')).exists()
    scaled=a.scaler_x.transform(a.imputer.transform(X))
    assert np.allclose(saved['model'].predict(scaled),a.model.predict(scaled))
    onnx_path=service.export_model_to_onnx(a.model,scaled,model_name='bare-audit')
    assert onnx_path and onnx_path.endswith('.onnx'), service.last_error
    contract=json.loads(Path(onnx_path.replace('.onnx','_onnx_contract.json')).read_text(encoding='utf-8'))
    assert contract['input_representation']=='fitted_feature_matrix'
    assert contract['raw_spectrum_replay'] is False
    actual=isolated_onnx_predictions(onnx_path,scaled.astype(np.float32))
    assert np.allclose(actual,a.model.predict(scaled),rtol=2e-4,atol=2e-5)


@pytest.mark.parametrize('task',['regression','classification'])
def test_fitted_analyzer_onnx_embeds_preprocessing_and_checks_prediction_contract(task,data,tmp_path):
    X,y,classes=data
    X=X.copy()
    X.iloc[2,1]=np.nan
    if task=='regression':
        analyzer=QuantitativeAnalyzer('mlr')
        analyzer.fit(X,y,input_representation='raw_spectrum')
    else:
        analyzer=QualitativeAnalyzer('logistic')
        analyzer.fit(X,classes,input_representation='raw_spectrum')

    service=ONNXService(str(tmp_path))
    path=service.export_analyzer_to_onnx(
        analyzer,X.iloc[:12],model_name='fitted-analyzer',method=analyzer.method
    )
    assert path and path.endswith('.onnx'), service.last_error
    sidecar=Path(path).with_name(Path(path).stem+'_onnx_contract.json')
    contract=json.loads(sidecar.read_text(encoding='utf-8'))
    assert contract['runtime_parity']=='passed'
    assert contract['raw_spectrum_replay'] is True
    assert contract['input_feature_names']==list(X.columns)
    assert Path(path).stat().st_size>0

    actual=[isolated_onnx_predictions(path,X.iloc[:12].to_numpy(dtype=np.float32))]
    expected=np.asarray(analyzer.predict(X.iloc[:12]))
    assert contract['output_shapes'][0][0] in (None,'N')
    if task=='classification':
        assert len(contract['output_shapes'])==2
        assert contract['output_shapes'][1]==[contract['output_shapes'][0][0],len(analyzer.label_encoder.classes_)]
    else:
        assert len(contract['output_shapes'])==1
        assert len(contract['output_shapes'][0])==1
    single=isolated_onnx_predictions(path,X.iloc[:1].to_numpy(dtype=np.float32))
    assert single.shape==(1,)
    if task=='classification':
        expected=analyzer.label_encoder.transform(expected)
        assert np.asarray(actual[0]).shape==(12,)
        assert np.array_equal(np.asarray(actual[0]).astype(int),expected.astype(int))
        assert contract['output_semantics']=='encoded_class_index'
        assert contract['class_labels_by_encoded_index']==analyzer.label_encoder.classes_.tolist()
    else:
        assert np.allclose(
            np.asarray(actual[0]),
            expected,
            rtol=contract['parity_rtol'],
            atol=contract['parity_atol'],
        )
        assert contract['target_standardization_inverse_embedded'] is True

def test_serialized_predictor_restores_imputer_scaling_and_target(data):
    X,y,_=data
    a=QuantitativeAnalyzer('plsr'); a.fit(X,y,input_representation='raw_spectrum')
    restored=pickle.loads(pickle.dumps(a.fitted_predictor))
    assert np.allclose(restored.predict_raw(X).predictions,a.predict(X))

@pytest.mark.parametrize('task',['regression','classification'])
def test_controller_explicit_task_dispatches_correct_analyzer(task,data):
    from types import SimpleNamespace
    from app.controllers.modeling_controller import ModelingController
    from app.models.modeling_model import ModelingModel
    from app.services.modeling_service import ModelingService
    from app.utils.label_processor import EnhancedLabelProcessor
    import logging
    X,y,classes=data
    controller=ModelingController.__new__(ModelingController)
    controller.data_model=SimpleNamespace(X_train=X.iloc[:27],X_test=X.iloc[27:],y_train=(y if task=='regression' else classes)[:27],y_test=(y if task=='regression' else classes)[27:])
    controller.modeling_service=ModelingService({})
    controller.modeling_model=ModelingModel()
    controller.label_processor=EnhancedLabelProcessor()
    controller.logger=logging.getLogger('modeling-audit')
    result=controller.apply_modeling(method='svm',params={'C':.123},task_type=task)
    assert result.task_type==task
    assert type(result.model).__name__==('SVR' if task=='regression' else 'SVC')
    assert len(result.predictions)==9

def test_controller_rejects_unknown_task(data):
    from types import SimpleNamespace
    from app.controllers.modeling_controller import ModelingController
    import logging
    X,y,_=data
    controller=ModelingController.__new__(ModelingController)
    controller.data_model=SimpleNamespace(X_train=X.iloc[:27],X_test=X.iloc[27:],y_train=y[:27],y_test=y[27:])
    controller.logger=logging.getLogger('modeling-audit')
    with pytest.raises(Exception,match='Unsupported task_type'):
        controller.apply_modeling(method='svm',params={},task_type='unsupported')

@pytest.mark.parametrize('task,method,estimator_name,params',[
    ('regression','mlr','LinearRegression',{'fit_intercept':False}),
    ('regression','ridge','Ridge',{'alpha':.123}),
    ('regression','lasso','Lasso',{'alpha':.01,'max_iter':500}),
    ('regression','elasticnet','ElasticNet',{'alpha':.01,'l1_ratio':.3,'max_iter':500}),
    ('regression','dt','DecisionTreeRegressor',{'max_depth':3,'min_samples_leaf':2}),
    ('classification','logistic','LogisticRegression',{'C':.123,'max_iter':200}),
])
def test_paper_inventory_model_identity_parameters_and_actual_cv(task,method,estimator_name,params,data,monkeypatch):
    X,y,classes=data
    a=QuantitativeAnalyzer(method) if task=='regression' else QualitativeAnalyzer(method)
    target=y if task=='regression' else classes
    a.fit(X,target,**params)
    assert type(a.model).__name__==estimator_name
    assert all(a.model.get_params()[key]==value for key,value in params.items())
    actual_fit_params=[]
    original_fit=type(a.model).fit
    def observe_fit(model,*args,**kwargs):
        actual_fit_params.append({key:model.get_params()[key] for key in params})
        return original_fit(model,*args,**kwargs)
    monkeypatch.setattr(type(a.model),'fit',observe_fit)
    cv=a.cross_validate(X,y,n_splits=3) if task=='regression' else a.cross_validate(X,classes,cv=3)
    assert len(cv['cv_predictions'])==36
    assert len(actual_fit_params)==3
    assert all(observed==params for observed in actual_fit_params)
    assert len(a.predict(X.iloc[:3]))==3

@pytest.mark.parametrize('label,canonical',[
    ('Linear Regression','mlr'),('Ridge Regression','ridge'),
    ('Lasso Regression','lasso'),('Elastic Net','elasticnet'),
    ('Decision Tree','dt'),
])
def test_paper_regression_aliases(label,canonical):
    assert QuantitativeAnalyzer(label).method==canonical

def test_logistic_regression_alias():
    assert QualitativeAnalyzer('Logistic Regression').method=='logistic'

def test_same_second_save_keeps_both_models_and_sidecars(tmp_path,data,monkeypatch):
    from datetime import datetime
    import app.services.onnx_service as save_module
    from sklearn.linear_model import LinearRegression
    class FixedDatetime:
        @staticmethod
        def now():
            return datetime(2026,10,2,12,0,0)
    monkeypatch.setattr(save_module,'datetime',FixedDatetime)
    X,y,_=data
    first=LinearRegression().fit(X,y)
    second=LinearRegression().fit(X,y+99)
    service=ONNXService(str(tmp_path))
    paths=[service.auto_save_model(model,X.to_numpy(),model_name='same',method='same') for model in [first,second]]
    assert None not in paths and paths[0]!=paths[1]
    for path,model in zip(paths,[first,second]):
        saved=pickle.loads(Path(path).read_bytes())
        assert np.allclose(saved['model'].predict(X),model.predict(X))
        assert Path(path).with_name(Path(path).stem+'_info.txt').exists()

def test_pickle_save_sanitizes_untrusted_filename_labels(tmp_path,data):
    X,y,_=data
    a=QuantitativeAnalyzer('mlr');a.fit(X,y)
    service=ONNXService(str(tmp_path))
    path=service.auto_save_model(a.model,X.to_numpy(),model_name='../../bad:name?*',method='..\\outside/path')
    assert path and Path(path).resolve().parent==tmp_path.resolve()
    assert not set('<>:"/\\|?*').intersection(Path(path).name)
    assert pickle.loads(Path(path).read_bytes())['model'] is not None

def test_pickle_exclusive_create_rejects_forced_collision(tmp_path,data,monkeypatch):
    from datetime import datetime
    from types import SimpleNamespace
    import app.services.onnx_service as save_module
    X,y,_=data
    a=QuantitativeAnalyzer('mlr');a.fit(X,y)
    monkeypatch.setattr(save_module,'datetime',SimpleNamespace(now=lambda:datetime(2026,10,2,12,0,0)))
    monkeypatch.setattr(save_module.uuid,'uuid4',lambda:SimpleNamespace(hex='fixeduuid'))
    service=ONNXService(str(tmp_path))
    first=service.save_model_as_pickle(a.model,X.to_numpy(),model_name='same',method='same')
    original=Path(first).read_bytes()
    second=service.save_model_as_pickle(a.model,X.to_numpy(),model_name='same',method='same')
    assert second is None
    assert Path(first).read_bytes()==original
