"""Spectral score rankings must remain readable without losing export data."""
import json
import os

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import numpy as np
from PyQt5.QtWidgets import QApplication

from app.utils.visualization_window import VisualizationWindow
from app.services.plot_export_service import export_figure, ExportProfile


def test_large_spectral_ranking_shows_top_twenty_and_exports_every_score(tmp_path):
    app = QApplication.instance() or QApplication([])
    window = VisualizationWindow()
    names = [str(950 + 5 * i) for i in range(141)]
    scores = np.arange(141, dtype=float)
    try:
        window.plot_feature_importance(scores, names, title='Training-only scores')
        axis = window.figure.axes[0]
        assert len(axis.patches) == 20
        assert [label.get_text() for label in axis.get_yticklabels()] == names[-20:][::-1]
        np.testing.assert_array_equal([bar.get_width() for bar in axis.patches], scores[-20:][::-1])
        assert axis.yaxis_inverted()
        assert 'Top 20 of 141 features' in axis.get_title()
        full_data = window._current_plot_metadata['feature_importance']
        assert full_data['feature_names'] == names
        assert full_data['scores'] == scores.tolist()
        window._record_plot_style_metadata()
        result = export_figure(window.figure, tmp_path / 'scores.svg',
                               profile=ExportProfile(format='svg'),
                               metadata=window._current_plot_metadata)
        sidecar = json.loads((tmp_path / 'scores.svg.json').read_text())
        assert sidecar['metadata']['feature_importance'] == full_data
        assert result['metadata']['feature_importance']['displayed_indices'] == list(range(140,120,-1))
    finally:
        window.close()
        app.processEvents()
