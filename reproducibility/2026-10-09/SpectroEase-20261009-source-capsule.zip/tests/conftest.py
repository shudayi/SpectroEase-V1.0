"""Keep one Qt application alive throughout combined application tests."""
import os
from pathlib import Path
import pytest
import PyQt5

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
os.environ.setdefault(
    'QT_QPA_PLATFORM_PLUGIN_PATH',
    os.path.join(os.path.dirname(PyQt5.__file__), 'Qt5', 'plugins'),
)
if os.environ.get('QT_QPA_PLATFORM') == 'offscreen' and os.name == 'nt':
    os.environ.setdefault(
        'QT_QPA_FONTDIR',
        str(Path(os.environ.get('WINDIR', r'C:\Windows')) / 'Fonts'),
    )


@pytest.fixture(scope='session', autouse=True)
def spectroease_qt_application():
    from PyQt5.QtWidgets import QApplication
    # Destroying a temporary QApplication between modules also destroys Qt
    # objects held by imported modules, including the shared Translator.
    app = QApplication.instance() or QApplication(['SpectroEase tests'])
    yield app
