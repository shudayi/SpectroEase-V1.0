"""The in-app agent must inspect report content rather than file existence."""
from unittest.mock import patch
import pytest
from app.tools.test_agent import e2e_smoke as e2e
from plugins.reporting.spectrum_report_generator import SpectrumReportGenerator

def fake_report(tmp_path,payload=b'',name='fake.pdf',metrics=None):
    metrics=metrics or {'accuracy':.5,'f1':.5}
    path=tmp_path/name
    def generate(*args,**kwargs):
        path.write_bytes(payload)
        return str(path)
    rep=e2e.E2ESmokeReport(passed=True)
    with patch.object(SpectrumReportGenerator,'generate_report',side_effect=generate):
        ok=e2e._report(rep,tmp_path,metrics)
    return ok,rep

@pytest.mark.parametrize('payload',[b'',b'not a PDF',b'%PDF-1.4\ncorrupt\n%%EOF'])
def test_empty_or_corrupt_pdf_is_not_report_success(tmp_path,payload):
    ok,rep=fake_report(tmp_path,payload)
    assert not ok and not rep.steps[-1].passed

def test_unchanged_existing_report_is_rejected(tmp_path):
    path=tmp_path/'old.pdf'
    path.write_bytes(b'%PDF-old invalid')
    rep=e2e.E2ESmokeReport(passed=True)
    with patch.object(SpectrumReportGenerator,'generate_report',return_value=str(path)):
        assert not e2e._report(rep,tmp_path,{'accuracy':.5,'f1':.5})
    assert 'unchanged' in rep.steps[-1].detail

def test_valid_pdf_without_metric_content_is_rejected(tmp_path):
    from reportlab.pdfgen.canvas import Canvas
    path=tmp_path/'wrong.pdf'
    def generate(*args,**kwargs):
        canvas=Canvas(str(path));canvas.drawString(40,700,'unrelated report');canvas.save()
        return str(path)
    rep=e2e.E2ESmokeReport(passed=True)
    with patch.object(SpectrumReportGenerator,'generate_report',side_effect=generate):
        assert not e2e._report(rep,tmp_path,{'accuracy':.5,'f1':.5})
    assert 'missing' in rep.steps[-1].detail

def test_actual_report_generation_validates_readable_metric_content(tmp_path):
    rep=e2e.E2ESmokeReport(passed=True)
    assert e2e._report(rep,tmp_path,{'accuracy':.875,'f1':.8125})
    assert 'metric content verified' in rep.steps[-1].detail
