"""Deterministic contract tests for stateless algorithm onboarding."""

from dataclasses import replace
import json

import numpy as np
import pandas as pd
import pytest

from app.services.algorithm_onboarding_service import (
    AlgorithmOnboardingError,
    AlgorithmOnboardingService,
    OnboardingCandidate,
    ParameterField,
)
from app.services.preprocessing_registry import get_entry, unregister_plugin


SCALE_SOURCE = """import numpy as np

def transform(X, params):
    return np.asarray(X, dtype=float) * params["scale"]
"""

R_SOURCE = "scale_spectra <- function(X, scale = 2) { X * scale }"


def make_candidate(**overrides):
    values = {
        "name": "deterministic scale",
        "python_source": SCALE_SOURCE,
        "original_r_source": R_SOURCE,
        "algorithm_category": "stateless_preprocessing",
        "parameter_schema": {"scale": {"type": "number", "default": 2.0, "minimum": 0.0}},
        "parameters": {},
        "X": [[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]],
        "axis": [900.0, 1000.0],
        "axis_unit": "nm",
        "reference_examples": [
            {
                "input": [[0.5, 1.0], [2.0, 3.0]],
                "expected": [[1.0, 2.0], [4.0, 6.0]],
            }
        ],
        "rtol": 1e-8,
        "atol": 1e-10,
        "dependencies": ["numpy"],
    }
    values.update(overrides)
    return OnboardingCandidate(**values)


def test_verifies_stateless_transform_against_reference_and_axis_contract(tmp_path):
    report = AlgorithmOnboardingService(tmp_path).verify_candidate(make_candidate())

    assert report.passed
    outcomes = {item.name: item.status for item in report.checks}
    assert outcomes["source_syntax"] == "pass"
    assert outcomes["interface_contract"] == "pass"
    assert outcomes["parameter_schema"] == "pass"
    assert outcomes["numeric_shape_finiteness"] == "pass"
    assert outcomes["axis_preservation"] == "pass"
    assert outcomes["axis_output_alignment"] == "pass"
    assert outcomes["reference_concordance"] == "pass"
    assert outcomes["row_independence"] == "pass"


def test_bounded_repairs_revalidate_every_exact_source(tmp_path):
    service = AlgorithmOnboardingService(tmp_path)
    initial = make_candidate(python_source="def transform(X, params):\n    return X\n")
    callback_sources = []

    def deterministic_repair(source, failures, repair_round):
        callback_sources.append((source, repair_round, {item.name for item in failures if item.status != "pass"}))
        return SCALE_SOURCE

    report = service.verify_with_repairs(initial, deterministic_repair, max_repairs=3)

    assert report.passed
    assert len(callback_sources) == 1
    assert callback_sources[0][1] == 1
    assert len(report.attempts) == 2
    assert report.attempts[0].passed is False
    assert report.attempts[1].passed is True
    assert report.attempts[0].source_sha256 != report.attempts[1].source_sha256
    assert report.repairs[0].status == "candidate"

    candidate_id = service.accept_candidate(
        report,
        edited_python_source=report.candidate.python_source,
        user_confirmed=True,
    )
    try:
        record = json.loads((tmp_path / candidate_id / "plugin.json").read_text(encoding="utf-8"))
        assert record["repair_count"] == 1
        assert len(record["attempts"]) == 2
        assert len(record["repairs"]) == 1
    finally:
        unregister_plugin(candidate_id)


def test_repair_orchestration_never_exceeds_three_callbacks(tmp_path):
    service = AlgorithmOnboardingService(tmp_path)
    initial = make_candidate(python_source="def transform(X, params):\n    return X\n")
    calls = []

    def no_op_repair(source, _failures, round_number):
        calls.append(round_number)
        return source + "\n# deterministic repair attempt\n"

    report = service.verify_with_repairs(initial, no_op_repair, max_repairs=3)

    assert calls == [1, 2, 3]
    assert len(report.attempts) == 4
    assert len(report.repairs) == 3
    assert not report.passed


def test_row_cohort_dependent_transform_fails_invariance_check(tmp_path):
    source = """import numpy as np

def transform(X, params):
    return np.asarray(X) - np.mean(X, axis=0, keepdims=True)
"""
    X = [[1.0, 2.0], [3.0, 5.0], [7.0, 11.0]]
    expected = np.asarray(X) - np.mean(X, axis=0, keepdims=True)
    candidate = make_candidate(
        python_source=source,
        X=X,
        reference_examples=[{"input": X, "expected": expected.tolist()}],
    )

    report = AlgorithmOnboardingService(tmp_path).verify_candidate(candidate)

    row_check = next(item for item in report.checks if item.name == "row_independence")
    assert row_check.status == "fail"
    assert "unrelated rows" in row_check.details


@pytest.mark.parametrize(
    ("source", "check_name"),
    [
        ("import os\ndef transform(X, params):\n    return X\n", "source_policy"),
        ("import numpy as np\ndef transform(X, params):\n    return np.load('input.npy')\n", "source_policy"),
        ("def transform(X):\n    return X\n", "interface_contract"),
        ("def transform(X, params):\n    return X[:, :-1]\n", "numeric_shape_finiteness"),
        ("import numpy as np\ndef transform(X, params):\n    return np.full_like(X, np.nan)\n", "numeric_shape_finiteness"),
    ],
)
def test_policy_interface_shape_and_finiteness_rejections(tmp_path, source, check_name):
    report = AlgorithmOnboardingService(tmp_path).verify_candidate(make_candidate(python_source=source))

    assert not report.passed
    assert next(item for item in report.checks if item.name == check_name).status == "fail"


def test_missing_trusted_reference_is_not_verified_and_cannot_be_accepted(tmp_path):
    service = AlgorithmOnboardingService(tmp_path)
    report = service.verify_candidate(make_candidate(reference_examples=[]))

    assert not report.passed
    assert next(item for item in report.checks if item.name == "reference_concordance").status == "not_verified"
    with pytest.raises(AlgorithmOnboardingError, match="revalidation"):
        service.accept_candidate(report, edited_python_source=SCALE_SOURCE, user_confirmed=True)


def test_acceptance_requires_explicit_confirmation_and_exact_editor_source(tmp_path):
    service = AlgorithmOnboardingService(tmp_path)
    report = service.verify_candidate(make_candidate())
    assert report.passed

    with pytest.raises(AlgorithmOnboardingError, match="confirmation"):
        service.accept_candidate(report, edited_python_source=SCALE_SOURCE, user_confirmed=False)
    with pytest.raises(AlgorithmOnboardingError, match="changed after verification"):
        service.accept_candidate(
            report,
            edited_python_source=SCALE_SOURCE + "\n# user edit after verification\n",
            user_confirmed=True,
        )


def test_acceptance_persists_reloads_fresh_then_dispatches_existing_dataframe_runner(tmp_path):
    service = AlgorithmOnboardingService(tmp_path)
    report = service.verify_candidate(make_candidate())
    candidate_id = service.accept_candidate(
        report,
        edited_python_source=report.candidate.python_source,
        user_confirmed=True,
    )

    try:
        record = json.loads((tmp_path / candidate_id / "plugin.json").read_text(encoding="utf-8"))
        assert record["hashes"]["generated_python_sha256"] == report.source_sha256
        assert record["hashes"]["original_r_source_sha256"]
        assert record["hashes"]["reference_fixtures_sha256"]
        assert record["hashes"]["parameters_sha256"]
        assert record["protocol"] == "stateless_transform_X_params_v1"
        assert record["repair_count"] == 0
        assert record["check_outcomes"][-1]["name"] == "persistence_reload"
        assert record["check_outcomes"][-1]["status"] == "pass"
        assert any(item["name"] == "numpy" for item in record["dependencies"])

        unregister_plugin(candidate_id)
        fresh_service = AlgorithmOnboardingService(tmp_path)
        fresh_report = fresh_service.load_accepted_candidate(candidate_id)
        assert fresh_report.passed
        entry = get_entry(candidate_id)
        assert entry is not None

        from app.services.preprocessing_service import PreprocessingService

        frame = pd.DataFrame([[2.0, 4.0], [6.0, 8.0]], index=["a", "b"], columns=["900", "1000"])
        transformed = PreprocessingService({}).apply_method(frame, candidate_id, {"scale": 3.0})
        np.testing.assert_allclose(transformed.to_numpy(), [[6.0, 12.0], [18.0, 24.0]])
        assert transformed.index.equals(frame.index)
        assert transformed.columns.equals(frame.columns)
    finally:
        unregister_plugin(candidate_id)


def test_tampered_persisted_python_is_rejected_before_registration(tmp_path):
    service = AlgorithmOnboardingService(tmp_path)
    report = service.verify_candidate(make_candidate())
    candidate_id = service.accept_candidate(report, edited_python_source=SCALE_SOURCE, user_confirmed=True)
    unregister_plugin(candidate_id)
    record_path = tmp_path / candidate_id / "plugin.json"
    record = json.loads(record_path.read_text(encoding="utf-8"))
    record["candidate"]["python_source"] += "\n# tampered\n"
    record_path.write_text(json.dumps(record), encoding="utf-8")

    with pytest.raises(AlgorithmOnboardingError, match="manifest hash mismatch"):
        AlgorithmOnboardingService(tmp_path).load_accepted_candidate(candidate_id)
    assert get_entry(candidate_id) is None
    unregister_plugin(candidate_id)


def test_disable_and_remove_require_explicit_record_removal_consent(tmp_path):
    service = AlgorithmOnboardingService(tmp_path)
    report = service.verify_candidate(make_candidate())
    candidate_id = service.accept_candidate(report, edited_python_source=SCALE_SOURCE, user_confirmed=True)

    try:
        assert get_entry(candidate_id) is not None
        assert service.disable_plugin(candidate_id)
        assert get_entry(candidate_id) is None
        with pytest.raises(AlgorithmOnboardingError, match="confirmation"):
            service.remove_plugin_record(candidate_id, user_confirmed=False)
        assert service.remove_plugin_record(candidate_id, user_confirmed=True)
        assert not (tmp_path / candidate_id / "plugin.json").exists()
    finally:
        unregister_plugin(candidate_id)


def test_stateful_category_and_invalid_axis_are_withheld(tmp_path):
    service = AlgorithmOnboardingService(tmp_path)
    stateful = service.verify_candidate(make_candidate(algorithm_category="stateful_preprocessing"))
    bad_axis = service.verify_candidate(make_candidate(axis=[900.0]))

    assert next(item for item in stateful.checks if item.name == "state_contract").status == "fail"
    assert next(item for item in bad_axis.checks if item.name == "axis_preservation").status == "fail"


def test_typed_dataclass_schema_and_required_parameter_validation(tmp_path):
    service = AlgorithmOnboardingService(tmp_path)
    optional = service.verify_candidate(make_candidate(
        parameter_schema={"scale": ParameterField(type="number", default=2.0)},
    ))
    required_missing = service.verify_candidate(make_candidate(
        parameter_schema={"scale": {"type": "number", "required": True}},
    ))

    assert next(item for item in optional.checks if item.name == "parameter_schema").status == "pass"
    assert next(item for item in required_missing.checks if item.name == "parameter_schema").status == "fail"


def test_top_level_side_effects_and_input_mutation_are_rejected(tmp_path):
    top_level_effect = "print('runs while loading')\ndef transform(X, params):\n    return X\n"
    mutation = "def transform(X, params):\n    X[:] = 0\n    return X\n"
    service = AlgorithmOnboardingService(tmp_path)

    side_effect_report = service.verify_candidate(make_candidate(python_source=top_level_effect))
    mutation_report = service.verify_candidate(make_candidate(python_source=mutation))

    assert next(item for item in side_effect_report.checks if item.name == "source_policy").status == "fail"
    assert next(item for item in mutation_report.checks if item.name == "numeric_shape_finiteness").status == "fail"


def test_aliased_side_effect_import_is_rejected_before_candidate_execution(tmp_path):
    output_path = tmp_path / "must_not_be_written.npy"
    source = (
        "from numpy import save as write_array\n"
        "def transform(X, params):\n"
        f"    write_array({str(output_path)!r}, X)\n"
        "    return X\n"
    )

    report = AlgorithmOnboardingService(tmp_path / "plugins").verify_candidate(
        make_candidate(python_source=source)
    )

    policy = next(item for item in report.checks if item.name == "source_policy")
    assert policy.status == "fail"
    assert "save" in policy.details
    assert not output_path.exists()


def test_assigned_numpy_side_effect_alias_is_rejected_before_candidate_execution(tmp_path):
    output_path = tmp_path / "assigned_alias_must_not_write.npy"
    source = (
        "import numpy as np\n"
        "def transform(X, params):\n"
        "    write_array = np.save\n"
        f"    write_array({str(output_path)!r}, X)\n"
        "    return X\n"
    )

    report = AlgorithmOnboardingService(tmp_path / "plugins").verify_candidate(
        make_candidate(python_source=source)
    )

    policy = next(item for item in report.checks if item.name == "source_policy")
    assert policy.status == "fail"
    assert "including aliases" in policy.details
    assert not output_path.exists()


def test_corrupt_json_root_shape_raises_onboarding_error(tmp_path):
    candidate_id = "corrupt_record"
    record_path = tmp_path / candidate_id / "plugin.json"
    record_path.parent.mkdir(parents=True)
    record_path.write_text("[]", encoding="utf-8")

    with pytest.raises(AlgorithmOnboardingError, match="root must be a JSON object"):
        AlgorithmOnboardingService(tmp_path).load_accepted_candidate(candidate_id)
