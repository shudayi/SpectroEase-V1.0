"""Console setup must preserve streams held by Qt, pytest and Optuna."""
import io
import logging
import sys
from unittest.mock import patch

from app.utils.logger import _CurrentConsoleHandler, _ensure_utf8_stdout


def test_utf8_setup_preserves_text_stream_identity_and_existing_handler():
    buffer = io.BytesIO()
    stream = io.TextIOWrapper(buffer, encoding='ascii')
    handler = logging.StreamHandler(stream)
    with patch.object(sys, 'stdout', stream), patch.object(sys, 'stderr', stream):
        _ensure_utf8_stdout()
        _ensure_utf8_stdout()
        assert sys.stdout is stream and sys.stderr is stream
        assert not stream.closed
        handler.emit(logging.LogRecord('held', logging.INFO, '', 0, '光谱', (), None))
        stream.flush()
        assert '光谱'.encode('utf-8') in buffer.getvalue()


def test_capture_stream_and_no_console_remain_untouched():
    captured = io.StringIO()
    with patch.object(sys, 'stdout', captured), patch.object(sys, 'stderr', None):
        _ensure_utf8_stdout()
        assert sys.stdout is captured and sys.stderr is None


def test_console_handler_tracks_replaced_capture_without_using_closed_stream():
    old = io.StringIO()
    current = io.StringIO()
    with patch.object(sys, 'stdout', old):
        handler = _CurrentConsoleHandler()
    old.close()
    record = logging.LogRecord('current', logging.INFO, '', 0, 'visible', (), None)
    with patch.object(sys, 'stdout', current):
        handler.emit(record)
        handler.flush()
    assert current.getvalue().strip() == 'visible'
    with patch.object(sys, 'stdout', None):
        handler.emit(record)
        handler.flush()
