# tests/test_integration_s2.py
"""Integration tests for S2-stage (A1 + D1 + B1 + C1) work."""

import os
import struct
import tempfile
import unittest

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import numpy as np


class A1IntegrationTests(unittest.TestCase):
    def test_csv_dispatch(self):
        with tempfile.NamedTemporaryFile(suffix='.csv', delete=False,
                                       mode='w', encoding='utf-8') as f:
            f.write('label,a,b\n0,1.0,2.0\n1,3.0,4.0\n')
            p = f.name
        try:
            from app.parsers import get_parser
            parser = get_parser(p)
            self.assertIsNotNone(parser)
            df = parser.parse(p)
            self.assertEqual(df.shape, (2, 3))
        finally:
            os.unlink(p)

    def test_spc_old_format(self):
        spc = bytearray(512)
        spc[0] = 0x4B
        struct.pack_into('<i', spc, 4, 4)
        struct.pack_into('<f', spc, 12, 100.0)
        struct.pack_into('<f', spc, 16, 400.0)
        spc += np.array([5, 10, 15, 20], dtype='<i2').tobytes()
        with tempfile.NamedTemporaryFile(suffix='.spc', delete=False) as f:
            f.write(spc)
            p = f.name
        try:
            from app.parsers import get_parser
            df = get_parser(p).parse(p)
            self.assertEqual(df.shape, (4, 2))
        finally:
            os.unlink(p)

    def test_jcamp_xypoints(self):
        body = '##TITLE=t\n##XYPOINTS=(XY)\n1,2\n3,4\n5,6\n##END=\n'
        with tempfile.NamedTemporaryFile(suffix='.jdx', delete=False,
                                       mode='w', encoding='utf-8') as f:
            f.write(body)
            p = f.name
        try:
            from app.parsers import get_parser
            df = get_parser(p).parse(p)
            self.assertEqual(df.shape, (3, 2))
        finally:
            os.unlink(p)


class D1IntegrationTests(unittest.TestCase):
    def test_registry_count(self):
        from app.services import preprocessing  # noqa: F401  registers
        from app.services.preprocessing_registry import list_entries
        entries = list_entries()
        self.assertGreaterEqual(len(entries), 25)

    def test_real_methods_registered(self):
        from app.services import preprocessing  # noqa: F401
        from app.services.preprocessing_registry import list_entries
        real = [e for e in list_entries() if e.quality == 'real']
        keys = {e.key for e in real}
        self.assertIn('Baseline (ALS)', keys)
        self.assertIn('Baseline (airPLS)', keys)
        self.assertIn('Peak Alignment', keys)

    def test_dispatch_through_service(self):
        import pandas as pd
        from app.services.preprocessing_service import PreprocessingService
        svc = PreprocessingService({})
        # Each row is a spectrum. Windows must fit the wavelength count,
        # not the number of samples (the old 50 x 2 fixture masked that bug).
        axis = np.linspace(0, 1, 41)
        df = pd.DataFrame(np.asarray([
            np.sin(axis * 4) + axis * (1 + i / 50)
            for i in range(50)]), columns=[str(950 + 5*i) for i in range(41)])
        for key in ('Savitzky-Golay Filter', 'Standard Normal Variate (SNV)',
                    'First Derivative', 'Baseline (ALS)', 'Baseline (airPLS)',
                    'Peak Alignment'):
            result = svc.apply_method(df, key, {})
            self.assertEqual(result.shape, df.shape)


class B1IntegrationTests(unittest.TestCase):
    def test_metric_registry(self):
        from app.services.metric_registry import list_metrics, get_metric
        reg = list_metrics()
        self.assertGreaterEqual(len(reg), 13)
        for name in ('rmse', 'mae', 'r2', 'mape', 'rpd', 'ccc',
                     'accuracy', 'f1_macro', 'f1_weighted', 'kappa',
                     'roc_auc'):
            self.assertIsNotNone(get_metric(name), name)

    def test_metric_rpd_ccc(self):
        from app.services.metric_registry import get_metric
        y = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        y_pred = y + 0.1
        rpd = get_metric('rpd').fn(y, y_pred)
        ccc = get_metric('ccc').fn(y, y_pred)
        self.assertGreater(rpd, 0)
        self.assertGreater(ccc, 0.9)

    def test_task_detector(self):
        from app.services.task_detector import detect_task_type, is_classification
        self.assertEqual(
            detect_task_type(np.array([0, 1, 2, 0, 1, 2] * 5)),
            'classification',
        )
        self.assertEqual(
            detect_task_type(np.linspace(0, 1, 50) + np.random.RandomState(0).normal(0, 0.01, 50)),
            'regression',
        )
        self.assertTrue(is_classification(np.array([0, 1, 0, 1])))

    def test_evaluate_schema(self):
        from sklearn.ensemble import RandomForestRegressor
        from sklearn.datasets import make_regression
        from app.services.evaluation_service import EvaluationService
        X, y = make_regression(n_samples=80, n_features=4, noise=10,
                                random_state=0)
        rf = RandomForestRegressor(n_estimators=10, random_state=0).fit(X, y)
        yp = rf.predict(X)
        es = EvaluationService()
        res = es.evaluate(y, yp, metrics=['rmse', 'mae', 'r2', 'mape',
                                          'rpd', 'ccc'])
        self.assertEqual(res.get('schema_version'), 1)
        self.assertEqual(res.get('task_type'), 'regression')
        for k in ('rmse', 'mae', 'r2', 'mape', 'rpd', 'ccc'):
            self.assertIn(k, res)
            self.assertIsNotNone(res[k])


class C1IntegrationTests(unittest.TestCase):
    def test_tokens_present(self):
        from app.ui import design_tokens as tok
        for k in ('CMAP_SEQUENTIAL', 'CMAP_DIVERGING', 'CMAP_QUALITATIVE',
                  'PALETTE_DEFAULT', 'PALETTE_FOREGROUND',
                  'PALETTE_BACKGROUND', 'PALETTE_GRID', 'PALETTE_AXIS',
                  'PALETTE_SUBTITLE', 'PALETTE_LEGEND_FRAME',
                  'DEFAULT_CMAP', 'COLOR_BLIND_PALETTE'):
            self.assertTrue(hasattr(tok, k))

    def test_mpl_theme_token_palette(self):
        from app.ui import mpl_theme
        from app.ui import design_tokens as tok
        pal = mpl_theme.get_color_palette(3)
        self.assertEqual(len(pal), 3)
        self.assertEqual(pal[0], tok.PALETTE_DEFAULT[0])

    def test_report_theme_default(self):
        from plugins.reporting.spectrum_report_generator import (
            ReportTheme, SpectrumReportGenerator,
        )
        gen = SpectrumReportGenerator(output_dir='/tmp/spc_test_reports')
        self.assertEqual(gen.theme.font_name, 'Helvetica')
        self.assertEqual(gen.theme.title_pt, 24)
        custom = ReportTheme(title_pt=18, font_name='Helvetica-Bold')
        gen2 = SpectrumReportGenerator(output_dir='/tmp/spc_test_reports',
                                        theme=custom)
        self.assertEqual(gen2.theme.title_pt, 18)


if __name__ == '__main__':
    unittest.main()
