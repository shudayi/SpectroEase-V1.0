"""Logical-screen sizing and responsive layout regression tests.

Fake screens exercise the sizing contract, non-zero work-area origins,
dialog clamping, and compact pane switching.  They do not emulate Windows'
native mixed-DPI window transitions.
"""
import os
import unittest
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt5.QtCore import QRect, QSize, Qt
from PyQt5.QtWidgets import QApplication, QDialog, QToolBar

from app.utils import ui_scaling as ui_mod
from app.utils import responsive as responsive_mod
from app.utils.ui_scaling import ui_scaling_manager as u, scaled_px
from app.ui import design_tokens as tok


class _FakeSignal:
    def __init__(self):
        self._slots = []

    def connect(self, slot):
        self._slots.append(slot)

    def disconnect(self, slot):
        if slot in self._slots:
            self._slots.remove(slot)

    def emit(self, *args):
        for slot in list(self._slots):
            slot(*args)


class _FakeScreen:
    def __init__(self, width, height, dpi=96, origin=(0, 0), available_rect=None, dpr=1.0):
        self._size = QSize(width, height)
        self._dpi = dpi
        self._dpr = dpr
        self._origin = origin
        self._available_rect = available_rect
        self.availableGeometryChanged = _FakeSignal()
        self.geometryChanged = _FakeSignal()
        self.logicalDotsPerInchChanged = _FakeSignal()

    def size(self):
        return self._size

    def geometry(self):
        return QRect(self._origin[0], self._origin[1], self._size.width(), self._size.height())

    def availableGeometry(self):
        return self._available_rect or self.geometry()

    def logicalDotsPerInch(self):
        return self._dpi

    def logicalDotsPerInchX(self):
        return self._dpi

    def logicalDotsPerInchY(self):
        return self._dpi

    def devicePixelRatio(self):
        return self._dpr

    def set_dpi(self, dpi):
        self._dpi = dpi
        self.logicalDotsPerInchChanged.emit(dpi)


def _force_screen(app, width, height, dpi=96, origin=(0, 0), available_rect=None, dpr=1.0):
    """Override primaryScreen and the manager's cached info."""
    fake = _FakeScreen(width, height, dpi, origin, available_rect, dpr)
    app.primaryScreen = lambda: fake
    u.refresh_for_screen(fake)
    return fake


class ScreenTierTests(unittest.TestCase):
    def setUp(self):
        self.app = QApplication.instance() or QApplication([])

    def test_tier_classification(self):
        cases = [
            (1280, 720, "compact"),
            (1366, 768, "compact"),
            (1600, 900, "standard"),
            (1920, 1080, "wide"),
            (2560, 1440, "ultrawide"),
            (3840, 2160, "ultrawide"),
        ]
        for width, height, expected in cases:
            _force_screen(self.app, width, height)
            self.assertEqual(u.tier(), expected, msg=f"{width}x{height}")

    def test_main_window_size_clamps(self):
        # Small logical work areas use most of the screen; larger areas retain
        # a 2/3 startup size.  Sizes must always fit in the logical work area.
        for width, height in [(1366, 768), (1920, 1080), (2560, 1440), (3840, 2160)]:
            _force_screen(self.app, width, height)
            w, h = u.get_main_window_size()
            usable_w, usable_h = width - 8, height - 8
            if usable_w <= 1400 or usable_h <= 760:
                target_w, target_h = int(usable_w * .90), int(usable_h * .94)
            else:
                target_w, target_h = int(usable_w * 2 / 3), int(usable_h * 2 / 3)
            self.assertEqual((w, h), (target_w, target_h))
            self.assertLessEqual(w, usable_w)
            self.assertLessEqual(h, usable_h)

    def test_scaled_geometry_is_identity_at_multiple_logical_dpi_values(self):
        for width, height, dpi, dpr in [
            (1366, 768, 96, 1.0),
            (1280, 720, 144, 1.5),
            (1920, 1080, 192, 2.0),
            (3840, 2160, 96, 1.0),
        ]:
            _force_screen(self.app, width, height, dpi=dpi, dpr=dpr)
            self.assertEqual(u.scale_factor, 1.0)
            self.assertEqual(u.font_scale, 1.0)
            self.assertEqual(scaled_px(120), 120)
            self.assertEqual(ui_mod.scaled_pt(10), 10)

    def test_table_height_tier(self):
        _force_screen(self.app, 1280, 720)
        self.assertEqual(u.get_table_height_for_height(800), scaled_px(tok.RESULT_TABLE_HEIGHT_SM))
        _force_screen(self.app, 1920, 1080)
        self.assertEqual(u.get_table_height_for_height(1080), scaled_px(tok.RESULT_TABLE_HEIGHT_LG))
        _force_screen(self.app, 3840, 2160)
        self.assertEqual(u.get_table_height_for_height(2160), scaled_px(tok.RESULT_TABLE_HEIGHT_XL))


class DataPartitioningViewTests(unittest.TestCase):
    def setUp(self):
        self.app = QApplication.instance() or QApplication([])

    def _build_view(self):
        from app.views.data_view import DataPartitioningView
        view = DataPartitioningView({})
        view.resize(560, 760)
        return view

    def test_view_fits_in_compact_workflow_width(self):
        for width, height in [(1366, 768), (1920, 1080), (3840, 2160)]:
            _force_screen(self.app, width, height)
            view = self._build_view()
            info_frame = getattr(view, "info_frame", None)
            self.assertIsNotNone(info_frame)
            self.assertIsNotNone(info_frame.objectName())
            self.assertIn(info_frame.objectName(), ("statusCard", ""))
            # Card must be visible and not collapsed.
            self.assertGreater(info_frame.width(), 0)
            page_title = getattr(view, "page_title", None)
            self.assertIsNotNone(page_title)
            self.assertEqual(page_title.objectName(), "pageTitle")

    def test_partition_button_visible_across_tiers(self):
        for width, height in [(1366, 768), (1920, 1080), (3840, 2160)]:
            _force_screen(self.app, width, height)
            view = self._build_view()
            btn = view.partition_data_btn
            self.assertTrue(btn.isEnabled() is False or btn.isEnabled())
            # Button must not be collapsed.
            self.assertGreater(btn.minimumSizeHint().width(), 0)


class ResponsiveDialogTests(unittest.TestCase):
    def setUp(self):
        self.app = QApplication.instance() or QApplication([])

    def test_fit_uses_current_screen_origin_and_caps_minimum_to_work_area(self):
        screen = _FakeScreen(
            900,
            700,
            origin=(-900, -100),
            available_rect=QRect(-900, -60, 860, 660),
            dpr=1.5,
        )
        dialog = QDialog()
        with patch.object(responsive_mod, "_widget_screen", return_value=screen):
            responsive_mod.fit_window_to_screen(
                dialog,
                preferred_width=1000,
                preferred_height=800,
                min_width=950,
                min_height=750,
                margin=20,
            )
        self.assertEqual((dialog.width(), dialog.height()), (840, 640))
        self.assertEqual((dialog.pos().x(), dialog.pos().y()), (-900, -60))
        dialog.close()
        dialog.deleteLater()

    def test_screen_resolution_prefers_parent_window_screen(self):
        owner_screen = _FakeScreen(1600, 900, dpi=144, dpr=1.5)
        fallback_screen = _FakeScreen(1920, 1080)

        class FakeHandle:
            def screen(self):
                return owner_screen

        class FakeOwner:
            def window(self):
                return self

            def windowHandle(self):
                return FakeHandle()

            def screen(self):
                return fallback_screen

        class FakeDialog:
            def parentWidget(self):
                return FakeOwner()

        self.assertIs(responsive_mod._widget_screen(FakeDialog()), owner_screen)


class VisualizationWidgetTests(unittest.TestCase):
    def setUp(self):
        self.app = QApplication.instance() or QApplication([])

    def test_nav_toolbar_icon_size_scales(self):
        from app.views.visualization_widget import VisualizationWidget
        _force_screen(self.app, 1920, 1080, dpi=96)
        widget = VisualizationWidget(x_unit="nm")
        nav = widget.nav_toolbar
        self.assertGreaterEqual(nav.iconSize().width(), 20)
        widget.deleteLater()

        _force_screen(self.app, 1920, 1080, dpi=192)  # 200% DPI
        widget2 = VisualizationWidget(x_unit="nm")
        self.assertGreaterEqual(widget2.nav_toolbar.iconSize().width(), 20)
        widget2.deleteLater()

    def test_change_event_re_applies_plot_style(self):
        from app.views.visualization_widget import VisualizationWidget
        from PyQt5.QtCore import QEvent
        _force_screen(self.app, 1920, 1080)
        widget = VisualizationWidget(x_unit="nm")
        # PyQt5 does not expose QEvent.DpiChange; use StyleChange which is
        # the most portable cross-platform signal we have. The changeEvent
        # handler must accept both the DpiChange (Qt6 / future) and
        # StyleChange variants without raising.
        event_type = getattr(QEvent, "StyleChange", None) or QEvent.Type.StyleChange
        event = QEvent(event_type)
        widget.changeEvent(event)
        widget.deleteLater()


class MainWindowTests(unittest.TestCase):
    def setUp(self):
        self.app = QApplication.instance() or QApplication([])

    def _build_main_window(self):
        # Avoid the heavy main_window import if PyQt already started.
        from app.views.main_window import MainWindow
        from app.utils.translator import Translator
        from app.services.llm_service import LLMService
        try:
            llm = LLMService(api_key="")
        except Exception:
            llm = None
        win = MainWindow(
            Translator(language="en"),
            {}, {}, {}, {},
            llm,
        )
        return win

    def test_main_window_size_across_tiers(self):
        for width, height in [(1366, 768), (1920, 1080), (3840, 2160)]:
            _force_screen(self.app, width, height)
            expected_size = u.get_main_window_size()
            win = self._build_main_window()
            self.assertEqual((win.width(), win.height()), expected_size)
            self.assertLessEqual(win.width(), width - 8)
            self.assertLessEqual(win.height(), height - 8)
            self.assertGreater(win.result_table.minimumHeight(), 0)
            win.close()
            win.deleteLater()

    def test_main_window_centers_on_nonzero_logical_screen_origin(self):
        screen = _force_screen(
            self.app,
            1920,
            1080,
            origin=(-1920, -120),
            available_rect=QRect(-1920, -80, 1880, 1020),
        )
        win = self._build_main_window()
        available = screen.availableGeometry()
        expected_x = available.x() + (available.width() - win.width()) // 2
        expected_y = available.y() + (available.height() - win.height()) // 2
        self.assertEqual(win.pos().x(), expected_x)
        self.assertEqual(win.pos().y(), expected_y)
        win.close()
        win.deleteLater()

    def test_compact_layout_switches_orientation_and_keeps_both_panes_scrollable(self):
        _force_screen(self.app, 1920, 1080)
        win = self._build_main_window()
        win.resize(900, 650)
        win._update_responsive_layout()
        self.app.processEvents()
        self.assertEqual(win._main_splitter.orientation(), Qt.Vertical)
        self.assertIs(win.workflow_scroll_area.widget(), win.workflow_tabs)
        self.assertIsNotNone(win.results_scroll_area.widget())

        win.resize(1300, 850)
        win._update_responsive_layout()
        self.app.processEvents()
        self.assertEqual(win._main_splitter.orientation(), Qt.Vertical)

        win.resize(900, 650)
        win._update_responsive_layout()
        win.show()
        self.app.processEvents()
        self.assertEqual(win._main_splitter.orientation(), Qt.Vertical)
        self.assertGreater(win.workflow_scroll_area.verticalScrollBar().maximum(), 0)
        self.assertGreater(win.results_scroll_area.verticalScrollBar().maximum(), 0)
        win.close()
        win.deleteLater()

    def test_main_window_layout_breakpoint_is_compact_below_1440_and_wide_at_1440(self):
        screen = _force_screen(self.app, 1440, 900)
        win = self._build_main_window()
        win.resize(1439, 850)
        win._update_responsive_layout(force=True)
        self.app.processEvents()
        self.assertEqual(win._main_splitter.orientation(), Qt.Vertical)
        win.resize(1440, 850)
        win._update_responsive_layout(force=True)
        self.app.processEvents()
        self.assertEqual(win._main_splitter.orientation(), Qt.Horizontal)
        win.close()
        win.deleteLater()

    def test_main_window_minimum_is_capped_to_logical_available_geometry(self):
        _force_screen(
            self.app,
            683,
            384,
            dpi=192,
            dpr=2.0,
            available_rect=QRect(0, 0, 667, 368),
        )
        win = self._build_main_window()
        self.assertLessEqual(win.minimumWidth(), 667)
        self.assertLessEqual(win.minimumHeight(), 368)
        win.close()
        win.deleteLater()

    def test_main_window_rebinds_metrics_when_qt_reports_screen_change(self):
        _force_screen(self.app, 1920, 1080)
        win = self._build_main_window()
        secondary = _FakeScreen(
            1000,
            700,
            dpi=144,
            origin=(-1000, 0),
            available_rect=QRect(-1000, 0, 980, 660),
            dpr=1.5,
        )
        win._on_window_screen_changed(secondary)
        self.assertEqual(u.screen_info["width"], 1000)
        self.assertEqual(u.screen_info["dpi"], 144)
        self.assertEqual(win._main_splitter.orientation(), Qt.Vertical)

        secondary.set_dpi(192)
        self.assertEqual(u.screen_info["dpi"], 192)
        self.assertEqual(u.scale_factor, 1.0)
        self.assertEqual(u.font_scale, 1.0)
        win.close()
        win.deleteLater()

    def test_toolbar_icon_size_at_ultrawide(self):
        for width, height in [(1920, 1080), (3840, 2160)]:
            _force_screen(self.app, width, height)
            win = self._build_main_window()
            toolbars = win.findChildren(QToolBar)
            self.assertGreater(len(toolbars), 0)
            tb = toolbars[0]
            self.assertGreaterEqual(tb.iconSize().width(), 20)
            win.close()
            win.deleteLater()


class CompactSettingsLayoutTests(unittest.TestCase):
    def test_small_screen_settings_forms_scroll_without_overlapping(self):
        from app.views.settings_dialog import SettingsDialog
        from config.settings import Settings
        from PyQt5.QtWidgets import QScrollArea, QTabWidget
        app = QApplication.instance() or QApplication([])
        screen = _FakeScreen(911, 512)
        with patch.object(responsive_mod, "_widget_screen", return_value=screen):
            dialog = SettingsDialog(Settings())
        dialog.show()
        app.processEvents()
        tabs = dialog.findChild(QTabWidget)
        self.assertEqual(tabs.count(), 3)
        self.assertTrue(all(isinstance(tabs.widget(i), QScrollArea) for i in range(3)))
        tabs.setCurrentIndex(1)
        app.processEvents()
        fields = [dialog.categorical_count_spin, dialog.categorical_ratio_spin,
                  dialog.isolation_forest_spin]
        for earlier, later in zip(fields, fields[1:]):
            self.assertLess(earlier.geometry().bottom(), later.geometry().top())
        self.assertGreater(tabs.widget(1).verticalScrollBar().maximum(), 0)
        tabs.setCurrentIndex(2)
        app.processEvents()
        self.assertGreaterEqual(dialog.cls_metrics_list.height(), 110)
        self.assertGreaterEqual(dialog.reg_metrics_list.height(), 100)
        self.assertLessEqual(dialog.width(), 911)
        self.assertLessEqual(dialog.height(), 512)
        dialog.close()
        dialog.deleteLater()


if __name__ == "__main__":
    unittest.main()
