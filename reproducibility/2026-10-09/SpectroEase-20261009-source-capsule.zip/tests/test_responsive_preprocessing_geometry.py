"""Actual themed geometry and spectral-unit regressions from public-data visual review."""
import numpy as np
import pytest
from PyQt5.QtWidgets import QApplication,QComboBox,QSpinBox,QDoubleSpinBox
from PyQt5.QtCore import QRect,QPoint
from PyQt5.QtTest import QTest
from app.utils.translator import Translator,translator
from app.views.main_window import MainWindow
from app.ui.style_sheet_builder import build_app_stylesheet
from app.services.llm_service import LLMService
from app.views.visualization_widget import VisualizationWidget


@pytest.mark.parametrize('width,height', [(1024,768),(1366,768),(1920,1080),(683,384),(512,384)])
def test_preprocessing_form_fields_do_not_overlap_at_small_work_areas(width,height):
    app=QApplication.instance() or QApplication([])
    class Screen:
        def availableGeometry(self):return QRect(0,0,width,height)
        def geometry(self):return self.availableGeometry()
        def logicalDotsPerInch(self):return 96
        def devicePixelRatio(self):return 1
    win=MainWindow(Translator('en'),{},{},{},{},LLMService(''))
    win.setStyleSheet(build_app_stylesheet('light'))
    win._current_qt_screen=lambda:Screen()
    win._run_scheduled_screen_refresh=lambda:setattr(win,'_screen_refresh_pending',False)
    win.setMinimumSize(*win._minimum_size_for_available_geometry(QRect(0,0,width,height)))
    win.workflow_tabs.setCurrentIndex(1);win.show();win.resize(width,height)
    win._update_responsive_layout(force=True);app.processEvents();QTest.qWait(150)
    for name in ('despiking_params_container','baseline_params_container','scatter_params_container','smoothing_params_container'):
        container=getattr(win,name)
        controls=[widget for widget in container.findChildren((QComboBox,QSpinBox,QDoubleSpinBox)) if not widget.isHidden()]
        rectangles=[(widget,QRect(widget.mapTo(container,QPoint(0,0)),widget.size())) for widget in controls]
        for index,(widget,rect) in enumerate(rectangles):
            assert widget.height() >= widget.minimumHeight(), (name,rect)
            for other,other_rect in rectangles[index+1:]:
                assert not rect.intersects(other_rect), (name,rect,other_rect)
    win.close();app.processEvents()


def test_spectral_label_is_neutral_or_explicit_and_survives_small_canvas_resize():
    app=QApplication.instance() or QApplication([])
    previous=translator.language
    translator.set_language('en')
    widget=VisualizationWidget()
    try:
        axis=np.linspace(950,1650,141)
        spectra=np.vstack([np.sin(axis/100)+i*.1 for i in range(5)])
        widget.plot_spectra(axis,spectra,title='Mapped source values')
        assert widget.ax.get_ylabel() == 'Spectral value'
        widget.show()
        for width,height in ((640,420),(420,320)):
            widget.resize(width,height);app.processEvents();QTest.qWait(200);widget.canvas.draw()
            renderer=widget.canvas.get_renderer()
            label=widget.ax.xaxis.label.get_window_extent(renderer)
            bounds=widget.figure.bbox
            assert label.y0 >= bounds.y0 - 1, (label.bounds,bounds.bounds)
            assert label.x0 >= bounds.x0 - 1 and label.x1 <= bounds.x1 + 1
        assert widget.set_spectral_y_label('Reflectance (%)')
        assert widget.ax.get_ylabel() == 'Reflectance (%)'
        widget.refresh_current_plot()
        assert widget.ax.get_ylabel() == 'Reflectance (%)'
        with pytest.raises(ValueError,match='cannot be empty'):widget.set_spectral_y_label(' ')
        translator.set_language('zh')
        assert translator.translate('visualization_widget.spectral_value_label') == '\u5149\u8c31\u503c'
    finally:
        widget.close();translator.set_language(previous)
