"""Execute each supported fold-safe pipeline on both task types."""
import numpy as np
import pandas as pd
import pytest

from app.services.modeling_service import ModelingService
from app.utils.exceptions import ModelingError


@pytest.mark.parametrize('task', ['classification', 'regression'])
@pytest.mark.parametrize('method', ['rf', 'svm', 'knn', 'dt', 'Neural Network'])
def test_all_pipeline_estimators_fit_predict(task, method):
    rng = np.random.default_rng(13)
    X = pd.DataFrame(rng.normal(size=(24, 4)))
    y = (X[0].to_numpy() > 0).astype(int) if task == 'classification' else X[0].to_numpy()
    params = {'max_iter': 5, 'hidden_layer_sizes': (3,)} if method == 'Neural Network' else {}
    pipeline = ModelingService({}).create_leak_proof_pipeline(method, params, task)
    pipeline.fit(X.iloc[:20], y[:20])
    assert pipeline.predict(X.iloc[20:]).shape == (4,)


def test_pipeline_rejects_unknown_task():
    with pytest.raises(ModelingError, match='Unsupported task type'):
        ModelingService({}).create_leak_proof_pipeline('rf', {}, 'unknown')
