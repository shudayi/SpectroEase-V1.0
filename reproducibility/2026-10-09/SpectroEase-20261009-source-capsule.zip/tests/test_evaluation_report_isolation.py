"""Evaluation/report figure isolation and target-space presentation checks."""
import base64
import json
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import matplotlib.pyplot as plt
import numpy as np
import pytest
from matplotlib.figure import Figure
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

from app.services.evaluation_service import EvaluationService
from app.services.prediction_contract import FittedSpectrumPredictor
from app.version import APP_VERSION, APP_VERSION_SOURCE
from plugins.reporting.spectrum_report_generator import SpectrumReportGenerator


def _corrected_predictions():
    # The estimator predicts standardized y; the production wrapper restores
    # the original target units before evaluation/report presentation.
    x = np.arange(5.0).reshape(-1, 1)
    y = 100.0 + 12.0 * x[:, 0]
    scaler = StandardScaler().fit(y.reshape(-1, 1))
    estimator = LinearRegression().fit(x, scaler.transform(y.reshape(-1, 1)).ravel())
    predictor = FittedSpectrumPredictor(
        estimator, "regression", y_scaler=scaler, n_features=1,
    )
    return predictor.predict_result(x, row_ids=tuple(f"r{i}" for i in range(5)))


def test_owned_evaluation_figures_preserve_predictions_matrix_order_and_global_state(monkeypatch):
    sentinel, axis = plt.subplots()
    axis.plot([1, 2], [3, 4], label="existing GUI figure")
    numbers = plt.get_fignums()
    current = plt.gcf()
    rc_before = dict(plt.rcParams)
    line_data = axis.lines[0].get_ydata().copy()
    snapshots = []
    original_savefig = Figure.savefig

    def inspect_and_save(figure, *args, **kwargs):
        main_axis = figure.axes[0]
        snapshot = {"title": main_axis.get_title(),
                    "xlabel": main_axis.get_xlabel(), "ylabel": main_axis.get_ylabel()}
        if main_axis.get_title() == "Residual Plot":
            snapshot["points"] = np.asarray(main_axis.collections[0].get_offsets()).copy()
        else:
            snapshot["matrix"] = np.asarray(main_axis.collections[0].get_array()).reshape(2, 2).copy()
            snapshot["xclasses"] = [label.get_text() for label in main_axis.get_xticklabels()]
            snapshot["yclasses"] = [label.get_text() for label in main_axis.get_yticklabels()]
        snapshots.append(snapshot)
        return original_savefig(figure, *args, **kwargs)

    monkeypatch.setattr(Figure, "savefig", inspect_and_save)
    prediction = _corrected_predictions()
    observed = prediction.predictions + np.array([1.0, -2.0, 0.5, 3.0, -1.0])
    before_prediction = prediction.predictions.copy()
    service = EvaluationService()
    try:
        for _ in range(4):
            regression = service.evaluate(observed, prediction.predictions,
                                          metrics=["rmse", "mae", "r2", "residual_plot"],
                                          task_type=prediction.task_type)
            assert regression["rmse"] == pytest.approx(np.sqrt(mean_squared_error(observed, prediction.predictions)))
            assert regression["mae"] == pytest.approx(mean_absolute_error(observed, prediction.predictions))
            assert regression["r2"] == pytest.approx(r2_score(observed, prediction.predictions))
            classification = service.evaluate(["Zeta", "Alpha", "Zeta", "Alpha"],
                                              ["Alpha", "Alpha", "Zeta", "Alpha"],
                                              metrics=["accuracy", "confusion_matrix"],
                                              task_type="classification")
            assert classification["accuracy"] == .75
            assert classification["confusion_matrix"] == [[2, 0], [1, 1]]
            assert classification["confusion_matrix_labels"] == ["Alpha", "Zeta"]
            assert base64.b64decode(regression["residual_plot"]).startswith(b"\x89PNG")
            assert base64.b64decode(classification["confusion_matrix_plot"]).startswith(b"\x89PNG")
            assert plt.get_fignums() == numbers
            assert plt.gcf() is current
            assert dict(plt.rcParams) == rc_before
        for snapshot in snapshots:
            if snapshot["title"] == "Residual Plot":
                assert np.allclose(snapshot["points"][:, 0], prediction.predictions)
                assert np.allclose(snapshot["points"][:, 1], observed - prediction.predictions)
                assert (snapshot["xlabel"], snapshot["ylabel"]) == ("Predicted Values", "Residuals")
            else:
                assert np.array_equal(snapshot["matrix"], [[2, 0], [1, 1]])
                assert snapshot["xclasses"] == snapshot["yclasses"] == ["Alpha", "Zeta"]
        assert np.array_equal(prediction.predictions, before_prediction)
        assert np.array_equal(axis.lines[0].get_ydata(), line_data)
    finally:
        plt.close(sentinel)


def test_failed_render_retains_metrics_and_does_not_leak_figures(monkeypatch):
    sentinel = plt.figure()
    numbers = plt.get_fignums()
    rc_before = dict(plt.rcParams)
    figures = []

    def fail_save(figure, *args, **kwargs):
        figures.append(figure)
        raise OSError("simulated image encoder failure")

    monkeypatch.setattr(Figure, "savefig", fail_save)
    try:
        service = EvaluationService()
        result = service.evaluate([1., 2., 3.], [1., 2., 4.],
                                  metrics=["rmse", "residual_plot"], task_type="regression")
        assert result["rmse"] == pytest.approx(np.sqrt(1 / 3))
        assert "residual_plot" not in result
        result = service.evaluate(["A", "B"], ["A", "A"],
                                  metrics=["accuracy", "confusion_matrix"], task_type="classification")
        assert result["accuracy"] == .5
        assert result["confusion_matrix"] == [[1, 0], [1, 0]]
        assert "confusion_matrix_error" in result
        assert len(figures) == 2
        assert all(not figure.axes for figure in figures)
        assert plt.get_fignums() == numbers
        assert plt.gcf() is sentinel
        assert dict(plt.rcParams) == rc_before
    finally:
        plt.close(sentinel)


def test_repeated_pdf_reports_preserve_source_units_metrics_version_and_global_figure(tmp_path):
    from pypdf import PdfReader

    sentinel = plt.figure()
    numbers = plt.get_fignums()
    rc_before = dict(plt.rcParams)
    prediction = _corrected_predictions()
    observed = prediction.predictions + np.array([1.0, -2.0, 0.5, 3.0, -1.0])
    service = EvaluationService()
    metrics = service.evaluate(observed, prediction.predictions, task_type="regression")
    source_metrics = dict(metrics)
    info = service.generate_reproducibility_info()
    assert info["software_versions"]["spectroease"] == APP_VERSION
    assert info["software_versions"]["spectroease_version_source"] == APP_VERSION_SOURCE
    generator = SpectrumReportGenerator(output_dir=str(tmp_path))
    try:
        for index in range(4):
            path = generator.generate_report(
                {"shape": (5, 141), "wavelength_range": "950-1650 nm", "n_samples": 5, "n_features": 141},
                {}, {}, metrics, reproducibility_info=info, title=f"Isolation report {index}",
            )
            document = PdfReader(path)
            text = "\n".join(page.extract_text() or "" for page in document.pages)
            assert "950-1650 nm" in text
            assert "rmse" in text and str(metrics["rmse"]) in text
            assert "mae" in text and str(metrics["mae"]) in text
            assert "r2" in text and str(metrics["r2"]) in text
            sidecar = json.loads(open(path[:-4] + "_reproducibility.json", encoding="utf-8").read())
            assert sidecar["software_versions"]["spectroease"] == APP_VERSION
            assert sidecar["software_versions"]["spectroease_version_source"] == APP_VERSION_SOURCE
            assert plt.get_fignums() == numbers
            assert plt.gcf() is sentinel
            assert dict(plt.rcParams) == rc_before
            assert metrics == source_metrics
    finally:
        plt.close(sentinel)
