"""Prevent incomplete or false-positive results in the in-app test agent."""
import subprocess
from pathlib import Path
from unittest.mock import patch

from app.tools.test_agent import existing_tests as agent


def test_discovery_covers_application_tests_and_excludes_dependencies(tmp_path):
    (tmp_path / "tests" / "nested").mkdir(parents=True)
    (tmp_path / "build_dist" / "vendor").mkdir(parents=True)
    for name in ["tests/test_a.py", "tests/nested/test_b.py",
                 "build_dist/vendor/test_hidden.py", "tests/helper.py"]:
        (tmp_path / name).write_text("", encoding="utf-8")
    assert agent.discover_test_files(tmp_path) == [
        "tests/nested/test_b.py", "tests/test_a.py"]


def test_discovery_matches_current_repository():
    root = Path(__file__).resolve().parents[1]
    assert set(agent.discover_test_files(root)) == {
        p.relative_to(root).as_posix() for p in (root / "tests").rglob("test_*.py")}
    assert "tests/test_algorithm_onboarding_service.py" in agent.TEST_FILES
    assert "tests/test_predictor_contract.py" in agent.TEST_FILES


def _fake_run(exit_code, xml_tests=1):
    def run(python, test_file, junit):
        junit.write_text(
            f'<testsuites><testsuite name="audit" tests="{xml_tests}" '
            'failures="0" errors="0" skipped="0" time="0"/></testsuites>',
            encoding="utf-8")
        return subprocess.CompletedProcess([], exit_code, "result", "")
    return run


def test_nonzero_exit_fails_even_with_green_xml():
    with patch.object(agent, "TEST_FILES", ["tests/test_fake.py"]), \
            patch.object(agent, "run_pytest_one", side_effect=_fake_run(1)):
        report = agent.run_existing_tests()
    assert not report.passed
    assert report.total_failures == 1


def test_empty_junit_is_not_success():
    with patch.object(agent, "TEST_FILES", ["tests/test_fake.py"]), \
            patch.object(agent, "run_pytest_one", side_effect=_fake_run(0, 0)):
        assert not agent.run_existing_tests().passed


def test_timeout_is_recorded_and_next_file_runs():
    good = _fake_run(0)
    def run(python, name, junit):
        if name.endswith("bad.py"):
            raise subprocess.TimeoutExpired([python], 180)
        return good(python, name, junit)
    with patch.object(agent, "TEST_FILES", ["tests/test_bad.py", "tests/test_ok.py"]), \
            patch.object(agent, "run_pytest_one", side_effect=run):
        report = agent.run_existing_tests()
    assert not report.passed
    assert len(report.suites) == 2
    assert report.suites[1].passed


def test_no_test_files_is_not_success():
    with patch.object(agent, "TEST_FILES", []):
        assert not agent.run_existing_tests().passed

def test_all_skipped_tests_are_not_certified_as_executed():
    def run(python,test_file,junit):
        junit.write_text('<testsuites><testsuite tests="3" failures="0" errors="0" skipped="3" time="0"/></testsuites>',encoding='utf-8')
        return subprocess.CompletedProcess([],0,'','')
    with patch.object(agent,'TEST_FILES',['tests/test_optional.py']),patch.object(agent,'run_pytest_one',side_effect=run):
        report=agent.run_existing_tests()
    assert not report.passed
    assert report.suites[0].skipped==3

def test_same_basename_test_files_cannot_reuse_old_xml():
    seen=[]
    def run(python,test_file,junit):
        seen.append(junit)
        if len(seen)==1:
            junit.write_text('<testsuites><testsuite tests="1" failures="0" errors="0" skipped="0" time="0"/></testsuites>')
        return subprocess.CompletedProcess([],0,'','')
    with patch.object(agent,'TEST_FILES',['tests/a/test_equal.py','tests/b/test_equal.py']),patch.object(agent,'run_pytest_one',side_effect=run):
        report=agent.run_existing_tests()
    assert seen[0]!=seen[1]
    assert not report.passed
    assert report.suites[0].passed and not report.suites[1].passed
