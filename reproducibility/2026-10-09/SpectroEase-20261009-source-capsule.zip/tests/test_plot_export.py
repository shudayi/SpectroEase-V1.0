import json
import os
import re
from dataclasses import FrozenInstanceError
from io import BytesIO

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
from PIL import Image
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

from app.services.plot_export_service import ExportProfile, export_figure
from app.ui import design_tokens as tok
from app.ui.mpl_layout import layout_figure
from app.ui.mpl_theme import get_series_style


def _make_figure():
    figure = Figure(figsize=(4.0, 2.0), dpi=110)
    FigureCanvasAgg(figure)
    axis = figure.add_subplot(111)
    axis.plot([400, 500, 600], [0.1, 0.7, 0.3], label="Class A", linewidth=1.5)
    axis.plot([400, 500, 600], [0.2, 0.4, 0.6], label="Class B", linestyle="--")
    axis.set_title("Representative spectra")
    axis.set_xlabel("Wavelength (nm)")
    axis.set_ylabel("Absorbance (a.u.)")
    axis.legend()
    axis.grid(True)
    figure.tight_layout()
    return figure


def _render_pixels(figure):
    buffer = BytesIO()
    figure.savefig(buffer, format="png", dpi=120)
    buffer.seek(0)
    return np.asarray(Image.open(buffer).convert("RGBA"))


def test_shared_layout_wraps_full_legend_labels_inside_figure_canvas():
    figure = Figure(figsize=(4.5, 2.6), dpi=120)
    canvas = FigureCanvasAgg(figure)
    axis = figure.add_subplot(111)
    labels = [
        "Control group with long treatment description A",
        "Control group with long treatment description B",
    ]
    axis.plot([400, 500, 600], [0.1, 0.4, 0.2], label=labels[0])
    axis.plot([400, 500, 600], [0.2, 0.3, 0.6], label=labels[1])
    axis.set_xlabel("Wavelength (nm)")
    axis.set_ylabel("Absorbance (a.u.)")
    legend = axis.legend()

    layout_figure(figure, legend_fontsize=8)
    canvas.draw()

    figure_box = figure.get_window_extent(canvas.get_renderer())
    legend_box = legend.get_window_extent(canvas.get_renderer())
    assert legend_box.x0 >= figure_box.x0
    assert legend_box.x1 <= figure_box.x1 + 1
    assert legend_box.y0 >= figure_box.y0
    assert legend_box.y1 <= figure_box.y1
    assert axis.get_position().width > 0.40
    for artist, expected in zip(legend.get_texts(), labels):
        assert artist._spectroease_full_label == expected
        assert " ".join(artist.get_text().split()) == expected
        assert "\n" in artist.get_text()


def test_wide_layout_moves_small_class_legend_below_and_uses_canvas_width():
    figure = Figure(figsize=(11.0, 5.8), dpi=100)
    canvas = FigureCanvasAgg(figure)
    axis = figure.add_subplot(111)
    for index, label in enumerate(("Class A", "Class B", "Class C", "Class D")):
        axis.plot([400, 500, 600], [index, index + 0.3, index + 0.1], label=label)
    legend = axis.legend()

    layout_figure(figure)
    canvas.draw()
    renderer = canvas.get_renderer()
    figure_box = figure.get_window_extent(renderer)
    legend_box = legend.get_window_extent(renderer)
    assert axis.get_position().width > 0.72
    assert legend_box.x0 >= figure_box.x0
    assert legend_box.x1 <= figure_box.x1 + 1
    assert legend_box.y0 >= figure_box.y0
    assert legend_box.y1 <= figure_box.y1


def test_wide_but_short_canvas_keeps_side_legend_without_flattening_axes():
    figure = Figure(figsize=(12.0, 2.2), dpi=100)
    canvas = FigureCanvasAgg(figure)
    axis = figure.add_subplot(111)
    for index, label in enumerate(("Class A", "Class B", "Class C", "Class D")):
        axis.plot([400, 500, 600], [index, index + 0.3, index + 0.1], label=label)
    legend = axis.legend()

    layout_figure(figure)
    canvas.draw()
    renderer = canvas.get_renderer()
    figure_box = figure.get_window_extent(renderer)
    legend_box = legend.get_window_extent(renderer)
    assert figure._spectroease_legend_layout == "side"
    assert axis.get_position().height > 0.68
    assert legend_box.x1 <= figure_box.x1 + 1
    assert legend_box.y0 >= figure_box.y0
    assert legend_box.y1 <= figure_box.y1


def test_1440_class_legend_stays_below_wavelength_label():
    figure = Figure(figsize=(9.0, 3.8), dpi=100)
    canvas = FigureCanvasAgg(figure)
    axis = figure.add_subplot(111)
    labels = [
        "Long class name for compact monitor 03",
        "Long class name for compact monitor 04",
        "Reference lot A — replicate family 01",
        "Reference lot B — replicate family 02",
    ]
    for index, label in enumerate(labels):
        axis.plot([400, 500, 600], [index, index + 0.3, index + 0.1], label=label)
    axis.set_xlabel("Wavelength (nm)")
    legend = axis.legend()

    layout_figure(figure, legend_fontsize=8)
    canvas.draw()
    renderer = canvas.get_renderer()
    legend_box = legend.get_window_extent(renderer)
    xlabel_box = axis.xaxis.label.get_window_extent(renderer)
    assert figure._spectroease_legend_layout == "bottom"
    assert legend_box.y1 < xlabel_box.y0


def test_visualization_resizes_and_reflows_legend_between_wide_and_compact_layouts():
    from PyQt5.QtTest import QTest
    from PyQt5.QtWidgets import QApplication
    from app.views.visualization_widget import VisualizationWidget

    app = QApplication.instance() or QApplication([])
    widget = VisualizationWidget()
    widget.resize(1200, 700)
    widget.show()
    widget.plot_spectra(
        np.array([400, 500, 600]),
        np.array([[0.1, 0.4, 0.2], [0.2, 0.3, 0.5]]),
        labels=np.array(["Class A", "Class B"]),
    )
    QTest.qWait(120)
    app.processEvents()
    assert widget.figure._spectroease_legend_layout == "bottom"
    wide_width = widget.ax.get_position().width

    widget.resize(640, 500)
    QTest.qWait(120)
    app.processEvents()
    renderer = widget.canvas.get_renderer()
    figure_box = widget.figure.get_window_extent(renderer)
    legend_box = widget.ax.get_legend().get_window_extent(renderer)
    assert widget.figure._spectroease_legend_layout == "side"
    assert widget.ax.get_position().width < wide_width
    assert legend_box.x1 <= figure_box.x1 + 1
    widget.close()


def test_pdf_export_has_reference_physical_width_editable_text_and_sidecar(tmp_path):
    figure = _make_figure()
    output = tmp_path / "spectra.pdf"

    result = export_figure(
        figure,
        output,
        profile=ExportProfile(
            width_mm=tok.MPL_EXPORT_SINGLE_COLUMN_MM,
            height_mm=tok.MPL_EXPORT_SINGLE_COLUMN_HEIGHT_MM,
            format="pdf",
        ),
        chart_type="Spectrum Plot",
        metadata={"sample_count": 2, "x_unit": "nm"},
    )

    pdf_bytes = output.read_bytes()
    assert pdf_bytes.startswith(b"%PDF-")
    # Type 42 embeds TrueType fonts; Type 3 outlines are not the editable text
    # path intended by this export profile.
    assert b"/Subtype /Type3" not in pdf_bytes
    match = re.search(rb"/MediaBox\s*\[\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*\]", pdf_bytes)
    assert match is not None
    _, _, page_width_pt, page_height_pt = map(float, match.groups())
    assert abs(page_width_pt / 72 * 25.4 - tok.MPL_EXPORT_SINGLE_COLUMN_MM) < 0.05
    expected_ratio = tok.MPL_EXPORT_SINGLE_COLUMN_HEIGHT_MM / tok.MPL_EXPORT_SINGLE_COLUMN_MM
    assert abs(page_height_pt / page_width_pt - expected_ratio) < 0.001

    sidecar_path = tmp_path / "spectra.pdf.json"
    sidecar = json.loads(sidecar_path.read_text(encoding="utf-8"))
    assert result["sidecar_path"] == str(sidecar_path)
    assert sidecar["chart_type"] == "Spectrum Plot"
    assert sidecar["width_mm"] == tok.MPL_EXPORT_SINGLE_COLUMN_MM
    assert sidecar["height_mm"] == tok.MPL_EXPORT_SINGLE_COLUMN_HEIGHT_MM
    assert sidecar["format"] == "pdf"
    assert sidecar["dpi"] == tok.MPL_EXPORT_DEFAULT_DPI
    assert sidecar["application"]["name"] == "SpectroEase"
    assert sidecar["application"]["version"] == "1.1"
    assert "internal reproducibility-report" in sidecar["application"]["version_source"]
    assert sidecar["software"]["matplotlib"]
    assert sidecar["axes"][0]["x_label"] == "Wavelength (nm)"
    assert sidecar["metadata"] == {"sample_count": 2, "x_unit": "nm"}


def test_png_export_uses_requested_pixels_and_svg_keeps_text_and_raster_dpi_note(tmp_path):
    figure = _make_figure()
    png_path = tmp_path / "spectra.png"
    png_result = export_figure(
        figure,
        png_path,
        profile=ExportProfile(width_mm=89, height_mm=59.33, format="png", dpi=240),
    )
    width_px, height_px = Image.open(png_path).size
    assert abs(width_px - 89 / 25.4 * 240) <= 1
    assert abs(height_px - 59.33 / 25.4 * 240) <= 1
    assert png_result["dpi"] == 240

    svg_path = tmp_path / "spectra.svg"
    svg_result = export_figure(
        figure,
        svg_path,
        profile=ExportProfile(width_mm=183, height_mm=122, format="svg", dpi=450),
    )
    svg_text = svg_path.read_text(encoding="utf-8")
    assert "<text" in svg_text
    assert "Wavelength (nm)" in svg_text
    assert svg_result["width_mm"] == 183
    assert svg_result["height_mm"] == 122
    assert svg_result["dpi"] == 450
    assert "raster artists embedded in PDF/SVG" in svg_result["dpi_note"]

    tiff_path = tmp_path / "spectra.tif"
    tiff_result = export_figure(
        figure,
        tiff_path,
        profile=ExportProfile(width_mm=89, height_mm=59.33, format="tiff", dpi=180),
    )
    tiff_width, tiff_height = Image.open(tiff_path).size
    assert abs(tiff_width - 89 / 25.4 * 180) <= 1
    assert abs(tiff_height - 59.33 / 25.4 * 180) <= 1
    assert tiff_result["format"] == "tiff"


def test_vector_export_records_resolution_used_for_embedded_heatmap(tmp_path):
    figure = Figure(figsize=(4, 3), dpi=100)
    FigureCanvasAgg(figure)
    axis = figure.add_subplot(111)
    axis.imshow(np.arange(16).reshape(4, 4), interpolation="nearest", cmap="viridis")
    axis.set_xlabel("Wavelength (nm)")
    axis.set_ylabel("Sample")

    output = tmp_path / "heatmap.svg"
    result = export_figure(
        figure,
        output,
        profile=ExportProfile(width_mm=89, height_mm=59.33, format="svg", dpi=450),
    )
    svg_text = output.read_text(encoding="utf-8")
    sidecar = json.loads((tmp_path / "heatmap.svg.json").read_text(encoding="utf-8"))
    assert "<image" in svg_text
    assert result["dpi"] == 450
    assert sidecar["dpi"] == 450
    assert "raster artists embedded in PDF/SVG" in sidecar["dpi_note"]


def test_export_does_not_change_interactive_figure_geometry_or_rendered_content(tmp_path):
    figure = _make_figure()
    axis = figure.axes[0]
    before_size = figure.get_size_inches().copy()
    before_dpi = figure.dpi
    before_xlim = axis.get_xlim()
    before_ylim = axis.get_ylim()
    before_position = axis.get_position().bounds
    before_lines = [(line.get_label(), line.get_linewidth(), line.get_xdata().copy(), line.get_ydata().copy())
                    for line in axis.lines]
    before_pixels = _render_pixels(figure)

    export_figure(figure, tmp_path / "copy.svg", width_mm=89, fmt="svg", publication_style=True)

    assert np.array_equal(figure.get_size_inches(), before_size)
    assert figure.dpi == before_dpi
    assert axis.get_xlim() == before_xlim
    assert axis.get_ylim() == before_ylim
    assert axis.get_position().bounds == before_position
    assert len(axis.lines) == len(before_lines)
    for line, expected in zip(axis.lines, before_lines):
        label, linewidth, x_data, y_data = expected
        assert line.get_label() == label
        assert line.get_linewidth() == linewidth
        assert np.array_equal(line.get_xdata(), x_data)
        assert np.array_equal(line.get_ydata(), y_data)
    assert np.array_equal(_render_pixels(figure), before_pixels)


def test_export_rejects_invalid_dimensions_and_formats(tmp_path):
    figure = _make_figure()
    try:
        export_figure(figure, tmp_path / "bad.jpg", fmt="jpg")
    except ValueError as exc:
        assert "Unsupported figure format" in str(exc)
    else:
        raise AssertionError("Unsupported format should be rejected")

    try:
        export_figure(figure, tmp_path / "too-wide.pdf", width_mm=500)
    except ValueError as exc:
        assert "width" in str(exc).lower()
    else:
        raise AssertionError("Out-of-range width should be rejected")


def test_export_profile_is_frozen_and_controls_export(tmp_path):
    profile = ExportProfile(width_mm=183, height_mm=122, format="svg", dpi=450, publication_style=False)
    try:
        profile.width_mm = 90
    except FrozenInstanceError:
        pass
    else:
        raise AssertionError("ExportProfile must be immutable")

    result = export_figure(_make_figure(), tmp_path / "profile.svg", profile=profile)
    assert result["format"] == "svg"
    assert result["width_mm"] == 183
    assert result["height_mm"] == 122
    assert result["dpi"] == 450
    assert result["publication_style"] is False

    assert ExportProfile(width_mm=183).height_mm == 122


def test_profile_dimensions_ignore_source_figure_aspect_and_dpi(tmp_path):
    wide_figure = _make_figure()
    tall_figure = Figure(figsize=(2.0, 8.0), dpi=144)
    FigureCanvasAgg(tall_figure)
    tall_axis = tall_figure.add_subplot(111)
    tall_axis.plot([0, 1], [0, 1])
    tall_axis.set_xlabel("x")
    tall_axis.set_ylabel("y")

    # Different display sizes/DPI stand in for figures created on different
    # screens. One immutable physical profile must still yield identical files.
    profile = ExportProfile(width_mm=89, height_mm=59.33, format="pdf", dpi=240,
                             publication_style=False)
    snapshots = [
        (figure.get_size_inches().copy(), figure.dpi)
        for figure in (wide_figure, tall_figure)
    ]
    pdf_paths = [tmp_path / "wide.pdf", tmp_path / "tall.pdf"]
    for figure, path in zip((wide_figure, tall_figure), pdf_paths):
        export_figure(figure, path, profile=profile)

    def pdf_media_box(path):
        data = path.read_bytes()
        match = re.search(rb"/MediaBox\s*\[\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*\]", data)
        assert match is not None
        return tuple(map(float, match.groups()))

    first_box, second_box = pdf_media_box(pdf_paths[0]), pdf_media_box(pdf_paths[1])
    assert first_box == second_box
    assert abs((first_box[2] - first_box[0]) / 72 * 25.4 - 89) < 0.05
    assert abs((first_box[3] - first_box[1]) / 72 * 25.4 - 59.33) < 0.05

    for raster_format in ("png", "tiff"):
        raster_profile = ExportProfile(width_mm=89, height_mm=59.33, format=raster_format,
                                       dpi=240, publication_style=False)
        output_sizes = []
        for label, figure in zip(("wide", "tall"), (wide_figure, tall_figure)):
            output_path = tmp_path / f"{label}.{raster_format}"
            result = export_figure(figure, output_path, profile=raster_profile)
            output_sizes.append(Image.open(result["figure_path"]).size)
        assert output_sizes[0] == output_sizes[1]
        expected = (round(89 / 25.4 * 240), round(59.33 / 25.4 * 240))
        assert all(abs(actual - wanted) <= 1 for size in output_sizes for actual, wanted in zip(size, expected))

    for figure, (size, dpi) in zip((wide_figure, tall_figure), snapshots):
        assert np.array_equal(figure.get_size_inches(), size)
        assert figure.dpi == dpi


def test_widget_exposes_export_action_for_spectrum_scatter_and_confusion_matrix(tmp_path):
    from PyQt5.QtWidgets import QApplication

    app = QApplication.instance() or QApplication([])
    from app.views.visualization_widget import VisualizationWidget

    widget = VisualizationWidget(x_unit="nm")
    assert widget.export_figure_button.text() == "Export figure…"
    assert not widget.export_figure_button.icon().isNull()

    widget.plot_spectra(np.array([400, 500, 600]), np.array([[0.1, 0.5, 0.2], [0.2, 0.4, 0.8]]),
                        labels=np.array(["Class A", "Class B"]))
    assert widget.current_chart_kind == "Spectrum Plot"
    assert widget.save_plot(str(tmp_path / "spectrum.pdf"))
    spectrum_meta = json.loads((tmp_path / "spectrum.pdf.json").read_text(encoding="utf-8"))
    assert spectrum_meta["metadata"]["sample_count"] == 2
    assert spectrum_meta["metadata"]["category_count"] == 2
    assert spectrum_meta["metadata"]["category_labels"] == ["Class A", "Class B"]
    assert spectrum_meta["metadata"]["category_order"] == ["Class A", "Class B"]
    assert spectrum_meta["metadata"]["palette"] == tok.MPL_PLOT_PALETTE_NAME
    assert spectrum_meta["metadata"]["series_color_map"]["Class A"] == tok.COLOR_BLIND_PALETTE[0].lower()
    assert spectrum_meta["metadata"]["series_color_map"]["Class B"] == tok.COLOR_BLIND_PALETTE[1].lower()

    widget.plot_scatter([1, 2, 3], [1.1, 1.9, 3.2], xlabel="Observed", ylabel="Predicted")
    assert widget.current_chart_kind == "Regression scatter"
    assert widget.save_plot(str(tmp_path / "scatter.pdf"))
    scatter_meta = json.loads((tmp_path / "scatter.pdf.json").read_text(encoding="utf-8"))
    assert scatter_meta["axes"][0]["x_label"] == "Observed"
    assert scatter_meta["metadata"]["point_count"] == 3
    assert scatter_meta["metadata"]["series_color_map"]["Predicted vs Observed"] == tok.COLOR_BLIND_PALETTE[5].lower()
    assert "1:1 reference" in scatter_meta["metadata"]["series_color_map"]

    widget.plot_confusion_matrix(np.array([[8, 2], [1, 9]]), class_names=["Zeta", "Alpha"])
    assert widget.current_chart_kind == "Confusion matrix"
    assert widget.save_plot(str(tmp_path / "confusion.pdf"))
    matrix_meta = json.loads((tmp_path / "confusion.pdf.json").read_text(encoding="utf-8"))
    assert matrix_meta["metadata"]["class_count"] == 2
    assert matrix_meta["metadata"]["class_names"] == ["Zeta", "Alpha"]
    assert matrix_meta["metadata"]["category_order"] == ["Zeta", "Alpha"]
    assert matrix_meta["metadata"]["colormap"] == tok.MPL_CONFUSION_CMAP
    assert matrix_meta["axes"][0]["x_label"]

    widget.current_plot_type = "Heatmap"
    widget.plot_spectra(np.array([400, 500, 600]), np.array([[0.1, 0.5, 0.2], [0.2, 0.4, 0.8]]))
    assert widget.save_plot(str(tmp_path / "heatmap.pdf"))
    heatmap_meta = json.loads((tmp_path / "heatmap.pdf.json").read_text(encoding="utf-8"))
    assert heatmap_meta["metadata"]["colormap"] == tok.MPL_SPECTRA_HEATMAP_CMAP

    widget.close()
    widget.deleteLater()
    app.processEvents()


def test_dense_series_styles_add_line_and_marker_cues_without_changing_palette():
    styles = [get_series_style(index, point_count=480) for index in range(11)]
    assert [style["color"] for style in styles[:10]] == list(tok.COLOR_BLIND_PALETTE)
    assert styles[10]["color"] == tok.COLOR_BLIND_PALETTE[0]
    assert styles[10]["linestyle"] != styles[0]["linestyle"]
    assert styles[10]["marker"] != "None"
    assert styles[10]["markevery"] == 40


def test_dense_categorical_spectrum_export_records_drawn_series_mapping(tmp_path):
    from PyQt5.QtWidgets import QApplication
    from app.views.visualization_widget import VisualizationWidget

    app = QApplication.instance() or QApplication([])
    labels = [f"Class {index:02d}" for index in range(11)]
    wavelengths = np.linspace(400, 900, 480)
    spectra = np.vstack([np.sin(wavelengths / 80 + index) for index in range(len(labels))])
    widget = VisualizationWidget(x_unit="nm")
    widget.plot_spectra(wavelengths, spectra, labels=labels)

    assert len(widget.ax.lines) == 11
    assert widget.ax.lines[0].get_color().lower() == tok.COLOR_BLIND_PALETTE[0].lower()
    assert widget.ax.lines[-1].get_color().lower() == tok.COLOR_BLIND_PALETTE[0].lower()
    assert widget.ax.lines[-1].get_linestyle() != widget.ax.lines[0].get_linestyle()
    assert widget.ax.lines[-1].get_marker() != "None"
    output = tmp_path / "dense-spectrum.pdf"
    assert widget.save_plot(str(output))
    sidecar = json.loads((tmp_path / "dense-spectrum.pdf.json").read_text(encoding="utf-8"))
    assert sidecar["metadata"]["category_order"] == labels
    assert len(sidecar["metadata"]["series_color_map"]) == 11
    assert sidecar["metadata"]["series_colors"][-1]["marker"] != "None"

    widget.close()
    widget.deleteLater()
    app.processEvents()


def test_visualization_window_save_image_writes_style_sidecar(tmp_path, monkeypatch):
    from PyQt5.QtWidgets import QApplication, QFileDialog
    from app.utils.visualization_window import VisualizationWindow

    app = QApplication.instance() or QApplication([])
    output = tmp_path / "window-spectrum.pdf"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *args, **kwargs: (str(output), "PDF Files (*.pdf)"))

    window = VisualizationWindow()
    window.plot_spectra(
        [400, 500, 600],
        [[0.1, 0.5, 0.2], [0.2, 0.4, 0.8]],
        labels=["Zeta", "Alpha"],
    )
    window.save_image()

    sidecar = json.loads((tmp_path / "window-spectrum.pdf.json").read_text(encoding="utf-8"))
    assert sidecar["metadata"]["category_order"] == ["Alpha", "Zeta"]
    assert sidecar["metadata"]["series_color_map"]["Alpha"] == tok.COLOR_BLIND_PALETTE[0].lower()
    assert sidecar["metadata"]["series_color_map"]["Zeta"] == tok.COLOR_BLIND_PALETTE[1].lower()
    window.close()
    window.deleteLater()
    app.processEvents()


def test_widget_redraw_tracks_qt_logical_canvas_size_after_resize(monkeypatch):
    from PyQt5.QtWidgets import QApplication
    from app.views.visualization_widget import VisualizationWidget

    app = QApplication.instance() or QApplication([])
    widget = VisualizationWidget(x_unit="nm")
    widget.resize(900, 650)
    widget.show()
    app.processEvents()

    logical_width, logical_height = widget.canvas.get_width_height(physical=False)
    assert (logical_width, logical_height) == (widget.canvas.width(), widget.canvas.height())
    assert logical_width > 0 and logical_height > 0

    calls = []
    original_draw_idle = widget.canvas.draw_idle

    def tracked_draw_idle(*args, **kwargs):
        calls.append(widget.canvas.get_width_height(physical=False))
        return original_draw_idle(*args, **kwargs)

    monkeypatch.setattr(widget.canvas, "draw_idle", tracked_draw_idle)
    widget.resize(760, 540)
    app.processEvents()
    assert calls
    assert calls[-1] == widget.canvas.get_width_height(physical=False)

    widget.close()
    widget.deleteLater()
    app.processEvents()


def test_spectrum_coordinates_follow_unit_selection_and_reorder_values(tmp_path):
    from PyQt5.QtWidgets import QApplication
    from app.views.visualization_widget import VisualizationWidget

    app = QApplication.instance() or QApplication([])
    wavelengths_nm = np.array([400.0, 500.0, 800.0])
    spectra = np.array([[1.0, 2.0, 3.0], [10.0, 20.0, 30.0]])
    widget = VisualizationWidget(x_unit="nm")
    widget.plot_spectra(wavelengths_nm, spectra, title="Unit regression")

    assert widget.ax.get_xlabel() == "Wavelength (nm)"
    assert np.array_equal(widget.ax.lines[0].get_xdata(), wavelengths_nm)
    assert np.array_equal(widget.ax.lines[0].get_ydata(), spectra[0])

    assert widget.set_x_unit("um") is True
    assert widget.ax.get_xlabel() == "Wavelength (µm)"
    assert np.allclose(widget.ax.lines[0].get_xdata(), [0.4, 0.5, 0.8])
    assert np.array_equal(widget.ax.lines[0].get_ydata(), spectra[0])
    assert widget._current_plot_metadata["x_unit"] == "um"

    assert widget.set_x_unit("cm-1") is True
    assert widget.ax.get_xlabel() == "Wavenumber (cm⁻¹)"
    assert np.allclose(widget.ax.lines[0].get_xdata(), [12500.0, 20000.0, 25000.0])
    assert np.array_equal(widget.ax.lines[0].get_ydata(), [3.0, 2.0, 1.0])
    assert np.array_equal(widget.ax.lines[1].get_ydata(), [30.0, 20.0, 10.0])
    assert widget._current_plot_metadata["x_unit"] == "cm-1"

    assert widget.set_x_unit("nm") is True
    assert widget.ax.get_xlabel() == "Wavelength (nm)"
    assert np.array_equal(widget.ax.lines[0].get_xdata(), wavelengths_nm)
    assert np.array_equal(widget.ax.lines[0].get_ydata(), spectra[0])
    assert np.array_equal(widget._plot_source["spectra"], spectra)

    widget.close()
    widget.deleteLater()
    app.processEvents()


def test_comparison_and_preprocessing_preview_follow_selected_spectral_unit():
    from PyQt5.QtWidgets import QApplication
    from app.views.visualization_widget import VisualizationWidget

    app = QApplication.instance() or QApplication([])
    wavelengths_nm = np.array([400.0, 500.0, 800.0])
    original = np.array([[1.0, 2.0, 3.0], [2.0, 3.0, 4.0]])
    processed = original + 10.0

    comparison = VisualizationWidget(x_unit="um")
    comparison.plot_spectra_comparison(wavelengths_nm, original, processed)
    assert comparison.ax.get_xlabel() == "Wavelength (µm)"
    assert np.allclose(comparison.ax.lines[0].get_xdata(), [0.4, 0.5, 0.8])
    assert np.allclose(comparison.ax.lines[0].get_ydata(), [1.5, 2.5, 3.5])
    comparison.set_x_unit("cm-1")
    assert comparison.ax.get_xlabel() == "Wavenumber (cm⁻¹)"
    assert np.allclose(comparison.ax.lines[0].get_xdata(), [12500.0, 20000.0, 25000.0])
    assert np.allclose(comparison.ax.lines[0].get_ydata(), [3.5, 2.5, 1.5])
    assert np.allclose(comparison.ax.lines[1].get_ydata(), [13.5, 12.5, 11.5])

    inline_comparison = VisualizationWidget(x_unit="um")
    inline_comparison.plot_spectra(
        wavelengths_nm, processed, original_spectra=original,
        comparison_mode=True, title="Inline comparison",
    )
    assert inline_comparison.ax.get_xlabel() == "Wavelength (µm)"
    assert np.allclose(inline_comparison.ax.lines[0].get_xdata(), [0.4, 0.5, 0.8])
    assert np.allclose(inline_comparison.ax.lines[0].get_ydata(), original[0])
    assert np.allclose(inline_comparison.ax.lines[2].get_ydata(), processed[0])
    inline_comparison.set_x_unit("cm-1")
    assert inline_comparison.ax.get_xlabel() == "Wavenumber (cm⁻¹)"
    assert np.allclose(inline_comparison.ax.lines[0].get_xdata(), [12500.0, 20000.0, 25000.0])
    assert np.allclose(inline_comparison.ax.lines[0].get_ydata(), original[0, ::-1])
    assert np.allclose(inline_comparison.ax.lines[2].get_ydata(), processed[0, ::-1])

    class PreviewModel:
        X_processed = processed

        @staticmethod
        def get_X():
            return original

        @staticmethod
        def get_y():
            return np.array(["A", "B"])

    preview = VisualizationWidget(x_unit="um")
    preview.update_preprocessing_preview(
        PreviewModel(), wavelengths_nm, preview_mode="Comparison"
    )
    assert preview.ax.get_xlabel() == "Wavelength (µm)"
    assert np.allclose(preview.ax.lines[0].get_xdata(), [0.4, 0.5, 0.8])
    assert np.allclose(preview.ax.lines[0].get_ydata(), original[0])
    preview.set_x_unit("cm-1")
    assert preview.ax.get_xlabel() == "Wavenumber (cm⁻¹)"
    assert np.allclose(preview.ax.lines[0].get_xdata(), [12500.0, 20000.0, 25000.0])
    assert np.allclose(preview.ax.lines[0].get_ydata(), original[0, ::-1])
    assert np.allclose(preview.ax.lines[1].get_ydata(), processed[0, ::-1])

    comparison.close()
    comparison.deleteLater()
    inline_comparison.close()
    inline_comparison.deleteLater()
    preview.close()
    preview.deleteLater()
    app.processEvents()


def test_visible_ui_export_entry_constructs_and_passes_export_profile(tmp_path, monkeypatch):
    from PyQt5.QtWidgets import QApplication, QDialog, QFileDialog, QMessageBox

    app = QApplication.instance() or QApplication([])
    from app.services import plot_export_service
    from app.services.plot_export_service import ExportProfile
    from app.views.visualization_widget import VisualizationWidget

    output = tmp_path / "ui-export.pdf"
    captured = {}

    def fake_export(figure, file_path, *, profile, chart_type, metadata):
        captured.update(
            profile=profile,
            chart_type=chart_type,
            metadata=dict(metadata),
        )
        return {
            "figure_path": str(output),
            "sidecar_path": str(output) + ".json",
            "width_mm": profile.width_mm,
            "height_mm": profile.height_mm,
        }

    monkeypatch.setattr(QDialog, "exec_", lambda self: QDialog.Accepted)
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *args, **kwargs: (str(output), "PDF files (*.pdf)"))
    monkeypatch.setattr(QMessageBox, "information", lambda *args, **kwargs: None)
    monkeypatch.setattr(plot_export_service, "export_figure", fake_export)

    widget = VisualizationWidget(x_unit="nm")
    widget.plot_spectra(
        np.array([400, 500, 600]),
        np.array([[0.1, 0.5, 0.2], [0.2, 0.4, 0.8]]),
        labels=np.array(["Zeta", "Alpha"]),
    )
    widget.show_export_dialog()

    assert isinstance(captured["profile"], ExportProfile)
    assert captured["profile"].width_mm == tok.MPL_EXPORT_SINGLE_COLUMN_MM
    assert captured["profile"].height_mm == tok.MPL_EXPORT_SINGLE_COLUMN_HEIGHT_MM
    assert captured["profile"].format == "pdf"
    assert captured["profile"].dpi == tok.MPL_EXPORT_DEFAULT_DPI
    assert captured["profile"].publication_style is True
    assert captured["metadata"]["category_labels"] == ["Alpha", "Zeta"]

    widget.close()
    widget.deleteLater()
    app.processEvents()
