"""Real Optuna engine, declared candidate and fit-boundary regression checks."""
import builtins
import numpy as np
import pytest
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from app.services.hyperparameter_optimization_service import HyperparameterOptimizationService
from app.utils.exceptions import HyperparameterOptimizationError


def data():
    rng=np.random.default_rng(23)
    X=rng.normal(size=(24,3));X[:,0]=np.arange(24)
    return X,np.array([0,1]*12),[f'row-{i}' for i in range(24)]


def test_optuna_real_engine_discrete_pairs_fixed_params_and_observed_fit_rows(monkeypatch):
    X,y,ids=data();fits=[];original=StandardScaler.fit
    def observe(self, values, *args, **kwargs):
        fits.append(set(np.asarray(values)[:,0].tolist()))
        return original(self,values,*args,**kwargs)
    monkeypatch.setattr(StandardScaler,'fit',observe)
    params,model,results=HyperparameterOptimizationService().optimize(
        DecisionTreeClassifier(random_state=2),X,y,method='optuna',
        param_grid={'max_depth':[1,3],'min_samples_leaf':2},cv=3,n_iter=4,
        sample_ids=ids,outer_test_sample_ids=['held-out-1'])
    assert model.optimization_backend_=='optuna_tpe'
    assert model.optimization_metadata_['version']=='4.9.0'
    assert model.optimization_metadata_['sampler']=='TPESampler'
    assert model.optimization_metadata_['n_startup_trials']<4
    assert len(results['params'])==4
    assert all(p['estimator__max_depth'] in (1,3) for p in results['params'])
    assert params['estimator__min_samples_leaf']==2
    assert model.get_params()['estimator__min_samples_leaf']==2
    expected=[set(int(i.split('-')[1]) for i in t['transformer_fit_sample_ids']) for t in model.cv_fit_trace_]
    assert len(fits)==4*3+1
    assert fits[:-1]==expected*4
    assert fits[-1]==set(range(24))
    assert model.outer_test_sample_ids_==['held-out-1']
    for t in model.cv_fit_trace_:assert not set(t['transformer_fit_sample_ids'])&set(t['validation_sample_ids'])


def test_optuna_regressor_float_pair_negative_error_score():
    X,_,ids=data();y=2*X[:,0]+X[:,1]
    params,model=HyperparameterOptimizationService().optuna_search(
        Ridge(),{'alpha':[.1,10.]},X,y,cv=3,n_iter=4,
        scoring='neg_mean_squared_error',sample_ids=ids,outer_test_sample_ids=['external'])
    assert params['estimator__alpha'] in (.1,10.)
    assert all(t['parameters']['estimator__alpha'] in (.1,10.) for t in model.optimization_trials_)
    assert all(t['mean_score']<=0 for t in model.optimization_trials_)
    assert np.isfinite(model.predict(X)).all()


def test_missing_optuna_is_clear_error_not_grid_fallback(monkeypatch):
    original=builtins.__import__
    def unavailable(name,*args,**kwargs):
        if name=='optuna':raise ImportError('test unavailable')
        return original(name,*args,**kwargs)
    monkeypatch.setattr(builtins,'__import__',unavailable)
    X,y,_=data()
    with pytest.raises(HyperparameterOptimizationError,match='select Grid Search explicitly'):
        HyperparameterOptimizationService().optuna_search(DecisionTreeClassifier(),{'max_depth':[1,3]},X,y)


@pytest.mark.parametrize('space,budget',[({},2),({'max_depth':[]},2),({'max_depth':[1]},0),({'max_depth':[1]},True)])
def test_invalid_optuna_space_or_budget_fails(space,budget):
    X,y,_=data()
    with pytest.raises(HyperparameterOptimizationError):
        HyperparameterOptimizationService().optuna_search(DecisionTreeClassifier(),space,X,y,n_iter=budget)


def test_optuna_outer_identity_overlap_rejected():
    X,y,ids=data()
    with pytest.raises(ValueError,match='Outer-test sample identities overlap'):
        HyperparameterOptimizationService().optuna_search(DecisionTreeClassifier(),{'max_depth':[1]},X,y,
            cv=3,n_iter=2,sample_ids=ids,outer_test_sample_ids=[ids[0]])
