"""Dataset status must describe the currently confirmed response/features."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')

import numpy as np
import pandas as pd
from PyQt5.QtWidgets import QApplication
from app.views.data_view import DataPartitioningView
from app.views.column_mapping_dialog import ColumnMappingDialog
from app.utils.translator import translator


def test_status_refreshes_after_mapping_target_and_identity_changes():
    app=QApplication.instance() or QApplication([])
    translator.set_language('en')
    view=DataPartitioningView({})
    data=pd.DataFrame({'ID':[f'record-{i}' for i in range(80)],
                       'Moisture':np.linspace(2,20,80),
                       'numeric_metadata':np.arange(80),
                       '950':np.linspace(.1,.3,80),
                       '955':np.linspace(.2,.4,80)})
    try:
        view.set_data_loaded('real_source.csv',data)
        view.sample_id_combo.setCurrentIndex(view.sample_id_combo.findData(0))
        view.set_column_mapping({'label_column':1,'wavelength_columns':[3,4]})
        text=view.info_label.text()
        assert 'Features: 2' in text
        assert 'Regression' in text
        assert 'Classes' not in text
        assert '2.000' in text and '20.000' in text
        assert 'real_source.csv' in text
        view.set_column_mapping({'label_column':1,'wavelength_columns':[3]})
        assert 'Features: 1' in view.info_label.text()
        view.clear_column_mapping()
        assert 'Features: 2' in view.info_label.text()
        # Selecting a wavelength as group metadata updates the automatic count.
        view.group_id_combo.setCurrentIndex(view.group_id_combo.findData(4))
        assert 'Features: 1' in view.info_label.text()
        view.label_column_combo.setCurrentIndex(0)
        assert 'Classification' in view.info_label.text()
        assert 'Target range' not in view.info_label.text()
        view.set_no_data()
        assert view._current_data is None
        assert 'real_source.csv' not in view.info_label.text()
    finally:
        view.close();app.processEvents()


def test_reopened_custom_mapping_preserves_spectra_and_excludes_other_response():
    app=QApplication.instance() or QApplication([])
    columns=['ID','Spectrometer','Cereal','Variety','Country','Year','Moisture','Protein']+[str(i) for i in range(950,1651,5)]
    positions=list(range(8,len(columns)))
    dialog=ColumnMappingDialog(columns,6,positions,identity_column_indices=[0])
    try:
        assert dialog._custom_radio.isChecked()
        assert dialog.get_mapping()=={'label_column':6,'wavelength_columns':positions}
        assert len(dialog._wl_list.selectedItems())==141
        assert not any(dialog._wl_list.item(i).isSelected() for i in range(8))
        assert '141' in dialog._summary_label.text()
        dialog._on_accept()
        accepted=dialog.get_mapping()
        reopened=ColumnMappingDialog(columns,accepted['label_column'],accepted['wavelength_columns'],identity_column_indices=[0])
        try:
            assert reopened.get_mapping()==accepted
            assert reopened._custom_radio.isChecked()
        finally:
            reopened.close()
    finally:
        dialog.close();app.processEvents()
