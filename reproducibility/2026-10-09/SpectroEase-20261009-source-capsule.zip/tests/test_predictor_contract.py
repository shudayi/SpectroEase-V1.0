import logging
import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
import pandas as pd
import pytest

from app.controllers.evaluation_controller import EvaluationController
from app.controllers.modeling_controller import ModelingController
from app.models.data_model import DataModel
from app.models.modeling_model import ModelingModel
from app.services.data_service import DataService
from app.services.evaluation_service import EvaluationService
from app.services.modeling_service import ModelingService
from app.services.prediction_contract import PredictionResult
from app.views.main_window import MainWindow
from plugins.modeling.qualitative_analyzer import QualitativeAnalyzer
from plugins.modeling.quantitative_analyzer import QuantitativeAnalyzer


FEATURES = [f"wavelength_{index}" for index in range(6)]


def _fixture(task_type):
    rng = np.random.default_rng(20261002)
    n_train, n_test = 160, 137
    train_base = rng.normal(size=(n_train, len(FEATURES)))
    test_base = rng.normal(size=(n_test, len(FEATURES)))
    coefficients = np.array([2.5, -1.2, 0.8, 3.1, -0.4, 1.7])
    if task_type == "regression":
        y_train = 125.0 + 37.0 * (train_base @ coefficients) + rng.normal(0, 0.4, n_train)
        y_test = 125.0 + 37.0 * (test_base @ coefficients) + rng.normal(0, 0.4, n_test)
        method = "mlr"
        analysis_type = "quantitative"
    else:
        train_groups_num = np.repeat(np.arange(40), 4)
        test_groups_num = np.arange(n_test) // 4
        if task_type == "numeric_classes":
            y_train = np.where(train_groups_num % 2 == 0, 10, 2)
            y_test = np.where(test_groups_num % 2 == 0, 10, 2)
        else:
            y_train = np.where(train_groups_num % 2 == 0, "zeta", "alpha")
            y_test = np.where(test_groups_num % 2 == 0, "zeta", "alpha")
        method = "dt"
        analysis_type = "qualitative"

    train_X = train_base.copy()
    test_X = test_base.copy()
    # Missing values exercise the saved train-only imputer and batch invariance.
    train_X[::17, 2] = np.nan
    test_X[0, 2] = np.nan
    train_index = [f"train-row-{i}" for i in range(n_train)]
    test_index = [f"test-row-{i}" for i in range(n_test)]
    X_train = pd.DataFrame(train_X, index=train_index, columns=FEATURES)
    X_test = pd.DataFrame(test_X, index=test_index, columns=FEATURES)
    groups_train = [f"train-group-{i // 4}" for i in range(n_train)]
    groups_test = [f"test-group-{i // 4}" for i in range(n_test)]
    samples_train = [f"train-sample-{i}" for i in range(n_train)]
    samples_test = [f"test-sample-{i}" for i in range(n_test)]
    return {
        "X_train": X_train,
        "X_test": X_test,
        "y_train": np.asarray(y_train),
        "y_test": np.asarray(y_test),
        "groups_train": groups_train,
        "groups_test": groups_test,
        "samples_train": samples_train,
        "samples_test": samples_test,
        "train_rows": train_index,
        "test_rows": test_index,
        "method": method,
        "analysis_type": analysis_type,
    }


def _fit_analyzer(data):
    if data["analysis_type"] == "quantitative":
        analyzer = QuantitativeAnalyzer(data["method"])
    else:
        analyzer = QualitativeAnalyzer(data["method"])
    analyzer.fit(
        data["X_train"], data["y_train"],
        row_ids=data["train_rows"],
        physical_sample_ids=data["samples_train"],
        group_ids=data["groups_train"],
        group_validation=True,
        feature_names=FEATURES,
        input_representation="raw_spectrum",
    )
    return analyzer


def _cross_validate(analyzer, data):
    kwargs = dict(
        sample_ids=data["train_rows"],
        outer_test_sample_ids=data["test_rows"],
        physical_sample_ids=data["samples_train"],
        outer_test_physical_sample_ids=data["samples_test"],
        group_ids=data["groups_train"],
        outer_test_group_ids=data["groups_test"],
        group_validation=True,
    )
    if data["analysis_type"] == "quantitative":
        return analyzer.cross_validate(data["X_train"], data["y_train"], n_splits=5, **kwargs)
    return analyzer.cross_validate(data["X_train"], data["y_train"], cv=5, **kwargs)


def _evaluation_service():
    service = EvaluationService()
    # Keep tests hermetic; EvaluationService persists optional debug snapshots.
    service.save_debug_data = lambda *_args, **_kwargs: None
    return service


def _assert_metrics_equal(actual, expected, task_type):
    names = ("rmse", "mae", "r2") if task_type == "regression" else (
        "accuracy", "precision", "recall", "f1"
    )
    for name in names:
        assert actual[name] == pytest.approx(expected[name])
    if task_type == "classification":
        assert np.array_equal(actual["confusion_matrix"], expected["confusion_matrix"])


class _CountingEstimator:
    def __init__(self, estimator):
        self.estimator = estimator
        self.calls = 0

    def predict(self, X):
        self.calls += 1
        return self.estimator.predict(X)


@pytest.mark.parametrize("task_type", ["regression", "numeric_classes", "string_classes"])
def test_full_oof_and_live_prediction_routes_share_one_vector(task_type, monkeypatch):
    data = _fixture(task_type)
    task = "regression" if task_type == "regression" else "classification"
    analyzer = _fit_analyzer(data)
    cv = _cross_validate(analyzer, data)

    assert len(cv["cv_predictions"]) == len(data["X_train"]) == 160
    assert len(cv["cv_target"]) == len(cv["cv_row_ids"]) == 160
    assert cv["cv_row_ids"] == data["train_rows"]
    assert cv["cv_physical_sample_ids"] == data["samples_train"]
    assert cv["cv_group_ids"] == data["groups_train"]
    assert set(cv["cv_row_ids"]).isdisjoint(data["test_rows"])
    for fold in cv["cv_fit_trace"]:
        assert set(fold["estimator_fit_sample_ids"]).isdisjoint(fold["validation_sample_ids"])
        assert set(fold["validation_sample_ids"]).isdisjoint(data["test_rows"])
        assert set(fold["train_group_ids"]).isdisjoint(fold["validation_group_ids"])
        assert set(fold["validation_group_ids"]).isdisjoint(data["groups_test"])

    if task_type == "numeric_classes":
        assert list(analyzer.label_encoder.classes_) == [2, 10]
        assert sorted(map(str, analyzer.label_encoder.classes_)) == ["10", "2"]

    direct_count = _CountingEstimator(analyzer.fitted_predictor.estimator)
    analyzer.fitted_predictor.estimator = direct_count
    prediction_result, main_metrics = MainWindow._predict_and_evaluate(
        None, analyzer, data["X_test"], data["y_test"], task,
        row_ids=data["test_rows"],
        physical_sample_ids=data["samples_test"],
        group_ids=data["groups_test"],
    )
    assert direct_count.calls == 1
    assert len(prediction_result.predictions) == 137
    assert prediction_result.row_ids == tuple(data["test_rows"])
    assert prediction_result.physical_sample_ids == tuple(data["samples_test"])
    assert prediction_result.group_ids == tuple(data["groups_test"])
    assert not set(prediction_result.row_ids).intersection(analyzer.fitted_predictor.fit_row_ids)
    assert not set(prediction_result.group_ids).intersection(analyzer.fitted_predictor.fit_group_ids)

    # A held-out row has exactly the same prediction alone and in a larger batch.
    alone = analyzer.predict(data["X_test"].iloc[[0]])
    batched = analyzer.predict(data["X_test"].iloc[:9])
    assert alone[0] == pytest.approx(batched[0]) if task == "regression" else alone[0] == batched[0]
    expected_imputer_mean = np.nanmean(data["X_train"].to_numpy(), axis=0)
    assert np.allclose(analyzer.imputer.statistics_, expected_imputer_mean)
    raw_result = analyzer.predict_raw(
        data["X_test"], row_ids=data["test_rows"],
        physical_sample_ids=data["samples_test"], group_ids=data["groups_test"],
    )
    assert len(raw_result.predictions) == 137
    with pytest.raises(ValueError, match="feature columns"):
        analyzer.predict(data["X_test"][list(reversed(FEATURES))])

    expected_cv_metrics = _evaluation_service().evaluate(
        np.asarray(cv["cv_target"]), np.asarray(cv["cv_predictions"]),
        metrics=(['rmse', 'mae', 'r2'] if task == "regression"
                 else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
        task_type=task,
    )
    if task == "regression":
        assert cv["r2"] == pytest.approx(expected_cv_metrics["r2"])
        assert cv["mae"] == pytest.approx(expected_cv_metrics["mae"])
        assert np.sqrt(cv["mse"]) == pytest.approx(expected_cv_metrics["rmse"])
    else:
        assert cv["accuracy"] == pytest.approx(expected_cv_metrics["accuracy"])
        assert cv["precision"] == pytest.approx(expected_cv_metrics["precision"])
        assert cv["recall"] == pytest.approx(expected_cv_metrics["recall"])
        assert cv["f1_score"] == pytest.approx(expected_cv_metrics["f1"])

    # EvaluationService and ModelingService evaluate exactly one returned vector.
    service = _evaluation_service()
    count = _CountingEstimator(analyzer.model)
    analyzer.fitted_predictor.estimator = count
    service_result, service_metrics = service.evaluate_with_prediction(
        analyzer.fitted_predictor, data["X_test"], data["y_test"],
        metrics=(['rmse', 'mae', 'r2'] if task == "regression"
                 else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
        task_type=task, row_ids=data["test_rows"],
        physical_sample_ids=data["samples_test"], group_ids=data["groups_test"],
    )
    assert count.calls == 1
    assert np.array_equal(service_result.predictions, prediction_result.predictions)
    _assert_metrics_equal(service_metrics, main_metrics, task)

    count.calls = 0
    service.evaluate_model(
        analyzer.fitted_predictor, data["X_test"], data["y_test"],
        metrics=(['rmse', 'mae', 'r2'] if task == "regression"
                 else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
        task_type=task, row_ids=data["test_rows"],
        physical_sample_ids=data["samples_test"], group_ids=data["groups_test"],
    )
    assert count.calls == 1

    # The ModelingService training route reports metrics from its stored vector.
    trainer = ModelingService(plugins={})
    trainer.evaluation_service = _evaluation_service()
    analyzer_class = QuantitativeAnalyzer if task == "regression" else QualitativeAnalyzer
    original_predict_result = analyzer_class.predict_result
    route_calls = []

    def counted_predict_result(self, *args, **kwargs):
        route_calls.append(self)
        return original_predict_result(self, *args, **kwargs)

    monkeypatch.setattr(analyzer_class, "predict_result", counted_predict_result)
    model_data = trainer.apply_modeling(
        data["X_train"], data["y_train"], data["X_test"], data["y_test"],
        data["method"], analysis_type=data["analysis_type"],
        train_row_ids=data["train_rows"], test_row_ids=data["test_rows"],
        train_physical_sample_ids=data["samples_train"],
        test_physical_sample_ids=data["samples_test"],
        train_group_ids=data["groups_train"], test_group_ids=data["groups_test"],
        group_validation=True, input_representation="raw_spectrum",
    )
    assert len(route_calls) == 1
    assert len(model_data.predictions) == 137
    assert np.array_equal(model_data.predictions, model_data.prediction_result.predictions)
    recomputed = trainer.evaluation_service.evaluate_prediction_result(
        data["y_test"], model_data.prediction_result,
        metrics=(['rmse', 'mae', 'r2'] if task == "regression"
                 else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
        task_type=task, row_ids=data["test_rows"],
        physical_sample_ids=data["samples_test"], group_ids=data["groups_test"],
    )
    _assert_metrics_equal(model_data.evaluation_results, recomputed, task)

    model_data.fitted_predictor.estimator = _CountingEstimator(model_data.model)
    modeling_service_metrics = trainer.evaluate_model(
        model_data.fitted_predictor, data["X_test"], data["y_test"],
        task_type=task, row_ids=data["test_rows"],
        physical_sample_ids=data["samples_test"], group_ids=data["groups_test"],
    )
    assert model_data.fitted_predictor.estimator.calls == 1
    _assert_metrics_equal(modeling_service_metrics, recomputed, task)

    model_data.fitted_predictor.estimator = _CountingEstimator(model_data.model)
    stored_model_metrics = trainer.evaluate(model_data, data["X_test"], data["y_test"])
    assert model_data.fitted_predictor.estimator.calls == 1
    _assert_metrics_equal(stored_model_metrics, recomputed, task)

    # ModelingController.evaluate_model uses the stored fitted predictor.
    modeling_model = ModelingModel()
    modeling_model.set_model_data(model_data)
    modeling_model.trained_model = model_data.trained_model
    modeling_model.fitted_predictor = model_data.fitted_predictor
    modeling_model.analysis_type = data["analysis_type"]
    modeling_model.fitted_predictor.estimator = _CountingEstimator(model_data.model)
    controller = object.__new__(ModelingController)
    controller.logger = logging.getLogger("test-modeling-controller")
    controller.modeling_service = trainer
    controller.modeling_model = modeling_model
    controller.data_model = type("Data", (), {
        "X_test": data["X_test"], "y_test": data["y_test"],
        "sample_id_test": pd.Series(data["samples_test"], index=data["test_rows"]),
        "group_id_test": pd.Series(data["groups_test"], index=data["test_rows"]),
    })()
    controller.evaluation_service = trainer.evaluation_service
    controller.label_processor = __import__(
        "app.utils.label_processor", fromlist=["EnhancedLabelProcessor"]
    ).EnhancedLabelProcessor()
    controller_metrics = controller.evaluate_model()
    assert modeling_model.fitted_predictor.estimator.calls == 1
    _assert_metrics_equal(controller_metrics, recomputed, task)

    # EvaluationController also follows the fitted predictor route.
    view = type("View", (), {
        "get_selected_metrics": lambda self: (['rmse', 'mae', 'r2'] if task == "regression"
                                               else ['accuracy', 'precision', 'recall', 'f1', 'confusion_matrix']),
        "display_message": lambda self, *_args: None,
        "update_evaluation_results": lambda self, results: setattr(self, "results", results),
    })()
    view.evaluate_button = type("Button", (), {"setEnabled": lambda self, _enabled: None})()
    eval_model = ModelingModel()
    eval_model.trained_model = model_data.trained_model
    eval_model.fitted_predictor = model_data.fitted_predictor
    eval_model.analysis_type = data["analysis_type"]
    eval_model.fitted_predictor.estimator = _CountingEstimator(model_data.model)
    data_model = type("Data", (), {
        "X_test": data["X_test"], "y_test": data["y_test"],
        "sample_id_test": pd.Series(data["samples_test"], index=data["test_rows"]),
        "group_id_test": pd.Series(data["groups_test"], index=data["test_rows"]),
    })()
    eval_controller = EvaluationController(view, None, data_model, eval_model)
    eval_controller.evaluation_service = trainer.evaluation_service
    monkeypatch.setattr(
        "app.controllers.evaluation_controller.run_heavy",
        lambda fn: fn(),
    )
    eval_controller.evaluate_model()
    assert eval_model.fitted_predictor.estimator.calls == 1
    _assert_metrics_equal(view.results, recomputed, task)


def test_fitted_predictor_rejects_raw_input_for_prepared_representation():
    data = _fixture("regression")
    analyzer = QuantitativeAnalyzer("mlr")
    analyzer.fit(
        data["X_train"].to_numpy(), data["y_train"],
        row_ids=data["train_rows"],
        input_representation="prepared:pca_features",
    )
    with pytest.raises(ValueError, match="Raw-spectrum prediction is unavailable"):
        analyzer.predict_raw(data["X_test"].to_numpy())


def test_main_window_partitioned_snv_keeps_prepared_provenance_and_blocks_raw_prediction(
    monkeypatch,
):
    from PyQt5.QtWidgets import QApplication, QMessageBox
    from app.utils.translator import Translator
    from app.utils import logger as logger_module
    from app.views import main_window as main_window_module

    monkeypatch.setattr(logger_module, "_ensure_utf8_stdout", lambda: None)
    app = QApplication.instance() or QApplication([])

    class _FastProgress:
        was_cancelled = False

        def __init__(self, *_args, **_kwargs):
            pass

        def show(self):
            pass

        def update_progress(self, *_args, **_kwargs):
            pass

        def hide(self):
            pass

        def close(self):
            pass

    monkeypatch.setattr(main_window_module, "ProgressDialog", _FastProgress)
    monkeypatch.setattr(main_window_module, "run_heavy", lambda operation, **_kwargs: operation())
    monkeypatch.setattr(QMessageBox, "information", lambda *_args, **_kwargs: None)
    window = MainWindow(Translator(language="en"), {}, {}, {}, {}, None)
    try:
        rng = np.random.default_rng(20261002)
        raw_X = rng.normal(size=(80, len(FEATURES)))
        target = 21.0 + raw_X @ np.array([1.4, -0.8, 0.5, 2.1, -1.2, 0.9])
        frame = pd.DataFrame(
            np.column_stack((target, raw_X)),
            columns=["target", *FEATURES],
        )
        data_model = window.controller.data_controller.data_model
        data_model.set_data(frame)
        processed_y, label_metadata = data_model.label_processor.process_labels_smart(
            frame["target"], "regression"
        )
        split = DataService({}).partition_data(
            frame,
            "Train-Test Split",
            {
                "target_column": 0,
                "task_type": "regression",
                "processed_labels": processed_y,
                "original_labels": frame["target"],
                "label_metadata": label_metadata,
                "row_keys": list(data_model.get_row_keys()),
                "test_size": 0.25,
                "random_state": 13,
                "shuffle": True,
            },
        )
        data_model.set_partitioned_data(split, task_type="regression")
        assert data_model.has_verified_split()
        assert data_model.partitioned_input_representation == "raw_spectrum"

        window.current_spectra = raw_X.copy()
        window.current_feature_source = "original"
        window.controller.feature_selection_controller = None
        assert window.controller.preprocessing_controller.apply_preprocessing(
            ["Standard Normal Variate (SNV)"], {}
        )
        assert data_model.partitioned_input_representation == "prepared:preprocessed"
        assert window.current_feature_source == "original"  # exercise the stale-selector route

        window.analysis_type.setCurrentIndex(window.analysis_type.findData("Quantitative"))
        window.update_analysis_methods("Quantitative")
        window.analysis_method.setCurrentIndex(window.analysis_method.findData("PLSR"))
        window.auto_save_onnx_model_from_analysis = lambda *_args, **_kwargs: None
        errors = []
        window.display_error = lambda *args, **_kwargs: errors.append(args)
        window.start_analysis()

        model = window.controller.modeling_controller.modeling_model
        assert not errors
        assert model.fitted_predictor is not None
        assert model.cv_input_representation == "prepared:preprocessed"
        assert model.fitted_predictor.input_representation == "prepared:preprocessed"
        assert model.prediction_result is not None
        assert len(model.prediction_result.predictions) == len(data_model.X_test)
        with pytest.raises(ValueError, match="Raw-spectrum prediction is unavailable"):
            model.fitted_predictor.predict_raw(raw_X[:1])

        # The separate controller training entry point must preserve the same
        # matrix provenance instead of inferring rawness from a DataFrame index.
        controller_result = window.controller.modeling_controller.apply_modeling(
            method="mlr", params={}, task_type="regression"
        )
        assert controller_result.fitted_predictor.input_representation == "prepared:preprocessed"
        with pytest.raises(ValueError, match="Raw-spectrum prediction is unavailable"):
            controller_result.fitted_predictor.predict_raw(raw_X[:1])

        from types import SimpleNamespace
        window.controller.check_model_trained = lambda: True
        window.controller.hyperopt_controller = SimpleNamespace(
            apply_main_window_selection=lambda *_args: (
                {"alpha": 1.0}, controller_result.trained_model, {}
            )
        )
        window.display_message = lambda *_args, **_kwargs: None
        window.controller.modeling_controller.modeling_model.cv_scope_safe = True
        window.optimize_current_model()
        optimized_predictor = window.controller.modeling_controller.modeling_model.fitted_predictor
        assert optimized_predictor.input_representation == "prepared:preprocessed"
        with pytest.raises(ValueError, match="Raw-spectrum prediction is unavailable"):
            optimized_predictor.predict_raw(raw_X[:1])
    finally:
        window.close()


def test_modeling_controller_mixed_label_fallback_never_predicts_with_bare_estimator():
    from types import SimpleNamespace

    class _BareModel:
        def __init__(self):
            self.calls = 0

        def predict(self, _X):
            self.calls += 1
            raise AssertionError("bare estimator prediction must not run")

    class _FailingEvaluationService:
        def __init__(self):
            self.calls = 0

        def evaluate_with_prediction(self, *_args, **_kwargs):
            self.calls += 1
            if self.calls == 1:
                raise ValueError("mix of continuous and binary targets")
            return PredictionResult(
                predictions=np.array([0, 1]), task_type="classification"
            ), {"error": "predictor retry failed"}

    bare_model = _BareModel()
    X_test = np.ones((2, 2))
    y_test = np.array([1, "positive"], dtype=object)
    model_data = SimpleNamespace(
        model=bare_model,
        task_type="classification",
        fitted_predictor=object(),
        test_data={"X_test": X_test, "y_test": y_test},
    )
    controller = object.__new__(ModelingController)
    controller.logger = logging.getLogger("test-mixed-label-fallback")
    controller.modeling_model = SimpleNamespace(
        get_model_data=lambda: model_data,
        trained_model=bare_model,
        analysis_type="qualitative",
        fitted_predictor=model_data.fitted_predictor,
    )
    controller.modeling_service = SimpleNamespace(
        update_model_data=lambda *_args, **_kwargs: None,
    )
    controller.data_model = SimpleNamespace(X_test=X_test, y_test=y_test)
    controller.evaluation_service = _FailingEvaluationService()
    controller.label_processor = __import__(
        "app.utils.label_processor", fromlist=["EnhancedLabelProcessor"]
    ).EnhancedLabelProcessor()

    result = controller.evaluate_model()
    assert "bare-estimator fallback is disabled" in result["error"]
    assert "predictor retry failed" in result["error"]
    assert bare_model.calls == 0


def test_modeling_controller_mixed_label_recovery_reuses_prediction_result():
    from types import SimpleNamespace

    y_test = np.array([1, "positive"], dtype=object)
    prediction_result = PredictionResult(
        predictions=np.array([0, 1]), task_type="classification"
    )

    class _EvaluationService:
        def __init__(self):
            self.scored_result = None

        def evaluate_with_prediction(self, *_args, **_kwargs):
            return prediction_result, {"error": "mix of continuous and binary targets"}

        def evaluate_prediction_result(self, _y, result, **_kwargs):
            self.scored_result = result
            return {"accuracy": 1.0}

    evaluation_service = _EvaluationService()
    model_data = SimpleNamespace(
        model=object(), task_type="classification", fitted_predictor=object(),
        test_data={"X_test": np.ones((2, 2)), "y_test": y_test},
    )
    controller = object.__new__(ModelingController)
    controller.logger = logging.getLogger("test-mixed-label-result-reuse")
    controller.modeling_model = SimpleNamespace(
        get_model_data=lambda: model_data,
        trained_model=object(), analysis_type="qualitative",
        fitted_predictor=model_data.fitted_predictor,
    )
    controller.modeling_service = SimpleNamespace(
        update_model_data=lambda *_args, **_kwargs: None,
    )
    controller.data_model = SimpleNamespace(X_test=None, y_test=None)
    controller.evaluation_service = evaluation_service
    controller.label_processor = __import__(
        "app.utils.label_processor", fromlist=["EnhancedLabelProcessor"]
    ).EnhancedLabelProcessor()

    result = controller.evaluate_model()
    assert result["accuracy"] == 1.0
    assert evaluation_service.scored_result is prediction_result


def test_prediction_result_rejects_misaligned_ids_and_grouped_scope_without_groups():
    with pytest.raises(ValueError, match="row_ids"):
        PredictionResult(np.array([1.0, 2.0]), "regression", row_ids=("only-one",))

    data = _fixture("regression")
    analyzer = _fit_analyzer(data)
    with pytest.raises(ValueError, match="explicit group IDs for prediction rows"):
        analyzer.predict_result(
            data["X_test"], row_ids=data["test_rows"],
            physical_sample_ids=data["samples_test"], group_ids=None,
        )

    from app.services.prediction_contract import FittedSpectrumPredictor
    with pytest.raises(ValueError, match="explicit training group IDs"):
        FittedSpectrumPredictor(
            estimator=analyzer.model, task_type="regression", group_validation=True,
        )
