"""Targeted delimiter-selection regression tests for TextParser."""

import pandas as pd
import pytest

from app.parsers.csv_parser import TextParser
from app.services.data_service import DataService


def test_txt_comma_delimited_data_does_not_stop_at_one_column(tmp_path):
    path = tmp_path / "spectra.txt"
    path.write_text("label,250,251\nA,1.2,1.3\nB,2.2,2.3\n", encoding="utf-8")

    frame = TextParser().parse(str(path))

    assert list(frame.columns) == ["label", "250", "251"]
    assert frame.shape == (2, 3)
    assert frame.iloc[0].tolist() == ["A", 1.2, 1.3]


def test_txt_quoted_comma_stays_inside_its_field(tmp_path):
    path = tmp_path / "quoted.txt"
    path.write_text(
        'sample,description,value\nS1,"powdered milk, type A",1.5\n'
        'S2,"powdered milk, type B",2.5\n',
        encoding="utf-8",
    )

    frame = TextParser().parse(str(path))

    assert list(frame.columns) == ["sample", "description", "value"]
    assert frame.shape == (2, 3)
    assert frame["description"].tolist() == [
        "powdered milk, type A",
        "powdered milk, type B",
    ]


def test_txt_tab_delimited_data_is_inferred_from_content(tmp_path):
    path = tmp_path / "spectra.txt"
    path.write_text("label\t250\t251\nA\t1.2\t1.3\nB\t2.2\t2.3\n", encoding="utf-8")

    frame = TextParser().parse(str(path))

    assert list(frame.columns) == ["label", "250", "251"]
    assert frame.shape == (2, 3)


def test_tsv_keeps_tab_semantics_when_cells_contain_commas_and_spaces(tmp_path):
    path = tmp_path / "spectra.tsv"
    path.write_text(
        "sample\tbrand\tvalue\nSample A, replicate 1\tBrand A\t1.5\n"
        "Sample B, replicate 1\tBrand B\t2.5\n",
        encoding="utf-8",
    )

    frame = TextParser().parse(str(path))

    assert list(frame.columns) == ["sample", "brand", "value"]
    assert frame.shape == (2, 3)
    assert frame.iloc[0, 0] == "Sample A, replicate 1"
    assert frame.iloc[0, 1] == "Brand A"


def test_txt_whitespace_delimited_data_accepts_multiple_spaces(tmp_path):
    path = tmp_path / "spectra.txt"
    path.write_text("label   250    251\nA  1.2  1.3\nB    2.2 2.3\n", encoding="utf-8")

    frame = TextParser().parse(str(path))

    assert list(frame.columns) == ["label", "250", "251"]
    assert frame.shape == (2, 3)
    assert frame.iloc[1].tolist() == ["B", 2.2, 2.3]


def test_txt_without_delimiters_remains_a_valid_single_column_file(tmp_path):
    path = tmp_path / "labels.txt"
    path.write_text("alpha\nbeta\ngamma\n", encoding="utf-8")

    frame = TextParser().parse(str(path))

    # Keep pandas' existing default header behavior for single-column files.
    assert list(frame.columns) == ["alpha"]
    assert frame.shape == (2, 1)
    assert frame.iloc[:, 0].tolist() == ["beta", "gamma"]


def test_txt_with_stable_comma_and_tab_tables_is_rejected_as_ambiguous(tmp_path):
    path = tmp_path / "ambiguous.txt"
    path.write_text("left,right\tvalue\nA,B\t1\nC,D\t2\n", encoding="utf-8")

    with pytest.raises(ValueError, match="Ambiguous .txt delimiter"):
        TextParser().parse(str(path))


def test_txt_with_ragged_delimited_rows_is_rejected(tmp_path):
    path = tmp_path / "ragged.txt"
    path.write_text("label,value\nA,1,extra\nB,2\n", encoding="utf-8")

    with pytest.raises(ValueError, match="Unable to infer a consistent delimiter"):
        TextParser().parse(str(path))


def test_empty_txt_keeps_pandas_empty_file_error(tmp_path):
    path = tmp_path / "empty.txt"
    path.write_text("", encoding="utf-8")

    with pytest.raises(pd.errors.EmptyDataError):
        TextParser().parse(str(path))


@pytest.mark.parametrize(
    ("suffix", "content", "expected_columns"),
    [
        (".txt", "instrument metadata\nlabel,250,251\nA,1.2,1.3\nB,2.2,2.3\n", ["label", "250", "251"]),
        (".txt", "metadata,with,commas\nlabel\t250\t251\nA\t1.2\t1.3\nB\t2.2\t2.3\n", ["label", "250", "251"]),
        (".txt", "metadata,with,commas\nlabel 250 251\nA 1.2 1.3\nB 2.2 2.3\n", ["label", "250", "251"]),
        (".csv", "instrument metadata\nlabel,250,251\nA,1.2,1.3\nB,2.2,2.3\n", ["label", "250", "251"]),
        (".tsv", "instrument metadata\nlabel\t250\t251\nA\t1.2\t1.3\nB\t2.2\t2.3\n", ["label", "250", "251"]),
    ],
)
def test_data_service_skip_first_row_uses_expected_delimiter(
    tmp_path, monkeypatch, suffix, content, expected_columns
):
    path = tmp_path / f"spectra{suffix}"
    path.write_text(content, encoding="utf-8")

    # Isolate delimiter routing from interactive quality handling and dtype
    # conversion so this regression exercises only load_data's parser path.
    service = DataService.__new__(DataService)
    service.data_import_stats = {}
    monkeypatch.setattr(service, "_handle_data_quality_issues", lambda data, _path: data)
    monkeypatch.setattr(service, "_analyze_data_quality", lambda _data, _path: {})
    monkeypatch.setattr(service, "_apply_conservative_rules", lambda data: data)

    frame = service.load_data(str(path), skip_first_row=True)

    assert list(frame.columns) == expected_columns
    assert frame.shape == (2, 3)
    assert frame.iloc[0, 0] == "A"
