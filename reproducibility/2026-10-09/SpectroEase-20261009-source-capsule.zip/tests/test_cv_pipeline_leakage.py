"""Regression tests for the active Analyzer cross-validation fit scope."""

import numpy as np
import pandas as pd
import pytest
from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler as SklearnStandardScaler


class RecordingStandardScaler(SklearnStandardScaler):
    """Capture identities encoded in the first feature at each transformer fit."""

    fit_feature_rows = []

    def fit(self, X, y=None, sample_weight=None):
        array = np.asarray(X)
        if array.ndim == 2 and array.shape[1] > 1:
            self.__class__.fit_feature_rows.append(array[:, 0].astype(int).tolist())
        return super().fit(X, y=y, sample_weight=sample_weight)


def _identified_features(n=15, offset=0):
    ids = [f"train-{i}" for i in range(n)]
    X = pd.DataFrame(
        {
            "row_identity_probe": np.arange(offset, offset + n, dtype=float),
            "signal": np.sin(np.arange(n, dtype=float)) + np.arange(n) * 0.1,
        },
        index=pd.Index(ids, name="_row_key"),
    )
    return X, ids


def _expected_fold_ids(ids, y, folds, classification):
    splitter = (
        StratifiedKFold(n_splits=folds, shuffle=True, random_state=42)
        if classification else KFold(n_splits=folds, shuffle=True, random_state=42)
    )
    y_array = np.asarray(y)
    return [
        {ids[index] for index in train_indices}
        for train_indices, _ in splitter.split(np.zeros((len(ids), 1)), y_array)
    ]


def _fit_ids_from_probe(values, ids):
    return {ids[int(value)] for value in values}


def test_quantitative_cv_records_only_fold_training_rows(monkeypatch):
    import plugins.modeling.quantitative_analyzer as module

    RecordingStandardScaler.fit_feature_rows = []
    monkeypatch.setattr(module, "StandardScaler", RecordingStandardScaler)
    X, ids = _identified_features()
    y = np.linspace(1.0, 4.0, len(ids))
    outer_test_ids = ["outer-test-a", "outer-test-b"]

    analyzer = module.QuantitativeAnalyzer("mlr")
    result = analyzer.cross_validate(
        X, y, n_splits=3, sample_ids=ids,
        outer_test_sample_ids=outer_test_ids,
    )

    assert result["cv_available"] is True
    expected = _expected_fold_ids(ids, y, 3, classification=False)
    feature_fit_rows = RecordingStandardScaler.fit_feature_rows
    assert len(feature_fit_rows) == 3
    assert [{ids[i] for i in rows} for rows in feature_fit_rows] == expected
    assert len(analyzer.last_cv_fit_trace) == 3
    for trace, expected_train in zip(analyzer.last_cv_fit_trace, expected):
        assert set(trace["transformer_fit_sample_ids"]) == expected_train
        assert all(
            set(scope_ids) == expected_train
            for scope_ids in trace["transformer_fit_sample_ids_by_name"].values()
        )
        assert set(trace["estimator_fit_sample_ids"]) == expected_train
        assert set(trace["validation_sample_ids"]).isdisjoint(expected_train)
        assert set(trace["transformer_fit_sample_ids"]).isdisjoint(outer_test_ids)


def test_qualitative_cv_scaler_is_fitted_inside_each_fold(monkeypatch):
    import plugins.modeling.qualitative_analyzer as module

    RecordingStandardScaler.fit_feature_rows = []
    monkeypatch.setattr(module, "StandardScaler", RecordingStandardScaler)
    X, ids = _identified_features()
    y = np.asarray(["class-a" if i % 2 else "class-b" for i in range(len(ids))])
    outer_test_ids = ["outer-test-a", "outer-test-b"]

    analyzer = module.QualitativeAnalyzer("dt")
    result = analyzer.cross_validate(
        X, y, cv=3, sample_ids=ids,
        outer_test_sample_ids=outer_test_ids,
    )

    assert result["cv_available"] is True
    expected = _expected_fold_ids(ids, y, 3, classification=True)
    feature_fit_rows = RecordingStandardScaler.fit_feature_rows
    assert len(feature_fit_rows) == 3
    assert [{ids[i] for i in rows} for rows in feature_fit_rows] == expected
    assert len(analyzer.last_cv_fit_trace) == 3
    for trace, expected_train in zip(analyzer.last_cv_fit_trace, expected):
        assert set(trace["transformer_fit_sample_ids"]) == expected_train
        assert all(
            set(scope_ids) == expected_train
            for scope_ids in trace["transformer_fit_sample_ids_by_name"].values()
        )
        assert set(trace["estimator_fit_sample_ids"]) == expected_train
        assert set(trace["validation_sample_ids"]).isdisjoint(expected_train)
        assert set(trace["transformer_fit_sample_ids"]).isdisjoint(outer_test_ids)


@pytest.mark.parametrize("analyzer_kind", ["quantitative", "qualitative"])
def test_analyzers_fail_closed_when_prior_learned_transform_is_declared(analyzer_kind):
    from plugins.modeling.quantitative_analyzer import QuantitativeAnalyzer
    from plugins.modeling.qualitative_analyzer import QualitativeAnalyzer

    X, ids = _identified_features()
    labels = np.asarray(["a" if i % 2 else "b" for i in range(len(ids))])
    analyzer = (
        QuantitativeAnalyzer("mlr") if analyzer_kind == "quantitative"
        else QualitativeAnalyzer("dt")
    )

    with pytest.raises(ValueError, match="fold-safe"):
        analyzer.cross_validate(
            X, labels, sample_ids=ids,
            unsafe_transform_reason="PCA was fitted before inner CV",
        )
    assert analyzer.last_cv_fit_trace == []


def test_analyzer_rejects_outer_test_identity_overlap_before_any_fit():
    from plugins.modeling.quantitative_analyzer import QuantitativeAnalyzer

    X, ids = _identified_features()
    analyzer = QuantitativeAnalyzer("mlr")
    with pytest.raises(ValueError, match="overlap"):
        analyzer.cross_validate(
            X, np.linspace(1.0, 4.0, len(ids)), n_splits=3,
            sample_ids=ids,
            outer_test_sample_ids=[ids[0], "outer-test-only"],
        )
    assert analyzer.last_cv_fit_trace == []


def test_grid_search_uses_fold_local_pipeline_and_excludes_outer_test_ids(monkeypatch):
    import app.services.hyperparameter_optimization_service as module
    from sklearn.linear_model import Ridge

    RecordingStandardScaler.fit_feature_rows = []
    monkeypatch.setattr(module, "StandardScaler", RecordingStandardScaler)
    X, ids = _identified_features(n=15)
    y = np.linspace(-1.0, 2.0, len(ids))
    outer_test_ids = ["held-out-a", "held-out-b"]

    service = module.HyperparameterOptimizationService()
    search = service.grid_search(
        Ridge(), {"alpha": [0.1]}, X, y, cv=3, scoring="accuracy",
        sample_ids=ids, outer_test_sample_ids=outer_test_ids,
    )

    # The controller's legacy default is accuracy; regression must score r2.
    assert search.scoring == "r2"
    expected = _expected_fold_ids(ids, y, 3, classification=False)
    assert len(search.cv_fit_trace_) == 3
    assert [set(item["transformer_fit_sample_ids"]) for item in search.cv_fit_trace_] == expected
    assert [set(item["estimator_fit_sample_ids"]) for item in search.cv_fit_trace_] == expected
    assert all(
        set(scope_ids) == expected_train
        for item, expected_train in zip(search.cv_fit_trace_, expected)
        for scope_ids in item["transformer_fit_sample_ids_by_name"].values()
    )
    assert set(search.refit_sample_ids_) == set(ids)
    assert set(search.outer_test_sample_ids_).isdisjoint(ids)

    observed = [
        {ids[int(index)] for index in rows}
        for rows in RecordingStandardScaler.fit_feature_rows
    ]
    # GridSearchCV does three fold fits and one refit on outer-training only.
    assert observed.count(set(ids)) == 1
    observed.remove(set(ids))
    assert observed == expected
    for trace in search.cv_fit_trace_:
        assert set(trace["transformer_fit_sample_ids"]).isdisjoint(outer_test_ids)
        assert set(trace["estimator_fit_sample_ids"]).isdisjoint(outer_test_ids)


@pytest.mark.parametrize("method", ["grid_search", "random_search"])
@pytest.mark.parametrize(
    ("scoring", "expected_scoring"),
    [("accuracy", "r2"), ("neg_mean_squared_error", "neg_mean_squared_error")],
)
def test_regression_search_resolves_legacy_accuracy_and_honors_controller_scorer(
        method, scoring, expected_scoring):
    from app.services.hyperparameter_optimization_service import HyperparameterOptimizationService
    from sklearn.linear_model import Ridge

    X, ids = _identified_features(n=18)
    y = np.linspace(-2.0, 3.0, len(ids)) + np.sin(np.arange(len(ids)))
    search_method = getattr(HyperparameterOptimizationService(), method)
    kwargs = {"n_iter": 1} if method == "random_search" else {}
    search = search_method(
        Ridge(), {"alpha": [0.1, 1.0]}, X, y, cv=3, scoring=scoring,
        sample_ids=ids, outer_test_sample_ids=["held-out-a"], **kwargs,
    )

    assert search.scoring == expected_scoring
    assert len(search.cv_fit_trace_) == 3
    assert all(
        set(item["estimator_fit_sample_ids"]).isdisjoint({"held-out-a"})
        for item in search.cv_fit_trace_
    )


def test_search_rejects_any_outer_test_identity_in_the_training_input(monkeypatch):
    import app.services.hyperparameter_optimization_service as module
    from sklearn.linear_model import Ridge
    from app.utils.exceptions import HyperparameterOptimizationError

    RecordingStandardScaler.fit_feature_rows = []
    monkeypatch.setattr(module, "StandardScaler", RecordingStandardScaler)
    X, ids = _identified_features(n=12)
    ids[-1] = "outer-test-reused"

    with pytest.raises(HyperparameterOptimizationError, match="overlap"):
        module.HyperparameterOptimizationService().grid_search(
            Ridge(), {"alpha": [0.1]}, X, np.linspace(0.0, 1.0, len(ids)),
            cv=3, scoring="r2", sample_ids=ids,
            outer_test_sample_ids=["outer-test-reused"],
        )
    assert RecordingStandardScaler.fit_feature_rows == []


def test_random_search_keeps_classifier_preprocessing_inside_each_fold():
    from app.services.hyperparameter_optimization_service import HyperparameterOptimizationService
    from sklearn.tree import DecisionTreeClassifier

    X, ids = _identified_features(n=18)
    y = np.asarray(["class-a" if i % 2 else "class-b" for i in range(len(ids))])
    search = HyperparameterOptimizationService().random_search(
        DecisionTreeClassifier(random_state=0), {"max_depth": [1]}, X, y,
        cv=3, n_iter=1, scoring="accuracy", sample_ids=ids,
        outer_test_sample_ids=["held-out-a"],
    )

    expected = _expected_fold_ids(ids, y, 3, classification=True)
    assert [set(item["transformer_fit_sample_ids"]) for item in search.cv_fit_trace_] == expected
    assert [set(item["estimator_fit_sample_ids"]) for item in search.cv_fit_trace_] == expected
    assert all(
        set(scope_ids) == expected_train
        for item, expected_train in zip(search.cv_fit_trace_, expected)
        for scope_ids in item["transformer_fit_sample_ids_by_name"].values()
    )
    assert set(search.refit_sample_ids_) == set(ids)


def test_genetic_search_uses_the_same_fold_fit_identity_scope(monkeypatch):
    import random
    import app.services.hyperparameter_optimization_service as module
    from sklearn.tree import DecisionTreeClassifier

    RecordingStandardScaler.fit_feature_rows = []
    monkeypatch.setattr(module, "StandardScaler", RecordingStandardScaler)
    random.seed(42)
    X, ids = _identified_features(n=18)
    y = np.asarray(["class-a" if i % 2 else "class-b" for i in range(len(ids))])
    service = module.HyperparameterOptimizationService()
    result = service.genetic_algorithm(
        DecisionTreeClassifier, {"max_depth": [1, 2], "min_samples_split": [2, 3]},
        X, y, cv=3, n_population=4, n_generations=1,
        scoring="accuracy", sample_ids=ids,
        outer_test_sample_ids=["held-out-a"],
    )

    expected = _expected_fold_ids(ids, y, 3, classification=True)
    assert [set(item["transformer_fit_sample_ids"]) for item in result.cv_fit_trace_] == expected
    assert [set(item["estimator_fit_sample_ids"]) for item in result.cv_fit_trace_] == expected
    assert all(
        set(scope_ids) == expected_train
        for item, expected_train in zip(result.cv_fit_trace_, expected)
        for scope_ids in item["transformer_fit_sample_ids_by_name"].values()
    )
    assert set(result.refit_sample_ids_) == set(ids)
    assert len(RecordingStandardScaler.fit_feature_rows) > 3
    assert all(len(rows) < len(ids) or rows == list(range(len(ids))) for rows in RecordingStandardScaler.fit_feature_rows)


def test_optuna_or_fallback_path_returns_fold_scoped_fit_trace():
    from app.services.hyperparameter_optimization_service import HyperparameterOptimizationService
    from sklearn.tree import DecisionTreeClassifier

    X, ids = _identified_features(n=18)
    y = np.asarray(["class-a" if i % 2 else "class-b" for i in range(len(ids))])
    best_params, best_model = HyperparameterOptimizationService().optuna_search(
        DecisionTreeClassifier(random_state=0), {"max_depth": [1]}, X, y,
        cv=3, n_iter=1, scoring="accuracy", sample_ids=ids,
        outer_test_sample_ids=["held-out-a"],
    )

    expected = _expected_fold_ids(ids, y, 3, classification=True)
    assert len(best_model.cv_fit_trace_) == 3
    assert [set(item["transformer_fit_sample_ids"]) for item in best_model.cv_fit_trace_] == expected
    assert all(
        set(scope_ids) == expected_train
        for item, expected_train in zip(best_model.cv_fit_trace_, expected)
        for scope_ids in item["transformer_fit_sample_ids_by_name"].values()
    )
    assert set(best_model.refit_sample_ids_) == set(ids)
    assert best_params


def test_gui_marks_prefit_feature_selection_cv_unavailable_without_fitting():
    import os
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from types import SimpleNamespace
    from app.views.main_window import (
        _cv_unavailable_transform_reason, _execute_fold_safe_cv,
    )

    data_model = SimpleNamespace(X_train_selected=np.ones((4, 2)))
    reason = _cv_unavailable_transform_reason(
        "selected_features", {"selected_features": {"selected_features": ["PC1"]}}, data_model
    )

    class AnalyzerMustNotRun:
        called = False

        def cross_validate(self, *args, **kwargs):
            self.called = True
            raise AssertionError("unsafe prefit feature selection must not reach CV")

    analyzer = AnalyzerMustNotRun()
    result = _execute_fold_safe_cv(
        analyzer, np.ones((4, 2)), np.arange(4), "regression", 2,
        ["row-a", "row-b", "row-c", "row-d"], ["test-row"], reason,
    )
    assert result["cv_available"] is False
    assert "feature selection" in result["cv_unavailable_reason"]
    assert analyzer.called is False


def test_gui_cv_path_passes_internal_train_and_outer_test_row_keys():
    import os
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from app.views.main_window import _execute_fold_safe_cv

    class CapturingAnalyzer:
        def cross_validate(self, X, y, **kwargs):
            self.received = (X, y, kwargs)
            return {"cv_available": True}

    analyzer = CapturingAnalyzer()
    X = np.arange(12, dtype=float).reshape(6, 2)
    y = np.asarray([1., 2., 3., 4., 5., 6.])
    result = _execute_fold_safe_cv(
        analyzer, X, y, "regression", 3,
        ["train-a", "train-b", "train-c", "train-d", "train-e", "train-f"],
        ["test-a", "test-b"], None,
    )

    assert result["cv_available"] is True
    received_X, received_y, kwargs = analyzer.received
    assert received_X is X
    assert received_y is y
    assert kwargs["sample_ids"] == ["train-a", "train-b", "train-c", "train-d", "train-e", "train-f"]
    assert kwargs["outer_test_sample_ids"] == ["test-a", "test-b"]


def test_dataset_or_split_invalidation_clears_hyperparameter_search_scope():
    import os
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from types import SimpleNamespace
    from app.views.main_window import MainWindow

    model = SimpleNamespace(
        cv_scope_safe=True, cv_scope_reason=None,
        cv_train_sample_ids=["old-train"], cv_test_sample_ids=["old-test"],
    )
    fake_window = SimpleNamespace(
        feature_data_options={"original": [1], "preprocessed": [2], "pca_features": [3], "selected_features": [4]},
        current_feature_source="selected_features", processed_spectra=[5], current_spectra=[6],
        controller=SimpleNamespace(
            modeling_controller=SimpleNamespace(modeling_model=model),
            preprocessing_controller=None, feature_selection_controller=None,
        ),
    )

    MainWindow.invalidate_dataset_feature_state(fake_window)

    assert model.cv_scope_safe is False
    assert "changed" in model.cv_scope_reason
    assert model.cv_train_sample_ids is None
    assert model.cv_test_sample_ids is None


def test_hyperparameter_controller_blocks_unverified_fold_scope_before_search():
    from types import SimpleNamespace
    from unittest.mock import Mock
    from app.controllers.hyperparameter_optimization_controller import HyperparameterOptimizationController

    class Button:
        def setEnabled(self, _enabled):
            pass

    class View:
        apply_button = Button()

        def get_selected_method(self):
            return "grid_search"

        def get_parameters(self):
            return {"param_grid": {"alpha": [0.1]}, "cv": 3}

        def display_message(self, message, *_args):
            self.message = message

    model = SimpleNamespace(
        X_train=np.ones((4, 2)), y_train=np.arange(4), trained_model=object(),
        cv_scope_safe=False, cv_scope_reason="PCA was fitted before inner CV",
    )
    controller = HyperparameterOptimizationController(View(), None, model)
    controller.hyperopt_service.optimize = Mock(side_effect=AssertionError("must be blocked"))

    controller.apply_optimization()

    controller.hyperopt_service.optimize.assert_not_called()
    assert "unavailable" in controller.view.message
    assert "PCA" in controller.view.message


def test_hyperparameter_controller_sends_training_rows_only_to_search(monkeypatch):
    from types import SimpleNamespace
    import app.controllers.hyperparameter_optimization_controller as controller_module
    from app.controllers.hyperparameter_optimization_controller import HyperparameterOptimizationController
    from app.services.hyperparameter_optimization_service import HyperparameterOptimizationService
    from sklearn.linear_model import Ridge

    class Button:
        def setEnabled(self, _enabled):
            pass

    class View:
        apply_button = Button()

        def get_selected_method(self):
            return "grid_search"

        def get_parameters(self):
            return {"param_grid": {"alpha": [0.1]}, "scoring": "r2", "cv": 3}

        def update_optimization_results(self, *_args):
            pass

        def display_message(self, *_args):
            pass

    X_train, train_ids = _identified_features(n=15)
    y_train = np.linspace(-1.0, 2.0, len(train_ids))
    X_test, test_ids = _identified_features(n=2, offset=1000)
    test_ids = ["held-out-a", "held-out-b"]
    model = SimpleNamespace(
        X_train=X_train.to_numpy(), y_train=y_train,
        X_test=X_test.to_numpy(), y_test=np.asarray([100., 200.]),
        trained_model=Ridge(), parameters={},
        cv_scope_safe=True, cv_train_sample_ids=train_ids,
        cv_test_sample_ids=test_ids,
    )
    controller = HyperparameterOptimizationController(View(), None, model)
    controller.hyperopt_service = HyperparameterOptimizationService()
    monkeypatch.setattr(controller_module, "run_heavy", lambda job: job())
    real_optimize = controller.hyperopt_service.optimize

    def capture_training_only_search(estimator, X, y, **kwargs):
        assert np.array_equal(X, model.X_train)
        assert np.array_equal(y, model.y_train)
        assert not np.any(np.isin(X[:, 0], X_test.iloc[:, 0].to_numpy()))
        assert set(y).isdisjoint(set(model.y_test))
        return real_optimize(estimator, X, y, **kwargs)

    controller.hyperopt_service.optimize = capture_training_only_search

    controller.apply_optimization()

    search = model.trained_model
    assert hasattr(search, "cv_fit_trace_")
    assert set(search.refit_sample_ids_) == set(train_ids)
    assert set(search.outer_test_sample_ids_) == set(test_ids)
    for trace in search.cv_fit_trace_:
        assert set(trace["transformer_fit_sample_ids"]).isdisjoint(test_ids)
        assert set(trace["validation_sample_ids"]).isdisjoint(test_ids)


@pytest.mark.parametrize(
    ("method", "view_params", "expected_method_params"),
    [
        (
            "random_search",
            {
                "param_distributions": {"alpha": [0.1, 0.2, 0.5]},
                "n_iter": 7,
                "scoring": "r2",
                "cv": 3,
            },
            {
                "param_distributions": {"alpha": [0.1, 0.2, 0.5]},
                "n_iter": 7,
            },
        ),
        (
            "genetic_algorithm",
            {
                "param_ranges": {"alpha": [0.1, 2.0]},
                "n_population": 6,
                "n_generations": 4,
                "scoring": "r2",
                "cv": 3,
            },
            {
                "param_grid": {"alpha": [0.1, 2.0]},
                "n_population": 6,
                "n_generations": 4,
            },
        ),
    ],
)
def test_hyperparameter_controller_forwards_random_and_ga_strategy_parameters(
        monkeypatch, method, view_params, expected_method_params):
    from types import SimpleNamespace
    import app.controllers.hyperparameter_optimization_controller as controller_module
    from app.controllers.hyperparameter_optimization_controller import HyperparameterOptimizationController

    class Button:
        def setEnabled(self, _enabled):
            pass

    class View:
        apply_button = Button()

        def get_selected_method(self):
            return method

        def get_parameters(self):
            return view_params

        def update_optimization_results(self, *_args):
            pass

        def display_message(self, *_args):
            pass

    class CapturingService:
        def __init__(self):
            self.call = None

        def optimize(self, estimator, X, y, **kwargs):
            self.call = (estimator, X, y, kwargs)
            return {"chosen": True}, estimator, {}

    model = SimpleNamespace(
        X_train=np.ones((6, 2)), y_train=np.arange(6, dtype=float),
        trained_model=object(), parameters={}, cv_scope_safe=True,
        cv_train_sample_ids=[f"train-{i}" for i in range(6)],
        cv_test_sample_ids=["held-out"],
    )
    controller = HyperparameterOptimizationController(View(), None, model)
    capture = CapturingService()
    controller.hyperopt_service = capture
    monkeypatch.setattr(controller_module, "run_heavy", lambda job: job())

    controller.apply_optimization()

    assert capture.call is not None
    _estimator, X, y, kwargs = capture.call
    assert np.array_equal(X, model.X_train)
    assert np.array_equal(y, model.y_train)
    assert kwargs["method"] == method
    assert kwargs["cv"] == 3
    assert kwargs["scoring"] == "r2"
    assert kwargs["sample_ids"] == model.cv_train_sample_ids
    assert kwargs["outer_test_sample_ids"] == model.cv_test_sample_ids
    for key, value in expected_method_params.items():
        assert kwargs[key] == value
    if method == "random_search":
        assert "param_grid" not in kwargs
        assert "n_population" not in kwargs
    else:
        assert "param_distributions" not in kwargs
        assert "n_iter" not in kwargs
