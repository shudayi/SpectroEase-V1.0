import inspect
import ast
import os
from pathlib import Path
import sys
import unittest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from plugin_loader import load_plugins


class PluginLoaderRegressionTests(unittest.TestCase):
    def test_load_plugins_returns_instances_with_compatibility_aliases(self):
        plugin_groups = load_plugins(str(PROJECT_ROOT / "plugins"))
        preprocessing, feature_selection, modeling, data_partitioning = plugin_groups

        self.assertGreaterEqual(len(preprocessing), 1)
        self.assertGreaterEqual(len(feature_selection), 1)
        self.assertGreaterEqual(len(modeling), 1)
        self.assertGreaterEqual(len(data_partitioning), 1)

        for group in plugin_groups:
            for plugin in group.values():
                self.assertFalse(inspect.isclass(plugin), f"{plugin!r} should be an instance")
                if hasattr(plugin, "get_parameter_info"):
                    self.assertTrue(hasattr(plugin, "get_params_info"))

        for plugin in data_partitioning.values():
            self.assertTrue(hasattr(plugin, "split_data"))
            self.assertTrue(hasattr(plugin, "partition"))


class PackagingRegressionTests(unittest.TestCase):
    def test_specs_include_runtime_plugins_without_local_venv_paths(self):
        spec_names = ["main.spec", "SpectroEase_exe.spec", "SpectroEase_folder.spec"]

        for spec_name in spec_names:
            spec_text = (PROJECT_ROOT / spec_name).read_text(encoding="utf-8")
            self.assertIn("('plugins', 'plugins')", spec_text)
            self.assertIn("('interfaces', 'interfaces')", spec_text)
            self.assertNotIn(".venv", spec_text)


class ResponsiveDialogRegressionTests(unittest.TestCase):
    def test_key_dialogs_do_not_use_fixed_window_size(self):
        dialog_files = [
            f for f in sorted((PROJECT_ROOT / "app/views").glob("*dialog.py"))
            if "-副本" not in f.name
        ]

        for dialog_file in dialog_files:
            source = dialog_file.read_text(encoding="utf-8")
            tree = ast.parse(source)
            # This regression protects top-level window responsiveness. A
            # multiline child editor may keep a designed height inside a
            # scroll area without fixing the dialog's dimensions.
            windows = {"self"}
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
                    constructor = node.value.func
                    if isinstance(constructor, ast.Name) and constructor.id == "QDialog":
                        windows.update(t.id for t in node.targets if isinstance(t, ast.Name))
            for node in ast.walk(tree):
                if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
                    continue
                receiver = node.func.value
                if isinstance(receiver, ast.Name) and receiver.id in windows:
                    self.assertNotIn(node.func.attr,
                                     {"setFixedSize", "setFixedHeight", "setFixedWidth", "setMaximumSize"},
                                     f"{dialog_file}:{node.lineno}")

    def test_key_dialogs_use_screen_fit_helper(self):
        dialog_files = [
            f for f in sorted((PROJECT_ROOT / "app/views").glob("*dialog.py"))
            if "-副本" not in f.name
        ]

        for dialog_file in dialog_files:
            source = dialog_file.read_text(encoding="utf-8")
            self.assertIn("fit_window_to_screen", source, dialog_file)

    def test_parameter_dialog_buttons_are_outside_scroll_area(self):
        dialog_files = [
            PROJECT_ROOT / "app/views/emsc_parameter_dialog.py",
            PROJECT_ROOT / "app/views/osc_parameter_dialog.py",
            PROJECT_ROOT / "app/views/rnv_parameter_dialog.py",
        ]

        for dialog_file in dialog_files:
            source = dialog_file.read_text(encoding="utf-8")
            self.assertNotIn("main_layout.addLayout(button_layout)", source, dialog_file)
            self.assertIn("footer_widget.setLayout(button_layout)", source, dialog_file)
            self.assertIn("outer_layout.addWidget(footer_widget)", source, dialog_file)
            self.assertLess(
                source.index("scroll_area.setWidget(content_widget)"),
                source.index("outer_layout.addWidget(footer_widget)"),
                dialog_file,
            )
            self.assertRegex(
                source,
                r"(?:description_text\.setMaximumHeight\((?:ui\.scaled_px\((?:96|tok\.TEXT_EDIT_MAX_HEIGHT_SM)\)|96|tok\.TEXT_EDIT_MAX_HEIGHT_SM)\)|ui\.set_max_height\(self\.description_text,\s*(?:ui\.scaled_px\((?:96|tok\.TEXT_EDIT_MAX_HEIGHT_SM)\)|96|tok\.TEXT_EDIT_MAX_HEIGHT_SM)\))",
                dialog_file,
            )

    def test_enhanced_preprocessing_visualization_uses_responsive_sizing(self):
        source = (PROJECT_ROOT / "app/views/enhanced_preprocessing_visualization.py").read_text(encoding="utf-8")

        self.assertNotIn("setMinimumSize(1000, 700)", source)
        # After scaling refactor, dimensions may be wrapped with ui.scaled_px().
        self.assertRegex(
            source,
            r"fit_window_to_screen\(\s*self\s*,\s*(?:ui\.scaled_px\(1000\)|1000)\s*,\s*(?:ui\.scaled_px\(700\)|700)\s*,\s*min_width\s*=\s*(?:ui\.scaled_px\(720\)|720)\s*,\s*min_height\s*=\s*(?:ui\.scaled_px\(520\)|520)\s*\)"
        )


class DataPartitioningLayoutRegressionTests(unittest.TestCase):
    def test_data_partitioning_view_avoids_hard_width_truncation(self):
        source = (PROJECT_ROOT / "app/views/data_view.py").read_text(encoding="utf-8")

        self.assertNotIn("setMaximumWidth(", source)
        self.assertIn("method_layout = QGridLayout()", source)
        self.assertIn("def _new_params_grid", source)
        self.assertIn("def _should_use_single_column_params", source)
        # After scaling refactor, column widths are wrapped with ui.scaled_px() or tokens.
        self.assertRegex(source, r"grid\.setColumnMinimumWidth\(0,\s*(?:ui\.scaled_px\((?:64|tok\.GRID_LABEL_COL_WIDTH_SM)\)|64)\)")
        self.assertRegex(source, r"grid\.setColumnMinimumWidth\(0,\s*(?:ui\.scaled_px\((?:120|tok\.GRID_SINGLE_LABEL_COL_WIDTH)\)|120)\)")

    def test_plugin_parameters_use_multirow_grid_layout(self):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        try:
            from PyQt5.QtWidgets import QApplication, QGridLayout
            from app.views.data_view import DataPartitioningView
        except ImportError as exc:
            self.skipTest(f"PyQt5 is not available: {exc}")

        class DemoPartitioner:
            def get_parameter_info(self):
                return {
                    "alpha": {"type": "float", "default": 0.1},
                    "beta": {"type": "int", "default": 2},
                    "name": {"type": "str", "default": "demo"},
                }

        app = QApplication.instance() or QApplication([])
        view = DataPartitioningView({"Demo": DemoPartitioner()})

        view.init_param_widgets("Demo")
        params_layout = view.params_form.itemAt(0).widget().layout()

        self.assertIsInstance(params_layout, QGridLayout)
        self.assertIsNotNone(params_layout.itemAtPosition(1, 0))
        self.assertIsNotNone(params_layout.itemAtPosition(0, 2))
        self.assertEqual(set(view.param_widgets), {"alpha", "beta", "name"})
        app.processEvents()

    def test_plugin_parameters_with_long_label_use_single_column_layout(self):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        try:
            from PyQt5.QtWidgets import QApplication, QGridLayout
            from app.views.data_view import DataPartitioningView
        except ImportError as exc:
            self.skipTest(f"PyQt5 is not available: {exc}")

        class LongLabelPartitioner:
            def get_parameter_info(self):
                return {
                    "calibration_window_size": {"type": "int", "default": 8},
                    "beta": {"type": "float", "default": 0.2},
                }

        app = QApplication.instance() or QApplication([])
        view = DataPartitioningView({"Long": LongLabelPartitioner()})

        view.init_param_widgets("Long")
        params_layout = view.params_form.itemAt(0).widget().layout()

        self.assertIsInstance(params_layout, QGridLayout)
        self.assertIsNotNone(params_layout.itemAtPosition(0, 0))
        self.assertIsNotNone(params_layout.itemAtPosition(1, 0))
        self.assertIsNone(params_layout.itemAtPosition(0, 2))
        # Single-column mode: label col + control col only (no second pair).
        # Column minimums must stay slim: the workflow panel can be ~300px wide, and
        # the old 120/180 minimums overflowed it, clipping labels and controls.
        self.assertGreaterEqual(params_layout.columnMinimumWidth(0), 56)
        self.assertLessEqual(params_layout.columnMinimumWidth(0), 120)
        self.assertGreaterEqual(params_layout.columnMinimumWidth(1), 88)
        self.assertLessEqual(params_layout.columnMinimumWidth(1), 180)
        self.assertEqual(set(view.param_widgets), {"calibration_window_size", "beta"})
        app.processEvents()

    def test_plugin_parameters_more_than_four_use_single_column_layout(self):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        try:
            from PyQt5.QtWidgets import QApplication, QGridLayout
            from app.views.data_view import DataPartitioningView
        except ImportError as exc:
            self.skipTest(f"PyQt5 is not available: {exc}")

        class ManyParamsPartitioner:
            def get_parameter_info(self):
                return {
                    "a": {"type": "int", "default": 1},
                    "b": {"type": "int", "default": 2},
                    "c": {"type": "int", "default": 3},
                    "d": {"type": "int", "default": 4},
                    "e": {"type": "int", "default": 5},
                }

        app = QApplication.instance() or QApplication([])
        view = DataPartitioningView({"Many": ManyParamsPartitioner()})

        view.init_param_widgets("Many")
        params_layout = view.params_form.itemAt(0).widget().layout()

        self.assertIsInstance(params_layout, QGridLayout)
        self.assertIsNotNone(params_layout.itemAtPosition(4, 0))
        self.assertIsNone(params_layout.itemAtPosition(0, 2))
        self.assertEqual(set(view.param_widgets), {"a", "b", "c", "d", "e"})
        app.processEvents()


class LLMGeneratedCodeSafetyTests(unittest.TestCase):
    def test_generated_code_safety_scan_blocks_dangerous_patterns(self):
        from app.utils import code_sandbox

        findings = code_sandbox.validate_code(
            "import os\nclass Bad:\n    def apply(self, data, params):\n        return open('x').read()\n",
        )

        self.assertIn("Import of os is not allowed", findings)
        self.assertIn("Call to open() is not allowed", findings)

    def test_code_sandbox_blocks_subprocess_and_eval(self):
        from app.utils import code_sandbox

        code = (
            "import subprocess\n"
            "class Bad:\n"
            "    def apply(self, data, params):\n"
            "        return eval('1+1')\n"
        )
        findings = code_sandbox.validate_code(code)

        self.assertIn("Import of subprocess is not allowed", findings)
        self.assertIn("Call to eval() is not allowed", findings)

    def test_code_sandbox_blocks_dangerous_attributes(self):
        from app.utils import code_sandbox

        code = (
            "import os\n"
            "class Bad:\n"
            "    def apply(self, data, params):\n"
            "        return os.system('ls')\n"
        )
        findings = code_sandbox.validate_code(code)

        self.assertIn("Call to .system() is not allowed", findings)


class DataModelRegressionTests(unittest.TestCase):
    def test_default_label_column_zero(self):
        import pandas as pd
        from app.models.data_model import DataModel

        model = DataModel()
        df = pd.DataFrame({
            'label': [1, 2, 3],
            'w1': [4, 5, 6],
            'w2': [7, 8, 9],
        })
        model.set_data(df)

        X = model.get_X()
        y = model.get_y()

        self.assertIsNotNone(X)
        self.assertEqual(list(X.columns), ['w1', 'w2'])
        self.assertEqual(list(y), [1, 2, 3])

    def test_label_column_index_configurable(self):
        import pandas as pd
        from app.models.data_model import DataModel

        model = DataModel()
        df = pd.DataFrame({
            'w1': [4, 5, 6],
            'label': [1, 2, 3],
            'w2': [7, 8, 9],
        })
        model.set_data(df)
        model.set_label_column_index(1)

        X = model.get_X()
        y = model.get_y()

        self.assertEqual(list(X.columns), ['w1', 'w2'])
        self.assertEqual(list(y), [1, 2, 3])

    def test_set_label_column_index_invalidates_cache(self):
        import pandas as pd
        from app.models.data_model import DataModel

        model = DataModel()
        df1 = pd.DataFrame({'label': [1, 2], 'w1': [3, 4]})
        model.set_data(df1)
        X_first = model.get_X()

        model.set_label_column_index(1)
        df2 = pd.DataFrame({'w1': [5, 6], 'label': [7, 8]})
        model.set_data(df2)
        X_second = model.get_X()

        self.assertIsNot(X_first, X_second)
        self.assertEqual(list(X_second.columns), ['w1'])
        self.assertEqual(list(model.get_y()), [7, 8])

    def test_set_partitioned_data_invalidates_cache(self):
        import pandas as pd
        from app.models.data_model import DataModel

        model = DataModel()
        df = pd.DataFrame({'label': [1, 2, 3], 'w1': [4, 5, 6]})
        model.set_data(df)
        model.get_X()

        partitioned = {
            'X_train': pd.DataFrame({'w1': [4, 5]}),
            'y_train': pd.Series([1, 2]),
            'X_test': pd.DataFrame({'w1': [6]}),
            'y_test': pd.Series([3]),
        }
        model.set_partitioned_data(partitioned)

        # Cache is cleared; a fresh get_X should recompute from the original data.
        self.assertIsNone(model._x)
        self.assertIsNone(model._y)

    def test_label_column_index_out_of_range_raises(self):
        import pandas as pd
        from app.models.data_model import DataModel

        model = DataModel()
        df = pd.DataFrame({'label': [1, 2], 'w1': [3, 4]})
        model.set_data(df)
        model.set_label_column_index(5)

        with self.assertRaises(ValueError):
            model.get_X()

    def test_set_preprocessing_result_rejects_unverified_legacy_partition(self):
        import pandas as pd
        from app.models.data_model import DataModel

        model = DataModel()
        model.set_partitioned_data({
            'X_train': pd.DataFrame({'w1': [1, 2]}),
            'y_train': pd.Series([0, 1]),
            'X_test': pd.DataFrame({'w1': [3]}),
            'y_test': pd.Series([1]),
        })

        new_X_train = pd.DataFrame({'w1': [10, 20], 'w2': [30, 40]})
        new_X_test = pd.DataFrame({'w1': [50], 'w2': [60]})
        accepted = model.set_preprocessing_result({
            'X_train': new_X_train,
            'X_test': new_X_test,
        })

        self.assertFalse(accepted)
        self.assertIs(model.X_train, model.partitioned_data['X_train'])
        self.assertIs(model.X_test, model.partitioned_data['X_test'])
        self.assertIsNone(model.features)
        # The unverified split is not modified with a preprocessing result.
        self.assertEqual(list(model.partitioned_data['y_train']), [0, 1])
        self.assertEqual(list(model.partitioned_data['y_test']), [1])


class DataPartitioningViewRegressionTests(unittest.TestCase):
    def test_label_column_selector_is_populated_after_load(self):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        try:
            from PyQt5.QtWidgets import QApplication
            from PyQt5.QtCore import Qt
            from app.views.data_view import DataPartitioningView
        except ImportError as exc:
            self.skipTest(f"PyQt5 is not available: {exc}")

        import pandas as pd

        app = QApplication.instance() or QApplication([])
        view = DataPartitioningView({})
        df = pd.DataFrame({'w1': [1, 2], 'label': [0, 1], 'w2': [3, 4]})

        received = []
        view.label_column_changed.connect(received.append)
        view.set_data_loaded("test.csv", df)

        self.assertTrue(view.label_column_combo.isEnabled())
        self.assertEqual(view.label_column_combo.count(), 3)
        self.assertEqual(view.label_column_combo.currentText(), 'w1')
        self.assertEqual(received, [0])

        view.label_column_combo.setCurrentIndex(1)
        app.processEvents()
        self.assertEqual(received, [0, 1])


class LLMHardeningTests(unittest.TestCase):
    def test_extract_message_content_validates_schema(self):
        from app.services.llm_service import _extract_message_content, LLMServiceError

        valid = {
            "choices": [{"message": {"content": "hello"}}]
        }
        self.assertEqual(_extract_message_content(valid), "hello")

        with self.assertRaises(LLMServiceError):
            _extract_message_content({"choices": []})

        with self.assertRaises(LLMServiceError):
            _extract_message_content({"choices": [{"message": {}}]})

        with self.assertRaises(LLMServiceError):
            _extract_message_content("not a dict")

    def test_sanitize_source_code_filters_control_characters(self):
        from app.views.llm_dialog import LLMDialog

        dialog = LLMDialog.__new__(LLMDialog)
        raw = "import os\x00\x01\nprint('hello')\r\n"
        sanitized = dialog._sanitize_source_code(raw)
        self.assertNotIn('\x00', sanitized)
        self.assertNotIn('\x01', sanitized)
        self.assertIn("import os", sanitized)
        self.assertIn("print('hello')", sanitized)

    def test_sanitize_source_code_truncates_long_input(self):
        from app.views.llm_dialog import LLMDialog

        dialog = LLMDialog.__new__(LLMDialog)
        long_input = "x" * 40000
        sanitized = dialog._sanitize_source_code(long_input)
        self.assertLessEqual(len(sanitized), 32768)

    def test_extract_code_from_response_handles_markdown_fences(self):
        from app.views.llm_dialog import LLMDialog

        dialog = LLMDialog.__new__(LLMDialog)

        fenced_python = "Here is the code:\n```python\nclass A:\n    pass\n```\nDone."
        self.assertEqual(
            dialog._extract_code_from_response(fenced_python),
            "class A:\n    pass"
        )

        fenced_generic = "```\nclass B:\n    pass\n```"
        self.assertEqual(
            dialog._extract_code_from_response(fenced_generic),
            "class B:\n    pass"
        )

        plain = "class C:\n    pass"
        self.assertEqual(dialog._extract_code_from_response(plain), plain)

    def test_llm_convert_worker_cancel_closes_session(self):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        try:
            from PyQt5.QtWidgets import QApplication
            from app.views.llm_dialog import _LLMConvertWorker
        except ImportError as exc:
            self.skipTest(f"PyQt5 is not available: {exc}")

        class DummyService:
            def chat(self, **kwargs):
                # Simulate a long blocking call.
                import time
                time.sleep(10)

        from unittest.mock import patch

        app = QApplication.instance() or QApplication([])
        worker = _LLMConvertWorker(DummyService(), "prompt")

        with patch.object(worker._session, 'close') as mock_close:
            worker.cancel()

        self.assertTrue(worker.is_cancelled())
        self.assertTrue(mock_close.called)


class SpectralUnitsGuiTests(unittest.TestCase):
    def test_axis_label_per_unit(self):
        from app.utils.spectral_units import axis_label
        # Each canonical unit has a human-readable axis label.
        units = ['nm', 'cm-1', 'um', 'THz', 'eV', 'Å']
        for unit in units:
            label = axis_label(unit)
            self.assertIsInstance(label, str)
            self.assertGreater(len(label), 0)

    def test_convert_array_roundtrip(self):
        from app.utils.spectral_units import convert_array
        import numpy as np
        values = np.array([500.0, 1000.0, 1500.0, 2000.0, 2500.0])
        back = convert_array(convert_array(values, 'nm', 'um'), 'um', 'nm')
        np.testing.assert_allclose(back, values, rtol=1e-9)


class SpectralTypeRegistryTests(unittest.TestCase):
    def test_default_registry_has_builtin_types(self):
        from app.services.spectral_type_registry import (
            SPECTRAL_TYPES, get_by_name, display_names
        )
        names = {entry.name for entry in SPECTRAL_TYPES}
        # Built-in types are always present.
        for required in ('nir', 'raman', 'mir', 'vis_nir', 'uv_vis'):
            self.assertIn(required, names)
        self.assertIsNotNone(get_by_name('nir'))
        # Unknown identifiers should return None (not None-sentinel).
        self.assertIsNone(get_by_name('invalid-name'))
        self.assertIn('nir', display_names())


class SettingsDialogTests(unittest.TestCase):
    def test_settings_persistence_and_load(self):
        from config.settings import Settings
        from app.utils.spectral_units import normalize_unit
        s = Settings()
        s.preferred_x_unit = 'cm-1'
        s.categorical_unique_count_max = 17
        s.save_settings()
        s2 = Settings()
        self.assertEqual(s2.preferred_x_unit, 'cm-1')
        self.assertEqual(s2.categorical_unique_count_max, 17)
        self.assertEqual(normalize_unit(s2.preferred_x_unit), 'cm-1')
        # Restore defaults to avoid leaking state to other tests.
        s2.preferred_x_unit = 'nm'
        s2.categorical_unique_count_max = 50
        s2.save_settings()


class ColumnMappingDialogTests(unittest.TestCase):
    def test_dialog_instantiation_with_data(self):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        try:
            from PyQt5.QtWidgets import QApplication
            from app.views.column_mapping_dialog import ColumnMappingDialog
            import pandas as pd
        except ImportError as exc:
            self.skipTest(f"PyQt5 not available: {exc}")
        app = QApplication.instance() or QApplication([])
        df = pd.DataFrame({'label': [0, 1], 'w1': [1.0, 2.0], 'w2': [3.0, 4.0]})
        dialog = ColumnMappingDialog(
            df.columns.tolist(),
            label_column_index=0,
            selected_wavelength_columns=[1, 2],
        )
        self.assertEqual(dialog._result['label_column'], 0)
        # Default selected wavelengths excludes the label column.
        self.assertNotIn(0, dialog._result['wavelength_columns'])


if __name__ == "__main__":
    unittest.main()
