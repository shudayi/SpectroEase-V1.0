"""Real child-process contract checks for the five initial plugin roles."""

from dataclasses import replace
import json

import numpy as np
import pytest

from app.services.verified_algorithm_service import Candidate, VerifiedAlgorithmError, VerifiedAlgorithmService


TRAIN = [[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]]
PROBE = [[7.0, 8.0], [9.0, 10.0]]


def candidate(kind: str) -> Candidate:
    if kind == "stateful_preprocessing":
        source = """import numpy as np
def fit(X, y, params):
    return {'mean': np.mean(X, axis=0).tolist()}
def transform(X, state, params):
    return np.asarray(X) - np.asarray(state['mean'])
"""
        reference = [[4.0, 4.0], [6.0, 6.0]]
    elif kind == "feature_selection":
        source = """import numpy as np
def fit(X, y, params):
    return {'indices': [1]}
def transform(X, state, params):
    return np.asarray(X)[:, state['indices']]
"""
        reference = [[8.0], [10.0]]
    elif kind == "classification":
        source = """import numpy as np
def fit(X, y, params):
    return {'threshold': float(np.mean(X[:, 0]))}
def predict(X, state, params):
    return (np.asarray(X)[:, 0] > state['threshold']).astype(int)
"""
        reference = [1, 1]
    elif kind == "regression":
        source = """import numpy as np
def fit(X, y, params):
    return {'offset': float(np.mean(y))}
def predict(X, state, params):
    return np.asarray(X)[:, 0] + state['offset']
"""
        reference = [8.0, 10.0]
    else:
        source = """import numpy as np
def score(y_true, y_pred, params):
    return float(np.mean((np.asarray(y_true) - np.asarray(y_pred)) ** 2))
"""
        reference = 0.5
    return Candidate(kind=kind, name=f"{kind} example", python_source=source,
                     parameter_schema={}, parameters={}, train_X=TRAIN,
                     train_y=[0, 1, 2] if kind == "regression" else [0, 0, 1] if kind == "classification" else None,
                     probe_X=[1.0, 2.0] if kind == "metric" else PROBE,
                     probe_y=[1.0, 1.0] if kind == "metric" else None,
                     reference_output=reference, axis=[950, 955])


@pytest.mark.parametrize("kind", ["stateful_preprocessing", "feature_selection", "classification", "regression", "metric"])
def test_five_roles_verify_accept_reload_and_execute(tmp_path, kind):
    service = VerifiedAlgorithmService(tmp_path)
    fixture = candidate(kind)
    report = service.verify(fixture)
    assert report.passed, report.checks
    accepted = service.accept(report, fixture.python_source, user_confirmed=True)
    fresh = VerifiedAlgorithmService(tmp_path)
    assert accepted in fresh.list_accepted(kind)
    assert fresh.reload(accepted).kind == kind
    if kind == "metric":
        assert fresh.execute(accepted, [1.0, 2.0], y_true=[1.0, 1.0]) == pytest.approx(0.5)
    else:
        state = fresh.fit(accepted, TRAIN, fixture.train_y)
        json.dumps(state, allow_nan=False)
        actual = fresh.execute(accepted, PROBE, state=state)
        np.testing.assert_allclose(actual, fixture.reference_output)


def test_numerical_failure_source_edit_and_record_tamper_rejected(tmp_path):
    service = VerifiedAlgorithmService(tmp_path)
    fixture = candidate("regression")
    bad = replace(fixture, reference_output=[0.0, 0.0])
    report = service.verify(bad)
    assert not report.passed
    assert any(c.name == "numeric_reference" and not c.passed for c in report.checks)
    with pytest.raises(VerifiedAlgorithmError):
        service.accept(report, bad.python_source, user_confirmed=True)
    good = service.verify(fixture)
    with pytest.raises(VerifiedAlgorithmError):
        service.accept(good, fixture.python_source + "\n# changed", user_confirmed=True)
    accepted = service.accept(good, fixture.python_source, user_confirmed=True)
    path = tmp_path / f"{accepted}.json"
    record = json.loads(path.read_text(encoding="utf-8"))
    record["candidate"]["python_source"] += "\n# changed"
    path.write_text(json.dumps(record), encoding="utf-8")
    with pytest.raises(VerifiedAlgorithmError):
        service.reload(accepted)


def test_batch_dependent_prediction_is_rejected(tmp_path):
    fixture = candidate("stateful_preprocessing")
    source = """import numpy as np
def fit(X, y, params):
    return {'ok': True}
def transform(X, state, params):
    return np.asarray(X) - np.mean(X, axis=0)
"""
    report = VerifiedAlgorithmService(tmp_path).verify(replace(fixture, python_source=source,
        reference_output=[[-1.0, -1.0], [1.0, 1.0]]))
    assert not report.passed
    assert any(c.name == "row_invariance" and not c.passed for c in report.checks)


def test_string_class_labels_and_feature_index_mismatch(tmp_path):
    source = """import numpy as np
def fit(X, y, params):
    return {'threshold': float(np.mean(X[:, 0]))}
def predict(X, state, params):
    return np.where(np.asarray(X)[:, 0] > state['threshold'], 'ripe', 'unripe')
"""
    classifier = replace(candidate("classification"), python_source=source,
                         train_y=["unripe", "unripe", "ripe"], reference_output=["ripe", "ripe"])
    report = VerifiedAlgorithmService(tmp_path).verify(classifier)
    assert report.passed, report.checks
    bad_selector_source = """import numpy as np
def fit(X, y, params):
    return {'indices': [1]}
def transform(X, state, params):
    return np.asarray(X)[:, [0]]
"""
    selector = replace(candidate("feature_selection"), python_source=bad_selector_source,
                       reference_output=[[7.0], [9.0]])
    report = VerifiedAlgorithmService(tmp_path).verify(selector)
    assert not report.passed
    assert any("indices" in c.detail for c in report.checks if not c.passed)

def test_runtime_fit_uses_partition_not_fixture_and_state_is_bound(tmp_path):
    service = VerifiedAlgorithmService(tmp_path / 'registry')
    fixture = candidate('stateful_preprocessing')
    accepted = service.accept(service.verify(fixture), fixture.python_source, user_confirmed=True)
    # 150 rows exercises runtime data beyond the small verification fixture cap.
    train_a = np.tile([[100.0, 200.0]], (150, 1))
    train_b = [[10.0, 20.0], [30.0, 40.0]]
    state_a = service.fit_accepted(accepted, train_a)
    state_b = service.fit_accepted(accepted, train_b)
    assert state_a['state']['mean'] == [100.0, 200.0]
    assert state_b['state']['mean'] == [20.0, 30.0]
    np.testing.assert_allclose(service.execute(accepted, [[101, 202]], state=state_a), [[1, 2]])
    path = tmp_path / 'saved' / 'fold-a.json'
    service.save_state(state_a, path)
    fresh = VerifiedAlgorithmService(tmp_path / 'registry')
    restored = fresh.load_state(accepted, path)
    np.testing.assert_array_equal(fresh.execute(accepted, [[101, 202]], state=restored), [[1, 2]])
    with pytest.raises(VerifiedAlgorithmError, match='feature count'):
        fresh.execute(accepted, [[1, 2, 3]], state=restored)
    altered = json.loads(json.dumps(restored))
    altered['state']['mean'][0] = 0
    with pytest.raises(VerifiedAlgorithmError, match='integrity'):
        fresh.execute(accepted, [[101, 202]], state=altered)
    # Accepted parameter edits must invalidate the persisted candidate itself.
    record_path = tmp_path / 'registry' / f'{accepted}.json'
    record = json.loads(record_path.read_text(encoding='utf-8'))
    record['candidate']['atol'] = 1.0
    record_path.write_text(json.dumps(record), encoding='utf-8')
    with pytest.raises(VerifiedAlgorithmError, match='configuration'):
        fresh.reload(accepted)

def test_cache_exact_record_bytes_deepcopy_clear_force_and_restart(tmp_path, monkeypatch):
    service = VerifiedAlgorithmService(tmp_path)
    fixture = candidate('stateful_preprocessing')
    accepted = service.accept(service.verify(fixture), fixture.python_source, user_confirmed=True)
    original_verify = service.verify
    calls = []
    def spy(value):
        calls.append(value)
        return original_verify(value)
    monkeypatch.setattr(service, 'verify', spy)
    returned = service.reload(accepted)
    returned.parameters['escape'] = 'not persisted'
    returned.train_X[0][0] = -1000
    assert service.reload(accepted).parameters == {}
    assert service.reload(accepted).train_X[0][0] == 1.
    assert calls == []
    service.reload(accepted, force_verify=True)
    assert len(calls) == 1
    service.clear_verification_cache()
    service.reload(accepted)
    assert len(calls) == 2
    fresh = VerifiedAlgorithmService(tmp_path)
    fresh_calls = []
    monkeypatch.setattr(fresh, 'verify', lambda value: (fresh_calls.append(value), original_verify(value))[1])
    fresh.reload(accepted)
    assert len(fresh_calls) == 1
    path = tmp_path / f'{accepted}.json'
    record = json.loads(path.read_text(encoding='utf-8'))
    for field, changed in [('python_source', fixture.python_source + '\n# edit'), ('parameters', {'changed': 1}),
                           ('parameter_schema', {'changed': {'type': 'number', 'default': 1}}),
                           ('reference_output', [[0., 0.], [0., 0.]])]:
        from copy import deepcopy
        altered = deepcopy(record); altered['candidate'][field] = changed
        path.write_text(json.dumps(altered), encoding='utf-8')
        with pytest.raises(VerifiedAlgorithmError):
            service.reload(accepted)
        path.write_text(json.dumps(record), encoding='utf-8')
        service.reload(accepted)
    altered = json.loads(json.dumps(record))
    altered['validator_version'] = 'unsupported-validator-version'
    path.write_text(json.dumps(altered), encoding='utf-8')
    with pytest.raises(VerifiedAlgorithmError, match='version'):
        service.reload(accepted)
    path.unlink()
    with pytest.raises(VerifiedAlgorithmError):
        service.reload(accepted)
