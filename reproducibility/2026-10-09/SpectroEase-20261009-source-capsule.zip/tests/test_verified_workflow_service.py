import copy

import numpy as np
import pytest

from app.services.verified_algorithm_service import VerifiedAlgorithmError
from app.services.verified_workflow_service import VerifiedWorkflowService


class Algorithms:
    """Deterministic backend to inspect workflow partition boundaries."""
    kinds = {"center": "stateful_preprocessing", "select": "feature_selection", "model": "regression"}

    def __init__(self):
        self.fits = []

    def reload(self, identifier):
        from types import SimpleNamespace
        return SimpleNamespace(kind=self.kinds[identifier])

    def fit_accepted(self, identifier, X, y):
        self.fits.append((identifier, np.array(X), np.array(y)))
        return {"mean": np.mean(X, axis=0).tolist(), "integrity_sha256": identifier, "n_features": np.asarray(X).shape[1]}

    def execute(self, identifier, X, state):
        X = np.asarray(X)
        if identifier == "center":
            return X - state["mean"]
        if identifier == "select":
            return X[:, :1]
        return X[:, 0]


def test_workflow_uses_training_only_and_replays_without_fit():
    backend = Algorithms()
    workflow = VerifiedWorkflowService(backend)
    train = np.array([[1., 10.], [3., 30.]])
    test = np.array([[9., 90.], [11., 110.]])
    original = copy.deepcopy(train)
    result = workflow.run({"preprocessing": "center", "feature_selection": "select", "model": "model"},
                          train, [0., 2.], test, [7., 9.], ["a", "b"], ["c", "d"])
    assert result["predictions"] == [7., 9.]
    assert result["metrics"]["RMSE"] == 0
    assert len(backend.fits) == 3
    assert all(len(X) == 2 for _, X, _ in backend.fits)
    np.testing.assert_array_equal(train, original)
    np.testing.assert_array_equal(workflow.predict(result, [[9., 90.]]), [7.])
    assert len(backend.fits) == 3
    assert all(t["training_ids"] == ["a", "b"] for t in result["fit_trace"])


def test_workflow_rejects_overlap_before_fit():
    backend = Algorithms()
    with pytest.raises(VerifiedAlgorithmError, match="overlap"):
        VerifiedWorkflowService(backend).run({"model": "model"}, [[1.]], [1.], [[2.]],
                                             train_ids=["same"], test_ids=["same"])
    assert not backend.fits

def test_axis_rejects_same_width_reorder_before_fit_and_execute():
    backend = Algorithms()
    workflow = VerifiedWorkflowService(backend)
    with pytest.raises(VerifiedAlgorithmError, match='axes'):
        workflow.run({'model': 'model'}, [[1., 2.], [3., 4.]], [1., 2.], [[5., 6.]],
                     axis=[950, 955], test_axis=[955, 950])
    assert backend.fits == []
    result = workflow.run({'preprocessing': 'center', 'model': 'model'}, [[1., 2.], [3., 4.]],
                          [1., 2.], [[5., 6.]], axis=[950, 955], test_axis=[950, 955])
    assert result['axis_scope'] == 'exact_ordered_input_labels'
    np.testing.assert_allclose(workflow.predict(result, [[5., 6.]], axis=[950, 955]), [3.])
    for axis in ([955, 950], None):
        with pytest.raises(VerifiedAlgorithmError, match='axis'):
            workflow.predict(result, [[5., 6.]], axis=axis)
