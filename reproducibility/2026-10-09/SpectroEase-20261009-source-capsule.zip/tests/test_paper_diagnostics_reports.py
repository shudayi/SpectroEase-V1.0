"""Regression/classification numerical checks for manuscript-promised diagnostics."""
import json
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd
import pytest
from scipy.stats import t, f
from sklearn.linear_model import LinearRegression, LogisticRegression, Ridge
from sklearn.cross_decomposition import PLSRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import roc_auc_score, average_precision_score

from app.services.diagnostics_service import generate_diagnostics, diagnostic_figures
from app.services.prediction_contract import FittedSpectrumPredictor
from plugins.reporting.spectrum_report_generator import SpectrumReportGenerator


@pytest.fixture
def regression():
    rng = np.random.default_rng(18)
    X = rng.normal(size=(60, 4))
    y = 30 + X @ np.array([2., -1., .8, 0.]) + rng.normal(size=60) * .3
    return X[:45], y[:45], X[45:], y[45:]


def test_ols_interval_and_studentization_independent_formula(regression):
    Xt, yt, X, y = regression
    model = LinearRegression().fit(Xt, yt)
    result = generate_diagnostics(model, X, y, 'regression', X_train=Xt, y_train=yt)
    D = np.column_stack([np.ones(len(Xt)), Xt]); E = np.column_stack([np.ones(len(X)), X])
    covariance = np.linalg.inv(D.T @ D)
    ht = np.diag(D @ covariance @ D.T); h = np.diag(E @ covariance @ E.T)
    residual = yt - model.predict(Xt)
    sigma = np.sqrt(residual @ residual / (len(Xt) - D.shape[1]))
    critical = t.ppf(.975, len(Xt) - D.shape[1])
    np.testing.assert_allclose(result['geometry']['test_leverage'], h)
    np.testing.assert_allclose(result['geometry']['training_studentized_residuals'], residual / (sigma*np.sqrt(1-ht)))
    np.testing.assert_allclose(result['intervals']['mean_lower'], model.predict(X) - critical*sigma*np.sqrt(h))
    np.testing.assert_allclose(result['intervals']['prediction_upper'], model.predict(X) + critical*sigma*np.sqrt(1+h))
    assert np.all(np.asarray(result['intervals']['prediction_upper']) > np.asarray(result['intervals']['mean_upper']))
    json.dumps(result, allow_nan=False)


def test_intervals_remain_in_original_target_units(regression):
    Xt, yt, X, y = regression
    scaler_x = StandardScaler().fit(Xt); scaler_y = StandardScaler().fit(yt[:, None])
    estimator = LinearRegression().fit(scaler_x.transform(Xt), scaler_y.transform(yt[:, None]).ravel())
    predictor = FittedSpectrumPredictor(estimator, 'regression', x_scaler=scaler_x, y_scaler=scaler_y, n_features=4)
    got = generate_diagnostics(predictor, X, y, 'regression', X_train=Xt, y_train=yt)
    reference = generate_diagnostics(LinearRegression().fit(Xt, yt), X, y, 'regression', X_train=Xt, y_train=yt)
    np.testing.assert_allclose(got['intervals']['mean_lower'], reference['intervals']['mean_lower'], atol=1e-10)


def test_pls_geometry_hotelling_independent_covariance(regression):
    Xt, yt, X, y = regression
    estimator = PLSRegression(n_components=2).fit(Xt, yt)
    got = generate_diagnostics(estimator, X, y, 'regression', X_train=Xt, y_train=yt, bootstrap_iterations=20)
    train_scores = estimator.transform(Xt); scores = estimator.transform(X)
    cov = np.cov(train_scores, rowvar=False)
    centered = scores - train_scores.mean(axis=0)
    expected = np.diag(centered @ np.linalg.inv(cov) @ centered.T)
    np.testing.assert_allclose(got['hotelling']['test_t2'], expected)
    assert got['hotelling']['threshold'] == pytest.approx(2*46*44/(45*43)*f.ppf(.95, 2, 43))
    assert 'conditional' in got['hotelling']['scope']
    assert got['intervals']['method'] == 'Training-pairs percentile bootstrap'


def test_bootstrap_deterministic_refits_and_no_heldout_target_use(regression):
    Xt, yt, X, y = regression
    estimator = RandomForestRegressor(n_estimators=6, max_depth=3, random_state=None).fit(Xt, yt)
    before = estimator.predict(X).copy()
    first = generate_diagnostics(estimator, X, y, 'regression', X_train=Xt, y_train=yt, bootstrap_iterations=20)
    second = generate_diagnostics(estimator, X, y+10000, 'regression', X_train=Xt, y_train=yt, bootstrap_iterations=20)
    assert first['intervals'] == second['intervals']
    np.testing.assert_array_equal(before, estimator.predict(X))
    assert 'prediction_lower' not in first['intervals']
    assert 'geometry' not in first
    assert first['intervals']['successful_fits'] == 20


def test_bootstrap_fitted_transform_boundary_with_missing_values(regression):
    Xt, yt, X, y = regression
    Xt = Xt.copy(); X = X.copy(); Xt[0, 0] = np.nan; X[0, 0] = np.nan
    imputer = SimpleImputer().fit(Xt); scaler = StandardScaler().fit(imputer.transform(Xt))
    yscale = StandardScaler().fit(yt[:, None])
    model = Ridge().fit(scaler.transform(imputer.transform(Xt)), yscale.transform(yt[:, None]).ravel())
    predictor = FittedSpectrumPredictor(model, 'regression', imputer=imputer, x_scaler=scaler, y_scaler=yscale, n_features=4)
    mean_before = imputer.statistics_.copy()
    got = generate_diagnostics(predictor, X, y, 'regression', X_train=Xt, y_train=yt, bootstrap_iterations=20)
    assert got['intervals']['successful_fits'] == 20
    np.testing.assert_array_equal(mean_before, imputer.statistics_)
    assert np.min(got['intervals']['mean_lower']) > 15


def test_rank_deficient_new_direction_rejected():
    Xt = np.column_stack([np.arange(20.), np.arange(20.)]); yt = np.arange(20.) + np.sin(np.arange(20.))
    model = LinearRegression().fit(Xt, yt)
    got = generate_diagnostics(model, [[1, 5]], [3.], 'regression', X_train=Xt, y_train=yt, bootstrap_iterations=0)
    assert 'geometry' not in got and 'intervals' not in got
    assert 'estimable' in got['unavailable']['linear_geometry']


def test_group_fit_does_not_use_invalid_row_bootstrap(regression):
    Xt, yt, X, y = regression
    estimator = Ridge().fit(Xt, yt)
    predictor = FittedSpectrumPredictor(estimator, 'regression', group_validation=True, fit_group_ids=list(range(45)))
    got = generate_diagnostics(predictor, X, y, 'regression', X_train=Xt, y_train=yt, bootstrap_iterations=20)
    assert 'intervals' not in got
    assert 'group' in got['unavailable']['bootstrap_intervals']


@pytest.fixture
def classification():
    rng = np.random.default_rng(88)
    X = rng.normal(size=(90, 3))
    labels = np.asarray(['A alpha', 'B beta', 'C gamma'])[np.arange(90) % 3]
    X[:, 0] += (np.arange(90) % 3)*3
    return X[:60], labels[:60], X[60:], labels[60:]


def test_multiclass_actual_scores_and_label_order(classification):
    Xt, yt, X, y = classification
    encoder = LabelEncoder().fit(yt)
    model = LogisticRegression(max_iter=200).fit(Xt, encoder.transform(yt))
    predictor = FittedSpectrumPredictor(model, 'classification', label_encoder=encoder, n_features=3)
    got = generate_diagnostics(predictor, X, y, 'classification')
    np.testing.assert_allclose(got['scores'], model.predict_proba(X))
    assert got['score_classes'] == encoder.classes_.tolist()
    for i, curve in enumerate(got['classification_curves']):
        assert curve['roc_auc'] == pytest.approx(roc_auc_score(y==encoder.classes_[i], model.predict_proba(X)[:, i]))
        assert curve['average_precision'] == pytest.approx(average_precision_score(y==encoder.classes_[i], model.predict_proba(X)[:, i]))
    assert sum(got['class_distribution']['observed']) == len(y)


def test_decision_scores_not_fabricated_probabilities(classification):
    from sklearn.svm import LinearSVC
    Xt, yt, X, y = classification
    model = LinearSVC().fit(Xt, yt)
    got = generate_diagnostics(model, X, y, 'classification')
    assert got['score_method'] == 'decision_function'
    np.testing.assert_allclose(got['scores'], model.decision_function(X))


def test_hard_label_only_classifier_has_no_roc():
    class HardOnly:
        classes_ = np.asarray(['a', 'b'])
        def predict(self, X): return np.asarray(['a'] * len(X))
    got = generate_diagnostics(HardOnly(), np.ones((4, 2)), ['a','a','b','b'], 'classification')
    assert 'scores' not in got and 'classification_curves' not in got
    assert 'hard labels' in got['unavailable']['roc_precision_recall']


def test_one_class_heldout_omits_undefined_roc(classification):
    Xt, yt, X, y = classification
    model = LogisticRegression().fit(Xt, yt)
    got = generate_diagnostics(model, X, np.repeat('A alpha', len(X)), 'classification')
    assert got['classification_curves'] == []
    assert 'curve_A alpha' in got['unavailable']


def test_named_features_order_guard(regression):
    Xt, yt, X, y = regression
    predictor = FittedSpectrumPredictor(LinearRegression().fit(Xt, yt), 'regression', feature_names=['a','b','c','d'], n_features=4)
    with pytest.raises(ValueError, match='feature columns'):
        generate_diagnostics(predictor, pd.DataFrame(X, columns=['b','a','c','d']), y, 'regression')


def test_all_figures_owned_agg_and_layout(classification, regression):
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    Xt, yt, X, y = regression
    reg = generate_diagnostics(PLSRegression(n_components=2).fit(Xt, yt), X, y, 'regression', X_train=Xt,y_train=yt,bootstrap_iterations=20)
    Xt, yt, X, y = classification
    clf = generate_diagnostics(LogisticRegression().fit(Xt, yt), X, y, 'classification')
    sets = [diagnostic_figures(reg), diagnostic_figures(clf)]
    assert set(sets[0]) >= {'predicted_observed','residuals','confidence_band','studentized_residuals','leverage','hotelling'}
    assert set(sets[1]) >= {'roc','precision_recall','class_distribution','confusion_matrix','feature_importance'}
    for figures in sets:
        for figure in figures.values():
            assert isinstance(figure.canvas, FigureCanvasAgg)
            figure.canvas.draw()
            renderer = figure.canvas.get_renderer()
            for ax in figure.axes:
                assert ax.get_tightbbox(renderer).x0 >= -1
                assert ax.get_tightbbox(renderer).x1 <= figure.bbox.width+1
            figure.clear()


def test_pdf_embeds_real_graphics_and_scope_sidecar(tmp_path, regression):
    from pypdf import PdfReader
    Xt, yt, X, y = regression
    diagnostics = generate_diagnostics(LinearRegression().fit(Xt, yt), X, y, 'regression',X_train=Xt,y_train=yt)
    generator = SpectrumReportGenerator(output_dir=str(tmp_path),page_size='A4')
    path = generator.generate_report({'shape':X.shape,'spectra':X,'wavelengths':[950,955,960,965]},
          {'SNV': {'enabled':True}}, {}, {'rmse':.3}, title='Diagnostics & intervals',diagnostics=diagnostics)
    reader = PdfReader(path)
    count = sum(len(page.images) for page in reader.pages)
    assert count >= 6
    text = '\n'.join(page.extract_text() for page in reader.pages)
    assert 'independent homoscedastic Gaussian' in text
    assert 'Diagnostic Graphics' in text
    sidecar = json.loads(open(path[:-4]+'_diagnostics.json',encoding='utf-8').read())
    assert sidecar == diagnostics


@pytest.mark.parametrize('task', ['classification','regression'])
def test_parallel_report_owned_renderers(tmp_path, task, classification, regression):
    Xt, yt, X, y = classification if task == 'classification' else regression
    estimator = LogisticRegression().fit(Xt,yt) if task == 'classification' else LinearRegression().fit(Xt,yt)
    data=generate_diagnostics(estimator,X,y,task,X_train=Xt,y_train=yt)
    generator=SpectrumReportGenerator(output_dir=str(tmp_path))
    def render(_): return generator.generate_report({'shape':X.shape},{},{},{'metric':.4},diagnostics=data)
    with ThreadPoolExecutor(max_workers=2) as executor: paths=list(executor.map(render,range(2)))
    assert paths[0] != paths[1]
    from pypdf import PdfReader
    assert all(any(page.images for page in PdfReader(path).pages) for path in paths)
