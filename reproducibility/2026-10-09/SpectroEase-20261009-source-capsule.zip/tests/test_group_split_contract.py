import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
import pandas as pd
import pytest
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor

from app.models.data_model import DataModel
from app.controllers.data_controller import DataController
from app.utils.exceptions import DataServiceError
from app.services.data_service import DataService
from app.services.hyperparameter_optimization_service import HyperparameterOptimizationService
from plugins.data_partitioning.advanced_splitter import AdvancedSplitter
from plugins.modeling.quantitative_analyzer import QuantitativeAnalyzer
from plugins.modeling.qualitative_analyzer import QualitativeAnalyzer


def _physical_data(n_groups=12, reps=2):
    rows = []
    for group in range(n_groups):
        for replicate in range(reps):
            rows.append({
                "sample": f"sample-{group}-{replicate}",
                "batch": f"batch-{group}",
                "nir_a": float(group + replicate / 10),
                "nir_b": float(group * 2 - replicate / 5),
                "target": float(group + replicate / 4),
            })
    frame = pd.DataFrame(rows)
    frame.index = pd.Index([f"rk-{i}" for i in range(len(frame))], name="_row_key")
    return frame


def _partition_params(frame, method="Train-Test Split", **extra):
    return {
        "task_type": "regression",
        "target_column": frame.columns.get_loc("target"),
        "sample_id_column": frame.columns.get_loc("sample"),
        "group_id_column": frame.columns.get_loc("batch"),
        "group_validation": True,
        "test_size": 0.25,
        "random_state": 41,
        "processed_labels": frame["target"].to_numpy(),
        "original_labels": frame["target"].to_numpy(),
        "row_keys": frame.index.tolist(),
        **extra,
    }


def _assert_trace_disjoint(trace):
    assert trace
    for fold in trace:
        assert set(fold["train_group_ids"]).isdisjoint(fold["validation_group_ids"])
        assert set(fold["train_physical_sample_ids"]).isdisjoint(
            fold["validation_physical_sample_ids"]
        )
        assert set(fold["estimator_fit_sample_ids"]).isdisjoint(
            fold["validation_sample_ids"]
        )


def test_outer_group_split_excludes_ids_and_preserves_row_alignment():
    frame = _physical_data()
    service = DataService.__new__(DataService)
    service.plugins = {}
    result = service.partition_data(frame, "Train-Test Split", _partition_params(frame))

    assert list(result["X_train"].columns) == ["nir_a", "nir_b"]
    assert list(result["X_test"].columns) == ["nir_a", "nir_b"]
    assert result["X_train"].index.equals(result["y_train"].index)
    assert result["X_test"].index.equals(result["y_test"].index)
    assert result["sample_id_train"].index.equals(result["X_train"].index)
    assert result["group_id_test"].index.equals(result["X_test"].index)
    assert set(result["group_id_train"]).isdisjoint(set(result["group_id_test"]))
    assert set(result["sample_id_train"]).isdisjoint(set(result["sample_id_test"]))
    data_controller = DataController.__new__(DataController)
    data_controller._validate_partition_result(
        result, expected_row_keys=frame.index.tolist(),
        expected_feature_columns=["nir_a", "nir_b"],
    )
    malformed = dict(result)
    malformed["group_id_train"] = result["group_id_train"].iloc[::-1]
    with pytest.raises(DataServiceError, match="not aligned"):
        data_controller._validate_partition_result(
            malformed, expected_row_keys=frame.index.tolist(),
            expected_feature_columns=["nir_a", "nir_b"],
        )

    original = frame.set_index(frame.index)
    for key, value in result["y_train"].items():
        assert value == original.loc[key, "target"]
    for key, value in result["sample_id_test"].items():
        assert value == original.loc[key, "sample"]


def test_group_kfold_keeps_replicate_groups_together():
    frame = _physical_data()
    service = DataService.__new__(DataService)
    service.plugins = {}
    params = _partition_params(
        frame, n_splits=3, method="K-Fold", target_column=frame.columns.get_loc("target")
    )
    result = service.partition_data(frame, "K-Fold", params)
    groups = frame["batch"].to_numpy()
    for train_idx, validation_idx in result["cv_splits"]:
        assert set(groups[train_idx]).isdisjoint(set(groups[validation_idx]))
        assert set(frame["sample"].to_numpy()[train_idx]).isdisjoint(
            set(frame["sample"].to_numpy()[validation_idx])
        )
    assert not ({"sample", "batch"} & set(result["X_train"].columns))


def test_logo_uses_selected_groups_and_refuses_implicit_grouping():
    frame = _physical_data()
    service = DataService.__new__(DataService)
    service.plugins = {}
    params = _partition_params(frame)
    with pytest.raises(ValueError, match="requires group validation"):
        service.partition_data(frame, "LOGO", {**params, "group_validation": False})
    result = service.partition_data(frame, "LOGO", params)
    assert set(result["group_id_train"]).isdisjoint(set(result["group_id_test"]))
    assert set(result["sample_id_train"]).isdisjoint(set(result["sample_id_test"]))
    assert len(result["cv_splits"]) == frame["batch"].nunique()


@pytest.mark.parametrize("bad_groups, message", [
    (None, "no group_id column"),
    (["" for _ in range(24)], "blank, or null-sentinel values"),
    ([np.nan for _ in range(24)], "missing, blank, or null-sentinel values"),
])
def test_missing_or_blank_group_ids_fail_closed(bad_groups, message):
    frame = _physical_data()
    if bad_groups is not None:
        frame["batch"] = bad_groups
    service = DataService.__new__(DataService)
    service.plugins = {}
    params = _partition_params(frame)
    if bad_groups is None:
        params["group_id_column"] = None
    with pytest.raises(ValueError, match=message):
        service.partition_data(frame, "Train-Test Split", params)


def test_conflicting_sample_to_group_mapping_is_rejected():
    frame = _physical_data()
    frame.loc[frame.index[1], "sample"] = frame.loc[frame.index[0], "sample"]
    frame.loc[frame.index[1], "batch"] = "different-batch"
    service = DataService.__new__(DataService)
    service.plugins = {}
    with pytest.raises(ValueError, match="maps to multiple group_id"):
        service.partition_data(frame, "Train-Test Split", _partition_params(frame))


def test_blank_sample_ids_are_rejected_when_group_validation_is_requested():
    frame = _physical_data()
    frame.loc[frame.index[0], "sample"] = " "
    service = DataService.__new__(DataService)
    service.plugins = {}
    with pytest.raises(ValueError, match="sample_id contains missing, blank"):
        service.partition_data(frame, "Train-Test Split", _partition_params(frame))


def test_repeated_physical_sample_rows_in_the_same_group_are_kept_together():
    frame = _physical_data()
    frame.loc[frame.index[1], "sample"] = frame.loc[frame.index[0], "sample"]
    service = DataService.__new__(DataService)
    service.plugins = {}
    result = service.partition_data(frame, "Train-Test Split", _partition_params(frame))
    sample = frame.loc[frame.index[0], "sample"]
    assert not (
        sample in set(result["sample_id_train"])
        and sample in set(result["sample_id_test"])
    )


def test_group_cv_refuses_fewer_groups_than_folds():
    frame = _physical_data(n_groups=3)
    service = DataService.__new__(DataService)
    service.plugins = {}
    params = _partition_params(frame, n_splits=4)
    with pytest.raises(ValueError, match="at least 4 unique groups"):
        service.partition_data(frame, "K-Fold", params)


@pytest.mark.parametrize("method", ["Train-Test Split", "K-Fold"])
def test_whitespace_equivalent_ids_are_canonical_before_outer_and_inner_splits(method):
    frame = _physical_data(n_groups=12, reps=4)
    # Simulate a source file that encodes one physical group/sample with
    # inconsistent surrounding whitespace across replicate rows.
    frame["batch"] = [
        value if row % 2 == 0 else f" {value} "
        for row, value in enumerate(frame["batch"])
    ]
    frame.loc[frame.index[1], "sample"] = f" {frame.loc[frame.index[0], 'sample']} "
    service = DataService.__new__(DataService)
    service.plugins = {}
    params = _partition_params(frame, method=method)
    if method == "K-Fold":
        params["n_splits"] = 3
    else:
        # This seed previously split whitespace-equivalent group spellings
        # across the outer train/test partitions.
        params["random_state"] = 0
    result = service.partition_data(frame, method, params)

    assert result["group_id_train"].str.strip().equals(result["group_id_train"])
    assert result["group_id_test"].str.strip().equals(result["group_id_test"])
    assert result["sample_id_train"].str.strip().equals(result["sample_id_train"])
    assert result["sample_id_test"].str.strip().equals(result["sample_id_test"])
    assert set(result["group_id_train"]).isdisjoint(result["group_id_test"])
    assert set(result["sample_id_train"]).isdisjoint(result["sample_id_test"])

    data_controller = DataController.__new__(DataController)
    data_controller._validate_partition_result(
        result, expected_row_keys=frame.index.tolist(),
        expected_feature_columns=["nir_a", "nir_b"],
    )
    malformed = dict(result)
    malformed["group_id_test"] = result["group_id_test"].map(lambda value: f" {value} ")
    with pytest.raises(DataServiceError, match="noncanonical"):
        data_controller._validate_partition_result(
            malformed, expected_row_keys=frame.index.tolist(),
            expected_feature_columns=["nir_a", "nir_b"],
        )

    if method == "K-Fold":
        canonical_groups = frame["batch"].str.strip().to_numpy()
        for train_idx, validation_idx in result["cv_splits"]:
            assert set(canonical_groups[train_idx]).isdisjoint(canonical_groups[validation_idx])


@pytest.mark.parametrize("id_field", ["sample", "batch"])
@pytest.mark.parametrize("sentinel", ["nan", "none", "<na>"])
def test_string_null_sentinels_are_rejected_before_any_split(id_field, sentinel):
    frame = _physical_data()
    frame.loc[frame.index[0], id_field] = sentinel
    service = DataService.__new__(DataService)
    service.plugins = {}
    params = _partition_params(frame)
    if id_field == "batch":
        # The selected ID is invalid even when group-aware splitting is off;
        # identity metadata must have one consistent missing-value contract.
        params["group_validation"] = False
    with pytest.raises(ValueError, match="null-sentinel"):
        service.partition_data(frame, "Train-Test Split", params)


def test_data_model_keeps_ids_out_of_x_and_clears_identity_scope_on_invalidation():
    frame = _physical_data()
    model = DataModel()
    model.set_data(frame)
    model.set_label_column_index(frame.columns.get_loc("target"))
    service = DataService.__new__(DataService)
    service.plugins = {}
    params = _partition_params(frame)
    params["row_keys"] = model.get_row_keys().tolist()
    result = service.partition_data(frame, "Train-Test Split", params)
    model.set_partitioned_data(result, task_type="regression")

    assert model.row_alignment_verified
    assert model.group_validation is True
    assert model.get_X().columns.tolist() == ["nir_a", "nir_b"]
    assert model.sample_id_train.index.equals(model.X_train.index)
    model.set_label_column_index(frame.columns.get_loc("nir_a"))
    assert model.has_partitioned_data() is False
    assert model.group_validation is False
    assert model.sample_id_train is None and model.group_id_train is None

    model.set_data(frame.copy())
    assert model.sample_id_column_index is None
    assert model.group_id_column_index is None
    assert model.group_validation is False


def test_advanced_group_shuffle_requires_explicit_group_ids_and_keeps_them_out_of_x():
    frame = _physical_data()
    row_frame = frame[["nir_a", "nir_b", "target"]]
    splitter = AdvancedSplitter()
    with pytest.raises(ValueError, match="explicitly selected group_id"):
        splitter.partition(row_frame, {"method": "group_shuffle", "n_splits": 2})
    groups = frame["batch"].copy()
    result = splitter.partition(row_frame, {
        "method": "group_shuffle", "n_splits": 2, "test_size": 0.25,
        "group_ids": groups,
    })
    assert list(result["X_train"].columns) == ["nir_a", "nir_b"]
    assert set(groups.loc[result["X_train"].index]).isdisjoint(
        set(groups.loc[result["X_test"].index])
    )


def test_quantitative_and_qualitative_inner_cv_traces_are_group_disjoint():
    frame = _physical_data()
    train_groups = [f"batch-{i}" for i in range(9)]
    train = frame[frame["batch"].isin(train_groups)]
    outer_groups = [f"batch-{i}" for i in range(9, 12)]
    outer = frame[frame["batch"].isin(outer_groups)]

    regression = QuantitativeAnalyzer("mlr").cross_validate(
        train[["nir_a", "nir_b"]], train["target"], n_splits=3,
        sample_ids=train.index.tolist(), outer_test_sample_ids=outer.index.tolist(),
        physical_sample_ids=train["sample"].tolist(),
        outer_test_physical_sample_ids=outer["sample"].tolist(),
        group_ids=train["batch"].tolist(), outer_test_group_ids=outer["batch"].tolist(),
        group_validation=True,
    )
    assert regression["group_validation"] is True
    _assert_trace_disjoint(regression["cv_fit_trace"])

    classification_train = train
    classification_outer = outer
    train_labels = classification_train["batch"].str.extract(r"(\d+)$")[0].astype(int).mod(2).map({0: "A", 1: "B"})
    classification = QualitativeAnalyzer("dt").cross_validate(
        classification_train[["nir_a", "nir_b"]], train_labels, cv=3,
        sample_ids=classification_train.index.tolist(),
        outer_test_sample_ids=classification_outer.index.tolist(),
        physical_sample_ids=classification_train["sample"].tolist(),
        outer_test_physical_sample_ids=classification_outer["sample"].tolist(),
        group_ids=classification_train["batch"].tolist(),
        outer_test_group_ids=classification_outer["batch"].tolist(),
        group_validation=True,
    )
    assert classification["group_validation"] is True
    _assert_trace_disjoint(classification["cv_fit_trace"])


def test_main_window_cv_dispatch_forwards_physical_ids_and_group_scope():
    from app.views.main_window import _execute_fold_safe_cv

    class Analyzer:
        def cross_validate(self, X, y, **kwargs):
            return kwargs

    received = _execute_fold_safe_cv(
        Analyzer(), np.ones((4, 2)), np.arange(4), "regression", 2,
        ["rk0", "rk1", "rk2", "rk3"], ["rkt"], None,
        ["s0", "s1", "s2", "s3"], ["st"],
        ["g0", "g0", "g1", "g1"], ["gt"], True,
    )
    assert received["physical_sample_ids"] == ["s0", "s1", "s2", "s3"]
    assert received["outer_test_physical_sample_ids"] == ["st"]
    assert received["group_ids"] == ["g0", "g0", "g1", "g1"]
    assert received["outer_test_group_ids"] == ["gt"]
    assert received["group_validation"] is True


def test_main_window_invalidation_clears_old_physical_identity_scope():
    from types import SimpleNamespace
    from app.views.main_window import MainWindow

    model = SimpleNamespace(
        cv_scope_safe=True, cv_train_sample_ids=["row"], cv_test_sample_ids=["row-test"],
        cv_train_physical_sample_ids=["physical"], cv_test_physical_sample_ids=["physical-test"],
        cv_train_group_ids=["group"], cv_test_group_ids=["group-test"],
        cv_group_validation=True,
    )
    fake_window = SimpleNamespace(
        feature_data_options={}, current_feature_source="selected_features",
        processed_spectra=[1], current_spectra=[2],
        controller=SimpleNamespace(
            modeling_controller=SimpleNamespace(modeling_model=model),
        ),
    )
    MainWindow.invalidate_dataset_feature_state(fake_window)
    assert model.cv_train_physical_sample_ids is None
    assert model.cv_test_physical_sample_ids is None
    assert model.cv_train_group_ids is None
    assert model.cv_test_group_ids is None
    assert model.cv_group_validation is False


@pytest.mark.parametrize("method, kwargs", [
    ("grid_search", {"param_grid": {"max_depth": [1, 2]}}),
    ("random_search", {"param_distributions": {"max_depth": [1, 2]}, "n_iter": 2}),
    ("optuna", {"param_grid": {"max_depth": [1, 2]}, "n_iter": 2}),
    ("genetic_algorithm", {
        "param_grid": {"max_depth": [1, 2]}, "n_population": 10, "n_generations": 1,
    }),
])
def test_all_search_paths_use_explicit_train_only_groups(method, kwargs):
    frame = _physical_data()
    train = frame[frame["batch"].isin([f"batch-{i}" for i in range(9)])]
    outer = frame[frame["batch"].isin([f"batch-{i}" for i in range(9, 12)])]
    service = HyperparameterOptimizationService()
    _, best_model, _ = service.optimize(
        DecisionTreeRegressor(), train[["nir_a", "nir_b"]], train["target"],
        method=method, scoring="r2", cv=3,
        sample_ids=train.index.tolist(), outer_test_sample_ids=outer.index.tolist(),
        physical_sample_ids=train["sample"].tolist(),
        outer_test_physical_sample_ids=outer["sample"].tolist(),
        group_ids=train["batch"].tolist(), outer_test_group_ids=outer["batch"].tolist(),
        group_validation=True, **kwargs,
    )
    _assert_trace_disjoint(best_model.cv_fit_trace_)
    assert best_model.group_validation_ is True


def test_classification_hyperparameter_search_uses_stratified_group_folds():
    frame = _physical_data()
    train = frame[frame["batch"].isin([f"batch-{i}" for i in range(9)])]
    outer = frame[frame["batch"].isin([f"batch-{i}" for i in range(9, 12)])]
    labels = train["batch"].str.extract(r"(\d+)$")[0].astype(int).mod(2).map({0: "A", 1: "B"})
    service = HyperparameterOptimizationService()
    _, best_model, _ = service.optimize(
        DecisionTreeClassifier(random_state=7), train[["nir_a", "nir_b"]], labels,
        method="grid_search", param_grid={"max_depth": [1, 2]},
        scoring="accuracy", cv=3,
        sample_ids=train.index.tolist(), outer_test_sample_ids=outer.index.tolist(),
        physical_sample_ids=train["sample"].tolist(),
        outer_test_physical_sample_ids=outer["sample"].tolist(),
        group_ids=train["batch"].tolist(), outer_test_group_ids=outer["batch"].tolist(),
        group_validation=True,
    )
    _assert_trace_disjoint(best_model.cv_fit_trace_)


def test_search_refuses_group_mismatch_and_outer_test_reuse():
    service = HyperparameterOptimizationService()
    frame = _physical_data()
    groups = frame["batch"].tolist()
    with pytest.raises(ValueError, match="no explicit group_id"):
        service._fit_scope_splits(
            DecisionTreeRegressor(), frame[["nir_a"]], frame["target"], 3,
            group_validation=True,
        )
    with pytest.raises(ValueError, match="Outer-test group IDs overlap"):
        service._fit_scope_splits(
            DecisionTreeRegressor(), frame[["nir_a"]], frame["target"], 3,
            sample_ids=frame.index.tolist(), group_ids=groups,
            outer_test_group_ids=[groups[0]], group_validation=True,
        )


def test_hyperparameter_controller_forwards_physical_id_scope(monkeypatch):
    import app.controllers.hyperparameter_optimization_controller as controller_module
    from app.controllers.hyperparameter_optimization_controller import HyperparameterOptimizationController

    class Button:
        def setEnabled(self, _value):
            pass

    class View:
        apply_button = Button()

        def get_selected_method(self):
            return "grid_search"

        def get_parameters(self):
            return {"param_grid": {"max_depth": [1, 2]}}

        def update_optimization_results(self, *_args):
            pass

        def display_message(self, *_args):
            pass

        def display_error(self, *_args):
            pass

    class Model:
        X_train = pd.DataFrame({"x": [0., 1., 2., 3.]})
        y_train = pd.Series([0., 1., 2., 3.])
        trained_model = DecisionTreeRegressor().fit(X_train, y_train)
        cv_scope_safe = True
        cv_train_sample_ids = ["rk0", "rk1", "rk2", "rk3"]
        cv_test_sample_ids = ["rkt"]
        cv_train_physical_sample_ids = ["s0", "s1", "s2", "s3"]
        cv_test_physical_sample_ids = ["st"]
        cv_train_group_ids = ["g0", "g0", "g1", "g1"]
        cv_test_group_ids = ["gt"]
        cv_group_validation = True
        parameters = {}

    captured = {}

    class FakeService:
        def optimize(self, estimator, X, y, **kwargs):
            captured.update(kwargs)
            return {}, estimator, {}

    monkeypatch.setattr(controller_module, "run_heavy", lambda operation: operation())
    ctl = HyperparameterOptimizationController(View(), None, Model())
    ctl.hyperopt_service = FakeService()
    ctl.apply_optimization()
    assert captured["group_validation"] is True
    assert captured["group_ids"] == ["g0", "g0", "g1", "g1"]
    assert captured["outer_test_group_ids"] == ["gt"]
    assert captured["physical_sample_ids"] == ["s0", "s1", "s2", "s3"]
    assert captured["outer_test_physical_sample_ids"] == ["st"]


def test_mounted_main_window_optimizer_runs_grouped_search_from_visible_controls(monkeypatch):
    from PyQt5.QtWidgets import QApplication
    from app.utils.translator import Translator
    from app.utils import logger as logger_module
    from app.controllers import data_controller as data_controller_module
    from app.controllers import hyperparameter_optimization_controller as hpo_controller_module
    from app.views.main_window import MainWindow

    monkeypatch.setattr(logger_module, "_ensure_utf8_stdout", lambda: None)
    app = QApplication.instance() or QApplication([])
    window = MainWindow(Translator(language="en"), {}, {}, {}, {}, None)
    try:
        messages = []
        errors = []
        window.display_message = lambda *args: messages.append(args)
        window.display_error = lambda *args: errors.append(args)
        monkeypatch.setattr(
            data_controller_module.DataPartitioningResultsDialog,
            "exec_", lambda _dialog: 0,
        )

        frame = _physical_data(n_groups=12, reps=3)
        frame["batch"] = [
            value if row % 2 == 0 else f" {value} "
            for row, value in enumerate(frame["batch"])
        ]
        data_model = window.controller.data_controller.data_model
        data_model.set_data(frame)
        window.data_partitioning_view.set_data_loaded("synthetic.csv", frame)
        partition_view = window.data_partitioning_view
        partition_view.label_column_combo.setCurrentIndex(frame.columns.get_loc("target"))
        partition_view.sample_id_combo.setCurrentIndex(
            partition_view.sample_id_combo.findData(frame.columns.get_loc("sample"))
        )
        partition_view.group_id_combo.setCurrentIndex(
            partition_view.group_id_combo.findData(frame.columns.get_loc("batch"))
        )
        partition_view.group_validation_checkbox.setChecked(True)
        partition_view.method_combo.setCurrentText("Train-Test Split")
        partition_view.partition_data_btn.click()

        assert data_model.has_verified_split(), messages
        assert data_model.group_validation is True
        assert set(data_model.group_id_train).isdisjoint(data_model.group_id_test)
        assert data_model.group_id_train.str.strip().equals(data_model.group_id_train)
        assert data_model.group_id_test.str.strip().equals(data_model.group_id_test)
        window.controller.feature_selection_controller = None
        window._prepare_modeling_data("Quantitative")
        model = window.controller.modeling_controller.modeling_model
        model.analysis_type = "quantitative"
        model.trained_model = DecisionTreeRegressor(random_state=5).fit(
            model.X_train, model.y_train,
        )

        window.optimization_method.setCurrentIndex(
            window.optimization_method.findData("Grid Search")
        )
        window.evaluation_metric.setCurrentIndex(window.evaluation_metric.findData("R2"))
        window.cv_folds.setValue(3)
        assert window.workflow_tabs.widget(2).isAncestorOf(window.optimize_btn)
        window._update_optimizer_button()
        assert window.optimize_btn.isEnabled()

        captured = {}
        real_service = window.controller.hyperopt_controller.hyperopt_service
        real_optimize = real_service.optimize

        def record_and_run(estimator, X, y, **kwargs):
            captured.update(kwargs)
            result = real_optimize(estimator, X, y, **kwargs)
            captured["trace"] = result[1].cv_fit_trace_
            return result

        window.controller.hyperopt_controller.hyperopt_service.optimize = record_and_run
        monkeypatch.setattr(hpo_controller_module, "run_heavy", lambda operation: operation())
        window.optimize_btn.click()

        assert not errors
        assert messages
        assert captured["group_validation"] is True
        assert captured["group_ids"] == model.cv_train_group_ids
        assert captured["outer_test_group_ids"] == model.cv_test_group_ids
        assert set(captured["group_ids"]).isdisjoint(captured["outer_test_group_ids"])
        _assert_trace_disjoint(captured["trace"])
        for fold in captured["trace"]:
            assert set(fold["train_group_ids"]).isdisjoint(captured["outer_test_group_ids"])
            assert set(fold["validation_group_ids"]).isdisjoint(captured["outer_test_group_ids"])
        assert window.optimize_btn.isEnabled()
        window.invalidate_dataset_feature_state()
        assert not window.optimize_btn.isEnabled()
    finally:
        window.close()
