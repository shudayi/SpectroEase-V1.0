"""Actual accepted-code workflow replay, with scientific partition guards."""
import copy
import numpy as np
import pytest
from app.services.verified_algorithm_service import Candidate, VerifiedAlgorithmService, VerifiedAlgorithmError
from app.services.verified_workflow_service import VerifiedWorkflowService


def test_actual_accepted_operators_runtime_fit_and_saved_replay(tmp_path):
    service = VerifiedAlgorithmService(tmp_path / 'registry')
    center = Candidate('stateful_preprocessing', 'center integration',
        "import numpy as np\ndef fit(X, y, params):\n    return {'mean': np.mean(X, axis=0).tolist()}\ndef transform(X, state, params):\n    return X - np.asarray(state['mean'])\n",
        {}, {}, [[1., 2.], [3., 4.]], [[5., 6.], [7., 8.]], [[3., 3.], [5., 5.]])
    model = Candidate('regression', 'offset integration',
        "import numpy as np\ndef fit(X, y, params):\n    return {'offset': float(np.mean(y))}\ndef predict(X, state, params):\n    return X[:, 0] + state['offset']\n",
        {}, {}, [[1., 2.], [3., 4.]], [[5., 6.], [7., 8.]], [7., 9.], train_y=[1., 3.])
    ids = [service.accept(service.verify(c), c.python_source, user_confirmed=True) for c in (center, model)]
    workflow = VerifiedWorkflowService(service)
    result = workflow.run({'preprocessing': ids[0], 'model': ids[1]},
                          [[10., 20.], [30., 40.]], [2., 4.], [[40., 50.], [50., 60.]], [23., 33.],
                          ['train-a', 'train-b'], ['test-a', 'test-b'], axis=[950, 955], test_axis=[950, 955])
    assert result['predictions'] == [23., 33.]
    assert result['metrics']['RMSE'] == 0
    assert result['stages'][0]['state']['state']['mean'] == [20., 30.]
    assert result['stages'][1]['state']['state']['offset'] == 3.
    path = tmp_path / 'workflow.json'
    workflow.save(result, path)
    fresh = VerifiedWorkflowService(VerifiedAlgorithmService(tmp_path / 'registry'))
    restored = fresh.load(path)
    np.testing.assert_array_equal(fresh.predict(restored, [[40., 50.], [50., 60.]], axis=[950, 955]), [23., 33.])
    for changed in ([], result['stages'][::-1], result['stages'] + [result['stages'][-1]]):
        bad = copy.deepcopy(result); bad['stages'] = changed
        with pytest.raises(VerifiedAlgorithmError, match='stages'):
            workflow.predict(bad, [[40., 50.]])


def test_entity_overlap_rejected_before_backend_fit():
    class NeverRun:
        def fit_accepted(self, *args):
            pytest.fail('An overlapping group must not be fitted')
    workflow = VerifiedWorkflowService(NeverRun())
    with pytest.raises(VerifiedAlgorithmError, match='entity groups overlap'):
        workflow.cross_validate({'model': 'x'}, [[1.], [2.], [3.], [4.]], [0., 1., 2., 3.],
                                [([0, 2], [1, 3])], groups=['a', 'a', 'b', 'b'])

@pytest.mark.parametrize('train,target,probe,truth', [
    ([[float('nan')]], [1.], [[2.]], [2.]),
    ([[1.]], [float('inf')], [[2.]], [2.]),
    ([[1.]], [1.], [[2.]], [[2.]]),
    ([], [], [[2.]], [2.]),
])
def test_invalid_workflow_inputs_rejected_before_fit(train, target, probe, truth):
    class Backend:
        def reload(self, identifier):
            from types import SimpleNamespace
            return SimpleNamespace(kind='regression')
        def fit_accepted(self, *args):
            pytest.fail('Invalid inputs must be rejected before fit')
    with pytest.raises(VerifiedAlgorithmError):
        VerifiedWorkflowService(Backend()).run({'model': 'model'}, train, target, probe, truth)
