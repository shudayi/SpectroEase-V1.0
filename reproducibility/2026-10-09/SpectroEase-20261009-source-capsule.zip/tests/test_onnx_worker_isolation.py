"""Native export failures cannot terminate the calling GUI process."""
import subprocess
from types import SimpleNamespace

from app.services.onnx_service import ONNXService


def test_worker_native_crash_is_reported_and_temporary_payload_removed(tmp_path, monkeypatch):
    observed = {}
    def crash(command, **kwargs):
        observed['payload'] = command[-2]
        observed['env'] = kwargs['env']
        return SimpleNamespace(returncode=3221225477, communicate=lambda **kw: ('','native access violation'), poll=lambda:3221225477)
    monkeypatch.setenv('MINIMAX_API_KEY', 'test-only-placeholder')
    monkeypatch.setattr(subprocess, 'Popen', crash)
    service = ONNXService(str(tmp_path))
    assert service.export_model_to_onnx(object(), [[1.]]) is None
    assert '3221225477' in service.last_error
    assert 'MINIMAX_API_KEY' not in observed['env']
    from pathlib import Path
    assert not Path(observed['payload']).exists()


def test_worker_timeout_is_explicit(tmp_path, monkeypatch):
    import app.services.onnx_service as module
    clock=iter([0,121])
    monkeypatch.setattr(module.time,'monotonic',lambda:next(clock))
    killed=[]
    monkeypatch.setattr(subprocess, 'Popen', lambda *a,**k:SimpleNamespace(poll=lambda:None,kill=lambda:killed.append(True),communicate=lambda:('','')))
    service = ONNXService(str(tmp_path))
    assert service.export_model_to_onnx(object(), [[1.]]) is None
    assert '120' in service.last_error
    assert killed


def test_real_child_is_killed_on_cancellation(tmp_path, monkeypatch):
    import threading
    import sys
    import time
    original=subprocess.Popen
    processes=[]
    def sleeper(command,**kwargs):
        process=original([sys.executable,'-c','import time;time.sleep(30)'],**kwargs)
        processes.append(process)
        return process
    monkeypatch.setattr(subprocess,'Popen',sleeper)
    token=threading.Event()
    timer=threading.Timer(.25,token.set);timer.start()
    service=ONNXService(str(tmp_path))
    start=time.monotonic()
    assert service.export_analyzer_to_onnx(object(),[[1.]],cancel_event=token) is None
    timer.join()
    assert time.monotonic()-start<3
    assert processes[0].poll() is not None
    assert 'cancelled' in service.last_error
