# -*- coding: utf-8 -*-
"""
Tests for UI scaling helpers.

These tests do not require a QApplication; they verify the math and helpers
that do not depend on Qt runtime state.
"""

import unittest

from app.ui import design_tokens as tok
from app.utils.ui_scaling import (
    scaled_px,
    scaled_pt,
    scaled_qsize,
    ui_scaling_manager,
)


class UIScalingMathTests(unittest.TestCase):
    """Sanity checks for scaling math."""

    def test_scaled_px_positive(self):
        value = scaled_px(22)
        self.assertIsInstance(value, int)
        self.assertGreater(value, 0)

    def test_scaled_pt_clamped(self):
        pt = scaled_pt(tok.BASE_FONT_PT)
        self.assertIsInstance(pt, int)
        self.assertGreaterEqual(pt, 8)
        self.assertLessEqual(pt, 14)

    def test_scaled_qsize(self):
        size = scaled_qsize(20, 20)
        self.assertEqual(size.width(), scaled_px(20))
        self.assertEqual(size.height(), scaled_px(20))

    def test_design_tokens_present(self):
        self.assertEqual(tok.BASE_WIDTH, 1920)
        self.assertEqual(tok.BASE_HEIGHT, 1080)
        self.assertEqual(tok.BASE_DPI, 96)
        self.assertIn("Microsoft YaHei UI", tok.FONT_FAMILY_UI)

    def test_scale_factor_in_valid_range(self):
        sf = ui_scaling_manager.scale_factor
        self.assertGreaterEqual(sf, 0.7)
        self.assertLessEqual(sf, 2.0)

    def test_logical_dimensions_and_dpi_do_not_rescale_widget_geometry(self):
        original_info = dict(ui_scaling_manager.screen_info)
        try:
            for width, height, dpi, dpr in [
                (1366, 768, 96, 1.0),
                (1280, 720, 144, 1.5),
                (1920, 1080, 192, 2.0),
                (3840, 2160, 96, 1.0),
            ]:
                ui_scaling_manager.screen_info = {
                    "width": width,
                    "height": height,
                    "dpi": dpi,
                    "device_pixel_ratio": dpr,
                }
                ui_scaling_manager.scale_factor = ui_scaling_manager._calculate_scale_factor()
                ui_scaling_manager.font_scale = ui_scaling_manager._calculate_font_scale()
                self.assertEqual(ui_scaling_manager.scale_factor, 1.0)
                self.assertEqual(ui_scaling_manager.font_scale, 1.0)
                self.assertEqual(scaled_px(120), 120)
                self.assertEqual(scaled_pt(10), 10)
        finally:
            ui_scaling_manager.screen_info = original_info
            ui_scaling_manager.scale_factor = ui_scaling_manager._calculate_scale_factor()
            ui_scaling_manager.font_scale = ui_scaling_manager._calculate_font_scale()

    def test_qfont_helper_keeps_point_size_for_qt_to_convert(self):
        font = ui_scaling_manager.get_scaled_font("Segoe UI", 10)
        self.assertEqual(font.pointSize(), 10)


if __name__ == "__main__":
    unittest.main()
