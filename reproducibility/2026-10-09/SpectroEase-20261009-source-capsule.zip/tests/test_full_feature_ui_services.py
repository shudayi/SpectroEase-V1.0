"""Mounted UI and service regressions; Qt offscreen, temporary state only."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from pathlib import Path
from types import SimpleNamespace
import json
import numpy as np
import pandas as pd
import pytest
from PyQt5.QtCore import QRect, QPoint, Qt
from PyQt5.QtWidgets import QApplication,QMessageBox,QFileDialog,QPushButton,QLabel,QDialog

@pytest.fixture(scope='session', autouse=True)
def qapp():
    app=QApplication.instance() or QApplication([])
    yield app

@pytest.fixture
def window(tmp_path,monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv('SPECTROEASE_PLUGIN_DIR',str(tmp_path/'plugins'))
    from app.utils import logger
    monkeypatch.setattr(logger,'_ensure_utf8_stdout',lambda:None)
    from app.utils.translator import Translator,translator
    translator.set_language('en')
    from app.services.llm_service import LLMService
    from app.views.main_window import MainWindow
    app=QApplication.instance() or QApplication([])
    monkeypatch.setattr(QMessageBox,'information',lambda *a,**k:QMessageBox.Ok)
    monkeypatch.setattr(QMessageBox,'warning',lambda *a,**k:QMessageBox.Ok)
    monkeypatch.setattr(QMessageBox,'question',lambda *a,**k:QMessageBox.Yes)
    errors=[]
    monkeypatch.setattr(QMessageBox,'critical',lambda *a,**k:errors.append(str(a[-1])) or QMessageBox.Ok)
    win=MainWindow(Translator('en'),{},{},{},{},LLMService(''))
    frame=pd.DataFrame({'target':np.linspace(1,10,10),'950':np.linspace(.1,1.,10),'955':np.linspace(.5,2.,10),'960':np.linspace(1.,3.,10)})
    model=win.controller.data_controller.data_model
    model.set_data(frame)
    win.update_data_view(frame)
    yield win,frame,errors
    if hasattr(win,'progress_dialog'):
        win.progress_dialog.update_progress(100)
        win.progress_dialog.close()
    win.close();win.deleteLater();app.processEvents()
    translator.set_language('en')

@pytest.mark.parametrize('fmt',['csv','txt','xlsx'])
def test_toolbar_exports_current_processed_spectra(window,tmp_path,monkeypatch,fmt):
    win,frame,errors=window
    win.processed_spectra=frame.iloc[:,1:].to_numpy()*2
    target=tmp_path/f'current.{fmt}'
    monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *a,**k:(str(target),''))
    win.save_data()
    assert not errors
    from plugins.preprocessing.spectrum_converter import SpectrumConverter
    axis,spectra=SpectrumConverter.read_spectrum_file(str(target),fmt)
    np.testing.assert_allclose(axis,[950,955,960]);np.testing.assert_allclose(spectra,win.processed_spectra)

@pytest.mark.parametrize('fmt',['pdf','svg','png','tif'])
def test_toolbar_plot_exports(window,tmp_path,monkeypatch,fmt):
    win,frame,errors=window
    target=tmp_path/f'current.{fmt}'
    monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *a,**k:(str(target),''))
    win.save_plot()
    assert not errors
    assert target.stat().st_size>100
    assert target.with_suffix(target.suffix+'.json').is_file()

def test_undo_restores_data_model_and_invalidates_predictions(window):
    win,frame,errors=window
    model=win.controller.data_controller.data_model
    keys=model.get_row_keys()
    snapshot=win._capture_preprocessing_snapshot()
    old_revision=model.get_state_revision()
    model.preprocessed_data=frame.iloc[:,1:]*5
    model.X_processed=model.preprocessed_data.copy()
    win.processed_spectra=model.preprocessed_data.to_numpy()
    win.feature_data_options['selected_features']=np.ones((10,1))
    mm=win.controller.modeling_controller.modeling_model
    mm.evaluation_results={'r2':.99};mm.trained_model=object()
    win.operation_history.append({'time':'test','operation':'preprocess','data':win.current_spectra.copy(),'snapshot':snapshot})
    win.undo_last_operation()
    assert not errors
    assert model.preprocessed_data is None
    assert model.X_processed is None
    assert model.get_row_keys().equals(keys)
    assert model.get_state_revision()>old_revision
    pd.testing.assert_frame_equal(model.data,frame)
    np.testing.assert_allclose(win.current_spectra,frame.iloc[:,1:])
    assert mm.trained_model is None and mm.evaluation_results=={}
    assert win.feature_data_options['selected_features'] is None
    assert not win.operation_history

def test_legacy_undo_does_not_mutate_state(window):
    win,frame,errors=window
    win.operation_history.append({'time':'test','operation':'legacy','data':np.zeros((10,3))})
    original=win.current_spectra.copy()
    win.undo_last_operation()
    np.testing.assert_allclose(win.current_spectra,original)
    assert len(win.operation_history)==1

def test_all_mounted_preprocessing_options_reach_worker(window,monkeypatch):
    win,frame,errors=window
    for checkbox in [win.smooth_check,win.outlier_check,win.denoise_check,win.alignment_check]:checkbox.setChecked(True)
    win.smooth_method.setCurrentIndex(win.smooth_method.findData('Median'))
    win.outlier_threshold.setValue(2.4);win.denoise_strength.setValue(.7)
    win.alignment_method.setCurrentIndex(win.alignment_method.findData('COW'))
    recorded={}
    def start(methods,params,**kwargs):
        recorded.update(methods=methods,params=params)
        return SimpleNamespace(cancel=lambda:None)
    monkeypatch.setattr(win.controller.preprocessing_controller,'start_preprocessing_worker',start)
    win.apply_preprocessing()
    assert not errors
    assert set(recorded['methods'])=={'smoothing','outlier_detection','denoising','alignment'}
    assert recorded['params']['smoothing']['method']=='Median'
    assert recorded['params']['outlier_detection']['threshold']==2.4
    assert recorded['params']['denoising']['strength']==.7
    assert recorded['params']['alignment']['method']=='COW'
    assert win._pending_preprocessing_snapshot['data_model']['preprocessed_data'] is None

def test_unimplemented_calibration_is_disabled_and_rejected(window,monkeypatch):
    win,frame,errors=window
    assert not win.wavelength_calib_check.isEnabled()
    assert not win.intensity_calib_check.isEnabled()
    assert not win.reference_method.isEnabled()
    called=[]
    monkeypatch.setattr(win.controller.preprocessing_controller,'start_preprocessing_worker',lambda *a,**k:called.append(True))
    win.wavelength_calib_check.setChecked(True)
    win.apply_preprocessing()
    assert not called
    assert any('not implemented' in e for e in errors)

def test_settings_language_retranslates_existing_window(window):
    win,frame,errors=window
    from app.utils.translator import translator
    old=win.workflow_tabs.tabText(0)
    win._apply_language('zh')
    assert translator.language=='zh'
    assert win.workflow_tabs.tabText(0)!=old
    assert win.workflow_tabs.tabText(0)==translator.translate('main_window.data_tab_tab')
    win._apply_language('en')
    assert win.workflow_tabs.tabText(0)==old
    np.testing.assert_allclose(win.current_spectra,frame.iloc[:,1:])

@pytest.mark.parametrize('width',[1280,1528,1920])
def test_compact_data_form_controls_not_clipped(window,width):
    win,frame,errors=window
    from app.utils.ui_scaling import ui_scaling_manager as scaling
    app=QApplication.instance();win.show();app.processEvents()
    previous=dict(scaling.screen_info)
    try:
        scaling.screen_info['available_geometry']=QRect(0,0,width,1000)
        win.resize(width,900);win._update_responsive_layout(force=True);app.processEvents()
        view=win.data_partitioning_view
        assert win.workflow_scroll_area.horizontalScrollBar().maximum()==0
        for widget in view.findChildren(QPushButton)+view.findChildren(QLabel):
            if widget.isVisible():
                x=widget.mapTo(view,QPoint(0,0)).x()
                assert x>=0,(widget.text(),x)
                assert x+widget.width()<=view.width(),(widget.text(),x,widget.width(),view.width())
        assert view.column_mapping_btn.width()>=view.column_mapping_btn.minimumSizeHint().width()
    finally:scaling.screen_info=previous

def test_missing_optional_algorithm_disabled(window,monkeypatch):
    win,frame,errors=window
    monkeypatch.setattr('importlib.util.find_spec',lambda *_:None)
    win.update_analysis_methods('Quantitative')
    for key in ['XGBoost','LightGBM']:
        item=win.analysis_method.model().item(win.analysis_method.findData(key))
        assert not item.isEnabled()
        assert 'not installed' in item.toolTip()

def test_llm_zero_temperature_and_custom_provider_persist(tmp_path,monkeypatch):
    from config.llm_config import LLMConfig
    monkeypatch.setattr(LLMConfig,'CONFIG_PATH',str(tmp_path/'llm.json'))
    for key in ['API_KEY','PROVIDER','MODEL_NAME','API_BASE_URL','MAX_TOKENS','TEMPERATURE','REQUEST_TIMEOUT']:
        monkeypatch.setattr(LLMConfig,key,getattr(LLMConfig,key))
    LLMConfig.save_config('dummy-audit-key',temperature=0.,model_name='custom-model',api_base_url='http://localhost:11434/v1',provider='Ollama')
    LLMConfig.load_config()
    assert LLMConfig.TEMPERATURE==0.
    assert LLMConfig.MODEL_NAME=='custom-model'
    assert LLMConfig.PROVIDER=='Ollama'
    assert json.loads((tmp_path/'llm.json').read_text())['temperature']==0.

def test_llm_dialog_custom_model_provider_defaults(window,monkeypatch,tmp_path):
    win,frame,errors=window
    from config.llm_config import LLMConfig
    from app.views.llm_config_dialog import LLMConfigDialog
    for key in ['CONFIG_PATH','API_KEY','PROVIDER','MODEL_NAME','API_BASE_URL','MAX_TOKENS','TEMPERATURE','REQUEST_TIMEOUT']:
        monkeypatch.setattr(LLMConfig,key,getattr(LLMConfig,key))
    LLMConfig.CONFIG_PATH=str(tmp_path/'llm.json');LLMConfig.MODEL_NAME='custom-model'
    LLMConfig.PROVIDER='Custom';LLMConfig.API_BASE_URL='https://custom.invalid/v1'
    dialog=LLMConfigDialog(win)
    assert dialog.model_combo.isEditable()
    assert dialog.model_combo.currentText()=='custom-model'
    assert dialog.provider_combo.findText('Anthropic')<0
    dialog.provider_combo.setCurrentText('MiniMax')
    assert dialog.url_input.text()=='https://api.minimax.io/anthropic'
    assert dialog.model_combo.currentText()=='MiniMax-M3'
    dialog.provider_combo.setCurrentText('Ollama')
    assert dialog.url_input.text()=='http://localhost:11434/v1'
    dialog.temp_input.setText('0.0');dialog.save_config()
    assert dialog.result()==QDialog.Accepted and LLMConfig.PROVIDER=='Ollama'
    assert LLMConfig.TEMPERATURE==0.
    dialog.close()

def test_minimax_token_plan_uses_official_anthropic_compatible_payload(monkeypatch):
    from app.services.llm_service import LLMService
    captured={}
    class Response:
        status_code=200
        text='mock response'
        def json(self):
            return {'content':[{'type':'thinking','thinking':'private reasoning'},
                               {'type':'text','text':'converted'}],
                    'stop_reason':'end_turn'}
    class Session:
        def post(self,url,**kwargs):
            captured.update(url=url,**kwargs)
            return Response()
        def close(self):
            pass
    monkeypatch.setattr('app.services.llm_service.requests.Session',Session)
    service=LLMService('test-secret',base_url='https://api.minimax.io/anthropic',
                       model_name='MiniMax-M3',max_tokens=321)
    assert service.chat('Convert a tiny stateless transform.')=='converted'
    assert captured['url']=='https://api.minimax.io/anthropic/v1/messages'
    assert captured['json']['model']=='MiniMax-M3'
    assert captured['json']['max_tokens']==321
    assert captured['json']['system']
    assert captured['headers']['x-api-key']=='test-secret'
    assert captured['headers']['anthropic-version']=='2023-06-01'
    assert captured['json']['messages'][0]['role']=='user'

def test_minimax_empty_text_response_is_rejected():
    from app.services.llm_service import _extract_message_content
    from app.utils.exceptions import LLMServiceError
    with pytest.raises(LLMServiceError,match='no text content'):
        _extract_message_content({'content':[{'type':'thinking','thinking':'no text'}]})

def test_minimax_401_is_not_retried_or_logged_with_response_body(monkeypatch,caplog):
    from app.services.llm_service import LLMService
    from app.utils.exceptions import LLMServiceError
    calls=[]
    class Response:
        status_code=401
        text='provider error body includes test-secret-marker'
    class Session:
        def post(self,url,**kwargs):
            calls.append(url)
            return Response()
        def close(self): pass
    monkeypatch.setattr('app.services.llm_service.requests.Session',Session)
    service=LLMService('test-secret-marker',base_url='https://api.minimax.io/anthropic',
                       model_name='MiniMax-M3')
    with pytest.raises(LLMServiceError,match='Check the API key'):
        service.chat('small fixture request')
    assert len(calls)==1
    assert 'test-secret-marker' not in caplog.text

def test_dpapi_credential_round_trip_and_legacy_plaintext_read(monkeypatch):
    from app.utils import credential_store
    monkeypatch.setattr(credential_store.sys,'platform','win32')
    monkeypatch.setattr(credential_store,'_dpapi_protect',lambda value:b'mock-encrypted:'+value)
    monkeypatch.setattr(credential_store,'_dpapi_unprotect',lambda value:value.removeprefix(b'mock-encrypted:'))
    protected=credential_store.protect('dummy-credential')
    assert protected.startswith('dpapi:')
    assert credential_store.unprotect(protected)=='dummy-credential'
    assert credential_store.unprotect('legacy-dummy')=='legacy-dummy'

def test_api_key_is_not_saved_when_dpapi_encryption_fails(tmp_path,monkeypatch):
    from config.llm_config import LLMConfig
    from app.utils import credential_store
    target=tmp_path/'llm.json'
    monkeypatch.setattr(LLMConfig,'CONFIG_PATH',str(target))
    monkeypatch.setattr(credential_store.sys,'platform','win32')
    monkeypatch.setattr(credential_store,'_dpapi_protect',
                        lambda _value: (_ for _ in ()).throw(OSError('simulated DPAPI failure')))
    with pytest.raises(RuntimeError,match='key was not saved'):
        LLMConfig.save_config('must-not-hit-disk',provider='MiniMax')
    assert not target.exists()

def test_legacy_import_browse_no_translation_shadow(window,monkeypatch,tmp_path):
    from app.views.data_import_dialog import DataImportDialog
    target=tmp_path/'example.csv';target.write_text('target,950\n1,2\n')
    monkeypatch.setattr(QFileDialog,'getOpenFileName',lambda *a,**k:(str(target),''))
    dialog=DataImportDialog()
    dialog.browse_file()
    assert dialog.file_path==str(target)
    dialog.close()


def test_applied_operation_order_and_parameters_are_in_report(window):
    win,frame,errors=window
    controller=win.controller.preprocessing_controller
    controller.record_applied_methods({'success':True,'applied_method_steps':[
        {'method':'Median Filter','source_key':'smoothing','params':{'method':'Median','window_length':3}},
        {'method':'Area Normalization','source_key':'normalization','params':{'method':'Area'}},
        {'method':'Third Derivative','source_key':'derivative','params':{'order':3}}]})
    params=win._collect_preprocessing_params()
    assert list(params)==['Median Filter','Area Normalization','Third Derivative']
    from app.services.evaluation_service import EvaluationService
    info=EvaluationService().generate_reproducibility_info(preprocessing_params=params,global_random_state=0)
    assert info['processing_pipeline']['order']==list(params)
    assert info['random_state']==0
    assert info['processing_pipeline']['steps'][0]['parameters']['window_length']==3


def test_report_worker_preserves_reproducibility_sidecar(tmp_path):
    from app.views.main_window import _ReportWorker
    from unittest.mock import patch
    from plugins.reporting.spectrum_report_generator import SpectrumReportGenerator
    generator=SpectrumReportGenerator(str(tmp_path))
    worker=_ReportWorker({'n_samples':10,'n_features':3},{},{},{'rmse':.5},'audit_report',reproducibility_info={'random_state':0})
    with patch('app.views.main_window.SpectrumReportGenerator',return_value=generator):
        pdf=Path(worker.run_task())
    sidecar=pdf.with_name(pdf.stem+'_reproducibility.json')
    assert json.loads(sidecar.read_text())['random_state']==0


def test_dataset_change_clears_undo_and_stale_reports(window):
    win,frame,errors=window
    win.operation_history.append({'time':'old','operation':'old','snapshot':win._capture_preprocessing_snapshot()})
    mm=win.controller.modeling_controller.modeling_model
    mm.evaluation_results={'r2':.8};mm.reproducibility_info={'old':True}
    win.invalidate_dataset_feature_state()
    assert win.operation_history==[]
    assert mm.evaluation_results=={}
    assert mm.reproducibility_info is None


def test_language_keeps_user_column_names_and_plugin_names(window):
    win,frame,errors=window
    view=win.data_partitioning_view
    view.label_column_combo.clear();view.label_column_combo.addItem('Data')
    win.onboarded_plugin_combo.addItem('Data','user-plugin')
    before=win.onboarded_plugin_combo.itemText(win.onboarded_plugin_combo.count()-1)
    win._apply_language('zh')
    assert view.label_column_combo.itemText(0)=='Data'
    assert win.onboarded_plugin_combo.itemText(win.onboarded_plugin_combo.count()-1)==before


def test_unsupported_and_approximate_preprocessing_are_labelled(window):
    win,frame,errors=window
    assert not win.scatter_method.model().item(win.scatter_method.findData('OSC')).isEnabled()
    assert not win.alignment_method.model().item(win.alignment_method.findData('PAFFT')).isEnabled()
    for key in ['COW','ICS']:
        assert 'approximate' in win.alignment_method.itemText(win.alignment_method.findData(key))
    assert win.denoise_strength.maximum()==1.0


def test_successful_commit_invalidates_previous_predictions_and_revision(window,monkeypatch):
    win,frame,errors=window
    model=win.controller.data_controller.data_model
    revision=model.get_state_revision()
    mm=win.controller.modeling_controller.modeling_model
    mm.trained_model=object();mm.evaluation_results={'r2':.9};mm.reproducibility_info={'old':True}
    model.X_train_selected=frame.iloc[:8,1:2].copy()
    win.feature_data_options['selected_features']=np.ones((10,1))
    snapshot=win._capture_preprocessing_snapshot();win._pending_preprocessing_snapshot=snapshot
    monkeypatch.setattr(win,'_finish_preprocessing',lambda *args:None)
    win._on_preprocessing_result(['smoothing'],{'success':True,'state_revision':revision,'is_partitioned':False,
        'X_processed':frame.iloc[:,1:]*2,'preprocessed_data':frame.iloc[:,1:]*2,
        'methods':['smoothing'],'params_dict':{'smoothing':{'method':'Median'}},
        'applied_method_steps':[{'method':'Median Filter','source_key':'smoothing','params':{'method':'Median'}}]})
    assert not errors
    assert mm.trained_model is None and mm.evaluation_results=={} and mm.reproducibility_info is None
    assert model.X_train_selected is None
    assert win.feature_data_options['selected_features'] is None
    assert model.get_state_revision()>revision
    assert win._pending_preprocessing_snapshot is snapshot
    pd.testing.assert_frame_equal(model.preprocessed_data,frame.iloc[:,1:]*2)


def test_duplicate_canonical_steps_survive_report_and_undo_snapshot(window):
    win,frame,errors=window
    controller=win.controller.preprocessing_controller
    controller.record_applied_methods({'success':True,'applied_method_steps':[
        {'method':'Min-Max Scale','source_key':'standardization','params':{'method':'Min-Max'}},
        {'method':'Min-Max Scale','source_key':'normalization','params':{'method':'Min-Max'}}]})
    params=win._collect_preprocessing_params()
    assert len(params)==2
    assert [v['canonical_method'] for v in params.values()]==['Min-Max Scale','Min-Max Scale']
    assert [v['source_key'] for v in params.values()]==['standardization','normalization']
    from app.services.evaluation_service import EvaluationService
    assert len(EvaluationService().generate_reproducibility_info(preprocessing_params=params)['processing_pipeline']['steps'])==2
    assert len(win._capture_preprocessing_snapshot()['applied_steps'])==2


def test_connection_worker_uses_unsaved_draft_fields(window,monkeypatch):
    win,frame,errors=window
    from app.views.llm_config_dialog import LLMConfigDialog,_LLMTestWorker
    from config.llm_config import LLMConfig
    from unittest.mock import patch
    original_model=LLMConfig.MODEL_NAME
    dialog=LLMConfigDialog(win)
    dialog.url_input.setText('http://mock.invalid/draft/v1')
    dialog.model_combo.setCurrentText('draft-model')
    dialog.temp_input.setText('0.0');dialog.max_tokens_input.setText('321');dialog.timeout_input.setText('7')
    monkeypatch.setattr(_LLMTestWorker,'start',lambda self:None)
    dialog._on_test_clicked()
    worker=dialog._test_worker
    assert worker._draft_config=={'base_url':'http://mock.invalid/draft/v1','model_name':'draft-model','temperature':0.,'max_tokens':321,'request_timeout':7}
    captured={}
    class MockResponse:
        status_code=200;text='mock'
        def json(self):return {'choices':[{'message':{'content':'ok'}}]}
    class MockSession:
        def post(self,url,**kwargs):captured.update(url=url,**kwargs);return MockResponse()
        def close(self):pass
    with patch('app.services.llm_service.requests.Session',MockSession):
        assert worker.run_task()=='ok'
    assert captured['url']=='http://mock.invalid/draft/v1/chat/completions'
    assert captured['json']['model']=='draft-model'
    assert captured['json']['temperature']==0.
    assert captured['json']['max_tokens']==321
    assert captured['timeout']==(5,7)
    assert LLMConfig.MODEL_NAME==original_model
    dialog.close()


@pytest.mark.parametrize('analysis,expected',[('Quantitative',{'mlr','ridge','lasso','elasticnet','dt'}),('Qualitative',{'logistic'})])
def test_paper_algorithm_menu_inventory(window,analysis,expected):
    win,frame,errors=window
    win.update_analysis_methods(analysis)
    keys={win.analysis_method.itemData(i) for i in range(win.analysis_method.count())}
    assert expected.issubset(keys)
    assert all(win._model_parameter_schema(key) for key in expected)


@pytest.mark.parametrize('method',['mlr','ridge','lasso','elasticnet','dt','logistic'])
def test_mounted_model_parameter_dialog_saves_values(window,monkeypatch,method):
    win,frame,errors=window
    win.update_analysis_methods('Qualitative' if method=='logistic' else 'Quantitative')
    win.analysis_method.setCurrentIndex(win.analysis_method.findData(method))
    def accept(dialog):
        for widget in dialog.findChildren(type(win.cv_folds)):
            if widget.objectName().startswith('modelParameter_'):
                widget.setValue(widget.minimum()+1)
        return QDialog.Accepted
    monkeypatch.setattr(QDialog,'exec_',accept)
    dialog=win.open_model_parameters()
    assert dialog is not None
    values=win.model_parameter_values[method]
    assert set(values)==set(win._model_parameter_schema(method))
    assert not errors
    dialog.close()


def test_closing_connection_dialog_retains_running_cancelled_worker(window,monkeypatch):
    from app.views.llm_config_dialog import LLMConfigDialog,_LLMTestWorker,_ACTIVE_TEST_WORKERS
    from PyQt5.QtCore import QElapsedTimer
    import time
    win,frame,errors=window
    def slow(self):
        time.sleep(.9)
        return 'mock completed'
    monkeypatch.setattr(_LLMTestWorker,'run_task',slow)
    dialog=LLMConfigDialog(win)
    dialog.url_input.setText('http://mock.invalid/v1');dialog.model_combo.setCurrentText('mock-model')
    dialog._on_test_clicked()
    worker=dialog._test_worker
    dialog.close()
    assert worker.is_cancelled()
    if worker.isRunning():assert worker in _ACTIVE_TEST_WORKERS
    assert worker.wait(3000)
    QApplication.instance().processEvents()
    assert worker not in _ACTIVE_TEST_WORKERS
    assert not errors


@pytest.mark.parametrize('width,height',[(1024,720),(720,480),(1280,720)])
def test_short_screen_preserves_canvas_and_scroll_access_to_results(window,width,height):
    win,frame,errors=window
    from app.utils.ui_scaling import ui_scaling_manager as scaling
    from PyQt5.QtCore import Qt
    app=QApplication.instance();win.show();app.processEvents()
    previous=dict(scaling.screen_info)
    try:
        scaling.screen_info['available_geometry']=QRect(0,0,width,height)
        win.setMinimumSize(min(720,width),min(480,height))
        win.resize(width,height);win._update_responsive_layout(force=True)
        app.processEvents()
        canvas=win.visualization_widget.canvas
        assert canvas.height()>=220,(width,height,canvas.height())
        assert win.visualization_widget.height()>canvas.height()
        assert win.results_scroll_area.horizontalScrollBar().maximum()==0,(width,win.results_scroll_area.widget().minimumSizeHint().width(),win.results_scroll_area.viewport().width())
        if width<1440:
            assert win._main_splitter.orientation()==Qt.Vertical
            assert 160<=win._main_splitter.sizes()[0]<=360
            assert not win._main_splitter.childrenCollapsible()
            assert win.visualization_widget.minimumHeight()==460
            assert win.visualization_widget.height()>=460
            assert canvas.height()>=(240 if height<600 else 280)
        workflow_bar=win.workflow_scroll_area.verticalScrollBar()
        assert workflow_bar.maximum()>0,(width,height,win.workflow_scroll_area.viewport().height(),win.workflow_tabs.height())
        workflow_bar.setValue(workflow_bar.maximum())
        app.processEvents()
        assert workflow_bar.value()==workflow_bar.maximum()
        area=win.results_scroll_area
        scrollbar=area.verticalScrollBar()
        assert scrollbar.maximum()>0,(width,height,area.height(),area.widget().height())
        area.ensureWidgetVisible(win.result_table,0,0);app.processEvents()
        if width<1440:
            assert scrollbar.value()>0
        table_y=win.result_table.mapTo(area.viewport(),QPoint(0,0)).y()
        assert table_y<area.viewport().height()
        assert table_y+win.result_table.height()>0
        area.ensureWidgetVisible(canvas,0,0);app.processEvents()
        assert canvas.height()>=220
    finally:scaling.screen_info=previous


def test_partition_inputs_fit_styled_minimum_and_do_not_touch(window):
    win,frame,errors=window
    view=win.data_partitioning_view
    win.show();QApplication.instance().processEvents()
    view.init_param_widgets('Train-Test Split')
    QApplication.instance().processEvents()
    controls=[view.test_size_spin,view.random_state_spin,view.min_samples_spin]
    for control in controls:
        assert control.height()>=control.minimumSizeHint().height(), (control.height(),control.minimumSizeHint().height())
        assert control.maximumHeight()>control.minimumHeight()
    for first,second in zip(controls,controls[1:]):
        assert second.y()>first.y()+first.height()+3,(first.geometry(),second.geometry())


def test_loaded_status_and_spectral_config_count_exclude_metadata(window,monkeypatch):
    win,frame,errors=window
    controller=win.controller.data_controller
    model=controller.data_model
    with_ids=frame.copy();with_ids['sample_id']=[f's{i}' for i in range(len(frame))]
    model.set_data(with_ids);model.sample_id_column_index=4
    win.update_data_view(with_ids)
    assert '10 samples, 3 spectral features' in win.data_status.text()
    assert win.current_spectra.shape==(10,3)
    messages=[]
    monkeypatch.setattr(QMessageBox,'information',lambda *a,**k:messages.append(a[-1]) or QMessageBox.Ok)
    monkeypatch.setattr(controller,'apply_spectral_configuration',lambda *a:None)
    controller.apply_preselected_spectral_config(with_ids,'nir','Near Infrared')
    assert 'Features: 3' in messages[-1]
    model.clear_data();win.update_data_view(None)
    assert win.data_status.text()=='No data loaded'
    assert not errors


def test_new_inventory_retains_established_analysis_defaults(window):
    win,frame,errors=window
    win.update_analysis_methods('Quantitative');assert win.analysis_method.currentData()=='PLSR'
    win.update_analysis_methods('Qualitative');assert win.analysis_method.currentData()=='SVM'


@pytest.mark.parametrize('fmt',['csv','xlsx'])
def test_mounted_results_export_uses_committed_metrics_and_model_identity(window,tmp_path,monkeypatch,fmt):
    win,frame,errors=window
    model=win.controller.modeling_controller.modeling_model
    model.method='ridge';model.analysis_type='quantitative'
    model.evaluation_results={'task_type':'regression','rmse':1.25,'r2':0.0,'test_rmse':1.5,
                              'cv_scores':[0.0,.4],'sample_ids':[123,456]}
    # Changing the current menu cannot rename the committed result.
    win.update_analysis_methods('Qualitative')
    target=tmp_path/f'results.{fmt}'
    monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *a,**k:(str(target),''))
    assert win.workflow_tabs.indexOf(win.export_results_btn.parentWidget())>=0
    win.export_results_btn.click()
    actual=pd.read_csv(target) if fmt=='csv' else pd.read_excel(target)
    assert list(actual.columns)==['algorithm','task','metric','value','source']
    assert set(actual.algorithm)=={'ridge'} and set(actual.task)=={'regression'}
    assert set(actual.metric)=={'rmse','r2','test_rmse','cv_scores[0]','cv_scores[1]'}
    assert actual.loc[actual.metric=='r2','value'].iloc[0]==0
    assert actual.loc[actual.metric=='test_rmse','source'].iloc[0]=='test'
    assert actual.loc[actual.metric=='cv_scores[0]','source'].iloc[0]=='cross_validation'
    assert not errors


def test_results_export_requires_actual_results(window,tmp_path,monkeypatch):
    win,frame,errors=window
    called=[];monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *a,**k:called.append(True))
    win.export_results_btn.click()
    assert not called and not errors


def test_mounted_diagnostics_caches_exact_scope_and_report_receives_it(window,tmp_path,monkeypatch):
    from sklearn.linear_model import LinearRegression
    from app.services.prediction_contract import FittedSpectrumPredictor
    from app.views.main_window import _ReportWorker
    from plugins.reporting.spectrum_report_generator import SpectrumReportGenerator
    from PyQt5.QtWidgets import QTabWidget
    win,frame,errors=window
    model=win.controller.modeling_controller.modeling_model
    rng=np.random.default_rng(24);X=rng.normal(size=(18,2));y=2+X@np.array([1.4,-.3])+rng.normal(0,.05,18)
    estimator=LinearRegression().fit(X[:12],y[:12])
    model.fitted_predictor=FittedSpectrumPredictor(estimator,'regression',n_features=2)
    model.diagnostic_inputs={'X_train':X[:12],'X_test':X[12:],'y_train':y[:12],'y_test':y[12:],'task_type':'regression'}
    monkeypatch.setattr(QDialog,'exec_',lambda *a:QDialog.Accepted)
    win.diagnostics_btn.click()
    assert not errors
    actual=model.diagnostics
    np.testing.assert_allclose(actual['observed'],y[12:]);np.testing.assert_allclose(actual['predicted'],estimator.predict(X[12:]))
    dialogs=[d for d in win.findChildren(QDialog) if d.windowTitle()=='Model Diagnostics']
    assert dialogs[-1].findChild(QTabWidget).count()>=4
    captured={}
    monkeypatch.setattr(SpectrumReportGenerator,'generate_report',lambda *a,**k:captured.update(k) or 'mock.pdf')
    _ReportWorker({}, {}, {}, {}, 'test',diagnostics=actual).run_task()
    assert captured['diagnostics'] is actual
    win.invalidate_dataset_feature_state()
    assert model.diagnostics is None and model.diagnostic_inputs is None


def test_onnx_button_exports_the_committed_fitted_analyzer(window,monkeypatch):
    win,frame,errors=window
    model=win.controller.modeling_controller.modeling_model
    analyzer=SimpleNamespace(model=SimpleNamespace(),method='fixture-method')
    X_train=frame[['950','960']].copy()
    model.analyzer=analyzer
    model.diagnostic_inputs={'X_train':X_train}
    calls=[]
    monkeypatch.setattr(
        win.onnx_service,
        'export_analyzer_to_onnx',
        lambda actual_analyzer,actual_X,**kwargs: calls.append((actual_analyzer,actual_X,kwargs)) or 'fixture.onnx',
    )
    messages=[]
    monkeypatch.setattr(QMessageBox,'information',lambda *args,**kwargs:messages.append(args[-1]) or QMessageBox.Ok)
    assert win.workflow_tabs.indexOf(win.export_onnx_btn.parentWidget())>=0
    win.export_onnx_btn.click()
    assert len(calls)==1
    assert calls[0][0] is analyzer
    pd.testing.assert_frame_equal(calls[0][1],X_train)
    assert calls[0][2]['model_name']=='SimpleNamespace'
    assert calls[0][2]['method']=='fixture-method'
    assert not calls[0][2]['cancel_event'].is_set()
    assert 'fixture.onnx' in messages[-1]
    assert not errors


@pytest.mark.parametrize('action', ['cancel', 'close_window'])
def test_onnx_export_keeps_ui_timer_responsive_and_cancels(window, monkeypatch, action):
    from PyQt5.QtCore import QTimer
    from app.views.progress_dialog import ProgressDialog
    import time
    win,frame,errors=window
    model=win.controller.modeling_controller.modeling_model
    model.analyzer=SimpleNamespace(model=object(),method='fixture')
    model.diagnostic_inputs={'X_train':frame[['950','960']]}
    ticks=[]
    timer=QTimer();timer.setInterval(10);timer.timeout.connect(lambda:ticks.append(1));timer.start()
    def delayed(*args,cancel_event,**kwargs):
        while not cancel_event.is_set():
            time.sleep(.01)
        return None
    monkeypatch.setattr(win.onnx_service,'export_analyzer_to_onnx',delayed)
    def cancel():
        if action == 'close_window':
            win.close()
            return
        dialogs=win.findChildren(ProgressDialog)
        assert dialogs
        dialogs[-1]._on_cancel()
    # Cancel after observed event delivery rather than wall-clock coalescing.
    timer.timeout.connect(lambda: cancel() if len(ticks)==3 else None)
    QTimer.singleShot(2500,lambda: win._onnx_cancel_event.set() if win._onnx_cancel_event else None)
    assert win.export_fitted_analyzer_onnx() is None
    timer.stop()
    assert len(ticks)>=3
    assert win.export_onnx_btn.isEnabled()
    assert win._onnx_cancel_event is None


def test_diagnostics_requires_committed_prediction_scope(window,monkeypatch):
    win,frame,errors=window
    calls=[]
    monkeypatch.setattr(QMessageBox,'information',lambda *a,**k:calls.append(a[-1]))
    win.diagnostics_btn.click()
    assert calls and 'held-out' in calls[-1] and not errors


def test_mapping_signal_reaches_controller_and_refreshes_authoritative_X(window,monkeypatch):
    win,frame,errors=window
    controller=win.controller.data_controller
    calls=[]
    def apply(mapping):
        calls.append(mapping)
        controller.data_model.set_label_column_index(1)
        return True
    monkeypatch.setattr(controller,'apply_column_mapping',apply)
    mapping={'label_column':1,'wavelength_columns':[0,2,3]}
    win.data_partitioning_view.column_mapping_changed.emit(mapping)
    assert calls==[mapping]
    np.testing.assert_allclose(win.current_spectra,controller.data_model.get_X())
    np.testing.assert_array_equal(win.wavelengths, [955,960])
    assert not errors


def _column_role_fixture_frame():
    # Keep enough distinct numeric responses for the automatic task detector
    # to identify regression (small synthetic targets are treated as classes).
    n = 60
    response = np.linspace(1.0, 20.0, n)
    return pd.DataFrame({
        'response': response,
        'metadata_numeric': np.arange(n, dtype=float) + 10000,
        'sample_id': [f'sample-{i}' for i in range(n)],
        'group_id': [f'group-{i // 2}' for i in range(n)],
        '960': response * 2 + 1,
        '950': response * -3 + 4,
        'other_response': response * 100,
    })


def _select_combo_data(combo, value):
    index = combo.findData(value)
    assert index >= 0
    combo.setCurrentIndex(index)


def test_confirmed_mapping_reaches_real_gui_partition_service_and_model(window, monkeypatch):
    win, _frame, errors = window
    data = _column_role_fixture_frame()
    model = win.controller.data_controller.data_model
    view = win.data_partitioning_view
    model.set_data(data)
    view.set_data_loaded('mapping.csv', data)
    _select_combo_data(view.sample_id_combo, 2)
    _select_combo_data(view.group_id_combo, 3)

    # The MainWindow slot is connected to this real DataView signal; no
    # controller or DataService dispatch is mocked.
    mapping = {'label_column': 0, 'wavelength_columns': [4, 5]}
    view.column_mapping_changed.emit(mapping)
    params = view.get_parameters()
    assert params['target_column'] == 0
    assert params['wavelength_columns'] == [4, 5]
    assert params['sample_id_column'] == 2
    assert params['group_id_column'] == 3

    class NonModalResultsDialog:
        def __init__(self, **_kwargs):
            pass

        def exec_(self):
            return 0

    monkeypatch.setattr(
        'app.controllers.data_controller.DataPartitioningResultsDialog',
        NonModalResultsDialog,
    )
    win.analysis_type.setCurrentIndex(win.analysis_type.findData('Quantitative'))
    win.partition_data_with_params()

    assert model.partitioned_data is not None, errors
    for key in ('X_train', 'X_test'):
        assert list(model.partitioned_data[key].columns) == ['960', '950']
        assert not {'response', 'metadata_numeric', 'sample_id', 'group_id', 'other_response'} & set(
            model.partitioned_data[key].columns
        )
    assert list(model.get_X().columns) == ['960', '950']
    assert not errors


def test_confirmed_mapping_change_invalidates_existing_split_and_model(window):
    win, _frame, errors = window
    data = _column_role_fixture_frame()
    model = win.controller.data_controller.data_model
    view = win.data_partitioning_view
    model.set_data(data)
    view.set_data_loaded('mapping.csv', data)
    _select_combo_data(view.sample_id_combo, 2)
    _select_combo_data(view.group_id_combo, 3)
    view.column_mapping_changed.emit({'label_column': 0, 'wavelength_columns': [4, 5]})
    result = win.controller.data_controller.partition_data(
        view.get_selected_method(), view.get_parameters(), task_type='regression'
    )
    assert result is not None

    modeling_model = win.controller.modeling_controller.modeling_model
    modeling_model.trained_model = object()
    modeling_model.evaluation_results = {'r2': .9}
    modeling_model.diagnostics = {'stale': True}
    view.column_mapping_changed.emit({'label_column': 0, 'wavelength_columns': [5, 4]})

    assert model.partitioned_data is None
    assert model.X_train is None and model.X_test is None
    assert model.wavelength_column_positions == [5, 4]
    assert modeling_model.trained_model is None
    assert modeling_model.evaluation_results == {}
    assert modeling_model.diagnostics is None
    assert not errors


def test_column_mapping_dialog_accepts_default_features_without_identity_roles(window, monkeypatch):
    from app.views.column_mapping_dialog import ColumnMappingDialog

    win, _frame, errors = window
    data = _column_role_fixture_frame()
    model = win.controller.data_controller.data_model
    view = win.data_partitioning_view
    model.set_data(data)
    view.set_data_loaded('mapping.csv', data)
    _select_combo_data(view.sample_id_combo, 2)
    _select_combo_data(view.group_id_combo, 3)
    opened = {}

    def accept_default_mode(dialog):
        opened['dialog'] = dialog
        assert dialog._fb_label_radio.isChecked()
        dialog._on_accept()
        return dialog.result()

    monkeypatch.setattr(ColumnMappingDialog, 'exec_', accept_default_mode)
    view.column_mapping_btn.click()

    dialog = opened['dialog']
    assert dialog.result() == dialog.Accepted
    mapping = dialog.get_mapping()
    assert mapping == {'label_column': 0, 'wavelength_columns': [1, 4, 5, 6]}
    assert view.get_column_mapping() == mapping
    assert model.sample_id_column_index == 2 and model.group_id_column_index == 3
    assert model.get_X().columns.tolist() == ['metadata_numeric', '960', '950', 'other_response']
    for identity_index in (2, 3):
        item = dialog._wl_list.item(identity_index)
        assert not item.flags() & Qt.ItemIsSelectable

    # The custom-mode Select All control follows the same identity exclusion.
    dialog._custom_radio.setChecked(True)
    dialog._on_select_all()
    assert dialog.get_mapping()['wavelength_columns'] == [1, 4, 5, 6]
    assert not errors


def test_response_change_preserves_roles_for_unpartitioned_preprocessing_and_group_split(window):
    win, _frame, errors = window
    n = 24
    first_response = np.linspace(1.0, 24.0, n)
    data = pd.DataFrame({
        'first_response': first_response,
        'second_response': first_response * 10 + 2,
        'sample_id': np.arange(1000, 1000 + n),
        'group_id': np.repeat(np.arange(12), 2),
        'wave_z': first_response * 2 + 1,
        'wave_a': first_response * -3 + 4,
    })
    model = win.controller.data_controller.data_model
    view = win.data_partitioning_view
    model.set_data(data)
    view.set_data_loaded('response-change.csv', data)
    _select_combo_data(view.sample_id_combo, 2)
    _select_combo_data(view.group_id_combo, 3)
    view.column_mapping_changed.emit({'label_column': 0, 'wavelength_columns': [4, 5]})

    # Changing the response goes through the real combo signal and MainWindow
    # slot before any split exists; preprocessing must still see only spectra.
    view.label_column_combo.setCurrentIndex(1)
    assert model.label_column_index == 1
    assert model.sample_id_column_index == 2
    assert model.group_id_column_index == 3
    assert model.wavelength_column_positions == [4, 5]
    assert model.get_X().columns.tolist() == ['wave_z', 'wave_a']

    preprocessor = win.controller.preprocessing_controller
    assert preprocessor.apply_preprocessing(['Standard Normal Variate (SNV)'])
    assert model.preprocessed_data.columns.tolist() == ['wave_z', 'wave_a']

    view.group_validation_checkbox.setChecked(True)
    split = win.controller.data_controller.partition_data(
        view.get_selected_method(), view.get_parameters(), task_type='regression'
    )
    assert split is not None, errors
    assert list(split['X_train'].columns) == ['wave_z', 'wave_a']
    assert list(split['X_test'].columns) == ['wave_z', 'wave_a']
    assert set(split['group_id_train']).isdisjoint(set(split['group_id_test']))
    assert set(split['sample_id_train']).isdisjoint(set(split['sample_id_test']))
    assert model.sample_id_column_index == 2 and model.group_id_column_index == 3
    assert not errors


def test_response_combo_rejects_identity_role_collision_and_rolls_back(window):
    win, _frame, errors = window
    data = _column_role_fixture_frame()
    model = win.controller.data_controller.data_model
    view = win.data_partitioning_view
    model.set_data(data)
    view.set_data_loaded('identity-collision.csv', data)
    _select_combo_data(view.sample_id_combo, 2)
    _select_combo_data(view.group_id_combo, 3)
    view.column_mapping_changed.emit({'label_column': 0, 'wavelength_columns': [4, 5]})

    previous_revision = model.get_state_revision()
    previous_mapping = view.get_column_mapping()
    previous_X = model.get_X().copy()
    invalid_index = view.label_column_combo.findText(data.columns[2])
    assert invalid_index >= 0

    # Exercise the actual response combo signal and MainWindow validation slot.
    view.label_column_combo.setCurrentIndex(invalid_index)

    assert view.label_column_combo.currentText() == data.columns[0]
    assert view.label_column_combo.currentIndex() == 0
    assert model.label_column_index == 0
    assert model.sample_id_column_index == 2 and model.group_id_column_index == 3
    assert model.wavelength_column_positions == [4, 5]
    pd.testing.assert_frame_equal(model.get_X(), previous_X)
    assert view.get_column_mapping() == previous_mapping
    assert model.get_state_revision() == previous_revision
    assert any('response column cannot also be a sample/group ID' in message for message in errors)
