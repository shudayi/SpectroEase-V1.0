"""Focused responsiveness and approval invalidation checks for fitted workflow UI."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from PyQt5.QtWidgets import QApplication, QScrollArea
from app.views.verified_workflow_dialog import VerifiedWorkflowDialog


def settle(dialog, app):
    import time
    until = time.monotonic() + 180
    while dialog.job is not None and time.monotonic() < until:
        app.processEvents()
        time.sleep(.01)
    assert dialog.job is None


def test_candidate_edits_invalidate_approval(tmp_path):
    app = QApplication.instance() or QApplication([])
    dialog = VerifiedWorkflowDialog(tmp_path)
    settle(dialog, app)
    dialog._verify(); settle(dialog, app)
    assert dialog.report.passed
    dialog.confirm.setChecked(True)
    assert dialog.accept_button.isEnabled()
    dialog.editor.insertPlainText(' ')
    assert dialog.report is None
    assert not dialog.accept_button.isEnabled()
    dialog.close()


def test_small_window_has_scroll_and_missing_split_fails(tmp_path):
    app = QApplication.instance() or QApplication([])
    dialog = VerifiedWorkflowDialog(tmp_path)
    settle(dialog, app)
    dialog.show(); dialog.resize(500, 350); app.processEvents()
    scroll = dialog.findChild(QScrollArea)
    assert scroll.widgetResizable()
    assert scroll.verticalScrollBar().maximum() > 0
    assert scroll.horizontalScrollBar().maximum() == 0
    dialog._run_workflow()
    assert 'verified train/test split' in dialog.status.text()
    dialog.close()

def test_real_core_gui_accept_execute_save_replay(tmp_path, monkeypatch):
    import json
    from dataclasses import asdict
    import numpy as np
    import pandas as pd
    from PyQt5.QtWidgets import QFileDialog
    from app.models.data_model import DataModel
    from tests.test_verified_algorithm_service import candidate
    app = QApplication.instance() or QApplication([])
    model = DataModel()
    model.set_data(pd.DataFrame({'a': [1.,3.,5.,7.,9.], 'b': [2.,4.,6.,8.,10.]}))
    keys = list(model._ensure_row_keys())
    train_index = pd.Index(keys[:3], name='_row_key')
    test_index = pd.Index(keys[3:], name='_row_key')
    X_train = pd.DataFrame([[1.,2.],[3.,4.],[5.,6.]], index=train_index)
    X_test = pd.DataFrame([[7.,8.],[9.,10.]], index=test_index)
    model.set_partitioned_data(dict(X_train=X_train, X_test=X_test,
        y_train=pd.Series([0.,1.,2.], index=train_index),
        y_test=pd.Series([5.,7.], index=test_index),
        train_row_keys=keys[:3], test_row_keys=keys[3:]))
    assert model.has_verified_split()
    dialog = VerifiedWorkflowDialog(tmp_path / 'plugins', data_model=model)
    settle(dialog, app)
    for kind in ('stateful_preprocessing', 'feature_selection', 'classification', 'regression', 'metric'):
        dialog.editor.setPlainText(json.dumps(asdict(candidate(kind))))
        dialog.verify_button.click(); settle(dialog, app)
        assert dialog.report.passed, (kind, dialog.status.text())
        dialog.confirm.setChecked(True)
        dialog.accept_button.click(); settle(dialog, app)
        assert dialog.status.text().startswith('Accepted:'), dialog.status.text()
    dialog.reload_button.click(); settle(dialog, app)
    for key in ('preprocessing','feature_selection','metric'):
        dialog.selectors[key].setCurrentIndex(1)
    model_combo = dialog.selectors['model']
    for index in range(model_combo.count()):
        if '[regression]' in model_combo.itemText(index): model_combo.setCurrentIndex(index); break
    dialog.run_button.click(); settle(dialog, app)
    assert 'completed' in dialog.status.text(), dialog.status.text()
    np.testing.assert_array_equal(dialog.last_result['predictions'], [5.,7.])
    assert dialog.last_result['metrics']['RMSE'] == 0
    assert len(dialog.last_result['fit_trace']) == 3
    assert len(dialog.figure.axes) == 1
    export_path = tmp_path / 'evaluation.csv'
    monkeypatch.setattr(QFileDialog, 'getSaveFileName', lambda *a, **k: (str(export_path), 'CSV'))
    dialog.export_button.click(); settle(dialog, app)
    exported = pd.read_csv(export_path)
    assert list(exported.columns) == ['internal_row_key','observed','predicted']
    assert exported['predicted'].tolist() == [5.,7.]
    assert exported['internal_row_key'].tolist() == keys[3:]
    if os.environ.get('SPECTROEASE_GUI_QA_CAPTURE'):
        from pathlib import Path
        capture_dir = Path(os.environ['SPECTROEASE_GUI_QA_CAPTURE']); capture_dir.mkdir(parents=True, exist_ok=True)
        dialog.resize(850, 740); dialog.tabs.setCurrentIndex(1); dialog.show(); app.processEvents()
        scroll = dialog.tabs.widget(1)
        scroll.verticalScrollBar().setValue(scroll.verticalScrollBar().maximum()); app.processEvents()
        dialog.grab().save(str(capture_dir / 'real-regression-workflow.png'))
        (capture_dir / 'real-regression-workflow.json').write_text(json.dumps(dialog.last_result, indent=2), encoding='utf-8')
    saved = tmp_path / 'fitted.json'
    monkeypatch.setattr(QFileDialog, 'getSaveFileName', lambda *a, **k: (str(saved), 'JSON'))
    dialog.save_button.click(); settle(dialog, app)
    assert saved.is_file(), dialog.status.text()
    monkeypatch.setattr(QFileDialog, 'getOpenFileName', lambda *a, **k: (str(saved), 'JSON'))
    dialog.load_button.click(); settle(dialog, app)
    assert 'Inference-only replay' in dialog.status.text(), dialog.status.text()
    assert json.loads(dialog.output.toPlainText())['replayed_predictions'] == [5.,7.]
    assert dialog.evaluation_snapshot is None
    assert not dialog.figure.axes
    classification_split = dict(model.get_partitioned_data())
    classification_split['y_train'] = pd.Series([0,0,1], index=train_index)
    classification_split['y_test'] = pd.Series([1,1], index=test_index)
    model.set_partitioned_data(classification_split, task_type='classification')
    for index in range(model_combo.count()):
        if '[classification]' in model_combo.itemText(index): model_combo.setCurrentIndex(index); break
    dialog.run_button.click(); settle(dialog, app)
    assert 'completed' in dialog.status.text(), dialog.status.text()
    assert dialog.last_result['predictions'] == [1,1]
    assert dialog.last_result['metrics']['accuracy'] == 1
    assert len(dialog.figure.axes[0].images) == 1
    assert dialog.figure.axes[0].images[0].get_clim() == (0,2)
    assert dialog.evaluation_snapshot['truth'] == [1,1]
    if os.environ.get('SPECTROEASE_GUI_QA_CAPTURE'):
        app.processEvents()
        dialog.grab().save(str(capture_dir / 'real-classification-workflow.png'))
        (capture_dir / 'real-classification-workflow.json').write_text(json.dumps(dialog.last_result, indent=2), encoding='utf-8')
    # A current test row matching a saved training row must not be replayed.
    model.X_test.index = pd.Index([keys[0], keys[4]], name='_row_key')
    # DataModel rejects this mutation before replay starts.
    dialog.load_button.click(); settle(dialog, app)
    assert 'verified raw split' in dialog.status.text() or 'overlap' in dialog.status.text()
    dialog.close()


def test_application_theme_tabs_and_controls_do_not_clip_or_overlap(tmp_path):
    from PyQt5.QtWidgets import QWidget, QPushButton, QComboBox, QCheckBox, QPlainTextEdit
    from PyQt5.QtGui import QFont, QFontMetrics
    from PyQt5.QtCore import QPoint, QRect
    from app.ui.style_sheet_builder import build_app_stylesheet
    app = QApplication.instance() or QApplication([])
    parent = QWidget(); parent.setStyleSheet(build_app_stylesheet('light'))
    dialog = VerifiedWorkflowDialog(tmp_path, parent=parent)
    settle(dialog, app)
    dialog.show(); dialog.resize(500, 480); app.processEvents()
    bar = dialog.tabs.tabBar()
    bold = QFont(bar.font()); bold.setBold(True)
    metrics = QFontMetrics(bold)
    for tab in range(dialog.tabs.count()):
        dialog.tabs.setCurrentIndex(tab); app.processEvents()
        assert bar.tabRect(tab).width() >= metrics.horizontalAdvance(dialog.tabs.tabText(tab)) + 24
        scroll = dialog.tabs.widget(tab)
        assert scroll.horizontalScrollBar().maximum() == 0
        content = scroll.widget()
        controls = content.findChildren((QPushButton, QComboBox, QCheckBox, QPlainTextEdit))
        rectangles = [(widget, QRect(widget.mapTo(content, QPoint(0,0)), widget.size())) for widget in controls]
        for index, (widget, rect) in enumerate(rectangles):
            for other, other_rect in rectangles[index+1:]:
                assert not rect.intersects(other_rect), (type(widget).__name__, type(other).__name__)
    dialog._error("<failure>" + "x" * 20000)
    app.processEvents()
    assert len(dialog.status.text()) <= 401
    assert dialog.status.textFormat() == 0  # Qt.PlainText
    assert dialog.width() == 500
    dialog.close(); parent.close()
