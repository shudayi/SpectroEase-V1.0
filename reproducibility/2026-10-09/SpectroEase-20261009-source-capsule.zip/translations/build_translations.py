"""Build en.json and zh.json from app/views/*.py UI strings."""
import ast
import json
import re
from pathlib import Path

VIEWS_DIR = Path(__file__).parent.parent / "app" / "views"
TRANS_DIR = Path(__file__).parent

WIDGET_NAMES = {
    "QLabel", "QPushButton", "QGroupBox", "QCheckBox", "QRadioButton",
    "QAction", "QMenu", "QMessageBox", "QLineEdit",
}
METHOD_NAMES = {
    "setWindowTitle", "setText", "setToolTip", "setStatusTip", "setWhatsThis",
    "setPlaceholderText", "addTab", "addItem", "addItems", "addAction",
    "addRow", "setTitle", "addMenu", "addSeparator",
    "setHorizontalHeaderLabels", "setVerticalHeaderLabels",
}
DIALOG_CTOR_NAMES = {
    "ProgressDialog", "LLMDialog", "PCAExplorerDialog", "OptimizationResultDialog",
    "DataQualityDialog", "ConversionResultDialog", "EMSCParameterDialog",
    "OSCParameterDialog", "RNVParameterDialog", "NaNInfHandlingDialog",
    "SpectralTypePreSelectionDialog", "SpectralTypeSelectionDialog",
}
FILE_DIALOG_FUNCS = {"getOpenFileName", "getSaveFileName", "getExistingDirectory"}

# -----------------------------------------------------------------------------
# English overrides: clean mixed-language source strings.
# -----------------------------------------------------------------------------
EN_VALUE_OVERRIDES = {
    "conversion_result_dialog.copy_button_copy_button_text": "Copied!",
    "conversion_result_dialog.copy_button_copy_button_text_2": "Copy Code",
    "data_view.force_classification_checkbox_force_classification_checkbox_tooltip":
        "When checked, the task will be treated as classification regardless of data type.",
    "feature_selection_view.title_label": "Feature Selection Method (Optional)",
    "feature_selection_view.description":
        "Select feature selection method (optional; if not selected, all features will be used):",
    "feature_selection_view.skip_button": "Skip Feature Selection",
    "feature_selection_view.apply_button": "Apply Feature Selection",
    "optimization_result_dialog.title": "AI Optimization Results",
    "optimization_result_dialog.apply_button": "Apply Changes",
    "optimization_result_dialog.cancel_button": "Cancel",
    "preprocessing_view.raman_group": "Raman Specific (Placeholder Interface)",
    "preprocessing_view.raman_info_label":
        "Note: External preprocessing can also meet these requirements",
}

# Clean key renames for the overrides above.
KEY_RENAMES = {
    "conversion_result_dialog.copy_button_copy_button_text": "conversion_result_dialog.copy_success",
    "conversion_result_dialog.copy_button_copy_button_text_2": "conversion_result_dialog.copy_code",
}


def is_static_str(node):
    return isinstance(node, ast.Constant) and isinstance(node.value, str)


def slugify(text):
    s = re.sub(r"[^\w\s-]", "", text).strip()
    s = re.sub(r"[-\s]+", "_", s)
    return s.lower()[:50].strip("_") or "text"


def target_name(node):
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        if isinstance(node.value, ast.Name) and node.value.id == "self":
            return node.attr
        return f"{target_name(node.value)}_{node.attr}"
    return ""


def object_name(node):
    if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name):
        if node.value.id == "self":
            return node.attr
        return f"{node.value.id}_{node.attr}"
    if isinstance(node, ast.Attribute):
        return object_name(node.value)
    return ""


def call_kind(func):
    if isinstance(func, ast.Name):
        return func.id, "name"
    if isinstance(func, ast.Attribute):
        return func.attr, "attr", object_name(func.value)
    return None


def iter_visible_args(call_node, kind_info):
    if kind_info[1] == "name":
        name = kind_info[0]
        if name in WIDGET_NAMES:
            if call_node.args and is_static_str(call_node.args[0]):
                yield call_node.args[0].value, None
        return
    if kind_info[1] != "attr":
        return
    attr = kind_info[0]
    obj = kind_info[2] if len(kind_info) > 2 else ""
    if attr in {"setWindowTitle"}:
        if call_node.args and is_static_str(call_node.args[0]):
            yield call_node.args[0].value, "title"
    elif attr in {"setText", "setToolTip", "setStatusTip", "setWhatsThis", "setPlaceholderText"}:
        if call_node.args and is_static_str(call_node.args[0]):
            suffix = {
                "setText": "text", "setToolTip": "tooltip",
                "setStatusTip": "status_tip", "setWhatsThis": "whats_this",
                "setPlaceholderText": "placeholder"
            }[attr]
            yield call_node.args[0].value, f"{obj}_{suffix}" if obj else suffix
    elif attr == "addTab":
        if len(call_node.args) >= 2 and is_static_str(call_node.args[1]):
            yield call_node.args[1].value, "tab"
    elif attr == "addItem":
        if call_node.args and is_static_str(call_node.args[0]):
            yield call_node.args[0].value, f"{obj}_item" if obj else "item"
    elif attr == "addItems":
        if call_node.args and isinstance(call_node.args[0], (ast.List, ast.Tuple)):
            for el in call_node.args[0].elts:
                if is_static_str(el):
                    yield el.value, f"{obj}_item" if obj else "item"
    elif attr == "addAction":
        if call_node.args and is_static_str(call_node.args[0]):
            yield call_node.args[0].value, f"{obj}_action" if obj else "action"
    elif attr in {"addRow"}:
        if call_node.args and is_static_str(call_node.args[0]):
            yield call_node.args[0].value, "label"
    elif attr == "setTitle":
        if call_node.args and is_static_str(call_node.args[0]):
            yield call_node.args[0].value, f"{obj}_title" if obj else "title"
    elif attr == "addMenu":
        if call_node.args and is_static_str(call_node.args[0]):
            yield call_node.args[0].value, f"{obj}_menu" if obj else "menu"
    elif attr in {"setHorizontalHeaderLabels", "setVerticalHeaderLabels"}:
        if call_node.args and isinstance(call_node.args[0], (ast.List, ast.Tuple)):
            for el in call_node.args[0].elts:
                if is_static_str(el):
                    yield el.value, "header"
    return


class Visitor(ast.NodeVisitor):
    def __init__(self, file_stem):
        self.file_stem = file_stem
        self.parents = []
        self.entries = {}
        self.key_counts = {}

    def visit(self, node):
        self.parents.append(node)
        super().visit(node)
        self.parents.pop()

    def context_for_call(self, call_node):
        for p in reversed(self.parents):
            if isinstance(p, ast.Assign):
                if getattr(p, 'value', None) is call_node and len(p.targets) == 1:
                    tn = target_name(p.targets[0])
                    if tn:
                        return tn
        return None

    def make_key(self, text, suggested):
        if text in self.entries:
            return self.entries[text]
        base = suggested or slugify(text)
        key = base
        i = 2
        while key in self.key_counts and self.key_counts[key] != text:
            key = f"{base}_{i}"
            i += 1
        self.key_counts[key] = text
        self.entries[text] = key
        return key

    def visit_Call(self, node):
        kind = call_kind(node.func)
        if not kind:
            self.generic_visit(node)
            return
        if kind[1] == "name" and kind[0] in DIALOG_CTOR_NAMES and node.args and is_static_str(node.args[0]):
            text = node.args[0].value
            key = self.make_key(text, "dialog_title")
            self.generic_visit(node)
            return
        if kind[1] == "attr" and kind[0] in FILE_DIALOG_FUNCS:
            if len(node.args) > 1 and is_static_str(node.args[1]):
                self.make_key(node.args[1].value, "dialog_caption")
            if len(node.args) > 3 and is_static_str(node.args[3]):
                self.make_key(node.args[3].value, "file_filter")
            self.generic_visit(node)
            return
        if (kind[1] == "attr" and isinstance(node.func, ast.Attribute)
                and isinstance(node.func.value, ast.Name) and node.func.value.id == "QMessageBox"
                and kind[0] in {"critical", "information", "warning", "question"}):
            if node.args and is_static_str(node.args[0]):
                self.make_key(node.args[0].value, "title")
            if len(node.args) > 1 and is_static_str(node.args[1]):
                self.make_key(node.args[1].value, "message")
            self.generic_visit(node)
            return
        if kind[1] == "name" and kind[0] in WIDGET_NAMES:
            ctx = self.context_for_call(node)
            if node.args and is_static_str(node.args[0]):
                text = node.args[0].value
                self.make_key(text, ctx)
            self.generic_visit(node)
            return
        if kind[1] == "attr":
            ctx = self.context_for_call(node)
            attr = kind[0]
            for text, hint in iter_visible_args(node, kind):
                if attr == "addTab" and node.args and isinstance(node.args[0], ast.Name):
                    suggested = f"{node.args[0].id}_tab"
                elif attr in {"addItem", "addItems"}:
                    suggested = f"{slugify(text)}_item"
                elif attr == "addAction":
                    suggested = f"{slugify(text)}_action"
                elif attr in {"setHorizontalHeaderLabels", "setVerticalHeaderLabels"}:
                    suggested = f"{slugify(text)}_header"
                elif attr == "addRow":
                    suggested = f"{slugify(text)}_label"
                elif ctx:
                    suggested = ctx
                else:
                    obj = kind[2] if len(kind) > 2 else ""
                    suggested = f"{obj}_{hint}" if obj else hint
                self.make_key(text, suggested)
        self.generic_visit(node)


def extract_file(path):
    src = path.read_text(encoding="utf-8")
    tree = ast.parse(src)
    visitor = Visitor(path.stem)
    visitor.parents = [tree]
    visitor.visit(tree)
    return visitor.entries


# -----------------------------------------------------------------------------
# Translation engine
# -----------------------------------------------------------------------------

# Strings that should not be translated at all.
PASS_THROUGH = {
    "0.7", "2000", "https://api.deepseek.com/v1",
    '{"C": [0.1, 1, 10], "kernel": ["linear", "rbf"]}',
    '{"C": [0.1, 10], "kernel": ["linear", "rbf"]}',
    # model / service identifiers
    "deepseek-coder", "deepseek-chat", "other",
    # matplotlib / UI theme identifiers
    "default", "ggplot", "seaborn-v0_8", "bmh", "grayscale",
    # sklearn/kernel identifiers used by logic
    "f_classif", "chi2", "mutual_info_classif", "linear", "polynomial", "spline",
    "nearest", "localz", "mad", "rbf", "sigmoid", "poly", "svm", "knn", "rf",
    "nn", "xgboost", "lightgbm", "batch", "label", "None",
    # algorithm / spectral acronyms kept in Chinese UI to avoid breaking currentText logic
    "C", "CSV", "TXT", "XLSX", "PCA", "PLSR", "MSC", "SNV", "EMSC", "RNV", "OSC",
    "DTW", "COW", "ICS", "PAFFT", "MAD", "IQR", "ISO", "LOF", "FFT", "NLM",
    "SVM", "KNN", "DT", "NN", "GPR", "XGBoost", "LightGBM", "MAE", "RMSE", "R²",
    "AUC", "F1", "R", "RE", "RF", "SVR", "LDA", "NIPALS",
    "NIR", "MIR", "FTIR", "UV-Vis", "Vis-NIR", "VIS-NIR", "UV-VIS",
    # method names that are selected by currentText
    "Savitzky-Golay", "Savitzky-Golay Filter", "Moving Average", "Moving Avg",
    "Median Filter", "Median", "Gaussian", "Gaussian Smooth", "Wavelet", "ALS",
    "airPLS", "Polynomial", "S-Golay", "Finite Diff", "Gap-Segment", "Min-Max",
    "Vector", "Area", "Maximum", "Z-Score", "Robust", "First", "Mean", "Med",
    "Max", "Standard Deviation", "Robust Scale", "Trimmed Mean", "Huber",
    "Standard OSC", "Direct OSC", "Recursive OSC", "Consensus OSC",
    "Classical", "Improved", "Symmetric", "NIPALS",
    "Standard EMSC", "Simple EMSC", "Advanced EMSC",
    "Standard RNV", "Ultra Robust", "Adaptive RNV",
    # optimization / feature-selection / modeling method identifiers (keep English)
    "No Optimization", "Grid Search", "Random Search", "Genetic Algorithm",
    "Bayesian", "Bayesian Optimization",
    "Recursive Feature Elimination", "Mutual Information", "Random Forest",
    "Neural Network", "Peak Detection", "LASSO",
    # quantitative / qualitative task identifiers selected by currentText
    "Quantitative", "Qualitative", "Classification Task", "Regression Task",
    # metric identifiers
    "Accuracy", "Precision", "Recall", "F1 Score",
    # preprocessing methods kept English
    "Normalize", "Standard Scale", "Min-Max Scale", "First Derivative", "Second Derivative",
    "Standard Normal Variate (SNV)", "Multiplicative Scatter Correction (MSC)",
}

# Exact overrides for complex / sentence-like strings.
UI_OVERRIDES = {
    "": "",
    "Tip: Please check if the code meets your requirements before clicking \"Apply to System\"":
        "提示：在点击“应用到系统”前，请检查代码是否满足您的需求。",
    "When checked, the task will be treated as classification regardless of data type.":
        "勾选后，无论数据类型如何，都会将任务视为分类任务。",
    "Select feature selection method (optional; if not selected, all features will be used):":
        "选择特征选择方法（可选步骤，如不选择将使用全部特征）：",
    "Note: External preprocessing can also meet these requirements":
        "注：外部预处理亦可满足需求",
    "Please select the type of spectral data you want to import.\nThis will optimize the analysis parameters automatically.":
        "请选择要导入的光谱数据类型。\n这将自动优化分析参数。",
    "\n        <b>Why Manual Selection After Auto-Detection?</b><br>\n        • <b>Overlapping Ranges:</b> Some spectral types have overlapping wavelength ranges<br>\n        • <b>Instrument Variations:</b> Different instruments may use slightly different ranges<br>\n        • <b>Preprocessing Optimization:</b> Each spectral type requires specific preprocessing methods<br>\n        • <b>Chemical Context:</b> The same wavelength range can be used for different techniques\n        ":
        "\n        <b>为何自动检测后仍需手动选择？</b><br>\n        • <b>范围重叠：</b>某些光谱类型的波长范围存在重叠<br>\n        • <b>仪器差异：</b>不同仪器的范围可能略有不同<br>\n        • <b>预处理优化：</b>每种光谱类型需要特定的预处理方法<br>\n        • <b>化学背景：</b>相同波长范围可用于不同技术\n        ",
    "Extended Multiplicative Scatter Correction (EMSC) is an advanced scatter correction method:\n\n• Extends MSC by including polynomial terms for wavelength dependence\n• Accounts for pathlength variations and chemical interferences\n• Uses orthogonal signal correction principles\n• Particularly effective for complex scatter patterns\n\nModel: X_corrected = (X - interference - polynomial) / scatter_factor":
        "扩展多元散射校正（EMSC）是一种高级散射校正方法：\n\n• 通过引入波长相关多项式项扩展 MSC\n• 考虑光程变化和化学干扰\n• 采用正交信号校正原理\n• 对复杂散射模式尤为有效\n\n模型：X_corrected = (X - interference - polynomial) / scatter_factor",
    "Orthogonal Signal Correction (OSC) removes systematic variation orthogonal to Y:\n\n• Removes variation unrelated to the target variable\n• Improves prediction accuracy and model interpretability\n• Reduces model complexity and overfitting\n• Particularly effective for multivariate calibration\n\nProcess: X_corrected = X - T_orth * P_orth^T (orthogonal to Y)":
        "正交信号校正（OSC）去除与 Y 正交的系统性变异：\n\n• 去除与目标变量无关的变异\n• 提高预测准确率和模型可解释性\n• 降低模型复杂度与过拟合\n• 对多元校正尤为有效\n\n过程：X_corrected = X - T_orth * P_orth^T（与 Y 正交）",
    "Robust Normal Variate (RNV) is a robust version of SNV:\n\n• Uses robust statistics (median, MAD) instead of mean and standard deviation\n• Less sensitive to outliers and extreme values\n• Maintains shape information while normalizing spectra\n• Particularly effective for noisy or contaminated spectra\n\nFormula: RNV(x) = (x - robust_center) / robust_scale":
        "稳健正态变量（RNV）是 SNV 的稳健版本：\n\n• 使用稳健统计量（中位数、MAD）替代均值和标准差\n• 对异常值和极端值不敏感\n• 归一化光谱时保持形状信息\n• 对噪声或受污染光谱尤为有效\n\n公式：RNV(x) = (x - robust_center) / robust_scale",
    "Recommended for spectral data with different scales":
        "推荐用于不同量程的光谱数据",
    "Toggle Y-axis locking for preprocessing comparison":
        "切换 Y 轴锁定以对比预处理效果",
    "Lock Y-axis (prevents intensity scaling artifacts)":
        "锁定 Y 轴（防止强度缩放伪影）",
    "Lock Y-axis (prevents intensity scaling artifacts) ✓":
        "锁定 Y 轴（防止强度缩放伪影）✓",
    "Processing Queue: None": "处理队列：无",
    "Processing...": "处理中...",
    "No data loaded": "未加载数据",
    "No file selected": "未选择文件",
    "No data available.": "暂无可用数据。",
    "No evaluation results or incorrect format": "无评估结果或格式不正确",
    "No class names provided, using default indices": "未提供类别名称，使用默认索引",
    "Final label count still mismatch, force repair": "类别数量仍不匹配，强制修复",
    "Use PCA Features for Modeling?": "是否将 PCA 特征用于建模？",
    "PCA Features Selected": "PCA 特征已选择",
    "Original Data Retained": "保留原始数据",
    "Generating Report": "正在生成报告",
    "Method Note": "方法说明",
    "Choose analysis type": "选择分析类型",
    "Extract features without requiring labels or data splitting":
        "无需标签或数据划分即可提取特征",
    "Preview plot requires pyqtgraph": "预览绘图需要 pyqtgraph",
    "Proceed with data as-is - may cause visualization errors":
        "按原样继续 - 可能导致可视化错误",
    "Cancel data loading and return to file selection":
        "取消数据加载并返回文件选择",
    "Remove all rows containing NaN or Inf values":
        "删除所有包含 NaN 或 Inf 值的行",
    "Replace NaN/Inf with interpolated values":
        "用插值替换 NaN/Inf",
    "Fill NaN values using interpolation": "使用插值填充 NaN 值",
    "Linear interpolation (Best for spectral data)": "线性插值（光谱数据最佳）",
    "Drop affected rows (Recommended for small datasets)": "删除受影响行（小数据集推荐）",
    "Interpolate values (Recommended for spectral data)": "插值填充（光谱数据推荐）",
    "Keep data unchanged (May cause plotting errors)": "保持数据不变（可能导致绘图错误）",
    "Remove affected rows/columns": "删除受影响的行/列",
    "Spike Removal (Recommended for Raman)": "尖峰去除（拉曼推荐）",
    "Raman Specific (Placeholder Interface)": "拉曼专用（占位接口）",
    "Raman Specific Preprocessing": "拉曼专用预处理",
    "Raman Spectroscopy": "拉曼光谱",
    "Expert Preprocessing Recommendations:": "专家预处理建议：",
    "Manual Selection & Expert Recommendations": "手动选择与专家建议",
    "Automatic Detection Results": "自动检测结果",
    "Auto-detect from data": "从数据中自动检测",
    "Spectral Data Type": "光谱数据类型",
    "Select Spectral Type": "选择光谱类型",
    "Select Your Spectral Data Type": "选择您的光谱数据类型",
    "Continue to Select Data": "继续选择数据",
    "Apply Configuration": "应用配置",
    "Custom Range": "自定义范围",
    "Basic - Standard parameters": "基础 - 标准参数",
    "Advanced - Optimized parameters": "高级 - 优化参数",
    "Expert - Custom parameters": "专家 - 自定义参数",
    "CSV Files (*.csv);;Text Files (*.txt);;Excel Files (*.xlsx)":
        "CSV 文件 (*.csv);;文本文件 (*.txt);;Excel 文件 (*.xlsx)",
    "PNG Files (*.png);;PDF Files (*.pdf)":
        "PNG 文件 (*.png);;PDF 文件 (*.pdf)",
    "PNG Files (*.png);;PDF Files (*.pdf);;SVG Files (*.svg)":
        "PNG 文件 (*.png);;PDF 文件 (*.pdf);;SVG 文件 (*.svg)",
    "Use PCA Features": "使用 PCA 特征",
    "PCA Features Activated": "PCA 特征已激活",
    "PCA Features Available": "PCA 特征可用",
    "PCA Error": "PCA 错误",
    "Feature Engineering Error": "特征工程错误",
    "Exploratory PCA Error": "探索性 PCA 错误",
    "Modeling PCA Error": "建模 PCA 错误",
    "Feature Extraction Error": "特征提取错误",
    "Analysis Results": "分析结果",
    "Data Quality Issues Detected": "检测到数据质量问题",
    "⚠️ Data Quality Issues Detected": "⚠️ 检测到数据质量问题",
    "⚠️ SCALING/NORMALIZATION ACTIVE": "⚠️ 缩放/归一化已激活",
    "❌ Auto-detection failed: No wavelength data available":
        "❌ 自动检测失败：无波长数据",
    "NIR (Near-Infrared) - 800-2500 nm": "NIR（近红外）- 800-2500 nm",
    "Raman - 200-4000 cm⁻¹": "拉曼 - 200-4000 cm⁻¹",
    "MIR/FTIR (Mid-Infrared) - 2500-25000 nm": "MIR/FTIR（中红外）- 2500-25000 nm",
    "Vis-NIR (Visible-NIR) - 400-1100 nm": "Vis-NIR（可见-近红外）- 400-1100 nm",
    "UV-Vis (Ultraviolet-Visible) - 200-800 nm": "UV-Vis（紫外-可见光）- 200-800 nm",
    "VIS-NIR (Visible-Near-Infrared) - 400-1100 nm": "VIS-NIR（可见-近红外）- 400-1100 nm",
    "UV-VIS (Ultraviolet-Visible) - 200-800 nm": "UV-VIS（紫外-可见光）- 200-800 nm",
    "NIR (Near-Infrared)": "NIR（近红外）",
    "MIR (Mid-Infrared)": "MIR（中红外）",
    "VIS-NIR (Visible-Near-Infrared)": "VIS-NIR（可见-近红外）",
    "UV-VIS (Ultraviolet-Visible)": "UV-VIS（紫外-可见光）",
    "UV-Vis (Ultraviolet-Visible)": "UV-Vis（紫外-可见光）",
    "Vis-NIR (Visible-NIR)": "Vis-NIR（可见-近红外）",
    "Evaluate": "评估",
    "Remove rows or columns with NaN/Inf values": "删除包含 NaN/Inf 值的行或列",
    "Feature Selection Method (Optional)": "特征选择方法（可选）",
    "Number of features (k):": "特征数量（k）：",
    "Number of features to select:": "待选特征数量：",
    "Select modeling algorithm to use:": "选择要使用的建模算法：",
    "Converted Code:": "转换后的代码：",
    "Auto (based on CEV threshold)": "自动（基于 CEV 阈值）",
    "Number of Iterations:": "迭代次数：",
    "Number of Generations:": "进化代数：",
    "Number of Features (k):": "特征数量（k）：",
    "Number of Features to Select:": "待选特征数量：",
    "Number of Features:": "特征数量：",
    "Top N Features:": "前 N 个特征：",
    "Select Preprocessing Methods:": "选择预处理方法：",
    "Select Feature Selection Method:": "选择特征选择方法：",
    "Select Modeling Algorithm:": "选择建模算法：",
    "Select Hyperparameter Optimization Method:": "选择超参数优化方法：",
    "Parameter Grid (JSON):": "参数网格（JSON）：",
    "Parameter Distributions (JSON):": "参数分布（JSON）：",
    "Parameter Ranges (JSON):": "参数范围（JSON）：",
    "Polynomial Order:": "多项式阶数：",
    "Polynomial Order": "多项式阶数",
    "Poly Order:": "多项式阶数：",
    "Poly:": "多项式：",
    "Window Length:": "窗口长度：",
    "Window Size:": "窗口大小：",
    "Kernel Size:": "核大小：",
    "C Parameter:": "C 参数：",
    "Max Iter:": "最大迭代：",
    "CV Folds:": "交叉验证折数：",
    "Cross-Validation Folds:": "交叉验证折数：",
    "Test Split Ratio:": "测试集比例：",
    "Random Seed:": "随机种子：",
    "Learning Rate:": "学习率：",
    "Max Depth:": "最大深度：",
    "Hidden Layers:": "隐藏层：",
    "Neurons per Layer:": "每层神经元数：",
    "Epochs:": "训练轮数：",
    "Number of Boosting Rounds:": "提升轮数：",
    "Number of Components:": "主成分数：",
    "Number of OSC Components:": "OSC 成分数：",
    "Number of Trees:": "树数量：",
    "Population Size:": "种群大小：",
    "CEV Threshold:": "CEV 阈值：",
    "Preprocessing:": "预处理：",
    "Output:": "输出：",
    "Components:": "成分数：",
    "Score function:": "评分函数：",
    "Importance threshold:": "重要性阈值：",
    "Regularization strength (alpha):": "正则化强度（alpha）：",
    "Features to remove each step:": "每步移除特征数：",
    "Sample Index:": "样本索引：",
    "Preview Type:": "预览类型：",
    "Display:": "显示：",
    "Theme:": "主题：",
    "Description:": "描述：",
    "Spectral Type:": "光谱类型：",
    "Adaptation Level:": "适配等级：",
    "Smoothing Window:": "平滑窗口：",
    "Plot Type:": "绘图类型：",
    "Task Type:": "任务类型：",
    "Analysis Type:": "分析类型：",
    "Analysis Method:": "分析方法：",
    "Evaluation Metric:": "评估指标：",
    "Model Method:": "模型方法：",
    "Optimization Method:": "优化方法：",
    "Method:": "方法：",
    "Type:": "类型：",
    "Metric:": "指标：",
    "Label:": "标签：",
    "Format:": "格式：",
    "Module:": "模块：",
    "Source:": "来源：",
    "Template:": "模板：",
    "Algorithm:": "算法：",
    "Reference:": "参考：",
    "Wavelength Start:": "波长起始：",
    "Wavelength End:": "波长结束：",
    "Regularization Parameter:": "正则化参数：",
    "Convergence Tolerance:": "收敛容差：",
    "Include Wavelength Terms:": "包含波长项：",
    "Include Pathlength Variation:": "包含光程变化：",
    "Use Interference Matrix:": "使用干扰矩阵：",
    "Center Data:": "数据中心化：",
    "Scale Data:": "数据缩放：",
    "Cross-Validation:": "交叉验证：",
    "Variance Threshold:": "方差阈值：",
    "Orthogonality Constraint:": "正交约束：",
    "Iterative Refinement:": "迭代优化：",
    "Enable Robust Estimation:": "启用稳健估计：",
    "Outlier Threshold:": "异常值阈值：",
    "MAD Constant:": "MAD 常数：",
    "Minimum Scale Value:": "最小缩放值：",
    "Trimmed Mean Percentage:": "截尾均值百分比：",
    "Centering Method:": "中心方法：",
    "Scaling Method:": "缩放方法：",
    "OSC Algorithm:": "OSC 算法：",
    "Deflation Method:": "收缩方法：",
    "Reference Spectrum:": "参考光谱：",
    "Threshold:": "阈值：",
    "Threshold (%):": "阈值（%）：",
    "Window:": "窗口：",
    "Order:": "阶数：",
    "Strength:": "强度：",
    "File Format:": "文件格式：",
    "Data Preview:": "数据预览：",
    "API Key:": "API 密钥：",
    "Model:": "模型：",
    "API URL:": "API URL：",
    "Temperature:": "温度：",
    "Max Tokens:": "最大 Token 数：",
    "LLM Configuration": "LLM 配置",
    "Input Source Code:": "输入源代码：",
    "Conversion Result:": "转换结果：",
    "Result:": "结果：",
    "Algorithm Description": "算法描述",
    "Basic Parameters": "基础参数",
    "Advanced Parameters": "高级参数",
    "Preset Configurations": "预设配置",
    "Tip:": "提示：",
    "Copied!": "复制成功！",
    "Paste your algorithm code here...": "在此粘贴您的算法代码...",
    "🔬 Select Your Spectral Data Type": "🔬 选择您的光谱数据类型",
    "Select Your Spectral Data Type": "选择您的光谱数据类型",
    "Select Target Module:": "选择目标模块：",
    "Enable Wavelength Calibration": "启用波长校准",
    "Enable Intensity Calibration": "启用强度校准",
    "Wavelength Calibration": "波长校准",
    "Intensity Calibration": "强度校准",
    "🔒 Y-Axis Locked": "🔒 Y 轴已锁定",
    "🔓 Y-Axis Auto": "🔓 Y 轴自动",
    "Y-Axis Locked": "Y 轴已锁定",
    "Y-Axis Auto": "Y 轴自动",
    "SNV (Standard Normal Variate)": "SNV（标准正态变量）",
    "MSC (Multiplicative Scatter Correction)": "MSC（多元散射校正）",
}

# Multi-word technical phrases. Longer first.
PHRASE_ZH = {
    "Root Mean Square Error (RMSE)": "均方根误差（RMSE）",
    "Mean Absolute Error (MAE)": "平均绝对误差（MAE）",
    "R-squared (R²)": "决定系数（R²）",
    "Relative Error (RE)": "相对误差（RE）",
    "Area Under ROC Curve (AUC)": "ROC 曲线下面积（AUC）",
    "F1 Score": "F1 分数",
    "Standard Normal Variate (SNV)": "标准正态变量（SNV）",
    "Multiplicative Scatter Correction (MSC)": "多元散射校正（MSC）",
    "Extended Multiplicative Scatter Correction (EMSC)": "扩展多元散射校正（EMSC）",
    "Robust Normal Variate (RNV)": "稳健正态变量（RNV）",
    "Orthogonal Signal Correction (OSC)": "正交信号校正（OSC）",
    "Principal Component Analysis": "主成分分析",
    "Partial Least Squares Regression": "偏最小二乘回归",
    "Partial Least Squares": "偏最小二乘",
    "Random Forest": "随机森林",
    "Support Vector Machine": "支持向量机",
    "Support Vector Regression": "支持向量回归",
    "Neural Network": "神经网络",
    "Gradient Boosting": "梯度提升",
    "Gaussian Process Regression": "高斯过程回归",
    "Linear Discriminant Analysis": "线性判别分析",
    "K-Nearest Neighbors": "K 近邻",
    "Decision Tree": "决策树",
    "Savitzky-Golay Filter": "Savitzky-Golay 滤波",
    "Moving Average": "移动平均",
    "Median Filter": "中值滤波",
    "Gaussian Smooth": "高斯平滑",
    "First Derivative": "一阶导数",
    "Second Derivative": "二阶导数",
    "Finite Diff": "有限差分",
    "Gap-Segment": "Gap-Segment",
    "Baseline Correction": "基线校正",
    "Scatter Correction": "散射校正",
    "Spike Removal": "尖峰去除",
    "Peak Alignment": "峰对齐",
    "Reference Selection": "参考光谱选择",
    "Reference Spectrum": "参考光谱",
    "Feature Selection": "特征选择",
    "Feature Extraction": "特征提取",
    "Feature Importance": "特征重要性",
    "Feature Engineering": "特征工程",
    "Hyperparameter Optimization": "超参数优化",
    "Model Evaluation": "模型评估",
    "Model Selection": "模型选择",
    "Model Setup": "模型设置",
    "Model Specific Parameters": "模型专属参数",
    "Training Control": "训练控制",
    "Learning Curve": "学习曲线",
    "Confusion Matrix": "混淆矩阵",
    "Residual Plot": "残差图",
    "Scatter Plot": "散点图",
    "Spectrum Plot": "光谱图",
    "Line Plot": "折线图",
    "Bar Chart": "条形图",
    "Heatmap": "热力图",
    "3D Plot": "三维图",
    "ROC Curve": "ROC 曲线",
    "Scores Plot": "得分图",
    "Loadings Plot": "载荷图",
    "Data Partitioning": "数据划分",
    "Data Management": "数据管理",
    "Data Preview": "数据预览",
    "Data Quality": "数据质量",
    "Data Loading": "数据加载",
    "Data Splitting": "数据划分",
    "Preprocessing Options": "预处理选项",
    "Preprocessing Algorithms Guide": "预处理算法指南",
    "Expert Preprocessing Recommendations": "专家预处理建议",
    "Spectral Data Type": "光谱数据类型",
    "Spectral Type": "光谱类型",
    "Analysis Settings": "分析设置",
    "Analysis Method": "分析方法",
    "Analysis Type": "分析类型",
    "Analysis Results": "分析结果",
    "Evaluation Metric": "评估指标",
    "Evaluation Metrics": "评估指标",
    "Evaluation Results": "评估结果",
    "Quantitative Metrics": "定量指标",
    "Qualitative Metrics": "定性指标",
    "PCA Configuration": "PCA 配置",
    "PCA Features": "PCA 特征",
    "Original Data": "原始数据",
    "Advanced Methods": "高级方法",
    "Best Practices": "最佳实践",
    "Standard Interface Template": "标准接口模板",
    "Input Source Code": "输入源代码",
    "Conversion Result": "转换结果",
    "Preset Configurations": "预设配置",
    "Centering Method": "中心方法",
    "Scaling Method": "缩放方法",
    "Deflation Method": "收缩方法",
    "OSC Algorithm": "OSC 算法",
    "Interpolation Method": "插值方法",
    "Preview Settings": "预览设置",
    "Preview Plot": "预览图",
    "Preview Type": "预览类型",
    "Processing Queue": "处理队列",
    "Variance Explained": "方差解释",
    "Task Type": "任务类型",
    "Classification Task": "分类任务",
    "Regression Task": "回归任务",
    "Cross-Validation": "交叉验证",
    "Test Split Ratio": "测试集比例",
    "Random Seed": "随机种子",
    "Max Depth": "最大深度",
    "Learning Rate": "学习率",
    "Hidden Layers": "隐藏层",
    "Neurons per Layer": "每层神经元数",
    "Number of Boosting Rounds": "提升轮数",
    "Number of Components": "成分数",
    "Number of Features": "特征数量",
    "Number of Iterations": "迭代次数",
    "Number of Generations": "进化代数",
    "Number of Estimators": "估计器数量",
    "Number of Trees": "树数量",
    "Population Size": "种群大小",
    "Regularization Parameter": "正则化参数",
    "Regularization Strength": "正则化强度",
    "Convergence Tolerance": "收敛容差",
    "Maximum Iterations": "最大迭代次数",
    "Minimum Scale Value": "最小缩放值",
    "Trimmed Mean Percentage": "截尾均值百分比",
    "MAD Constant": "MAD 常数",
    "Outlier Threshold": "异常值阈值",
    "Enable Robust Estimation": "启用稳健估计",
    "Include Wavelength Terms": "包含波长项",
    "Include Pathlength Variation": "包含光程变化",
    "Use Interference Matrix": "使用干扰矩阵",
    "Wavelength Start": "波长起始",
    "Wavelength End": "波长结束",
    "Variance Threshold": "方差阈值",
    "Orthogonality Constraint": "正交约束",
    "Iterative Refinement": "迭代优化",
    "Center Data": "数据中心化",
    "Scale Data": "数据缩放",
    "Standard EMSC": "标准 EMSC",
    "Simple EMSC": "简单 EMSC",
    "Advanced EMSC": "高级 EMSC",
    "Standard OSC": "标准 OSC",
    "Direct OSC": "直接 OSC",
    "Recursive OSC": "递归 OSC",
    "Consensus OSC": "共识 OSC",
    "Standard RNV": "标准 RNV",
    "Ultra Robust": "超稳健",
    "Adaptive RNV": "自适应 RNV",
    "Mean Spectrum": "平均光谱",
    "Median Spectrum": "中位数光谱",
    "First Sample": "第一个样本",
    "Custom Reference": "自定义参考",
    "Trimmed Mean": "截尾均值",
    "Standard Deviation": "标准差",
    "Robust Scale": "稳健尺度",
    "Mean replacement": "均值替换",
    "Median replacement": "中位数替换",
    "Linear interpolation": "线性插值",
    "Remove affected rows": "删除受影响行",
    "Remove rows": "删除行",
    "Remove columns": "删除列",
    "Interpolate values": "插值填充",
    "Keep data unchanged": "保持数据不变",
    "Apply to System": "应用到系统",
    "Browse...": "浏览...",
    "Convert Code": "转换代码",
    "Copy Code": "复制代码",
    "Integrate to System": "集成到系统",
    "Test Connection": "测试连接",
    "Test Parameters": "测试参数",
    "Test Failed": "测试失败",
    "Parameter Test": "参数测试",
    "Parameter Warning": "参数警告",
    "Parameter Error": "参数错误",
    "AI Assistant": "AI 助手",
    "AI Config": "AI 配置",
    "AI Optimization Results": "AI 优化结果",
    "Operation History": "操作历史",
    "Go back to previous data state": "返回上一个数据状态",
    "Increase plot zoom": "放大绘图",
    "Decrease plot zoom": "缩小绘图",
    "Save the current dataset": "保存当前数据集",
    "Save the current visualization": "保存当前可视化",
    "Open the AI assistant": "打开 AI 助手",
    "Configure AI service settings": "配置 AI 服务设置",
    "Show operation history": "显示操作历史",
    "Show feature loadings": "显示特征载荷",
    "Make Predictions": "进行预测",
    "Save Results": "保存结果",
    "Save Model": "保存模型",
    "Load Model": "加载模型",
    "Load Data": "加载数据",
    "Load CSV File": "加载 CSV 文件",
    "Save Plot": "保存绘图",
    "Save Image": "保存图像",
    "Save Data": "保存数据",
    "Import Data": "导入数据",
    "Export Plot": "导出图像",
    "Generate Report": "生成报告",
    "Start Analysis": "开始分析",
    "Apply Preprocessing": "应用预处理",
    "Apply Feature Selection": "应用特征选择",
    "Apply Optimization": "应用优化",
    "Apply Changes": "应用更改",
    "Train Model": "训练模型",
    "Evaluate Model": "评估模型",
    "Select Data File": "选择数据文件",
    "Select Target Module": "选择目标模块",
    "Select Preprocessing Methods": "选择预处理方法",
    "Select Feature Selection Method": "选择特征选择方法",
    "Select Modeling Algorithm": "选择建模算法",
    "Select Hyperparameter Optimization Method": "选择超参数优化方法",
    "Skip Feature Selection": "跳过特征选择",
    "Extract PCA Features": "提取 PCA 特征",
    "Force Classification Task": "强制分类任务",
    "Partition Data": "划分数据",
    "Confirm Code Integration": "确认代码集成",
    "Unsafe Code Detected": "检测到不安全代码",
    "Zoom In": "放大",
    "Zoom Out": "缩小",
    "Back": "返回",
    "History": "历史",
    "Help": "帮助",
    "Close": "关闭",
    "Reset": "重置",
    "Cancel": "取消",
    "Apply": "应用",
    "OK": "确定",
    "Save": "保存",
    "Open": "打开",
    "Preview": "预览",
    "Continue to Select Data": "继续选择数据",
    "Apply Configuration": "应用配置",
    "Custom Range": "自定义范围",
    "Basic - Standard parameters": "基础 - 标准参数",
    "Advanced - Optimized parameters": "高级 - 优化参数",
    "Expert - Custom parameters": "专家 - 自定义参数",
    "Auto-detect from data": "从数据中自动检测",
    "Manual Selection & Expert Recommendations": "手动选择与专家建议",
    "Automatic Detection Results": "自动检测结果",
    "Remaining Issues": "剩余问题",
    "Choose Action": "选择操作",
    "Issues Detected": "检测到的问题",
    "Data Quality Analysis": "数据质量分析",
    "Preview Changes": "预览更改",
    "Apply & Continue": "应用并继续",
    "Linear interpolation (Best for spectral data)": "线性插值（光谱数据最佳）",
    "Drop affected rows (Recommended for small datasets)": "删除受影响行（小数据集推荐）",
    "Interpolate values (Recommended for spectral data)": "插值填充（光谱数据推荐）",
    "Keep data unchanged (May cause plotting errors)": "保持数据不变（可能导致绘图错误）",
    "Feature Extraction (Unsupervised)": "特征提取（无监督）",
    "Enhanced Preprocessing Visualization": "增强预处理可视化",
    "Standardize data": "标准化数据",
    "Standardize Features": "标准化特征",
    "Correlation Coefficient (R)": "相关系数（R）",
    "Correlation Coefficient": "相关系数",
    "Quantitative Analysis: Predict continuous values (Regression analysis)": "定量分析：预测连续值（回归分析）",
    "Qualitative Analysis: Classification prediction (Category analysis)": "定性分析：分类预测（类别分析）",
    "Qualitative Analysis: Classification Prediction (Category Analysis)": "定性分析：分类预测（类别分析）",
    "Algorithm Description": "算法描述",
    "Basic Parameters": "基础参数",
    "Advanced Parameters": "高级参数",
    "Algorithm Parameters": "算法参数",
    "Algorithm Selection": "算法选择",
    "Cross-Validation Folds": "交叉验证折数",
    "Max Iter": "最大迭代",
    "CV Folds": "交叉验证折数",
    "Test Split Ratio": "测试集比例",
    "Epochs": "训练轮数",
    "Number of Features (k)": "特征数量（k）",
    "Number of Features to Select": "待选特征数量",
    "Top N Features": "前 N 个特征",
    "Number of OSC Components": "OSC 成分数",
    "Reference": "参考",
    "Sample Index": "样本索引",
    "Display": "显示",
    "Theme": "主题",
    "Adaptation Level": "适配等级",
    "Smoothing Window": "平滑窗口",
    "Score function": "评分函数",
    "Importance threshold": "重要性阈值",
    "Regularization strength (alpha)": "正则化强度（alpha）",
    "Features to remove each step": "每步移除特征数",
    "Plot Type": "绘图类型",
    "Model Method": "模型方法",
    "Optimization Method": "优化方法",
    "Input Source Code": "输入源代码",
    "Cancel - do not load this data": "取消 - 不加载此数据",
    "Interpolate missing values": "插值填充缺失值",
    "Cancel data loading and return to file selection": "取消数据加载并返回文件选择",
    "Feature Selection Methods": "特征选择方法",
    "Correlation Threshold": "相关性阈值",
    "Mutual Information": "互信息",
    "Recursive Feature Elimination": "递归特征消除",
    "PCA Exploratory Analysis": "PCA 探索性分析",
    "Algorithm Conversion and Integration": "算法转换与集成",
    "Select modeling algorithm to use:": "选择要使用的建模算法：",
    "Converted Code:": "转换后的代码：",
    "Parameter Grid": "参数网格",
    "Parameter Distributions": "参数分布",
    "Parameter Ranges": "参数范围",
    "Number of features (k):": "特征数量（k）：",
    "Number of features to select:": "待选特征数量：",
}

# Single-word / short token dictionary.
WORD_ZH = {
    "Method": "方法", "Methods": "方法",
    "Window": "窗口", "Windows": "窗口",
    "Size": "大小", "Sizes": "大小",
    "Length": "长度", "Lengths": "长度",
    "Order": "阶数", "Orders": "阶数",
    "Polynomial": "多项式", "Poly": "多项式",
    "Baseline": "基线",
    "Correction": "校正", "Corrections": "校正",
    "Scatter": "散射",
    "Spike": "尖峰",
    "Removal": "去除",
    "Smoothing": "平滑", "Smooth": "平滑",
    "Normalize": "归一化", "Normalization": "归一化",
    "Standardize": "标准化", "Standardization": "标准化",
    "Scale": "缩放", "Scaling": "缩放",
    "Derivative": "导数", "Derivatives": "导数",
    "Outlier": "异常值", "Outliers": "异常值",
    "Detection": "检测",
    "Denoise": "去噪", "Denoising": "去噪",
    "Peak": "峰", "Peaks": "峰",
    "Alignment": "对齐",
    "Reference": "参考", "References": "参考",
    "Selection": "选择",
    "Selected": "已选择",
    "Select": "选择",
    "Feature": "特征", "Features": "特征",
    "Importance": "重要性",
    "Extraction": "提取",
    "Optimization": "优化",
    "Evaluation": "评估",
    "Visualization": "可视化",
    "Analysis": "分析", "Analyses": "分析",
    "Analyze": "分析",
    "Processing": "处理", "Process": "处理",
    "Management": "管理",
    "Partitioning": "划分", "Partition": "划分",
    "Loading": "加载", "Load": "加载",
    "Save": "保存",
    "Import": "导入",
    "Export": "导出",
    "Browse": "浏览",
    "Cancel": "取消",
    "OK": "确定",
    "Apply": "应用",
    "Reset": "重置",
    "Help": "帮助",
    "Close": "关闭",
    "Start": "开始",
    "Train": "训练", "Training": "训练",
    "Test": "测试",
    "Predict": "预测",
    "Make": "进行",
    "Generate": "生成",
    "Convert": "转换", "Converted": "转换后",
    "Copy": "复制",
    "Code": "代码",
    "Result": "结果", "Results": "结果",
    "Tip": "提示",
    "Note": "注",
    "Description": "描述",
    "Information": "信息", "Info": "信息",
    "Success": "成功",
    "Error": "错误", "Errors": "错误",
    "Warning": "警告", "Warnings": "警告",
    "Question": "问题",
    "Message": "消息",
    "Remaining": "剩余",
    "Issues": "问题",
    "Detected": "检测到",
    "Choose": "选择",
    "Action": "操作", "Actions": "操作",
    "Preview": "预览",
    "Changes": "更改",
    "Plot": "图", "Plots": "图",
    "Chart": "图表",
    "Curve": "曲线",
    "Matrix": "矩阵",
    "Score": "分数", "Scores": "分数",
    "Value": "值", "Values": "值",
    "Metric": "指标", "Metrics": "指标",
    "Parameter": "参数", "Parameters": "参数",
    "Grid": "网格",
    "Distributions": "分布", "Distribution": "分布",
    "Ranges": "范围", "Range": "范围",
    "Population": "种群",
    "Generation": "代", "Generations": "代数",
    "Iterations": "迭代次数", "Iteration": "迭代",
    "Components": "成分", "Component": "成分",
    "Estimators": "估计器", "Estimator": "估计器",
    "Trees": "树",
    "Forest": "森林",
    "Boosting": "提升",
    "Rounds": "轮数", "Round": "轮数",
    "Layers": "层",
    "Neurons": "神经元",
    "Epochs": "轮数", "Epoch": "轮数",
    "Depth": "深度",
    "Rate": "比率",
    "Ratio": "比例",
    "Seed": "种子",
    "Threshold": "阈值",
    "Tolerance": "容差",
    "Strength": "强度",
    "Percentage": "百分比",
    "Constant": "常数",
    "Alpha": "Alpha",
    "Sigma": "Sigma",
    "Norm": "范数",
    "Kernel": "核",
    "Linear": "线性",
    "Rbf": "RBF",
    "Sigmoid": "Sigmoid",
    "Spline": "样条",
    "Nearest": "最近邻",
    "Huber": "Huber",
    "Trimmed": "截尾",
    "Mean": "均值",
    "Median": "中位数",
    "Mode": "众数",
    "Maximum": "最大", "Max": "最大",
    "Minimum": "最小", "Min": "最小",
    "Standard": "标准",
    "Robust": "稳健",
    "Simple": "简单",
    "Advanced": "高级",
    "Basic": "基础",
    "Expert": "专家",
    "Custom": "自定义",
    "Adaptive": "自适应",
    "Aggressive": "激进",
    "Conservative": "保守",
    "Classical": "经典",
    "Improved": "改进",
    "Symmetric": "对称",
    "Direct": "直接",
    "Recursive": "递归",
    "Consensus": "共识",
    "Original": "原始",
    "Processed": "处理后",
    "Comparison": "对比",
    "None": "无",
    "Default": "默认",
    "Auto": "自动",
    "Data": "数据",
    "File": "文件", "Files": "文件",
    "Format": "格式",
    "Image": "图像",
    "Dataset": "数据集",
    "Sample": "样本", "Samples": "样本",
    "Index": "索引", "Indices": "索引",
    "Type": "类型", "Types": "类型",
    "Task": "任务", "Tasks": "任务",
    "Target": "目标",
    "Label": "标签",
    "Module": "模块",
    "Source": "来源",
    "Template": "模板",
    "Input": "输入",
    "Output": "输出",
    "Config": "配置", "Configuration": "配置",
    "Settings": "设置", "Setting": "设置",
    "Options": "选项", "Option": "选项",
    "Preferences": "首选项",
    "Guide": "指南",
    "Recommendations": "建议",
    "Algorithms": "算法", "Algorithm": "算法",
    "Model": "模型", "Models": "模型", "Modeling": "建模",
    "System": "系统",
    "Assistant": "助手",
    "Zoom": "缩放",
    "In": "放大",
    "Out": "缩小",
    "History": "历史",
    "Back": "返回",
    "Operation": "操作", "Operations": "操作",
    "Progress": "进度",
    "Status": "状态",
    "Queue": "队列",
    "Current": "当前",
    "Display": "显示",
    "Mode": "模式",
    "Theme": "主题",
    "Available": "可用",
    "Activated": "已激活",
    "Retained": "已保留",
    "Mismatch": "不匹配",
    "Repair": "修复",
    "Force": "强制",
    "Missing": "缺失",
    "Insufficient": "不足",
    "Class": "类别", "Classes": "类别",
    "Names": "名称", "Name": "名称",
    "Count": "数量",
    "Provided": "提供",
    "Using": "使用",
    "Lock": "锁定",
    "Locked": "已锁定",
    "Toggle": "切换",
    "Prevent": "防止", "Prevents": "防止",
    "Intensity": "强度",
    "Artifacts": "伪影",
    "Active": "激活", "Activated": "已激活",
    "Requires": "需要",
    "Temperature": "温度",
    "Tokens": "令牌数", "Token": "令牌",
    "Connection": "连接",
    "Failed": "失败",
    "Passed": "通过",
    "Drop": "删除",
    "Interpolate": "插值", "Interpolation": "插值",
    "Replace": "替换",
    "Affected": "受影响",
    "Rows": "行", "Row": "行",
    "Columns": "列", "Column": "列",
    "Unchanged": "不变",
    "Causing": "导致",
    "Plotting": "绘图",
    "Quality": "质量",
    "Small": "小",
    "Large": "大",
    "May": "可能",
    "Cause": "导致",
    "Proceed": "继续",
    "As-is": "按原样",
    "Best": "最佳",
    "Practices": "实践",
    "Special": "特殊",
    "Placeholder": "占位",
    "Interface": "接口",
    "External": "外部",
    "Meet": "满足", "Meets": "满足",
    "Requirements": "需求", "Requirement": "需求",
    "Before": "之前",
    "Clicking": "点击",
    "Check": "检查",
    "Your": "您的",
    "Different": "不同",
    "Preprocessing": "预处理",
    "Preprocess": "预处理",
    "Unsupervised": "无监督",
    "Enhanced": "增强",
    "Loadings": "载荷",
    "Residual": "残差",
    "Learning": "学习",
    "Confusion": "混淆",
    "Principal": "主",
    "Wavelength": "波长",
    "Convergence": "收敛",
    "Orthogonality": "正交性",
    "Centering": "中心化",
    "Center": "中心",
    "Iterative": "迭代",
    "Refinement": "优化",
    "Deflation": "收缩",
    "Scales": "缩放", "Scale": "缩放",
    "Coefficient": "系数",
    "Correlation": "相关性",
    "Calibration": "校准",
    "Mutual": "互",
    "Under": "下",
    "Curve": "曲线",
    "Score": "分数",
    "Number": "数量",
    "of": "的",
}

PHRASES_SORTED = sorted(PHRASE_ZH.items(), key=lambda kv: len(kv[0]), reverse=True)


def is_passthrough(text):
    if text in PASS_THROUGH:
        return True
    if re.fullmatch(r"\d+(\.\d+)?", text):
        return True
    if text.startswith("http"):
        return True
    if text.startswith("{") and text.endswith("}"):
        return True
    return False


WORD_RE = re.compile(r"[A-Za-z0-9_\-²³]+|[^A-Za-z0-9_\-²³]+")


def replace_phrases(text):
    for phrase, zh in PHRASES_SORTED:
        # case-insensitive replacement with a simple boundary check
        pattern = r"(?<![A-Za-z0-9_\-])" + re.escape(phrase) + r"(?![A-Za-z0-9_\-])"
        text = re.sub(pattern, zh, text, flags=re.IGNORECASE)
    return text


def translate_tokens(text):
    """Translate remaining English word tokens after phrase replacement."""
    tokens = WORD_RE.findall(text)
    out = []
    for tok in tokens:
        if not re.fullmatch(r"[A-Za-z0-9_\-²³]+", tok):
            out.append(tok)
            continue
        if tok in WORD_ZH:
            out.append(WORD_ZH[tok])
        else:
            # try case-insensitive
            low = tok.lower()
            found = None
            for k, v in WORD_ZH.items():
                if k.lower() == low:
                    found = v
                    break
            out.append(found if found else tok)
    return "".join(out)


def normalize_colon(text):
    # Convert a trailing English colon (preceded by non-space or Chinese) to full-width colon.
    if text.rstrip().endswith(":"):
        text = text.rstrip()[:-1] + "："
    return text


def translate_en_to_zh(text, _depth=0):
    if _depth > 5:
        return text
    if not text or not text.strip():
        return text
    if is_passthrough(text):
        return text
    if text in UI_OVERRIDES:
        return UI_OVERRIDES[text]
    if text in PHRASE_ZH:
        return PHRASE_ZH[text]

    # Structural patterns with recursive translation of captured parts.
    patterns = [
        # Number / Maximum / Minimum / Cross-Validation prefixes
        (r"^Number of (.+?):$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "数量："),
        (r"^Maximum (.+?):$", lambda m: "最大" + translate_en_to_zh(m.group(1), _depth+1) + "："),
        (r"^Minimum (.+?):$", lambda m: "最小" + translate_en_to_zh(m.group(1), _depth+1) + "："),
        (r"^Cross-Validation (.+?):$", lambda m: "交叉验证" + translate_en_to_zh(m.group(1), _depth+1) + "："),
        # Verb prefixes
        (r"^Enable (.+?)$", lambda m: "启用" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Apply (.+?)$", lambda m: "应用" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Select (.+?):$", lambda m: "选择" + translate_en_to_zh(m.group(1), _depth+1) + "："),
        (r"^Best (.+?):$", lambda m: "最佳" + translate_en_to_zh(m.group(1), _depth+1) + "："),
        (r"^Save (.+?)$", lambda m: "保存" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Load (.+?)$", lambda m: "加载" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Show (.+?)$", lambda m: "显示" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Extract (.+?)$", lambda m: "提取" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Generate (.+?)$", lambda m: "生成" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Start (.+?)$", lambda m: "开始" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Cancel (.+?)$", lambda m: "取消" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Keep (.+?)$", lambda m: "保持" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Drop (.+?)$", lambda m: "删除" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Remove (.+?)$", lambda m: "移除" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Replace (.+?)$", lambda m: "替换" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Fill (.+?)$", lambda m: "填充" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Toggle (.+?)$", lambda m: "切换" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Open (.+?)$", lambda m: "打开" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Close (.+?)$", lambda m: "关闭" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Make (.+?)$", lambda m: "进行" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Go back to (.+?)$", lambda m: "返回" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Increase (.+?)$", lambda m: "放大" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Decrease (.+?)$", lambda m: "缩小" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Recommended for (.+?)$", lambda m: "推荐用于" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Proceed with (.+?)$", lambda m: "继续使用" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Choose (.+?)$", lambda m: "选择" + translate_en_to_zh(m.group(1), _depth+1)),
        (r"^Please select (.+?)$", lambda m: "请选择" + translate_en_to_zh(m.group(1), _depth+1)),
        # Common suffixes
        (r"^(.+?) Settings$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "设置"),
        (r"^(.+?) Configuration$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "配置"),
        (r"^(.+?) Config$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "配置"),
        (r"^(.+?) Parameters$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "参数"),
        (r"^(.+?) Options$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "选项"),
        (r"^(.+?) Results$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "结果"),
        (r"^(.+?) Metrics$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "指标"),
        (r"^(.+?) Group$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "组"),
        (r"^(.+?) Plot$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "图"),
        (r"^(.+?) Chart$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "图"),
        (r"^(.+?) Curve$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "曲线"),
        (r"^(.+?) Matrix$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "矩阵"),
        (r"^(.+?) Detection$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "检测"),
        (r"^(.+?) Correction$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "校正"),
        (r"^(.+?) Selection$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "选择"),
        (r"^(.+?) Alignment$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "对齐"),
        (r"^(.+?) Elimination$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "消除"),
        (r"^(.+?) Extraction$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "提取"),
        (r"^(.+?) Optimization$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "优化"),
        (r"^(.+?) Evaluation$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "评估"),
        (r"^(.+?) Visualization$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "可视化"),
        (r"^(.+?) Analysis$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "分析"),
        (r"^(.+?) Processing$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "处理"),
        (r"^(.+?) Management$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "管理"),
        (r"^(.+?) Partitioning$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "划分"),
        (r"^(.+?) Importance$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "重要性"),
        (r"^(.+?) Loading$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "加载"),
        (r"^(.+?) Guide$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "指南"),
        # Common label suffixes ending with colon
        (r"^(.+?) Method:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "方法："),
        (r"^(.+?) Algorithm:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "算法："),
        (r"^(.+?) Type:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "类型："),
        (r"^(.+?) Label:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "标签："),
        (r"^(.+?) Metric:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "指标："),
        (r"^(.+?) Format:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "格式："),
        (r"^(.+?) Mode:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "模式："),
        (r"^(.+?) Module:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "模块："),
        (r"^(.+?) Function:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "函数："),
        (r"^(.+?) Threshold:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "阈值："),
        (r"^(.+?) Threshold \(%\):$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "阈值（%）："),
        (r"^(.+?) Ratio:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "比例："),
        (r"^(.+?) Size:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "大小："),
        (r"^(.+?) Length:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "长度："),
        (r"^(.+?) Order:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "阶数："),
        (r"^(.+?) Rate:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "比率："),
        (r"^(.+?) Seed:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "种子："),
        (r"^(.+?) Depth:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "深度："),
        (r"^(.+?) Layers:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "层数："),
        (r"^(.+?) Neurons:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "神经元数："),
        (r"^(.+?) Epochs:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "轮数："),
        (r"^(.+?) Rounds:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "轮数："),
        (r"^(.+?) Trees:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "树数量："),
        (r"^(.+?) Tokens:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "令牌数："),
        (r"^(.+?) Value:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "值："),
        (r"^(.+?) Percentage:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "百分比："),
        (r"^(.+?) Tolerance:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "容差："),
        (r"^(.+?) Strength:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "强度："),
        (r"^(.+?) Start:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "起始："),
        (r"^(.+?) End:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "结束："),
        (r"^(.+?) Folds:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "折数："),
        (r"^(.+?) Components:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "成分数："),
        (r"^(.+?) Generations:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "代数："),
        (r"^(.+?) Iterations:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "迭代次数："),
        (r"^(.+?) Features:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "特征数："),
        (r"^(.+?) Recommendations:$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "建议："),
        (r"^(.+?) Error$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "错误"),
        (r"^(.+?) Warning$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "警告"),
        (r"^(.+?) Success$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "成功"),
        (r"^(.+?) Information$", lambda m: translate_en_to_zh(m.group(1), _depth+1) + "信息"),
    ]

    for pat, repl in patterns:
        m = re.match(pat, text)
        if m:
            return repl(m)

    # phrase + token translation
    translated = replace_phrases(text)
    translated = translate_tokens(translated)
    translated = normalize_colon(translated)
    return translated


def main():
    existing_en = {}
    en_path = TRANS_DIR / "en.json"
    if en_path.exists():
        with en_path.open("r", encoding="utf-8") as f:
            existing_en = json.load(f)

    final_en = dict(existing_en)

    for path in sorted(VIEWS_DIR.glob("*.py")):
        if "副本" in path.name or path.name == "__init__.py":
            continue
        entries = extract_file(path)
        for text, key in entries.items():
            if not text or not text.strip():
                continue
            if re.fullmatch(r"\d+(\.\d+)?", text.strip()):
                continue
            full_key = f"{path.stem}.{key}"
            final_en[full_key] = text

    # Apply English overrides and key renames.
    for old_key, new_val in EN_VALUE_OVERRIDES.items():
        if old_key in final_en:
            final_en[old_key] = new_val
    for old_key, new_key in KEY_RENAMES.items():
        if old_key in final_en:
            final_en[new_key] = final_en.pop(old_key)

    final_en = {k: v for k, v in final_en.items() if v and v.strip()}

    # Build zh.json from final_en values.
    zh = {}
    for k, v in final_en.items():
        zh[k] = translate_en_to_zh(v)

    with (TRANS_DIR / "en.json").open("w", encoding="utf-8") as f:
        json.dump(final_en, f, ensure_ascii=False, indent=4)
        f.write("\n")
    with (TRANS_DIR / "zh.json").open("w", encoding="utf-8") as f:
        json.dump(zh, f, ensure_ascii=False, indent=4)
        f.write("\n")

    print(f"Total keys: {len(final_en)}")
    print(f"English keys: {len(final_en)}")
    print(f"Chinese keys: {len(zh)}")


if __name__ == "__main__":
    main()
