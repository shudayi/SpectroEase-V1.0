import numpy as np
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4, A3
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, Preformatted
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
import os
import sys
import json
import tempfile
from datetime import datetime
from io import BytesIO
from xml.sax.saxutils import escape
from uuid import uuid4
import re

# Page size registry; callers can override via ``generate_report(..., page_size='A4')``.
PAGE_SIZES = {
    'letter': letter,
    'A4': A4,
    'a4': A4,
    'A3': A3,
}

# Default font family. Reportlab built-in fonts are reliable; users can override
# via the settings dialog in future iterations.
DEFAULT_REPORT_FONT = 'Helvetica'


def _header_foreground(background):
    """Choose black or white for readable table headings on a custom theme."""
    rgb = colors.HexColor(background)
    linear = [value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4
              for value in (rgb.red, rgb.green, rgb.blue)]
    luminance = sum(weight * value for weight, value in zip((0.2126, 0.7152, 0.0722), linear))
    return colors.black if luminance > 0.179 else colors.white


@dataclass
class ReportTheme:
    """Theming bundle for the PDF report.

    All fields default to reportlab-friendly values; values can be
    overridden by the caller (e.g. via a Settings dialog future iteration).
    """

    font_name: str = DEFAULT_REPORT_FONT
    title_pt: int = 24
    body_pt: int = 11
    header_pt: int = 10
    section_pt: int = 14
    table_header_bg: str = '#E0E0E0'
    table_alt_bg: str = '#F5F5F5'
    col_widths: tuple = (150, 350)


class SpectrumReportGenerator:
    """Spectrum analysis report generator"""

    def __init__(self, output_dir="reports", page_size='letter',
                 font_name=None, theme: Optional[ReportTheme] = None):
        """
        Initialize report generator

        Args:
            output_dir: Report output directory
            page_size: 'letter' or 'A4'
            font_name: reportlab built-in font name; default Helvetica.
            theme: optional :class:`ReportTheme` overriding the layout.
        """
        self.page_size = page_size
        self.font_name = font_name or DEFAULT_REPORT_FONT
        self.theme = theme or ReportTheme(font_name=self.font_name)
        # Handle exe environment - use absolute path
        if getattr(sys, 'frozen', False):
            # Running as exe
            exe_dir = os.path.dirname(sys.executable)
            self.output_dir = os.path.join(exe_dir, output_dir)
        else:
            # Running as script
            self.output_dir = os.path.abspath(output_dir)

        self._ensure_writable_output_dir()

    def _ensure_writable_output_dir(self):
        """Validate output directory writability and fall back cross-platform."""
        candidates = [self.output_dir]

        # Cross-platform fallback candidates.
        candidates.append(os.path.join(tempfile.gettempdir(), "SpectroEase", "reports"))
        if sys.platform == "win32":
            candidates.append(os.path.join(os.path.expanduser("~"), "Documents", "SpectroEase", "reports"))
        else:
            candidates.append(os.path.join(os.path.expanduser("~"), "SpectroEase", "reports"))

        last_error = None
        for candidate in candidates:
            try:
                os.makedirs(candidate, exist_ok=True)
                probe_path = os.path.join(candidate, ".write_probe")
                with open(probe_path, "w", encoding="utf-8") as probe:
                    probe.write("probe")
                os.remove(probe_path)
                self.output_dir = candidate
                return
            except (OSError, PermissionError, IOError) as exc:
                last_error = exc
                continue

        # If no candidate is writable, raise a clear error.
        raise PermissionError(
            f"Cannot write to any report output directory: {candidates}. Last error: {last_error}"
        )
            
    def generate_report(self,
                       spectra_data: Dict[str, Any],
                       preprocessing_results: Dict[str, Any],
                       feature_extraction_results: Dict[str, Any],
                       analysis_results: Dict[str, Any],
                       reproducibility_info: Optional[Dict[str, Any]] = None,
                       title: str = "Spectral Analysis Report",
                       page_size: Optional[str] = None,
                       font_name: Optional[str] = None,
                       diagnostics: Optional[Dict[str, Any]] = None) -> str:
        """
        Generate analysis report

        Args:
            spectra_data: Spectral data information
            preprocessing_results: Preprocessing results
            feature_extraction_results: Feature extraction results
            analysis_results: Analysis results
            reproducibility_info: Optional reproducibility metadata dictionary
            title: Report title
            page_size: Override the page size (e.g. 'letter' or 'A4')
            font_name: Override the report font family
            diagnostics: Model-aware diagnostic vectors and scientific scope.

        Returns:
            str: Report file path
        """
        # Create PDF document
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_title = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', title).strip(' .') or 'Spectral Analysis Report'
        filename = f"{safe_title[:100]}_{timestamp}_{uuid4().hex[:12]}.pdf"
        chosen_page = PAGE_SIZES.get(page_size or self.page_size, letter)
        chosen_font = font_name or self.font_name
        filepath = os.path.join(self.output_dir, filename)
        doc = SimpleDocTemplate(filepath, pagesize=chosen_page)
        available_width = doc.width
        column_widths = [available_width * width / sum(self.theme.col_widths)
                         for width in self.theme.col_widths]
        
        # Prepare report content
        story = []
        styles = getSampleStyleSheet()
        
        # Add title
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=self.theme.title_pt,
            spaceAfter=30
        )
        story.append(Paragraph(escape(title), title_style))
        
        # Add timestamp
        timestamp_style = ParagraphStyle(
            'Timestamp',
            parent=styles['Normal'],
            fontSize=self.theme.header_pt,
            textColor=colors.gray
        )
        story.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", 
                             timestamp_style))
        story.append(Spacer(1, 20))
        
        # 1. Data Overview
        story.append(Paragraph("1. Data Overview", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        # Add basic data information table
        data_info = [
            ["Data Dimensions", f"{spectra_data.get('shape', 'N/A')}"],
            ["Wavelength Range", f"{spectra_data.get('wavelength_range', 'N/A')}"],
            ["Number of Samples", f"{spectra_data.get('n_samples', 'N/A')}"],
            ["Number of Features", f"{spectra_data.get('n_features', 'N/A')}"]
        ]
        
        # Create table with header row
        t = Table(data_info, colWidths=column_widths)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor(self.theme.table_header_bg)),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), self.theme.font_name + '-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        story.append(t)
        story.append(Spacer(1, 20))
        
        # 2. Preprocessing Results
        story.append(Paragraph("2. Preprocessing Results", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        # Add preprocessing method information
        if preprocessing_results:
            preprocess_info = [["Method", "Parameters"]]  # Add header row
            for method, params in preprocessing_results.items():
                preprocess_info.append([Paragraph(escape(str(method)), styles['Normal']),
                                        Paragraph(escape(str(params)), styles['Normal'])])
                
            t = Table(preprocess_info, colWidths=column_widths, repeatRows=1)
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(self.theme.table_header_bg)),
                ('TEXTCOLOR', (0, 0), (-1, 0), _header_foreground(self.theme.table_header_bg)),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), self.theme.font_name + '-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 11),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
        else:
            preprocess_info = [["No preprocessing methods applied"]]
            t = Table(preprocess_info, colWidths=[available_width])
            t.setStyle(TableStyle([
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, -1), self.theme.font_name + '-Oblique'),
                ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor(self.theme.table_header_bg)),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
        story.append(t)
        story.append(Spacer(1, 20))
        
        # 3. Feature Extraction Results
        story.append(Paragraph("3. Feature Extraction Results", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        # Add feature extraction method information
        if feature_extraction_results and 'No feature selection' not in feature_extraction_results:
            feature_info = [["Method", "Results"]]  # Add header row
            for method, params in feature_extraction_results.items():
                feature_info.append([Paragraph(escape(str(method)), styles['Normal']),
                                     Paragraph(escape(str(params)), styles['Normal'])])
                
            t = Table(feature_info, colWidths=column_widths, repeatRows=1)
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(self.theme.table_header_bg)),
                ('TEXTCOLOR', (0, 0), (-1, 0), _header_foreground(self.theme.table_header_bg)),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), self.theme.font_name + '-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 11),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
        else:
            feature_info = [["No feature selection methods applied"]]
            t = Table(feature_info, colWidths=[available_width])
            t.setStyle(TableStyle([
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, -1), self.theme.font_name + '-Oblique'),
                ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor(self.theme.table_header_bg)),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
        story.append(t)
        story.append(Spacer(1, 20))
        
        # 4. Analysis Results
        story.append(Paragraph("4. Analysis Results", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        # Add analysis results information
        if analysis_results and 'No analysis' not in analysis_results:
            analysis_info = [["Metric", "Value"]]  # Add header row
            for metric, value in analysis_results.items():
                if metric in {'diagnostics', 'task_type', 'schema_version'}:
                    continue
                analysis_info.append([Paragraph(escape(str(metric)), styles['Normal']),
                                      Paragraph(escape(str(value)), styles['Normal'])])
                
            t = Table(analysis_info, colWidths=column_widths, repeatRows=1)
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(self.theme.table_header_bg)),
                ('TEXTCOLOR', (0, 0), (-1, 0), _header_foreground(self.theme.table_header_bg)),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), self.theme.font_name + '-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 11),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
        else:
            analysis_info = [["No modeling or analysis has been performed yet"]]
            t = Table(analysis_info, colWidths=[available_width])
            t.setStyle(TableStyle([
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, -1), self.theme.font_name + '-Oblique'),
                ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor(self.theme.table_header_bg)),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
        story.append(t)

        result_metadata = {key: analysis_results[key] for key in ('task_type', 'schema_version')
                           if analysis_results and key in analysis_results}
        if result_metadata:
            story.append(Spacer(1, 8))
            metadata_text = '; '.join(f'{escape(key)}: {escape(str(value))}'
                                      for key, value in result_metadata.items())
            story.append(Paragraph('Result metadata — ' + metadata_text, styles['Normal']))

        # 5. Reproducibility Information
        if reproducibility_info:
            story.append(Spacer(1, 20))
            story.append(Paragraph("5. Reproducibility Information", styles['Heading2']))
            story.append(Spacer(1, 12))
            from app.services.evaluation_service import EvaluationService
            report_text = EvaluationService.format_reproducibility_report(reproducibility_info)
            story.append(Preformatted(report_text, styles['Code'], maxLineLength=82))

        # Figures are rendered from numeric snapshots by an owned Agg canvas,
        # independent of the currently selected GUI plot or pyplot globals.
        diagnostic_data = diagnostics if diagnostics is not None else (analysis_results or {}).get('diagnostics')
        figures = {}
        if diagnostic_data:
            from app.services.diagnostics_service import diagnostic_figures
            figures.update(diagnostic_figures(diagnostic_data))
        spectra = spectra_data.get('spectra')
        wavelengths = spectra_data.get('wavelengths')
        if spectra is not None and wavelengths is not None:
            from matplotlib.figure import Figure
            from matplotlib.backends.backend_agg import FigureCanvasAgg
            matrix = np.asarray(spectra, dtype=float)
            x = np.asarray(wavelengths, dtype=float)
            if matrix.ndim != 2 or x.ndim != 1 or matrix.shape[1] != len(x):
                raise ValueError('Report spectra rows must match the supplied wavelength axis')
            if not np.isfinite(matrix).all() or not np.isfinite(x).all():
                raise ValueError('Report spectra and wavelengths must be finite')
            fig = Figure(figsize=(6.4, 4.2), constrained_layout=True)
            FigureCanvasAgg(fig)
            ax = fig.subplots()
            # Bound report size while documenting the display subset precisely.
            displayed = matrix[:100]
            ax.plot(x, displayed.T, linewidth=.6, alpha=.5)
            ax.set(title=f'Current spectra: first {len(displayed)} of {len(matrix)} rows',
                   xlabel='Wavelength / wavenumber (imported units)', ylabel='Signal (current representation)')
            figures = {'spectra': fig, **figures}
        if figures:
            story.append(Spacer(1, 20))
            story.append(Paragraph('6. Diagnostic Graphics', styles['Heading2']))
            for name, figure in figures.items():
                buffer = BytesIO()
                try:
                    figure.savefig(buffer, format='png', dpi=150)
                    buffer.seek(0)
                    image_width = min(available_width, 460)
                    story.append(Paragraph(escape(name.replace('_', ' ').title()), styles['Heading3']))
                    figsize = figure.get_size_inches()
                    image_height = image_width * figsize[1] / figsize[0]
                    if image_height > doc.height - 100:
                        image_width *= (doc.height - 100) / image_height
                        image_height = doc.height - 100
                    story.append(Image(buffer, width=image_width, height=image_height))
                    story.append(Spacer(1, 12))
                finally:
                    figure.clear()
        if diagnostic_data:
            story.append(Paragraph('Diagnostic assumptions and availability', styles['Heading3']))
            notes = list(diagnostic_data.get('notes', []))
            for section in ('intervals', 'hotelling'):
                if diagnostic_data.get(section, {}).get('scope'):
                    notes.append(diagnostic_data[section]['scope'])
            notes.extend(f'{key}: {value}' for key, value in diagnostic_data.get('unavailable', {}).items())
            for note in notes:
                story.append(Paragraph(escape(str(note)), styles['Normal']))
                story.append(Spacer(1, 6))

        # Generate PDF
        doc.build(story)

        if diagnostic_data:
            with open(os.path.splitext(filepath)[0] + '_diagnostics.json', 'w', encoding='utf-8') as handle:
                json.dump(diagnostic_data, handle, indent=2, ensure_ascii=False, allow_nan=False)

        # Write sidecar JSON with the same base filename
        if reproducibility_info:
            base_name = os.path.splitext(filename)[0]
            sidecar_path = os.path.join(self.output_dir, f"{base_name}_reproducibility.json")
            try:
                with open(sidecar_path, 'w', encoding='utf-8') as f:
                    json.dump(reproducibility_info, f, indent=2, default=str)
            except Exception as e:
                print(f"Warning: Could not write reproducibility sidecar: {e}")

        return filepath 
