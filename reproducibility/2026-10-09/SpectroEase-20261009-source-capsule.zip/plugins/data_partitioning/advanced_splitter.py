# plugins/data_partitioning/advanced_splitter.py

import sys
import os
# Add project root to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from interfaces.data_partitioning_algorithm import DataPartitioningAlgorithm
import pandas as pd
import numpy as np
from sklearn.model_selection import TimeSeriesSplit, GroupShuffleSplit
from typing import Dict, Any

class AdvancedSplitter(DataPartitioningAlgorithm):
    """Advanced data splitting plugin"""

    def get_name(self) -> str:
        return "Advanced Splitter"

    def get_parameter_info(self) -> Dict[str, Any]:
        return {
            'method': {
                'type': 'str',
                'default': 'time_series',
                'options': ['time_series', 'group_shuffle', 'blocked'],
                'description': 'Advanced splitting method'
            },
            'n_splits': {
                'type': 'int',
                'default': 5,
                'description': 'Number of splits for cross-validation'
            },
            'test_size': {
                'type': 'float',
                'default': 0.2,
                'description': 'Test set size ratio'
            },
            'gap': {
                'type': 'int',
                'default': 0,
                'description': 'Gap between train and test for time series'
            },
            'max_train_size': {
                'type': 'int',
                'default': None,
                'description': 'Maximum training set size'
            }
        }

    def get_params_info(self) -> Dict[str, Any]:
        """Interface-compatible alias used by the plugin loader."""
        return self.get_parameter_info()

    def partition(self, data: pd.DataFrame, params: Dict[str, Any]) -> Dict[str, Any]:
        """Partition data using the selected advanced splitting method."""
        method = params.get('method', 'time_series')
        n_splits = params.get('n_splits', 5)
        test_size = params.get('test_size', 0.2)
        gap = params.get('gap', 0)
        max_train_size = params.get('max_train_size', None)

        X = data.iloc[:, :-1]
        y = data.iloc[:, -1]

        cv_splits = []
        first_split = None

        if method == 'time_series':
            tscv = TimeSeriesSplit(n_splits=n_splits, gap=gap, max_train_size=max_train_size)
            for i, (train_idx, test_idx) in enumerate(tscv.split(X)):
                split = {
                    'fold': i + 1,
                    'X_train': X.iloc[train_idx], 'X_test': X.iloc[test_idx],
                    'y_train': y.iloc[train_idx], 'y_test': y.iloc[test_idx],
                    'train_size': len(train_idx), 'test_size': len(test_idx)
                }
                cv_splits.append(split)
                if first_split is None:
                    first_split = split
        elif method == 'group_shuffle':
            groups = params.get('group_ids')
            if groups is None:
                raise ValueError(
                    "group_shuffle requires an explicitly selected group_id column; "
                    "feature values and row order cannot be used as group identity"
                )
            if hasattr(groups, 'index') and not groups.index.equals(X.index):
                raise ValueError("Explicit group_id values are not aligned to the splitter rows")
            groups = np.asarray(groups)
            if len(groups) != len(X) or pd.isna(groups).any() or any(not str(value).strip() for value in groups):
                raise ValueError("Explicit group_id values must be complete and nonblank")
            if len(np.unique(groups)) < 2:
                raise ValueError("group_shuffle requires at least two unique groups")
            gss = GroupShuffleSplit(n_splits=n_splits, test_size=test_size, random_state=42)
            for i, (train_idx, test_idx) in enumerate(gss.split(X, y, groups)):
                split = {
                    'fold': i + 1,
                    'X_train': X.iloc[train_idx], 'X_test': X.iloc[test_idx],
                    'y_train': y.iloc[train_idx], 'y_test': y.iloc[test_idx],
                    'train_groups': len(np.unique(groups[train_idx])),
                    'test_groups': len(np.unique(groups[test_idx]))
                }
                cv_splits.append(split)
                if first_split is None:
                    first_split = split
        elif method == 'blocked':
            n_samples = len(X)
            n_test = int(n_samples * test_size)
            n_train = n_samples - n_test
            block_size = n_samples // n_splits
            for i in range(n_splits):
                test_start = i * block_size
                test_end = min(test_start + n_test, n_samples)
                test_idx = np.arange(test_start, test_end)
                train_idx = np.concatenate([
                    np.arange(0, test_start),
                    np.arange(test_end, n_samples)
                ])
                if len(train_idx) > n_train:
                    train_idx = np.random.choice(train_idx, n_train, replace=False)
                split = {
                    'fold': i + 1,
                    'X_train': X.iloc[train_idx], 'X_test': X.iloc[test_idx],
                    'y_train': y.iloc[train_idx], 'y_test': y.iloc[test_idx],
                    'block_start': test_start, 'block_end': test_end
                }
                cv_splits.append(split)
                if first_split is None:
                    first_split = split
        else:
            raise ValueError(f"Unknown method: {method}")

        if first_split is None:
            raise ValueError(f"No splits generated for method: {method}")

        return {
            'X_train': first_split['X_train'], 'X_test': first_split['X_test'],
            'y_train': first_split['y_train'], 'y_test': first_split['y_test'],
            'method': method, 'n_splits': n_splits, 'cv_splits': cv_splits
        }

    def apply(self, data: pd.DataFrame, params: Dict[str, Any]) -> Dict[str, Any]:
        """Deprecated alias for partition()."""
        return self.partition(data, params)

    def split_data(self, data: pd.DataFrame, params: dict) -> dict:
        """Deprecated alias for partition()."""
        return self.partition(data, params)
