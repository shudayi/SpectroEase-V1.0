import numpy as np
import pandas as pd
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import StratifiedKFold
from typing import Dict, Any, List, Optional
from scipy.cluster.hierarchy import dendrogram, linkage
import matplotlib.pyplot as plt
from sklearn.metrics import (
    make_scorer, accuracy_score, f1_score, precision_score, recall_score,
    confusion_matrix, mean_squared_error, r2_score, mean_absolute_error
)
from app.utils.data_compatibility import (
    standardize_classification_labels,
    prepare_labels_safely, 
    encode_classification_labels,
    predict_with_encoded_labels,
    normalize_label,
    evaluate_classification
)
from app.utils.label_processor import EnhancedLabelProcessor
import logging
import traceback
from collections import Counter

  
try:
    import sys
    sys.path.append('.')
    from plugins.modeling.sklearn_debug_tracer import install_sklearn_tracers, detect_mixed_types
    install_sklearn_tracers()
    # Debug tracer activated
except ImportError as e:
    print("English text")
    def detect_mixed_types(data, name="data"):
        return False

# Setup logging
logger = logging.getLogger(__name__)

class QualitativeAnalyzer:
    """Qualitative Analysis Class"""
    
    def __init__(self, method: str = 'lda'):
        """
        Initialize qualitative analyzer
        
        Args:
            method: Analysis method ('kmeans', 'hierarchical', 'lda', 'qda', 'svm', 'rf', 'knn', 'dt', 'nn', 'xgboost', 'lightgbm')
        """
        # Standardize method names - allow multiple spellings
        method_mapping = {
            'random_forest': 'rf',
            'randomforest': 'rf',
            'random forest': 'rf',
            'rf': 'rf',
            'knn': 'knn',
            'lda': 'lda',
            'qda': 'qda',
            'svm': 'svm',
            'kmeans': 'kmeans',
            'k-means': 'kmeans',
            'k_means': 'kmeans',
            'hierarchical': 'hierarchical',
            'dt': 'dt',
            'decision_tree': 'dt',
            'decision tree': 'dt',
            'decisiontree': 'dt',
            'nn': 'nn',
            'neural_network': 'nn',
            'neural network': 'nn',
            'neuralnetwork': 'nn',
            'xgboost': 'xgboost',
            'lightgbm': 'lightgbm',
            'logistic': 'logistic',
            'logistic regression': 'logistic',
            'logistic_regression': 'logistic',
            'logisticregression': 'logistic',
        }
        
        # Try to standardize method name
        self.method = method_mapping.get(method.lower(), method)
        logger.debug(f"Initializing QualitativeAnalyzer, method: '{method}' standardized to '{self.method}'")
        
        # Initialize attributes
        self.model = None
        self.scaler = StandardScaler()
        self.imputer = None
        self.fitted_predictor = None
        self.input_representation = 'fitted_feature_matrix'
        self.model_params = {}
        self.task_type = 'classification'  # Explicitly mark task type as classification
        
        # **CRITICAL FIX: Initialize enhanced label processor for consistent handling**
        self.label_processor = EnhancedLabelProcessor()
        print("QualitativeAnalyzer initialized with EnhancedLabelProcessor")
        
        # If method name is invalid, log warning but don't raise error immediately (delay until fit)
        valid_methods = [k for k in method_mapping.values()]
        if self.method not in valid_methods:
            logger.warning(f"Warning: '{self.method}' is not a valid method name. Valid methods are: {set(valid_methods)}")
        
    def fit(self, X: np.ndarray, y: np.ndarray, **kwargs) -> None:
        """
        Train the model
        
        Args:
            X: Input features
            y: Target labels
            **kwargs: Additional parameters for the model
        """
        global pd
        
        logger.debug(f"Fitting model with method {self.method}")
        
        # Check if input data is empty
        if X is None or len(X) == 0:
            logger.error("Input features cannot be empty")
            raise ValueError("Input features cannot be empty")
            
        if y is None or len(y) == 0:
            logger.error("Target labels cannot be empty")
            raise ValueError("Target labels cannot be empty")
            
        # Preserve the fitting boundary and identity scope before conversion.
        feature_names = list(X.columns) if isinstance(X, pd.DataFrame) else kwargs.pop('feature_names', None)
        fit_row_ids = kwargs.pop('row_ids', None)
        fit_physical_sample_ids = kwargs.pop('physical_sample_ids', None)
        fit_group_ids = kwargs.pop('group_ids', None)
        group_validation = kwargs.pop('group_validation', False)
        self.input_representation = kwargs.pop('input_representation', 'fitted_feature_matrix')
        kwargs.pop('task_type', None)
        kwargs.pop('feature_names', None)
        self.model_params = dict(kwargs)
        if isinstance(X, pd.DataFrame):
            X = X.to_numpy()

        # Fit imputation and scaling on outer-training rows only. Prediction
        # batches use this saved state instead of batch-dependent means.
        from sklearn.impute import SimpleImputer
        self.imputer = SimpleImputer(strategy='mean', keep_empty_features=True)
        X_imputed = self.imputer.fit_transform(np.asarray(X, dtype=float))
        X_scaled = self.scaler.fit_transform(X_imputed)
        
        # **CRITICAL FIX: Standardize label processing, remove spaces and other inconsistencies**

        
        # Preserve homogeneous numeric class labels; stringify only text/mixed
        # vocabularies so inverse decoding restores the original label domain.
        y_values = np.asarray(y).reshape(-1)
        if y_values.dtype.kind in 'iufb':
            y_clean = y_values
        else:
            y_clean = np.asarray([str(label).strip() for label in y_values], dtype=str)
        

        
        # Use sklearn LabelEncoder for standardized encoding
        from sklearn.preprocessing import LabelEncoder
        self.label_encoder = LabelEncoder()
        y_encoded = self.label_encoder.fit_transform(y_clean)
        
        # Create bidirectional mapping for debugging and validation
        self.label_forward_map = {label: idx for idx, label in enumerate(self.label_encoder.classes_)}
        self.label_inverse_map = {idx: label for idx, label in enumerate(self.label_encoder.classes_)}
        



        
        # Validate mapping consistency
        assert len(self.label_forward_map) == len(self.label_inverse_map), "Mapping table length inconsistent"
        assert len(self.label_encoder.classes_) == len(np.unique(y_encoded)), "Encoded category count inconsistent"
        
        self.task_type = 'classification'
        
        try:
            # Create model based on method
            self.model = self._create_model(y_encoded)
            
            # Fit the model
            self.model.fit(X_scaled, y_encoded)

            from app.services.prediction_contract import FittedSpectrumPredictor
            self.fitted_predictor = FittedSpectrumPredictor(
                estimator=self.model,
                task_type=self.task_type,
                imputer=self.imputer,
                x_scaler=self.scaler,
                label_encoder=self.label_encoder,
                feature_names=feature_names,
                n_features=X.shape[1],
                fit_row_ids=fit_row_ids,
                fit_physical_sample_ids=fit_physical_sample_ids,
                fit_group_ids=fit_group_ids,
                group_validation=group_validation,
                input_representation=self.input_representation,
            )
            
            # Verify model classes match our encoding
            if hasattr(self.model, 'classes_'):
                print(f"OK:Model training completed:")
                print(f"   Model recognized classes: {len(self.model.classes_)}")
                print(f"   Model class range: {self.model.classes_.min()}-{self.model.classes_.max()}")
                
                # Verify model classes match our encoding
                expected_classes = np.arange(len(self.label_encoder.classes_))
                if not np.array_equal(sorted(self.model.classes_), sorted(expected_classes)):
                    logger.warning(f"Model classes do not match expected classes: model={sorted(self.model.classes_)}, expected={sorted(expected_classes)}")
        except Exception as e:
            logger.error(f"Error during model training: {str(e)}")
            raise
            
    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Make predictions on new data
        
        Args:
            X: Input features for prediction
            
        Returns:
            Predicted labels in original format
        """
        if self.fitted_predictor is not None:
            return self.fitted_predictor.predict(X)

        if self.model is None:
            logger.error("Model has not been trained yet")
            raise ValueError("Model has not been trained yet")
        
        logger.debug("Making predictions on new data")
        
        X_scaled = self.scaler.transform(self.imputer.transform(np.asarray(X, dtype=float)))
        
        # Make predictions
        predictions = self.model.predict(X_scaled)
        
        # **CRITICAL FIX: Use standard LabelEncoder for inverse transformation**
        print(f"Raw prediction results:")
        print(f"   Type: {type(predictions)}, dtype: {predictions.dtype}")
        print(f"   Shape: {predictions.shape}")
        print(f"   Unique values: {np.unique(predictions)}")
        print(f"   Samples: {predictions[:10]}")
        
        # Use stored LabelEncoder for inverse transformation
        if hasattr(self, 'label_encoder') and self.label_encoder is not None:
            print(f"Found LabelEncoder, converting integer indices to original labels")
            
            try:
                # Convert integer prediction results back to original labels
                predictions_original = self.label_encoder.inverse_transform(predictions)
                
                print(f"OK:Converted prediction results:")
                print(f"   Type: {type(predictions_original)}, dtype: {predictions_original.dtype}")
                print(f"   Unique values: {np.unique(predictions_original)}")
                print(f"   Samples: {predictions_original[:10]}")
                
                logger.info(f"Final predictions type: {type(predictions_original)}, dtype: {predictions_original.dtype}")
                return predictions_original
                
            except Exception as e:
                print(f"Error:LabelEncoder inverse transform failed: {e}")
                print(f"   Prediction range: {predictions.min()} - {predictions.max()}")
                print(f"   Encoder range: 0 - {len(self.label_encoder.classes_) - 1}")
                
                # Try manual mapping as backup option
                if hasattr(self, 'label_inverse_map') and self.label_inverse_map:
                    print("Attempting manual mapping as fallback")
                    try:
                        converted_predictions = []
                        for pred in predictions:
                            pred_int = int(pred)
                            if pred_int in self.label_inverse_map:
                                converted_predictions.append(self.label_inverse_map[pred_int])
                            else:
                                # Find closest mapping
                                available_keys = list(self.label_inverse_map.keys())
                                closest_key = min(available_keys, key=lambda x: abs(x - pred_int))
                                print(f"Warning:Using closest mapping for {pred_int}: {closest_key} -> {self.label_inverse_map[closest_key]}")
                                converted_predictions.append(self.label_inverse_map[closest_key])
                        
                        predictions_manual = np.array(converted_predictions, dtype='<U50')
                        print(f"OK:Manual mapping successful: {predictions_manual[:5]}")
                        return predictions_manual
                        
                    except Exception as manual_error:
                        print(f"Error:Manual mapping also failed: {manual_error}")
        else:
            print("Error:No LabelEncoder found, this will cause conversion errors!")
            print(f"   Available attributes: {[attr for attr in dir(self) if 'label' in attr.lower()]}")
        
        # Final fallback: return original prediction results
        print("Warning:Returning raw predictions as fallback")
        logger.info(f"Final predictions type: {type(predictions)}, dtype: {predictions.dtype}")
        return predictions
    
    def predict_result(self, X, row_ids=None, physical_sample_ids=None,
                       group_ids=None, enforce_disjoint=True):
        if self.fitted_predictor is None:
            raise ValueError("Model not trained")
        return self.fitted_predictor.predict_result(
            X, row_ids=row_ids, physical_sample_ids=physical_sample_ids,
            group_ids=group_ids, enforce_disjoint=enforce_disjoint,
        )

    def predict_raw(self, X, **identity):
        if self.fitted_predictor is None:
            raise ValueError("Model not trained")
        return self.fitted_predictor.predict_raw(X, **identity)

    def cross_validate(self, X: np.ndarray, y: np.ndarray, cv: int = 5,
                       sample_ids=None, outer_test_sample_ids=None,
                       unsafe_transform_reason: Optional[str] = None,
                       physical_sample_ids=None, outer_test_physical_sample_ids=None,
                       group_ids=None, outer_test_group_ids=None,
                       group_validation: bool = False) -> Dict[str, Any]:
        """Evaluate a classifier with every learned transform scoped to a fold.

        ``fit`` remains the final outer-training fit used for the held-out test
        prediction.  This method deliberately clones the configured estimator
        and fits a fresh imputer, scaler, label encoder, and estimator on each
        inner training fold.  It never reuses ``self.scaler`` from ``fit``.
        """
        global pd
        self.last_cv_fit_trace = []
        if unsafe_transform_reason:
            raise ValueError(
                "Cross-validation is unavailable because this transform is not fold-safe: "
                f"{unsafe_transform_reason}"
            )

        if isinstance(X, pd.DataFrame):
            inferred_ids = list(X.index)
        else:
            inferred_ids = list(range(len(X)))
        fit_sample_ids = list(sample_ids) if sample_ids is not None else inferred_ids
        test_sample_ids = (
            list(outer_test_sample_ids) if outer_test_sample_ids is not None else []
        )
        if len(fit_sample_ids) != len(X):
            raise ValueError("sample_ids must match the number of CV rows")
        if len(set(fit_sample_ids)) != len(fit_sample_ids):
            raise ValueError("sample_ids must be unique within the outer training set")
        overlap = set(fit_sample_ids).intersection(test_sample_ids)
        if overlap:
            raise ValueError(
                "Outer-test sample identities overlap the CV training input: "
                f"{sorted(map(str, overlap))[:5]}"
            )

        groups = self._validate_cv_groups(
            len(X), group_ids, outer_test_group_ids, physical_sample_ids,
            outer_test_physical_sample_ids, cv, group_validation,
        )

        from sklearn.base import clone
        from sklearn.impute import SimpleImputer
        from sklearn.metrics import (
            accuracy_score, classification_report, confusion_matrix,
            f1_score, precision_score, recall_score,
        )
        from sklearn.model_selection import StratifiedKFold
        if group_validation:
            from sklearn.model_selection import StratifiedGroupKFold
        from sklearn.preprocessing import LabelEncoder

        try:
            X_array = np.asarray(X, dtype=float)
            raw_labels = np.asarray(y)
            if X_array.ndim != 2 or raw_labels.ndim != 1 or len(X_array) != len(raw_labels):
                raise ValueError("X and y must be a 2D feature matrix and an aligned 1D label vector")
            if raw_labels.dtype.kind in 'iufb':
                labels = raw_labels
            else:
                labels = np.asarray([str(value).strip() for value in raw_labels], dtype=str)
            classes, class_counts = np.unique(labels, return_counts=True)
            if len(classes) < 2:
                raise ValueError("Classification cross-validation requires at least two classes")
            if int(class_counts.min()) < cv:
                raise ValueError(
                    f"Cannot run {cv}-fold stratified CV: each class needs at least {cv} rows"
                )

            if group_validation:
                group_frame = pd.DataFrame({'label': labels, 'group': groups})
                groups_per_class = group_frame.drop_duplicates().groupby('label')['group'].nunique()
                if (groups_per_class < cv).any():
                    raise ValueError(
                        f"Each class must occur in at least {cv} groups for stratified group CV; "
                        f"found {groups_per_class.to_dict()}"
                    )
                splitter = StratifiedGroupKFold(n_splits=cv, shuffle=True, random_state=42)
                fold_iter = splitter.split(X_array, labels, groups=groups)
            else:
                splitter = StratifiedKFold(n_splits=cv, shuffle=True, random_state=42)
                fold_iter = splitter.split(X_array, labels)
            predictions = np.empty(len(labels), dtype=object)
            self.task_type = 'classification'
            all_forward = {label: index for index, label in enumerate(classes.tolist())}
            self.current_label_mapping = {
                'forward': all_forward,
                'inverse': {value: key for key, value in all_forward.items()},
            }

            for fold_index, (train_idx, validation_idx) in enumerate(
                    fold_iter, start=1):
                X_fold_train = X_array[train_idx]
                X_fold_validation = X_array[validation_idx]
                y_fold_train = labels[train_idx]
                y_fold_validation = labels[validation_idx]

                # The category vocabulary is also learned from this fold's
                # training labels; an unseen validation class fails closed.
                fold_encoder = LabelEncoder()
                y_fold_train_encoded = fold_encoder.fit_transform(y_fold_train)
                y_fold_validation_encoded = fold_encoder.transform(y_fold_validation)

                imputer = SimpleImputer(strategy='mean', keep_empty_features=True)
                X_fold_train_imputed = imputer.fit_transform(X_fold_train)
                X_fold_validation_imputed = imputer.transform(X_fold_validation)

                scaler = StandardScaler()
                X_fold_train_scaled = scaler.fit_transform(X_fold_train_imputed)
                X_fold_validation_scaled = scaler.transform(X_fold_validation_imputed)

                if self.model is None:
                    estimator = self._create_model(y_fold_train_encoded)
                else:
                    estimator = clone(self.model)
                estimator.fit(X_fold_train_scaled, y_fold_train_encoded)
                encoded_predictions = np.asarray(estimator.predict(X_fold_validation_scaled))
                fold_predictions = fold_encoder.inverse_transform(encoded_predictions.astype(int))
                predictions[validation_idx] = fold_predictions

                train_ids = [fit_sample_ids[int(index)] for index in train_idx]
                validation_ids = [fit_sample_ids[int(index)] for index in validation_idx]
                trace_item = {
                    'fold': fold_index,
                    'transformer_fit_sample_ids': list(train_ids),
                    'transformer_names': ['LabelEncoder', 'SimpleImputer', 'StandardScaler'],
                    'transformer_fit_sample_ids_by_name': {
                        'LabelEncoder': list(train_ids),
                        'SimpleImputer': list(train_ids),
                        'StandardScaler': list(train_ids),
                    },
                    'estimator_fit_sample_ids': list(train_ids),
                    'validation_sample_ids': list(validation_ids),
                }
                if group_validation:
                    train_groups = [groups[int(index)] for index in train_idx]
                    validation_groups = [groups[int(index)] for index in validation_idx]
                    if set(train_groups) & set(validation_groups):
                        raise ValueError("Group-aware CV placed one group in both fit and validation folds")
                    trace_item.update({
                        'train_group_ids': sorted(set(map(str, train_groups))),
                        'validation_group_ids': sorted(set(map(str, validation_groups))),
                        'train_physical_sample_ids': sorted(set(map(str, [physical_sample_ids[int(i)] for i in train_idx]))) if physical_sample_ids is not None else [],
                        'validation_physical_sample_ids': sorted(set(map(str, [physical_sample_ids[int(i)] for i in validation_idx]))) if physical_sample_ids is not None else [],
                    })
                self.last_cv_fit_trace.append(trace_item)

            if labels.dtype.kind in 'iufb':
                predictions = predictions.astype(labels.dtype)
            else:
                predictions = predictions.astype(str)

            accuracy = accuracy_score(labels, predictions)
            precision = precision_score(labels, predictions, average='weighted', zero_division=0)
            recall = recall_score(labels, predictions, average='weighted', zero_division=0)
            f1 = f1_score(labels, predictions, average='weighted', zero_division=0)
            return {
                'accuracy': float(accuracy),
                'precision': float(precision),
                'recall': float(recall),
                'f1_score': float(f1),
                'classification_report': classification_report(
                    labels, predictions, labels=classes.tolist(),
                    target_names=[str(value) for value in classes.tolist()], zero_division=0,
                ),
                'confusion_matrix': confusion_matrix(
                    labels, predictions, labels=classes.tolist(),
                ).tolist(),
                'task_type': 'classification',
                'cv_folds': cv,
                'n_samples': len(labels),
                'n_classes': len(classes),
                'diagnosis': None,
                'cv_available': True,
                'group_validation': bool(group_validation),
                'predictions': predictions.tolist(),
                'target': labels.tolist(),
                'cv_predictions': predictions.tolist(),
                'cv_target': labels.tolist(),
                'cv_row_ids': list(fit_sample_ids),
                'cv_physical_sample_ids': list(physical_sample_ids) if physical_sample_ids is not None else None,
                'cv_group_ids': list(group_ids) if group_ids is not None else None,
                'cv_fit_trace': list(self.last_cv_fit_trace),
            }
        except Exception as exc:
            self.last_cv_fit_trace = list(self.last_cv_fit_trace)
            logger.error("Fold-safe cross-validation failed: %s", exc)
            raise ValueError(f"Fold-safe classification CV failed: {exc}") from exc

    @staticmethod
    def _validate_cv_groups(n_rows, group_ids, outer_test_group_ids,
                            physical_sample_ids, outer_test_physical_sample_ids,
                            n_splits, group_validation):
        if not group_validation:
            return None
        if group_ids is None:
            raise ValueError("Group validation was requested but no explicit group_id values reached CV")
        groups = [str(value).strip() if value is not None else '' for value in group_ids]
        if len(groups) != n_rows or any(not value or value.lower() in {'nan', 'none', '<na>'} for value in groups):
            raise ValueError("group_id values must be complete, nonblank, and aligned to training rows")
        if len(set(groups)) < n_splits:
            raise ValueError(f"Group CV needs at least {n_splits} unique groups; found {len(set(groups))}")
        test_groups = [str(value).strip() for value in (list(outer_test_group_ids) if outer_test_group_ids is not None else [])]
        if set(groups) & set(test_groups):
            raise ValueError("Outer-test group IDs overlap the inner-CV training groups")
        if physical_sample_ids is not None:
            samples = [str(value).strip() if value is not None else '' for value in physical_sample_ids]
            if len(samples) != n_rows or any(not value or value.lower() in {'nan', 'none', '<na>'} for value in samples):
                raise ValueError("sample_id values must be complete, nonblank, and aligned to training rows")
            mapping = {}
            for sample, group in zip(samples, groups):
                if sample in mapping and mapping[sample] != group:
                    raise ValueError("A sample_id maps to multiple group_id values")
                mapping[sample] = group
            outer_samples = [str(value).strip() for value in (list(outer_test_physical_sample_ids) if outer_test_physical_sample_ids is not None else [])]
            if set(samples) & set(outer_samples):
                raise ValueError("Outer-test physical sample IDs overlap the inner-CV training samples")
        return groups

    def _create_model(self, y=None):
        """Preserve the selected algorithm and apply its declared parameters."""
        model = self._create_default_model(y)
        if self.model_params:
            model.set_params(**self.model_params)
        return model

    def _create_default_model(self, y=None):
        """Create a model with optimized parameters for spectral data classification"""
        if self.method == 'logistic':
            from sklearn.linear_model import LogisticRegression
            return LogisticRegression(C=1.0, max_iter=1000, random_state=42)
        elif self.method == 'kmeans':
            # Use silhouette analysis to determine optimal number of clusters if not specified
            # Default to 3 clusters if analysis fails or number is not determined
            try:
                if hasattr(self, 'n_clusters'):
                    return KMeans(n_clusters=self.n_clusters, random_state=42, n_init=10, max_iter=500)
                else:
                    return KMeans(n_clusters=3, random_state=42, n_init=10, max_iter=500)
            except:
                return KMeans(n_clusters=3, random_state=42, n_init=10, max_iter=500)
                
        elif self.method == 'hierarchical':
            try:
                if hasattr(self, 'n_clusters'):
                    return AgglomerativeClustering(n_clusters=self.n_clusters, linkage='ward')
                else:
                    return AgglomerativeClustering(n_clusters=3, linkage='ward')
            except:
                return AgglomerativeClustering(n_clusters=3, linkage='ward')
                
        elif self.method == 'lda':
            # **OPTIMIZED: Linear Discriminant Analysis for spectral data**
            return LinearDiscriminantAnalysis(
                solver='svd',  # more stable for high-dimensional data
                shrinkage=None,  # automatic shrinkage
                store_covariance=True,
                tol=1e-6  # improve precision
            )
            
        elif self.method == 'qda':
            # **OPTIMIZED: Quadratic Discriminant Analysis**
            return QuadraticDiscriminantAnalysis(
                reg_param=0.01,  # add regularization to prevent overfitting
                store_covariance=True,
                tol=1e-6
            )
            
        elif self.method == 'svm':
            # **OPTIMIZED FOR SPECTRAL DATA: Enhanced SVM parameters**
            return SVC(
                C=1.0,                     # moderate regularization parameter
                kernel='rbf',              # RBF kernel suitable for nonlinear relationships in spectral data
                gamma='scale',             # Automatically adjust gamma, adapt to data dimensions
                probability=True,          # Enable probability prediction
                random_state=42,
                class_weight='balanced',   # handle imbalanced data
                tol=1e-4,                 # improve convergence precision
                cache_size=500,           # increase cache, improve training speed
                max_iter=5000             # increase maximum iterations
            )
            
        elif self.method in ['rf', 'random_forest']:
            # **OPTIMIZED FOR SPECTRAL DATA: Enhanced Random Forest parameters**
            return RandomForestClassifier(
                n_estimators=500,          # increase number of trees for better accuracy
                max_depth=20,              # limit depth to prevent overfitting
                min_samples_split=5,       # prevent overfitting
                min_samples_leaf=2,        # prevent overfitting
                max_features='sqrt',       # suitable for high-dimensional spectral data
                bootstrap=True,
                random_state=42,
                class_weight='balanced',   # handle imbalanced data
                oob_score=True,           # enable out-of-bag scoring
                n_jobs=-1,                # parallel computing
                criterion='gini',         # Gini impurity
                warm_start=False
            )
            
        elif self.method == 'knn':
            # **OPTIMIZED FOR SPECTRAL DATA: Enhanced KNN parameters**
            return KNeighborsClassifier(
                n_neighbors=7,             # increase neighbors, improve stability
                weights='distance',        # distance weighting, suitable for spectral data
                algorithm='auto',          # automatically select optimal algorithm
                leaf_size=20,             # optimize tree structure
                p=2,                      # Euclidean distance
                metric='minkowski',       # Minkowski distance
                n_jobs=-1                 # parallel computing
            )
            
        elif self.method in ['dt', 'decision_tree']:
            # **OPTIMIZED FOR SPECTRAL DATA: Enhanced Decision Tree parameters**
            return DecisionTreeClassifier(
                max_depth=20,             # increase maximum depth, adapt to complex spectral patterns
                random_state=42,
                class_weight='balanced',  # handle imbalanced data
                criterion='gini',         # Gini impurity
                splitter='best',          # optimal split
                min_samples_split=5,      # prevent overfitting
                min_samples_leaf=2,       # prevent overfitting
                max_features='sqrt',      # feature subset selection, suitable for high-dimensional data
                max_leaf_nodes=None
            )
            
        elif self.method in ['nn', 'neural_network', 'mlp']:
            # **OPTIMIZED FOR SPECTRAL DATA: Enhanced Neural Network parameters**
            from sklearn.neural_network import MLPClassifier
            return MLPClassifier(
                hidden_layer_sizes=(300, 150, 75),  # increase network capacity
                activation='relu',                   
                solver='adam',                       
                alpha=0.0001,                       # reduce regularization, allow better fitting
                batch_size='auto',
                learning_rate='adaptive',           
                learning_rate_init=0.001,           # lower learning rate, more stable training
                max_iter=2000,                      # increase training rounds
                shuffle=True,
                random_state=42,
                tol=1e-6,                          
                verbose=False,
                warm_start=False,
                early_stopping=True,               
                validation_fraction=0.1,
                beta_1=0.9,
                beta_2=0.999,
                n_iter_no_change=50                # increase early stopping patience
            )
            
        elif self.method == 'xgboost':
            # **OPTIMIZED FOR SPECTRAL DATA: Enhanced XGBoost parameters**
            try:
                import xgboost as xgb
                
                # Auto-detect number of classes
                if hasattr(y, 'nunique'):
                    num_classes = y.nunique()
                else:
                    num_classes = len(np.unique(y))
                
                # Choose objective function based on number of classes
                if num_classes == 2:
                    objective = 'binary:logistic'
                    eval_metric = 'logloss'
                else:
                    objective = 'multi:softprob'
                    eval_metric = 'mlogloss'
                
                return xgb.XGBClassifier(
                    n_estimators=200,              # increase number of trees
                    max_depth=6,                   # moderate tree depth to avoid overfitting
                    learning_rate=0.05,            # lower learning rate for better accuracy
                    subsample=0.8,                 # subsample ratio
                    colsample_bytree=0.8,          # feature subsampling
                    random_state=42,
                    n_jobs=-1,                     # parallel computing
                    reg_alpha=0.1,                 # L1 regularization
                    reg_lambda=1.0,                # enhanced L2 regularization
                    objective=objective,           # dynamic objective function selection
                    eval_metric=eval_metric,       # dynamic evaluation metric selection
                    num_class=num_classes if num_classes > 2 else None  # specify number of classes for multiclass
                )
            except ImportError as error:
                raise ImportError('XGBoost is not installed; the selected algorithm cannot run.') from error
                
        elif self.method == 'lightgbm':
            # **OPTIMIZED FOR SPECTRAL DATA: Enhanced LightGBM parameters**
            try:
                import lightgbm as lgb
                
                # Auto-detect number of classes
                if hasattr(y, 'nunique'):
                    num_classes = y.nunique()
                else:
                    num_classes = len(np.unique(y))
                
                # Choose objective function based on number of classes
                if num_classes == 2:
                    objective = 'binary'
                    metric = 'binary_logloss'
                else:
                    objective = 'multiclass'
                    metric = 'multi_logloss'
                
                return lgb.LGBMClassifier(
                    n_estimators=300,              # increase number of trees for better accuracy
                    max_depth=8,                   # moderate tree depth
                    learning_rate=0.05,            # lower learning rate for better accuracy
                    num_leaves=31,                 # number of leaf nodes
                    subsample=0.8,                 # subsample ratio
                    colsample_bytree=0.8,          # feature subsampling
                    random_state=42,
                    n_jobs=-1,                     # parallel computing
                    reg_alpha=0.1,                 # L1 regularization
                    reg_lambda=1.0,                # enhanced L2 regularization
                    class_weight='balanced',       # handle imbalanced data
                    objective=objective,           # dynamic objective function selection
                    metric=metric,                 # dynamic evaluation metric selection
                    num_class=num_classes if num_classes > 2 else 1,
                    verbose=-1,                    # silent mode
                    min_child_samples=20,          # prevent overfitting
                    min_split_gain=0.1             # prevent overfitting
                )
            except ImportError as error:
                raise ImportError('LightGBM is not installed; the selected algorithm cannot run.') from error
        else:
            raise ValueError(f"Unsupported method: {self.method}")
    
    def _create_model_fallback(self, fallback_method='rf'):
        """Create fallback model when preferred method is not available"""
        logger.info(f"Creating fallback model: {fallback_method}")
        original_method = self.method
        self.method = fallback_method
        model = self._create_model()
        self.method = original_method  # Restore original method
        return model
    
    def plot_dendrogram(self, X: np.ndarray) -> None:
        """
        Plot hierarchical clustering dendrogram
        
        Args:
            X: Input features
        """
        if self.method != 'hierarchical':
            raise ValueError("Only hierarchical clustering method supports dendrograms")
            
        X_scaled = self.scaler.fit_transform(X)
        
        # Handle NaN values in X_scaled if any
        if np.isnan(X_scaled).any():
            logger.warning("NaN values found in scaled data for dendrogram. Filling with column means.")
            # For each column with NaN values, replace with column mean
            col_means = np.nanmean(X_scaled, axis=0)
            inds = np.where(np.isnan(X_scaled))
            X_scaled[inds] = np.take(col_means, inds[1])
        
        linkage_matrix = linkage(X_scaled, method='ward')
        
        plt.figure(figsize=(10, 7))
        dendrogram(linkage_matrix)
        plt.title('Hierarchical Clustering Dendrogram')
        plt.xlabel('Sample Index')
        plt.ylabel('Distance')
        plt.show()
    
    def get_model_params(self) -> Dict[str, Any]:
        """
        Get model parameters
        
        Returns:
            Dict[str, Any]: Model parameters
        """
        if self.model is None:
            return {}
            
        # Need to handle different data types properly for parameters
        # Return only serializable parameters
        params = {}
        
        try:
            if self.method == 'kmeans':
                params = {
                    'n_clusters': self.model.n_clusters,
                }
                # Convert numpy arrays to lists for JSON serialization
                if hasattr(self.model, 'cluster_centers_'):
                    centers = self.model.cluster_centers_
                    if isinstance(centers, np.ndarray):
                        params['cluster_centers_shape'] = centers.shape
                    else:
                        params['cluster_centers_'] = 'Not available as numpy array'
                        
                if hasattr(self.model, 'labels_'):
                    labels = self.model.labels_
                    if isinstance(labels, np.ndarray):
                        params['num_labels'] = len(labels)
                        params['unique_labels'] = len(np.unique(labels))
                    else:
                        params['labels_'] = 'Not available as numpy array'
                        
            elif self.method == 'hierarchical':
                params = {
                    'n_clusters': self.model.n_clusters,
                }
                if hasattr(self.model, 'labels_'):
                    labels = self.model.labels_
                    if isinstance(labels, np.ndarray):
                        params['num_labels'] = len(labels)
                        params['unique_labels'] = len(np.unique(labels))
                    else:
                        params['labels_'] = 'Not available as numpy array'
                        
            elif self.method == 'rf':
                params = {
                    'n_estimators': self.model.n_estimators,
                }
                if hasattr(self.model, 'max_depth'):
                    params['max_depth'] = self.model.max_depth
                    
                if hasattr(self.model, 'feature_importances_'):
                    # Convert feature importance array to list for safe serialization
                    feature_importances = self.model.feature_importances_
                    if isinstance(feature_importances, np.ndarray):
                        params['feature_importances_shape'] = feature_importances.shape
                        # Include top 5 feature importance values
                        if len(feature_importances) > 0:
                            top_indices = np.argsort(feature_importances)[-5:]
                            params['top5_feature_indices'] = top_indices.tolist()
                            params['top5_feature_importances'] = feature_importances[top_indices].tolist()
                else:
                    params['feature_importances_'] = 'Not available as numpy array'
            else:
                # Get basic parameters that should be available on most models
                basic_params = self.model.get_params()
                # Filter out complex objects that might not be JSON serializable
                for key, value in basic_params.items():
                    if isinstance(value, (int, float, str, bool, type(None))):
                        params[key] = value
                    elif isinstance(value, (list, tuple)) and all(isinstance(x, (int, float, str, bool, type(None))) for x in value):
                        params[key] = list(value)
                    else:
                        params[key] = str(type(value))
        except Exception as e:
            logger.error(f"Error extracting model parameters: {str(e)}")
            params['error'] = str(e)
                
        return params 

    def diagnose_low_accuracy(self, X, y, accuracy_threshold=0.3):
        """
        Diagnose possible causes of low accuracy
        
        Args:
            X: Feature data
            y: Label data
            accuracy_threshold: Accuracy threshold for triggering diagnosis
            
        Returns:
            dict: Diagnosis results and suggestions
        """
        diagnosis = {
            'issues': [],
            'suggestions': [],
            'data_stats': {},
            'model_issues': []
        }
        
        try:
            # 1. Data quality checks
            diagnosis['data_stats']['n_samples'] = len(X)
            diagnosis['data_stats']['n_features'] = X.shape[1] if hasattr(X, 'shape') else len(X[0])
            diagnosis['data_stats']['n_classes'] = len(np.unique(y))
            
            # Check if sample size is sufficient
            if len(X) < 100:
                diagnosis['issues'].append("Insufficient sample size")
                diagnosis['suggestions'].append("Increase training sample size, recommend at least 100 samples")
            
            # Check if feature dimensionality is too high
            if X.shape[1] > len(X):
                diagnosis['issues'].append("High feature dimensionality (curse of dimensionality)")
                diagnosis['suggestions'].append("Use feature selection or dimensionality reduction techniques")
            
            # Check class balance
            unique, counts = np.unique(y, return_counts=True)
            class_distribution = dict(zip(unique, counts))
            diagnosis['data_stats']['class_distribution'] = class_distribution
            
            min_count = min(counts)
            max_count = max(counts)
            imbalance_ratio = max_count / min_count if min_count > 0 else float('inf')
            
            if imbalance_ratio > 10:
                diagnosis['issues'].append("Severe class imbalance")
                diagnosis['suggestions'].append("Use class weights, oversampling, or undersampling techniques")
            elif imbalance_ratio > 3:
                diagnosis['issues'].append("Mild class imbalance")
                diagnosis['suggestions'].append("Consider using class_weight='balanced' parameter")
            
            # Check if there are too many classes
            if len(unique) > 20:
                diagnosis['issues'].append("Too many classes")
                diagnosis['suggestions'].append("Consider merging similar classes or using hierarchical classification")
            elif len(unique) > len(X) / 10:
                diagnosis['issues'].append("Too many classes relative to sample size")
                diagnosis['suggestions'].append("Increase samples per class")
            
            # 2. Data preprocessing checks
            # Check data range
            if hasattr(X, 'std'):
                feature_stds = X.std(axis=0)
                if np.any(feature_stds == 0):
                    diagnosis['issues'].append("Constant features detected")
                    diagnosis['suggestions'].append("Remove zero-variance features")
                
                if np.any(feature_stds > 1000) or np.any(feature_stds < 0.001):
                    diagnosis['issues'].append("Large feature scale differences")
                    diagnosis['suggestions'].append("Use StandardScaler or MinMaxScaler for feature scaling")
            
            # Check missing values
            if hasattr(X, 'isnull'):
                if X.isnull().any().any():
                    diagnosis['issues'].append("Missing values detected")
                    diagnosis['suggestions'].append("Handle missing values: imputation, deletion, or interpolation")
            elif isinstance(X, np.ndarray):
                if np.isnan(X).any():
                    diagnosis['issues'].append("NaN values detected")
                    diagnosis['suggestions'].append("Handle NaN values: imputation, deletion, or interpolation")
            
            # 3. Model compatibility checks
            # Check if current model is suitable for data characteristics
            if self.method == 'lda' and len(unique) >= X.shape[1]:
                diagnosis['model_issues'].append("LDA not suitable when n_classes >= n_features")
                diagnosis['suggestions'].append("Use Random Forest or SVM instead")
            
            if self.method == 'knn' and X.shape[1] > 50:
                diagnosis['model_issues'].append("KNN performs poorly on high-dimensional data")
                diagnosis['suggestions'].append("Apply dimensionality reduction first or use Random Forest")
            
            if self.method == 'svm' and len(X) > 10000:
                diagnosis['model_issues'].append("SVM is slow on large datasets")
                diagnosis['suggestions'].append("Consider Random Forest or reduce sample size")
            
            # 4. Spectral data specific recommendations
            diagnosis['suggestions'].extend([
                "For spectral data, recommend the following preprocessing:",
                "- SNV (Standard Normal Variate) to remove scattering effects",
                "- Derivative preprocessing (1st or 2nd order) to enhance spectral features",
                "- Baseline correction to remove baseline drift",
                "Recommended model selection order: Random Forest > SVM > LDA > KNN"
            ])
            
            return diagnosis
            
        except Exception as e:
            diagnosis['issues'].append(f"Diagnosis process error: {str(e)}")
            return diagnosis 
