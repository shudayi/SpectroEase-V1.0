import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.cross_decomposition import PLSRegression
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score, cross_val_predict, KFold, GroupKFold
from typing import Dict, Any, List, Optional
from app.utils.data_compatibility import standardize_classification_labels, standardize_regression_values
from app.utils.label_processor import EnhancedLabelProcessor
import logging

# Setup logging
logger = logging.getLogger(__name__)

class QuantitativeAnalyzer:
    """Quantitative Analysis Class"""
    
    def __init__(self, method: str = 'plsr'):
        """
        Initialize quantitative analyzer
        
        Args:
            method: Analysis method ('mlr', 'plsr', 'svr', 'rf', 'nn', 'xgboost', 'lightgbm', 'gpr', 'dt')
        """
        # Standardize method names
        method_mapping = {
            'linear': 'mlr',
            'mlr': 'mlr',
            'linear regression': 'mlr',
            'linear_regression': 'mlr',
            'ridge': 'ridge',
            'ridge regression': 'ridge',
            'lasso': 'lasso',
            'lasso regression': 'lasso',
            'elasticnet': 'elasticnet',
            'elastic net': 'elasticnet',
            'elastic_net': 'elasticnet',
            'pls': 'plsr',
            'plsr': 'plsr',
            'svr': 'svr',
            'svm': 'svr',
            'rf': 'rf',
            'random_forest': 'rf',
            'dt': 'dt',
            'decision_tree': 'dt',
            'decision tree': 'dt',
            'gpr': 'gpr',
            'gaussian_process': 'gpr',
            'nn': 'nn',
            'neural network': 'nn',
            'neural_network': 'nn',
            'xgboost': 'xgboost',
            'lightgbm': 'lightgbm',
            'random forest': 'rf',
        }
        
        self.method = method_mapping.get(method.lower(), method)
        self.model = None
        self.scaler_x = StandardScaler()
        self.scaler_y = StandardScaler()
        self.imputer = None
        self.fitted_predictor = None
        self.input_representation = 'fitted_feature_matrix'
        self.model_params = {}
        self.task_type = 'regression'  # Explicitly mark task type as regression
        
        # **CRITICAL FIX: Initialize enhanced label processor for consistent handling**
        self.label_processor = EnhancedLabelProcessor()

        
    def fit(self, X: np.ndarray, y: np.ndarray, **kwargs) -> None:
        """
        Train the model
        
        Args:
            X: Input features
            y: Target labels
            **kwargs: Additional parameters for the model
        """
        global pd
        
        # Save the exact feature boundary and optional identity scope before
        # converting pandas objects to arrays.
        feature_names = list(X.columns) if isinstance(X, pd.DataFrame) else kwargs.pop('feature_names', None)
        fit_row_ids = kwargs.pop('row_ids', None)
        fit_physical_sample_ids = kwargs.pop('physical_sample_ids', None)
        fit_group_ids = kwargs.pop('group_ids', None)
        group_validation = kwargs.pop('group_validation', False)
        self.input_representation = kwargs.pop('input_representation', 'fitted_feature_matrix')
        kwargs.pop('task_type', None)
        kwargs.pop('feature_names', None)

        # Convert pandas to numpy if needed
        if isinstance(X, pd.DataFrame):
            X = X.values
            
        if isinstance(y, pd.Series) or isinstance(y, pd.DataFrame):
            y = y.values
            
        # Match the fold-local CV path: imputer and scaler are fitted on the
        # outer training rows only and reused unchanged for prediction.
        from sklearn.impute import SimpleImputer
        self.imputer = SimpleImputer(strategy='mean', keep_empty_features=True)
        X_imputed = self.imputer.fit_transform(np.asarray(X, dtype=float))
        X_scaled = self.scaler_x.fit_transform(X_imputed)
        
        # For regression methods, we also scale the target
        if self.task_type == 'regression':
            y_scaled = self.scaler_y.fit_transform(y.reshape(-1, 1)).ravel()
        else:
            y_scaled = y
            
        # Create model based on method, adjusting parameters based on data
        if self.method == 'plsr':
            # **CRITICAL FIX: Optimize PLSR n_components selection strategy**
            # For spectral data, fewer components usually work better
            default_components = 3  # Changed to more conservative default value
            n_components = kwargs.get('n_components', default_components)
            
            # Ensure n_components does not exceed the minimum of feature count and sample count
            # Also consider the complexity of target variables
            max_components = min(5, n_components, X.shape[0], X.shape[1])
            
            # **NEW: Dynamically adjust component count based on data characteristics**
            # For small datasets, use fewer components
            if max_components > 5:
                max_components = min(5, max_components)  # Further limit to5
            
            # **CRITICAL FIX: Correctly set kwargs and create model**
            kwargs['n_components'] = max_components
        
        self.model_params = dict(kwargs)
        self.model = self._create_model(**kwargs)
        
        # Fit model
        self.model.fit(X_scaled, y_scaled)
        from app.services.prediction_contract import FittedSpectrumPredictor
        self.fitted_predictor = FittedSpectrumPredictor(
            estimator=self.model,
            task_type=self.task_type,
            imputer=self.imputer,
            x_scaler=self.scaler_x,
            y_scaler=self.scaler_y,
            feature_names=feature_names,
            n_features=X.shape[1],
            fit_row_ids=fit_row_ids,
            fit_physical_sample_ids=fit_physical_sample_ids,
            fit_group_ids=fit_group_ids,
            group_validation=group_validation,
            input_representation=self.input_representation,
        )
        
    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict target variable
        
        Args:
            X: Input features
            
        Returns:
            np.ndarray: Predictions
        """
        if self.fitted_predictor is not None:
            return self.fitted_predictor.predict(X)
        global pd

        if self.model is None:
            raise ValueError("Model not trained")
            
        # Convert pandas to numpy if needed
        if isinstance(X, pd.DataFrame):
            X = X.values
            
        X_scaled = self.scaler_x.transform(self.imputer.transform(np.asarray(X, dtype=float)))
        
        # Get predictions
        predictions = self.model.predict(X_scaled)
        
        # Inverse transform if regression
        if self.task_type == 'regression':
            if len(predictions.shape) == 1:
                predictions = predictions.reshape(-1, 1)
            predictions = self.scaler_y.inverse_transform(predictions)
            if len(predictions.shape) > 1 and predictions.shape[1] == 1:
                predictions = predictions.ravel()
                
        return predictions

    def predict_result(self, X, row_ids=None, physical_sample_ids=None,
                       group_ids=None, enforce_disjoint=True):
        if self.fitted_predictor is None:
            raise ValueError("Model not trained")
        return self.fitted_predictor.predict_result(
            X, row_ids=row_ids, physical_sample_ids=physical_sample_ids,
            group_ids=group_ids, enforce_disjoint=enforce_disjoint,
        )

    def predict_raw(self, X, **identity):
        if self.fitted_predictor is None:
            raise ValueError("Model not trained")
        return self.fitted_predictor.predict_raw(X, **identity)
        
    def cross_validate(self, X: np.ndarray, y: np.ndarray, n_splits: int = 5,
                       sample_ids=None, outer_test_sample_ids=None,
                       unsafe_transform_reason: Optional[str] = None,
                       physical_sample_ids=None, outer_test_physical_sample_ids=None,
                       group_ids=None, outer_test_group_ids=None,
                       group_validation: bool = False) -> Dict[str, Any]:
        """
        Perform cross-validation and return evaluation metrics
        
        Args:
            X: Input features
            y: Target labels
            n_splits: Number of cross-validation splits
            
        Returns:
            Dict: Dictionary containing evaluation metrics
        """
        global pd

        # CV never consumes a representation that was learned before the
        # inner split.  The active GUI passes a reason for cached PCA/selection
        # paths that are not yet represented as fold-local transformers.
        self.last_cv_fit_trace = []
        if unsafe_transform_reason:
            raise ValueError(
                "Cross-validation is unavailable because this transform is not fold-safe: "
                f"{unsafe_transform_reason}"
            )

        if isinstance(X, pd.DataFrame):
            inferred_ids = list(X.index)
            inferred_feature_names = list(X.columns)
        else:
            inferred_ids = list(range(len(X)))
            inferred_feature_names = None
        fit_sample_ids = list(sample_ids) if sample_ids is not None else inferred_ids
        test_sample_ids = (
            list(outer_test_sample_ids) if outer_test_sample_ids is not None else []
        )
        if len(fit_sample_ids) != len(X):
            raise ValueError("sample_ids must match the number of CV rows")
        if len(set(fit_sample_ids)) != len(fit_sample_ids):
            raise ValueError("sample_ids must be unique within the outer training set")
        overlap = set(fit_sample_ids).intersection(test_sample_ids)
        if overlap:
            raise ValueError(
                "Outer-test sample identities overlap the CV training input: "
                f"{sorted(map(str, overlap))[:5]}"
            )

        groups = self._validate_cv_groups(
            len(X), group_ids, outer_test_group_ids, physical_sample_ids,
            outer_test_physical_sample_ids, n_splits, group_validation,
        )
        
        # Print input data info for debugging
        logger.info(f"X shape: {X.shape}, y shape: {y.shape if hasattr(y, 'shape') else len(y)}")
        logger.info(f"X type: {type(X)}, y type: {type(y)}")
        
        # Convert pandas to numpy if needed after retaining row identities.
        if isinstance(X, pd.DataFrame):
            X = X.values
            
        if isinstance(y, pd.Series) or isinstance(y, pd.DataFrame):
            y = y.values
            
        # Perform cross-validation with custom pipeline to handle scaling
        kf = GroupKFold(n_splits=n_splits) if group_validation else KFold(
            n_splits=n_splits, shuffle=True, random_state=42
        )
        
        # Initialize arrays for predictions and true values
        predictions = np.zeros_like(y, dtype=float)
        
        # For each fold
        folds = kf.split(X, y, groups=groups) if group_validation else kf.split(X)
        physical_ids = list(physical_sample_ids) if physical_sample_ids is not None else None
        for fold_index, (train_idx, test_idx) in enumerate(folds, start=1):
            X_train, X_test = X[train_idx], X[test_idx]
            y_train, y_test = y[train_idx], y[test_idx]

            # Missing-value imputation and scaling learn state from this fold's
            # training rows only; the validation rows are transform-only.
            from sklearn.impute import SimpleImputer
            imputer = SimpleImputer(strategy='mean', keep_empty_features=True)
            X_train_imputed = imputer.fit_transform(X_train)
            X_test_imputed = imputer.transform(X_test)

            scaler_x = StandardScaler()
            X_train_scaled = scaler_x.fit_transform(X_train_imputed)
            X_test_scaled = scaler_x.transform(X_test_imputed)
            
            # For regression, also scale target
            if self.task_type == 'regression':
                scaler_y = StandardScaler()
                y_train_scaled = scaler_y.fit_transform(y_train.reshape(-1, 1)).ravel()
            else:
                y_train_scaled = y_train
            
            # Create and fit model with adjusted parameters if needed
            kwargs_for_cv = dict(self.model_params)
            if self.method == 'plsr':
                # **CRITICAL FIX: Use more conservative component count in cross-validation**
                # Use fewer components to avoid overfitting
                optimal_components = min(kwargs_for_cv.get('n_components', 3), X_train_scaled.shape[1], X_train_scaled.shape[0])
                kwargs_for_cv['n_components'] = optimal_components
                
            model = self._create_model(**kwargs_for_cv)
            model.fit(X_train_scaled, y_train_scaled)

            train_ids = [fit_sample_ids[int(index)] for index in train_idx]
            validation_ids = [fit_sample_ids[int(index)] for index in test_idx]
            trace_item = {
                'fold': fold_index,
                'transformer_fit_sample_ids': list(train_ids),
                'transformer_names': (
                    ['SimpleImputer', 'X StandardScaler']
                    + (['y StandardScaler'] if self.task_type == 'regression' else [])
                ),
                'transformer_fit_sample_ids_by_name': {
                    'SimpleImputer': list(train_ids),
                    'X StandardScaler': list(train_ids),
                    **({'y StandardScaler': list(train_ids)}
                       if self.task_type == 'regression' else {}),
                },
                'estimator_fit_sample_ids': list(train_ids),
                'validation_sample_ids': list(validation_ids),
            }
            if group_validation:
                train_groups = [groups[int(index)] for index in train_idx]
                validation_groups = [groups[int(index)] for index in test_idx]
                if set(train_groups) & set(validation_groups):
                    raise ValueError("Group-aware CV placed one group in both fit and validation folds")
                trace_item.update({
                    'train_group_ids': sorted(set(map(str, train_groups))),
                    'validation_group_ids': sorted(set(map(str, validation_groups))),
                    'train_physical_sample_ids': sorted(set(map(str, [physical_ids[int(i)] for i in train_idx]))) if physical_ids else [],
                    'validation_physical_sample_ids': sorted(set(map(str, [physical_ids[int(i)] for i in test_idx]))) if physical_ids else [],
                })
            self.last_cv_fit_trace.append(trace_item)
            
            # Make predictions
            fold_preds = model.predict(X_test_scaled)
            
            # For regression, inverse transform predictions
            if self.task_type == 'regression':
                if len(fold_preds.shape) == 1:
                    fold_preds = fold_preds.reshape(-1, 1)
                fold_preds = scaler_y.inverse_transform(fold_preds)
                if len(fold_preds.shape) > 1 and fold_preds.shape[1] == 1:
                    fold_preds = fold_preds.ravel()
            
            # Store predictions
            predictions[test_idx] = fold_preds
        
        # Calculate metrics
        if self.task_type == 'regression':
            from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
            
            # Calculate metrics
            r2 = r2_score(y, predictions)
            mse = mean_squared_error(y, predictions)
            mae = mean_absolute_error(y, predictions)
            
            # Log results
            logger.info(f"Cross-validation results:")
            logger.info(f"  - R-squared: {r2:.4f}")
            logger.info(f"  - MSE: {mse:.4f}")
            logger.info(f"  - MAE: {mae:.4f}")
            
            # Return metrics
            return {
                'cv_available': True,
                'r2': float(r2),
                'mse': float(mse),
                'mae': float(mae),
                'predictions': predictions.tolist(),
                'target': y.tolist(),
                'cv_predictions': predictions.tolist(),
                'cv_target': y.tolist(),
                'cv_row_ids': list(fit_sample_ids),
                'cv_physical_sample_ids': list(physical_sample_ids) if physical_sample_ids is not None else None,
                'cv_group_ids': list(group_ids) if group_ids is not None else None,
                'group_validation': bool(group_validation),
                'cv_fit_trace': list(self.last_cv_fit_trace),
            }
        else:
            from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
            
            # Calculate metrics
            accuracy = accuracy_score(y, predictions)
            f1 = f1_score(y, predictions, average='weighted')
            precision = precision_score(y, predictions, average='weighted')
            recall = recall_score(y, predictions, average='weighted')
            
            # Log results
            logger.info(f"Cross-validation results:")
            logger.info(f"  - Accuracy: {accuracy:.4f}")
            logger.info(f"  - F1 score: {f1:.4f}")
            logger.info(f"  - Precision: {precision:.4f}")
            logger.info(f"  - Recall: {recall:.4f}")
            
            # Return metrics
            return {
                'cv_available': True,
                'accuracy': float(accuracy),
                'f1': float(f1),
                'precision': float(precision),
                'recall': float(recall),
                'predictions': predictions.tolist(),
                'target': y.tolist(),
                'cv_predictions': predictions.tolist(),
                'cv_target': y.tolist(),
                'cv_row_ids': list(fit_sample_ids),
                'cv_physical_sample_ids': list(physical_sample_ids) if physical_sample_ids is not None else None,
                'cv_group_ids': list(group_ids) if group_ids is not None else None,
            }

    @staticmethod
    def _validate_cv_groups(n_rows, group_ids, outer_test_group_ids,
                            physical_sample_ids, outer_test_physical_sample_ids,
                            n_splits, group_validation):
        if not group_validation:
            return None
        if group_ids is None:
            raise ValueError("Group validation was requested but no explicit group_id values reached CV")
        groups = [str(value).strip() if value is not None else '' for value in group_ids]
        if len(groups) != n_rows or any(not value or value.lower() in {'nan', 'none', '<na>'} for value in groups):
            raise ValueError("group_id values must be complete, nonblank, and aligned to training rows")
        if len(set(groups)) < n_splits:
            raise ValueError(f"Group CV needs at least {n_splits} unique groups; found {len(set(groups))}")
        test_groups = [str(value).strip() for value in (list(outer_test_group_ids) if outer_test_group_ids is not None else [])]
        if set(groups) & set(test_groups):
            raise ValueError("Outer-test group IDs overlap the inner-CV training groups")
        if physical_sample_ids is not None:
            samples = [str(value).strip() if value is not None else '' for value in physical_sample_ids]
            if len(samples) != n_rows or any(not value or value.lower() in {'nan', 'none', '<na>'} for value in samples):
                raise ValueError("sample_id values must be complete, nonblank, and aligned to training rows")
            mapping = {}
            for sample, group in zip(samples, groups):
                if sample in mapping and mapping[sample] != group:
                    raise ValueError("A sample_id maps to multiple group_id values")
                mapping[sample] = group
            outer_samples = [str(value).strip() for value in (list(outer_test_physical_sample_ids) if outer_test_physical_sample_ids is not None else [])]
            if set(samples) & set(outer_samples):
                raise ValueError("Outer-test physical sample IDs overlap the inner-CV training samples")
        return groups
    
    def _create_model(self, **kwargs) -> Any:
        """Create the selected estimator and apply explicit user parameters."""
        kwargs.pop('task_type', None)
        model = self._create_default_model(**kwargs)
        if kwargs:
            model.set_params(**kwargs)
        return model

    def _create_default_model(self, **kwargs) -> Any:
        """
        Create a model instance based on method
        
        Args:
            **kwargs: Additional parameters for the model
            
        Returns:
            Model instance
        """
        # **CRITICAL FIX: Remove task_type from kwargs as it's not a sklearn parameter**
        kwargs.pop('task_type', None)
        
        # Linear Regression
        if self.method == 'mlr':
            return LinearRegression()
        elif self.method == 'ridge':
            return Ridge(alpha=1.0)
        elif self.method == 'lasso':
            return Lasso(alpha=1.0, max_iter=10000, random_state=42)
        elif self.method == 'elasticnet':
            return ElasticNet(alpha=1.0, l1_ratio=0.5, max_iter=10000, random_state=42)
        
        # Partial Least Squares Regression
        elif self.method == 'plsr':
            # **CRITICAL FIX: Optimize PLSR n_components selection strategy**
            # For spectral data, fewer components usually work better
            default_components = 3  # Changed to more conservative default value
            n_components = kwargs.get('n_components', default_components)
            
            # Ensure n_components does not exceed the minimum of feature count and sample count
            # Also consider the complexity of target variables
            max_components = min(10, n_components)  # Limit maximum components to 10
            
            # **NEW: Dynamically adjust component count based on data characteristics**
            # For small datasets, use fewer components
            if max_components > 5:
                max_components = min(5, max_components)  # Further limit to5
                
            return PLSRegression(
                n_components=max_components, 
                scale=False,  # We have already manually standardized
                max_iter=1000, 
                tol=1e-6
            )
        
        # Support Vector Regression
        elif self.method == 'svr':
            svr_params = {
                'C': 10.0,           # Increase regularization parameters
                'epsilon': 0.01,     # Reduce epsilon, improve precision
                'kernel': 'rbf',
                'gamma': 'auto',     # Change to auto
                'cache_size': 500,   # Increase cache
                'tol': 1e-4          # Improve convergence precision
            }
            return SVR(**svr_params)
        
        # Random Forest Regression
        elif self.method == 'rf':
            rf_params = {
                'n_estimators': 200,      # Increase number of trees
                'max_depth': None,        # Allow deeper trees
                'min_samples_split': 5,   # Prevent overfitting
                'min_samples_leaf': 2,    # Prevent overfitting
                'max_features': 'sqrt',   # Feature subset selection
                'bootstrap': True,
                'oob_score': True,
                'n_jobs': -1,
                'random_state': 42
            }
            return RandomForestRegressor(**rf_params)
        
        # Decision Tree Regression
        elif self.method == 'dt':
            dt_params = {
                'max_depth': 15,          # Increase maximum depth
                'min_samples_split': 5,   # Prevent overfitting
                'min_samples_leaf': 2,    # Prevent overfitting
                'max_features': 'sqrt',   # Feature subset selection
                'random_state': 42
            }
            return DecisionTreeRegressor(**dt_params)
        
        # Gaussian Process Regression
        elif self.method == 'gpr':
            from sklearn.gaussian_process.kernels import RBF, WhiteKernel
            kernel = RBF(length_scale=1.0) + WhiteKernel(noise_level=1e-5)
            gpr_params = {
                'kernel': kernel,
                'alpha': 1e-6,           # Reduce noise parameters
                'optimizer': 'fmin_l_bfgs_b',
                'n_restarts_optimizer': 5,  # Increase restart count
                'normalize_y': True,        # Standardize target variables
                'copy_X_train': True,
                'random_state': 42
            }
            return GaussianProcessRegressor(**gpr_params)
        
        elif self.method == 'nn':
            from sklearn.neural_network import MLPRegressor
            return MLPRegressor(hidden_layer_sizes=(100, 50), max_iter=1000,
                                random_state=42, early_stopping=True)
        elif self.method == 'xgboost':
            try:
                from xgboost import XGBRegressor
            except ImportError as error:
                raise ImportError('XGBoost is not installed; the selected algorithm cannot run.') from error
            return XGBRegressor(n_estimators=200, max_depth=6, random_state=42,
                                n_jobs=-1, objective='reg:squarederror')
        elif self.method == 'lightgbm':
            try:
                from lightgbm import LGBMRegressor
            except ImportError as error:
                raise ImportError('LightGBM is not installed; the selected algorithm cannot run.') from error
            return LGBMRegressor(n_estimators=200, random_state=42, n_jobs=-1, verbosity=-1)
        else:
            raise ValueError(f'Unsupported regression method: {self.method}')
    
    def get_model_params(self) -> Dict[str, Any]:
        """
        Get model parameters
        
        Returns:
            Dict[str, Any]: Model parameters
        """
        if self.model is None:
            return {}
            
        # Need to handle different data types properly for parameters
        # Return only serializable parameters
        params = {}
        
        try:
            if self.method == 'plsr':
                # For PLSR, return components, weights, etc.
                params = {
                    'n_components': self.model.n_components,
                }
                
                if hasattr(self.model, 'coef_'):
                    coef_shape = self.model.coef_.shape
                    params['coef_shape'] = list(coef_shape)
                    
                if hasattr(self.model, 'x_scores_'):
                    x_scores_shape = self.model.x_scores_.shape
                    params['x_scores_shape'] = list(x_scores_shape)
                    
                if hasattr(self.model, 'x_weights_'):
                    x_weights_shape = self.model.x_weights_.shape
                    params['x_weights_shape'] = list(x_weights_shape)
                    
            elif self.method == 'rf':
                # For Random Forest, return feature importances
                params = {
                    'n_estimators': self.model.n_estimators,
                    'max_depth': self.model.max_depth,
                }
                
                if hasattr(self.model, 'feature_importances_'):
                    # Get top 5 feature importances
                    importances = self.model.feature_importances_
                    indices = np.argsort(importances)[-5:]
                    top_importances = [(int(i), float(importances[i])) for i in indices]
                    params['top_importances'] = top_importances
                    
            else:
                # For other models, try to get basic parameters
                try:
                    model_params = self.model.get_params()
                    # Filter for serializable params
                    for k, v in model_params.items():
                        if isinstance(v, (int, float, str, bool, type(None))):
                            params[k] = v
                        else:
                            params[k] = str(type(v))
                except:
                    pass
                    
        except Exception as e:
            logger.error(f"Error getting model parameters: {str(e)}")
            params['error'] = str(e)
            
        return params 
