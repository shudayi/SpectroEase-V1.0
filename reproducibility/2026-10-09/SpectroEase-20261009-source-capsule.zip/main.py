import sys
import os
if '--spectroease-onnx-worker' in sys.argv:
    sys.argv.remove('--spectroease-onnx-worker')
    from app.services.onnx_export_worker import main as onnx_worker_main
    onnx_worker_main()
    raise SystemExit(0)
import io
import PyQt5

# Resolve Qt's platform plugin directory before importing any view modules.
# Matplotlib's Qt backend may initialize Qt while those modules are imported;
# setting this inside ``main()`` is too late, especially when the project path
# contains non-ASCII characters on Windows.
os.environ.setdefault(
    'QT_QPA_PLATFORM_PLUGIN_PATH',
    os.path.join(os.path.dirname(PyQt5.__file__), 'Qt5', 'plugins'),
)

# Configure existing console streams in place so retained logging handlers remain valid.
from app.utils.logger import _ensure_utf8_stdout
_ensure_utf8_stdout()

from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui import QFont, QIcon
from PyQt5.QtCore import Qt
from app.views.main_window import MainWindow
from app.utils.translator import Translator
from plugin_loader import load_plugins
from app.services.llm_service import LLMService
from app.ui import theme_manager
from config.llm_config import LLMConfig

def main():

    # import io
    # sys.stdout = io.StringIO()
    # sys.stderr = io.StringIO()

    # Qt 5.15 owns DPI conversion: widget geometry and screen geometry use
    # device-independent logical pixels, and point-sized fonts are converted
    # by Qt.  Set these attributes before QApplication is created.
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps)

    app = QApplication(sys.argv)

    icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logo.png')
    app.setWindowIcon(QIcon(icon_path))

    # Set application font
    font = QFont("Segoe UI", 10)
    app.setFont(font)

    # Apply global theme (QSS) to the QApplication so ALL top-level dialogs
    # inherit the design system (previously only MainWindow was styled).
    theme_manager.apply_theme_to_app(app)

    from config.settings import Settings
    from app.utils.translator import translator
    translator.set_language(Settings().language)
    
    llm_service = LLMService(api_key=LLMConfig.API_KEY)

    plugin_base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'plugins')
    preprocessing_plugins, feature_selection_plugins, modeling_plugins, data_partitioning_plugins = load_plugins(
        plugin_base_dir)

    main_window = MainWindow(
        translator, 
        preprocessing_plugins, 
        feature_selection_plugins, 
        modeling_plugins,
        data_partitioning_plugins,
        llm_service
    )
    

    main_window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    # Required when bounded algorithm workers spawn from a frozen Windows app.
    import multiprocessing
    multiprocessing.freeze_support()
    main()
